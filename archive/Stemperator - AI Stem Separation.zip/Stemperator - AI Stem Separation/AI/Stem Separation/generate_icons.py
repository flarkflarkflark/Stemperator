"""Generate STEMperator toolbar icons with STEM-colored border"""
from PIL import Image, ImageDraw, ImageFont
import os
import math

# Output folder
output_dir = r'C:\Users\Administrator\AppData\Roaming\REAPER\Data\toolbar_icons'
os.makedirs(output_dir, exist_ok=True)

# Different frame sizes
SIZES = {
    '': 30,        # Default
    '_150': 45,    # 150% scale
    '_200': 60,    # 200% scale
}

# STEM colors for border (top=vocals, right=drums, bottom=bass, left=other)
STEM_BORDER = [
    (255, 100, 100),   # Top - Vocals (red)
    (100, 200, 255),   # Right - Drums (blue)
    (150, 100, 255),   # Bottom - Bass (purple)
    (100, 255, 150),   # Left - Other (green)
]

STEM_COLORS = {
    'vocals': (255, 100, 100),
    'drums': (100, 200, 255),
    'bass': (150, 100, 255),
    'other': (100, 255, 150),
    'guitar': (255, 180, 100),
    'piano': (200, 150, 255),
}

BG_NORMAL = (40, 40, 45)
BG_HOVER = (55, 55, 65)
BG_ACTIVE = (70, 70, 80)

def get_font(size):
    try:
        return ImageFont.truetype('arial.ttf', int(size * 0.5))
    except:
        return ImageFont.load_default()

def adj_color(color, brightness):
    return tuple(int(c * brightness) for c in color)

def draw_stem_border(draw, x_offset, frame_size, brightness):
    """Draw 4-color STEM border"""
    b = max(2, int(frame_size * 0.08))  # border width
    fs = frame_size

    # Top (vocals)
    draw.rectangle([x_offset, 0, x_offset + fs - 1, b - 1],
                   fill=adj_color(STEM_BORDER[0], brightness))
    # Right (drums)
    draw.rectangle([x_offset + fs - b, 0, x_offset + fs - 1, fs - 1],
                   fill=adj_color(STEM_BORDER[1], brightness))
    # Bottom (bass)
    draw.rectangle([x_offset, fs - b, x_offset + fs - 1, fs - 1],
                   fill=adj_color(STEM_BORDER[2], brightness))
    # Left (other)
    draw.rectangle([x_offset, 0, x_offset + b - 1, fs - 1],
                   fill=adj_color(STEM_BORDER[3], brightness))

def create_icon(name, draw_func, frame_size, suffix=''):
    """Create 3-frame icon"""
    img = Image.new('RGBA', (frame_size * 3, frame_size), (0, 0, 0, 0))
    draw = ImageDraw.Draw(img)

    states = [(0, BG_NORMAL, 0.7), (frame_size, BG_HOVER, 0.85), (frame_size * 2, BG_ACTIVE, 1.0)]

    for x_off, bg, bright in states:
        draw.rectangle([x_off, 0, x_off + frame_size - 1, frame_size - 1], fill=bg)
        draw_stem_border(draw, x_off, frame_size, bright)
        draw_func(draw, x_off, frame_size, bright)

    filename = f'{name}{suffix}.png'
    img.save(os.path.join(output_dir, filename))
    return filename

def draw_letter(draw, x_off, fs, letter, color, bright):
    font = get_font(fs)
    bbox = draw.textbbox((0, 0), letter, font=font)
    tw, th = bbox[2] - bbox[0], bbox[3] - bbox[1]
    x = x_off + (fs - tw) // 2
    y = (fs - th) // 2 - int(fs * 0.02)
    draw.text((x, y), letter, fill=adj_color(color, bright), font=font)

# Icon drawing functions
def draw_vocals(d, x, fs, b): draw_letter(d, x, fs, 'V', STEM_COLORS['vocals'], b)
def draw_drums(d, x, fs, b): draw_letter(d, x, fs, 'D', STEM_COLORS['drums'], b)
def draw_bass(d, x, fs, b): draw_letter(d, x, fs, 'B', STEM_COLORS['bass'], b)
def draw_other(d, x, fs, b): draw_letter(d, x, fs, 'O', STEM_COLORS['other'], b)
def draw_guitar(d, x, fs, b): draw_letter(d, x, fs, 'G', STEM_COLORS['guitar'], b)
def draw_piano(d, x, fs, b): draw_letter(d, x, fs, 'P', STEM_COLORS['piano'], b)

def draw_allstems(draw, x_off, fs, bright):
    colors = [STEM_COLORS['vocals'], STEM_COLORS['drums'], STEM_COLORS['bass'], STEM_COLORS['other']]
    border = max(2, int(fs * 0.08))
    inner = fs - border * 2
    size = int(inner * 0.38)
    gap = int(inner * 0.12)
    sx = x_off + border + (inner - size*2 - gap) // 2
    sy = border + (inner - size*2 - gap) // 2
    for i, c in enumerate(colors):
        x = sx + (i % 2) * (size + gap)
        y = sy + (i // 2) * (size + gap)
        draw.rectangle([x, y, x + size - 1, y + size - 1], fill=adj_color(c, bright))

def draw_6stem(draw, x_off, fs, bright):
    colors = list(STEM_COLORS.values())
    border = max(2, int(fs * 0.08))
    bar_w = max(2, int(fs * 0.07))
    gap = max(1, int(fs * 0.02))
    total_w = len(colors) * bar_w + (len(colors) - 1) * gap
    sx = x_off + (fs - total_w) // 2
    margin = border + int(fs * 0.12)
    for i, c in enumerate(colors):
        x = sx + i * (bar_w + gap)
        draw.rectangle([x, margin, x + bar_w - 1, fs - margin], fill=adj_color(c, bright))

def draw_karaoke(draw, x_off, fs, bright):
    c = adj_color((255, 200, 100), bright)
    cx = x_off + fs // 2
    border = max(2, int(fs * 0.08))
    hr = int(fs * 0.12)
    hy = border + int((fs - border*2) * 0.28)
    bw, bh = int(fs * 0.07), int(fs * 0.14)
    sh, basew = int(fs * 0.1), int(fs * 0.1)

    draw.ellipse([cx - hr, hy - hr, cx + hr, hy + hr], fill=c)
    draw.rectangle([cx - bw//2, hy + hr, cx + bw//2, hy + hr + bh], fill=c)
    st = hy + hr + bh
    draw.line([cx, st, cx, st + sh], fill=c, width=max(1, int(fs * 0.05)))
    draw.line([cx - basew, st + sh, cx + basew, st + sh], fill=c, width=max(1, int(fs * 0.04)))

def draw_settings(draw, x_off, fs, bright):
    c = adj_color((180, 180, 190), bright)
    cx, cy = x_off + fs // 2, fs // 2
    border = max(2, int(fs * 0.08))
    outer_r = int((fs - border*2) * 0.38)
    inner_r = int((fs - border*2) * 0.26)
    hole_r = int((fs - border*2) * 0.1)

    points = []
    for i in range(16):
        angle = i * math.pi / 8
        r = outer_r if i % 2 == 0 else inner_r
        points.append((cx + int(math.cos(angle) * r), cy + int(math.sin(angle) * r)))

    draw.polygon(points, fill=c)
    bg = BG_NORMAL if bright < 0.8 else BG_HOVER if bright < 0.95 else BG_ACTIVE
    draw.ellipse([cx - hole_r, cy - hole_r, cx + hole_r, cy + hole_r], fill=bg)

def draw_explode(draw, x_off, fs, bright):
    c = adj_color((255, 150, 50), bright)
    cx, cy = x_off + fs // 2, fs // 2
    border = max(2, int(fs * 0.08))
    inner_r = int((fs - border*2) * 0.14)
    outer_r = int((fs - border*2) * 0.4)
    center_r = int((fs - border*2) * 0.11)
    lw = max(1, int(fs * 0.055))

    for i in range(8):
        angle = i * math.pi / 4
        x1, y1 = cx + int(math.cos(angle) * inner_r), cy + int(math.sin(angle) * inner_r)
        x2, y2 = cx + int(math.cos(angle) * outer_r), cy + int(math.sin(angle) * outer_r)
        draw.line([x1, y1, x2, y2], fill=c, width=lw)
    draw.ellipse([cx - center_r, cy - center_r, cx + center_r, cy + center_r], fill=c)

# All icons
ICONS = [
    ('toolbar_vocals', draw_vocals),
    ('toolbar_drums', draw_drums),
    ('toolbar_bass', draw_bass),
    ('toolbar_other', draw_other),
    ('toolbar_guitar', draw_guitar),
    ('toolbar_piano', draw_piano),
    ('toolbar_allstems', draw_allstems),
    ('toolbar_6stem', draw_6stem),
    ('toolbar_karaoke', draw_karaoke),
    ('toolbar_settings', draw_settings),
    ('toolbar_explode', draw_explode),
]

# Generate all
if __name__ == '__main__':
    count = 0
    for suffix, frame_size in SIZES.items():
        print(f'Generating {frame_size}px icons...')
        for name, func in ICONS:
            create_icon(name, func, frame_size, suffix)
            count += 1
    print(f'\n=== {count} icons created with STEM border! ===')
