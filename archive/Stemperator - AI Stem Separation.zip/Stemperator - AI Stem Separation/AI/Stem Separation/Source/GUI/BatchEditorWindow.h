#pragma once

#include <JuceHeader.h>
#include "PremiumLookAndFeel.h"

/**
 * BatchEditorWindow - Batch stem processing window
 *
 * A DocumentWindow that hosts the batch processing UI.
 * Follows the same pattern as StyledDialogWindow for stability.
 */
class BatchEditorWindow : public juce::DocumentWindow
{
public:
    // Callback when user clicks "Process All"
    std::function<void (const juce::Array<juce::File>& files, const juce::String& modelName,
                        const juce::File& outputFolder)> onStartBatch;

    // Callback to get recent output folders (returns StringArray of paths)
    std::function<juce::StringArray()> onGetRecentOutputFolders;

    // Callback when a folder is used (to add to recent list)
    std::function<void (const juce::File& folder)> onOutputFolderUsed;

    BatchEditorWindow (const juce::String& modelName)
        : juce::DocumentWindow ("Batch Stem Processing",
                                PremiumLookAndFeel::Colours::bgDark,
                                juce::DocumentWindow::minimiseButton)
    {
        setUsingNativeTitleBar (true);
        setResizable (true, false);

        // Create the content component
        content = std::make_unique<ContentComponent> (modelName, this);
        setContentNonOwned (content.get(), true);

        // Set initial size - larger for better readability
        centreWithSize (800, 800);
    }

    ~BatchEditorWindow() override = default;

    void closeButtonPressed() override
    {
        // Just hide, don't delete - the owner (PluginEditor) manages lifetime
        setVisible (false);
    }

    // Progress update from external processing
    void setProgress (int fileIndex, int totalFiles, const juce::String& statusText)
    {
        if (content != nullptr)
            content->setProgress (fileIndex, totalFiles, statusText);
    }

    void processingComplete (int successCount, int failCount)
    {
        if (content != nullptr)
            content->processingComplete (successCount, failCount);
    }

    const juce::Array<juce::File>& getFiles() const
    {
        static juce::Array<juce::File> empty;
        return content != nullptr ? content->getFiles() : empty;
    }

    juce::String getModelName() const
    {
        return content != nullptr ? content->getModelName() : "htdemucs";
    }

    int getQuality() const
    {
        return content != nullptr ? content->getQuality() : 1;  // Default to Balanced
    }

    juce::File getOutputFolder() const
    {
        return content != nullptr ? content->getOutputFolder() : juce::File();
    }

    bool isCancelRequested() const
    {
        return content != nullptr ? content->isCancelRequested() : false;
    }

    // Add files programmatically (called when files dropped on main window)
    void addFilesToBatch (const juce::Array<juce::File>& filesToAdd)
    {
        if (content != nullptr)
            content->addFilesToBatch (filesToAdd);
    }

    // Clear all files from the batch list
    void clearFiles()
    {
        if (content != nullptr)
            content->clearAllFiles();
    }

    // Refresh the output folder ComboBox with recent folders
    void refreshRecentOutputFolders()
    {
        if (content != nullptr && onGetRecentOutputFolders)
            content->setRecentOutputFolders (onGetRecentOutputFolders());
    }

private:
    /**
     * ContentComponent - The actual batch UI content
     */
    class ContentComponent : public juce::Component,
                             public juce::FileDragAndDropTarget,
                             public juce::ListBoxModel
    {
    public:
        ContentComponent (const juce::String& modelName, BatchEditorWindow* owner)
            : currentModel (modelName), parentWindow (owner)
        {
            setSize (800, 760);

            // File list
            fileList.setModel (this);
            fileList.setColour (juce::ListBox::backgroundColourId, PremiumLookAndFeel::Colours::bgPanel);
            fileList.setColour (juce::ListBox::outlineColourId, PremiumLookAndFeel::Colours::accent.withAlpha (0.3f));
            fileList.setOutlineThickness (1);
            fileList.setRowHeight (56);  // Extra large rows for readability
            fileList.setMultipleSelectionEnabled (true);
            addAndMakeVisible (fileList);

            // Input section label
            inputLabel.setText ("Input Files:", juce::dontSendNotification);
            inputLabel.setColour (juce::Label::textColourId, PremiumLookAndFeel::Colours::textBright);
            inputLabel.setFont (juce::FontOptions (32.0f).withStyle ("Bold"));
            addAndMakeVisible (inputLabel);

            // Button row
            addButton.setButtonText ("Add Files...");
            addButton.setTooltip ("Select audio files to add to the batch");
            addButton.onClick = [this] { addFiles(); };
            addAndMakeVisible (addButton);

            addFolderButton.setButtonText ("Add Folder...");
            addFolderButton.setTooltip ("Add all audio files from a folder");
            addFolderButton.onClick = [this] { addFolder(); };
            addAndMakeVisible (addFolderButton);

            clearButton.setButtonText ("Clear");
            clearButton.setTooltip ("Remove all files from the list");
            clearButton.onClick = [this] { files.clear(); updateUI(); };
            addAndMakeVisible (clearButton);

            removeButton.setButtonText ("Remove");
            removeButton.setTooltip ("Remove selected files from the list");
            removeButton.onClick = [this] { removeSelected(); };
            addAndMakeVisible (removeButton);

            // Output section
            outputLabel.setText ("Output:", juce::dontSendNotification);
            outputLabel.setColour (juce::Label::textColourId, PremiumLookAndFeel::Colours::textBright);
            outputLabel.setFont (juce::FontOptions (30.0f).withStyle ("Bold"));
            addAndMakeVisible (outputLabel);

            // Build output mode combo - items 1 = next to source, 2 = browse, 100+ = recent folders
            rebuildOutputCombo();
            outputModeCombo.setTooltip ("Choose where to save the separated stems");
            outputModeCombo.onChange = [this] { onOutputModeChanged(); };
            addAndMakeVisible (outputModeCombo);

            outputFolderLabel.setColour (juce::Label::textColourId, PremiumLookAndFeel::Colours::textDim);
            outputFolderLabel.setFont (juce::FontOptions (26.0f));
            addAndMakeVisible (outputFolderLabel);

            // Model selection
            modelLabel.setText ("Model:", juce::dontSendNotification);
            modelLabel.setColour (juce::Label::textColourId, PremiumLookAndFeel::Colours::textBright);
            modelLabel.setFont (juce::FontOptions (30.0f).withStyle ("Bold"));
            addAndMakeVisible (modelLabel);

            modelCombo.addItem ("htdemucs (4 stems)", 1);
            modelCombo.addItem ("htdemucs_6s (6 stems)", 2);
            modelCombo.setSelectedId (modelName == "htdemucs_6s" ? 2 : 1);
            modelCombo.setTooltip ("4 stems: vocals, drums, bass, other\n6 stems: adds guitar and piano");
            modelCombo.onChange = [this] { currentModel = (modelCombo.getSelectedId() == 2) ? "htdemucs_6s" : "htdemucs"; };
            addAndMakeVisible (modelCombo);

            // Quality selection
            qualityLabel.setText ("Quality:", juce::dontSendNotification);
            qualityLabel.setColour (juce::Label::textColourId, PremiumLookAndFeel::Colours::textBright);
            qualityLabel.setFont (juce::FontOptions (30.0f).withStyle ("Bold"));
            addAndMakeVisible (qualityLabel);

            qualityCombo.addItem ("Fast (lower quality)", 1);
            qualityCombo.addItem ("Balanced", 2);
            qualityCombo.addItem ("Best (slower)", 3);
            qualityCombo.setSelectedId (2);  // Default to Balanced
            qualityCombo.setTooltip ("Higher quality = better separation but slower processing");
            addAndMakeVisible (qualityCombo);

            // Status / Progress
            statusLabel.setText ("Drop audio files here or click 'Add Files'", juce::dontSendNotification);
            statusLabel.setColour (juce::Label::textColourId, PremiumLookAndFeel::Colours::textBright);
            statusLabel.setFont (juce::FontOptions (28.0f));
            statusLabel.setJustificationType (juce::Justification::centred);
            addAndMakeVisible (statusLabel);

            progressBar.setColour (juce::ProgressBar::backgroundColourId, PremiumLookAndFeel::Colours::bgPanel);
            progressBar.setColour (juce::ProgressBar::foregroundColourId, PremiumLookAndFeel::Colours::active);
            progressBar.setVisible (false);
            addAndMakeVisible (progressBar);

            // Process button
            processButton.setButtonText ("Process All");
            processButton.setColour (juce::TextButton::buttonColourId, PremiumLookAndFeel::Colours::active.darker (0.2f));
            processButton.setTooltip ("Start separating all files into stems");
            processButton.onClick = [this] { startProcessing(); };
            processButton.setEnabled (false);
            addAndMakeVisible (processButton);

            // Cancel button (hidden initially)
            cancelButton.setButtonText ("Cancel");
            cancelButton.setColour (juce::TextButton::buttonColourId, juce::Colours::darkred);
            cancelButton.setTooltip ("Stop batch processing and close window");
            cancelButton.onClick = [this] { requestCancel(); };
            cancelButton.setVisible (false);
            addAndMakeVisible (cancelButton);
        }

        ~ContentComponent() override
        {
            fileList.setModel (nullptr);
        }

        void paint (juce::Graphics& g) override
        {
            g.fillAll (PremiumLookAndFeel::Colours::bgMid);
        }

        void resized() override
        {
            auto b = getLocalBounds().reduced (20);

            // Bottom: Buttons row
            auto bottomRow = b.removeFromBottom (50);
            cancelButton.setBounds (bottomRow.removeFromRight (140));
            bottomRow.removeFromRight (12);
            processButton.setBounds (bottomRow.removeFromRight (180));

            b.removeFromBottom (15);

            // Progress bar
            progressBar.setBounds (b.removeFromBottom (28));
            b.removeFromBottom (10);

            // Status line
            statusLabel.setBounds (b.removeFromBottom (38));
            b.removeFromBottom (15);

            // Quality selection row
            auto qualityRow = b.removeFromBottom (44);
            qualityLabel.setBounds (qualityRow.removeFromLeft (110));
            qualityCombo.setBounds (qualityRow.removeFromLeft (280));
            b.removeFromBottom (10);

            // Model selection row
            auto modelRow = b.removeFromBottom (44);
            modelLabel.setBounds (modelRow.removeFromLeft (110));
            modelCombo.setBounds (modelRow.removeFromLeft (320));
            b.removeFromBottom (12);

            // Output section
            auto outputRow = b.removeFromBottom (44);
            outputLabel.setBounds (outputRow.removeFromLeft (110));
            outputModeCombo.setBounds (outputRow.removeFromLeft (280));
            outputRow.removeFromLeft (12);
            outputFolderLabel.setBounds (outputRow);
            b.removeFromBottom (15);

            // Input label
            inputLabel.setBounds (b.removeFromTop (40));
            b.removeFromTop (8);

            // Button row (below file list label)
            auto buttonRow = b.removeFromBottom (44);
            addButton.setBounds (buttonRow.removeFromLeft (140));
            buttonRow.removeFromLeft (10);
            addFolderButton.setBounds (buttonRow.removeFromLeft (160));
            buttonRow.removeFromLeft (10);
            removeButton.setBounds (buttonRow.removeFromLeft (120));
            buttonRow.removeFromLeft (10);
            clearButton.setBounds (buttonRow.removeFromLeft (100));
            b.removeFromBottom (10);

            // File list takes the rest
            fileList.setBounds (b);
        }

        // FileDragAndDropTarget
        bool isInterestedInFileDrag (const juce::StringArray& draggedFiles) override
        {
            if (isProcessing) return false;
            for (const auto& f : draggedFiles)
            {
                juce::File file (f);
                if (file.isDirectory() || isAudioFile (file))
                    return true;
            }
            return false;
        }

        void filesDropped (const juce::StringArray& droppedFiles, int, int) override
        {
            if (isProcessing) return;
            for (const auto& f : droppedFiles)
            {
                juce::File file (f);
                if (file.isDirectory())
                    addAudioFilesFromFolder (file);
                else if (isAudioFile (file))
                    addFile (file);
            }
            updateUI();
        }

        // ListBoxModel
        int getNumRows() override { return files.size(); }

        void paintListBoxItem (int row, juce::Graphics& g, int width, int height, bool selected) override
        {
            if (row >= files.size()) return;

            if (selected)
                g.fillAll (PremiumLookAndFeel::Colours::accent.withAlpha (0.3f));
            else if (row % 2)
                g.fillAll (PremiumLookAndFeel::Colours::bgDark.withAlpha (0.15f));

            juce::Colour textColour = PremiumLookAndFeel::Colours::textBright;
            juce::String prefix = "";

            if (row < currentFileIndex)
            {
                // Completed file - green checkmark
                textColour = PremiumLookAndFeel::Colours::active;
                prefix = "\u2713 ";  // ✓
            }
            else if (row == currentFileIndex && isProcessing)
            {
                // Currently processing - blue arrow
                textColour = PremiumLookAndFeel::Colours::accent;
                prefix = "\u25B6 ";  // ▶
            }

            g.setColour (textColour);
            g.setFont (juce::FontOptions (30.0f));  // Extra large font
            g.drawText (prefix + files[row].getFileName(), 10, 0, width - 20, height, juce::Justification::centredLeft);
        }

        void deleteKeyPressed (int) override
        {
            if (!isProcessing) removeSelected();
        }

        void listBoxItemDoubleClicked (int row, const juce::MouseEvent&) override
        {
            if (isProcessing) return;
            if (row >= 0 && row < files.size())
            {
                files.remove (row);
                updateUI();
            }
        }

        // Progress update from external processing
        void setProgress (int fileIndex, int totalFiles, const juce::String& statusText)
        {
            // Use SafePointer to prevent crash if component is destroyed during async call
            juce::Component::SafePointer<ContentComponent> safeThis (this);
            juce::MessageManager::callAsync ([safeThis, fileIndex, totalFiles, statusText]()
            {
                if (safeThis == nullptr) return;
                safeThis->currentFileIndex = fileIndex;
                safeThis->progress = (totalFiles > 0) ? (double) fileIndex / totalFiles : 0.0;
                safeThis->statusLabel.setText (statusText, juce::dontSendNotification);
                safeThis->fileList.repaint();
            });
        }

        void processingComplete (int successCount, int failCount)
        {
            // Use SafePointer to prevent crash if component is destroyed during async call
            juce::Component::SafePointer<ContentComponent> safeThis (this);
            juce::MessageManager::callAsync ([safeThis, successCount, failCount]()
            {
                if (safeThis == nullptr) return;
                safeThis->isProcessing = false;
                safeThis->progress = 0.0;
                safeThis->currentFileIndex = -1;
                safeThis->progressBar.setVisible (false);
                safeThis->processButton.setEnabled (true);
                safeThis->processButton.setButtonText ("Process All");
                safeThis->cancelButton.setVisible (false);
                safeThis->addButton.setEnabled (true);
                safeThis->addFolderButton.setEnabled (true);
                safeThis->removeButton.setEnabled (true);
                safeThis->clearButton.setEnabled (true);
                safeThis->outputModeCombo.setEnabled (true);
                safeThis->modelCombo.setEnabled (true);
                safeThis->qualityCombo.setEnabled (true);

                juce::String msg;
                if (failCount == 0)
                    msg = "Completed: " + juce::String (successCount) + " file" + (successCount > 1 ? "s" : "") + " processed";
                else
                    msg = "Done: " + juce::String (successCount) + " OK, " + juce::String (failCount) + " failed";
                safeThis->statusLabel.setText (msg, juce::dontSendNotification);

                safeThis->fileList.repaint();
            });
        }

        const juce::Array<juce::File>& getFiles() const { return files; }
        juce::String getModelName() const { return currentModel; }
        int getQuality() const { return qualityCombo.getSelectedId() - 1; }  // 0=Fast, 1=Balanced, 2=Best

        // Add files programmatically (called when files dropped on main window)
        void addFilesToBatch (const juce::Array<juce::File>& filesToAdd)
        {
            for (const auto& f : filesToAdd)
            {
                if (f.isDirectory())
                    addAudioFilesFromFolder (f);
                else if (isAudioFile (f))
                    addFile (f);
            }
            updateUI();
        }

        // Clear all files from the batch list
        void clearAllFiles()
        {
            files.clear();
            updateUI();
        }

        juce::File getOutputFolder() const
        {
            int selectedId = outputModeCombo.getSelectedId();

            // ID 2 = custom browsed folder
            if (selectedId == 2 && customOutputFolder.exists())
                return customOutputFolder;

            // ID >= 100 = recent folder
            if (selectedId >= 100)
            {
                int folderIndex = selectedId - 100;
                if (folderIndex >= 0 && folderIndex < recentOutputFolders.size())
                {
                    juce::File folder (recentOutputFolders[folderIndex]);
                    if (folder.isDirectory())
                        return folder;
                }
            }

            // ID 1 = next to source files (return empty)
            return juce::File();
        }

        bool isCancelRequested() const { return cancelRequested; }

        // Set recent output folders (called from parent)
        void setRecentOutputFolders (const juce::StringArray& folders)
        {
            recentOutputFolders = folders;
            rebuildOutputCombo();
        }

    private:
        juce::Array<juce::File> files;
        juce::String currentModel;
        juce::File customOutputFolder;
        juce::StringArray recentOutputFolders;  // Recent batch output folders
        double progress = 0.0;
        bool isProcessing = false;
        bool cancelRequested = false;
        int currentFileIndex = -1;
        BatchEditorWindow* parentWindow = nullptr;

        // UI components
        juce::ListBox fileList { "Files" };
        juce::Label inputLabel;
        juce::Label outputLabel;
        juce::Label modelLabel;
        juce::Label qualityLabel;
        juce::Label statusLabel;
        juce::Label outputFolderLabel;
        juce::TextButton addButton;
        juce::TextButton addFolderButton;
        juce::TextButton clearButton;
        juce::TextButton removeButton;
        juce::TextButton processButton;
        juce::TextButton cancelButton;
        juce::ComboBox outputModeCombo;
        juce::ComboBox modelCombo;
        juce::ComboBox qualityCombo;
        juce::ProgressBar progressBar { progress };

        std::unique_ptr<juce::FileChooser> fileChooser;

        bool isAudioFile (const juce::File& file)
        {
            auto ext = file.getFileExtension().toLowerCase();
            return ext == ".wav" || ext == ".mp3" || ext == ".flac" ||
                   ext == ".aiff" || ext == ".aif" || ext == ".ogg" ||
                   ext == ".m4a" || ext == ".wma" || ext == ".opus";
        }

        void addFile (const juce::File& file)
        {
            if (! files.contains (file))
                files.add (file);
        }

        void addAudioFilesFromFolder (const juce::File& folder)
        {
            for (const auto& entry : juce::RangedDirectoryIterator (folder, true, "*.wav;*.mp3;*.flac;*.aiff;*.aif;*.ogg;*.m4a;*.wma;*.opus"))
                if (entry.getFile().existsAsFile())
                    addFile (entry.getFile());
        }

        void updateUI()
        {
            fileList.updateContent();
            if (files.isEmpty())
            {
                statusLabel.setText ("Drop audio files here or click 'Add Files'", juce::dontSendNotification);
                processButton.setEnabled (false);
            }
            else
            {
                juce::int64 totalSize = 0;
                for (const auto& f : files)
                    totalSize += f.getSize();

                juce::String info = juce::String (files.size()) + " file" + (files.size() > 1 ? "s" : "");
                if (totalSize > 1024 * 1024)
                    info += " (" + juce::String::formatted ("%.1f MB", totalSize / (1024.0 * 1024.0)) + ")";

                statusLabel.setText (info + " ready to process", juce::dontSendNotification);
                processButton.setEnabled (true);
            }
        }

        void rebuildOutputCombo()
        {
            // Remember current selection if possible
            int previousId = outputModeCombo.getSelectedId();

            outputModeCombo.clear();
            outputModeCombo.addItem ("Next to source files", 1);
            outputModeCombo.addItem ("Browse...", 2);

            // Add recent folders (IDs 100+) - most recent first
            if (recentOutputFolders.size() > 0)
            {
                outputModeCombo.addSeparator();
                for (int i = 0; i < recentOutputFolders.size(); ++i)
                {
                    juce::File folder (recentOutputFolders[i]);
                    // Show folder name with parent for context
                    juce::String displayName = folder.getFileName();
                    if (folder.getParentDirectory().exists())
                        displayName = folder.getParentDirectory().getFileName() + "/" + displayName;
                    outputModeCombo.addItem (displayName, 100 + i);
                }
            }

            // Select last used folder (first in list = ID 100) if available
            if (recentOutputFolders.size() > 0 && (previousId == 0 || previousId == 1))
            {
                outputModeCombo.setSelectedId (100, juce::dontSendNotification);
                // Update the label to show full path
                juce::File folder (recentOutputFolders[0]);
                outputFolderLabel.setText (folder.getFullPathName(), juce::dontSendNotification);
            }
            else if (previousId >= 100 && previousId < 100 + recentOutputFolders.size())
            {
                // Restore previous recent folder selection
                outputModeCombo.setSelectedId (previousId, juce::dontSendNotification);
                int folderIndex = previousId - 100;
                juce::File folder (recentOutputFolders[folderIndex]);
                outputFolderLabel.setText (folder.getFullPathName(), juce::dontSendNotification);
            }
            else
            {
                outputModeCombo.setSelectedId (1, juce::dontSendNotification);
                outputFolderLabel.setText ("", juce::dontSendNotification);
            }
        }

        void onOutputModeChanged()
        {
            int selectedId = outputModeCombo.getSelectedId();

            if (selectedId == 2)
            {
                // Browse... option
                fileChooser = std::make_unique<juce::FileChooser> (
                    "Select Output Folder",
                    juce::File::getSpecialLocation (juce::File::userMusicDirectory),
                    "", true);

                fileChooser->launchAsync (
                    juce::FileBrowserComponent::openMode | juce::FileBrowserComponent::canSelectDirectories,
                    [this] (const juce::FileChooser& fc)
                    {
                        auto result = fc.getResult();
                        if (result.exists() && result.isDirectory())
                        {
                            customOutputFolder = result;
                            outputFolderLabel.setText (result.getFullPathName(), juce::dontSendNotification);

                            // Notify parent to add to recent list
                            if (parentWindow != nullptr && parentWindow->onOutputFolderUsed)
                                parentWindow->onOutputFolderUsed (result);
                        }
                        else
                        {
                            // User cancelled - select first recent folder or "Next to source"
                            if (recentOutputFolders.size() > 0)
                                outputModeCombo.setSelectedId (100);
                            else
                                outputModeCombo.setSelectedId (1);
                            customOutputFolder = juce::File();
                            outputFolderLabel.setText ("", juce::dontSendNotification);
                        }
                    });
            }
            else if (selectedId >= 100)
            {
                // Recent folder selected
                int folderIndex = selectedId - 100;
                if (folderIndex >= 0 && folderIndex < recentOutputFolders.size())
                {
                    juce::File folder (recentOutputFolders[folderIndex]);
                    if (folder.isDirectory())
                        outputFolderLabel.setText (folder.getFullPathName(), juce::dontSendNotification);
                    else
                        outputFolderLabel.setText ("(folder not found)", juce::dontSendNotification);
                }
                customOutputFolder = juce::File();
            }
            else
            {
                // "Next to source files" (ID 1)
                customOutputFolder = juce::File();
                outputFolderLabel.setText ("", juce::dontSendNotification);
            }
        }

        void addFiles()
        {
            fileChooser = std::make_unique<juce::FileChooser> (
                "Select Audio Files",
                juce::File::getSpecialLocation (juce::File::userMusicDirectory),
                "*.wav;*.mp3;*.flac;*.aiff;*.aif;*.ogg;*.m4a;*.wma;*.opus", true);

            fileChooser->launchAsync (
                juce::FileBrowserComponent::openMode |
                juce::FileBrowserComponent::canSelectFiles |
                juce::FileBrowserComponent::canSelectMultipleItems,
                [this] (const juce::FileChooser& fc)
                {
                    for (const auto& f : fc.getResults())
                        addFile (f);
                    updateUI();
                });
        }

        void addFolder()
        {
            fileChooser = std::make_unique<juce::FileChooser> (
                "Select Folder with Audio Files",
                juce::File::getSpecialLocation (juce::File::userMusicDirectory),
                "", true);

            fileChooser->launchAsync (
                juce::FileBrowserComponent::openMode | juce::FileBrowserComponent::canSelectDirectories,
                [this] (const juce::FileChooser& fc)
                {
                    auto result = fc.getResult();
                    if (result.exists() && result.isDirectory())
                    {
                        addAudioFilesFromFolder (result);
                        updateUI();
                    }
                });
        }

        void removeSelected()
        {
            auto selected = fileList.getSelectedRows();
            for (int i = selected.size() - 1; i >= 0; --i)
                if (selected[i] < files.size())
                    files.remove (selected[i]);
            updateUI();
        }

        void startProcessing()
        {
            if (files.isEmpty() || parentWindow == nullptr || parentWindow->onStartBatch == nullptr)
                return;

            isProcessing = true;
            cancelRequested = false;
            currentFileIndex = 0;
            progress = 0.0;

            processButton.setEnabled (false);
            processButton.setButtonText ("Processing...");
            cancelButton.setVisible (true);
            addButton.setEnabled (false);
            addFolderButton.setEnabled (false);
            removeButton.setEnabled (false);
            clearButton.setEnabled (false);
            outputModeCombo.setEnabled (false);
            modelCombo.setEnabled (false);
            qualityCombo.setEnabled (false);
            progressBar.setVisible (true);

            statusLabel.setText ("Starting...", juce::dontSendNotification);

            parentWindow->onStartBatch (files, currentModel, getOutputFolder());
        }

        void requestCancel()
        {
            cancelRequested = true;
            statusLabel.setText ("Cancelling...", juce::dontSendNotification);

            // Close the window immediately
            if (parentWindow != nullptr)
            {
                parentWindow->clearFiles();
                parentWindow->setVisible (false);
            }
        }

        JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (ContentComponent)
    };

    std::unique_ptr<ContentComponent> content;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (BatchEditorWindow)
};
