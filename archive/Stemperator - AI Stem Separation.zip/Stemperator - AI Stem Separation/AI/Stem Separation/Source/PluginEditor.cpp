#include "PluginProcessor.h"
#include "PluginEditor.h"
#include "DSP/StemSeparator.h"
#if USE_HIP || USE_OPENCL
#include "GPU/GPUStemSeparator.h"
#endif

//==============================================================================
// StemMixerSource - Mixes separated stems with mute/solo/volume controls
class StemperatorEditor::StemMixerSource : public juce::PositionableAudioSource
{
public:
    StemMixerSource (std::array<juce::AudioBuffer<float>, 6>& stems, StemperatorProcessor& proc)
        : stemBuffers (stems), processor (proc)
    {
        for (auto& level : stemLevels)
            level.store (0.0f);
    }

    void prepareToPlay (int samplesPerBlockExpected, double sampleRate) override
    {
        currentSampleRate = sampleRate;
    }

    void releaseResources() override {}

    void getNextAudioBlock (const juce::AudioSourceChannelInfo& bufferToFill) override
    {
        bufferToFill.clearActiveBufferRegion();

        if (stemBuffers[0].getNumSamples() == 0)
            return;

        auto& apvts = processor.getParameters();

        // Get mute/solo states (supports 6 stems)
        std::array<bool, 6> muted, soloed;
        bool anySoloed = false;

        const char* muteIDs[] = { "vocalsMute", "drumsMute", "bassMute", "otherMute", "guitarMute", "pianoMute" };
        const char* soloIDs[] = { "vocalsSolo", "drumsSolo", "bassSolo", "otherSolo", "guitarSolo", "pianoSolo" };
        const char* gainIDs[] = { "vocalsGain", "drumsGain", "bassGain", "otherGain", "guitarGain", "pianoGain" };

        int numStems = processor.getNumStems();  // 4 or 6 based on model

        for (int i = 0; i < numStems; ++i)
        {
            muted[i] = apvts.getRawParameterValue (muteIDs[i])->load() > 0.5f;
            soloed[i] = apvts.getRawParameterValue (soloIDs[i])->load() > 0.5f;
            if (soloed[i])
                anySoloed = true;
        }

        float masterGain = juce::Decibels::decibelsToGain (apvts.getRawParameterValue ("masterGain")->load());

        int numSamples = bufferToFill.numSamples;
        int startSample = bufferToFill.startSample;

        // Calculate samples to read from stem buffers
        juce::int64 stemStart = currentPosition;
        juce::int64 stemEnd = stemStart + numSamples;

        if (stemStart >= stemBuffers[0].getNumSamples())
        {
            currentPosition = 0;  // Loop back
            stemStart = 0;
            stemEnd = numSamples;
        }

        int samplesToRead = (int) std::min ((juce::int64) numSamples,
                                             (juce::int64) stemBuffers[0].getNumSamples() - stemStart);

        if (samplesToRead <= 0)
            return;

        // Mix stems and calculate levels (uses numStems from processor)
        for (int stemIdx = 0; stemIdx < numStems; ++stemIdx)
        {
            auto& stemBuffer = stemBuffers[static_cast<size_t>(stemIdx)];
            int stemChannels = stemBuffer.getNumChannels();
            int stemSamples = stemBuffer.getNumSamples();

            // Skip empty stem buffers (e.g., guitar/piano when using 4-stem model)
            if (stemChannels == 0 || stemSamples == 0)
            {
                stemLevels[static_cast<size_t>(stemIdx)].store (0.0f);
                continue;
            }

            // Check if this stem should play
            bool shouldPlay = ! muted[static_cast<size_t>(stemIdx)];
            if (anySoloed)
                shouldPlay = soloed[static_cast<size_t>(stemIdx)];

            // Calculate RMS level from stem buffer at current position
            int actualSamplesToRead = std::min (samplesToRead, stemSamples - (int) stemStart);
            if (actualSamplesToRead <= 0)
            {
                stemLevels[static_cast<size_t>(stemIdx)].store (0.0f);
                continue;
            }

            float sumSquares = 0.0f;
            for (int ch = 0; ch < stemChannels; ++ch)
            {
                const float* data = stemBuffer.getReadPointer (ch, (int) stemStart);
                for (int i = 0; i < actualSamplesToRead; ++i)
                    sumSquares += data[i] * data[i];
            }
            float rms = std::sqrt (sumSquares / (float) (actualSamplesToRead * stemChannels));

            // Apply gain to level display (so it matches what you hear)
            // Boost factor to match LIVE mode meter levels (LIVE mode has overlap/bleed that inflates meters)
            constexpr float meterBoost = 2.4f;  // ~7.5 dB boost for visual consistency with LIVE mode
            float stemGain = juce::Decibels::decibelsToGain (
                apvts.getRawParameterValue (gainIDs[stemIdx])->load());
            float displayLevel = shouldPlay ? rms * stemGain * meterBoost : rms * 0.3f * meterBoost;  // Dimmed if muted
            stemLevels[static_cast<size_t>(stemIdx)].store (displayLevel);

            if (! shouldPlay)
                continue;

            // Output boost to match LIVE mode volume (LIVE has spectral overlap)
            constexpr float stemsOutputBoost = 1.26f;  // +2 dB boost
            float finalGain = stemGain * masterGain * stemsOutputBoost;
            int outChannels = bufferToFill.buffer->getNumChannels();

            for (int ch = 0; ch < outChannels; ++ch)
            {
                int srcCh = std::min (ch, stemChannels - 1);
                bufferToFill.buffer->addFrom (ch, startSample,
                                               stemBuffer, srcCh, (int) stemStart,
                                               actualSamplesToRead, finalGain);
            }
        }

        currentPosition += samplesToRead;
    }

    // Get stem level for visualization
    float getStemLevel (int stemIndex) const
    {
        if (stemIndex >= 0 && stemIndex < 6)
            return stemLevels[stemIndex].load();
        return 0.0f;
    }

    void setNextReadPosition (juce::int64 newPosition) override
    {
        currentPosition = newPosition;
    }

    juce::int64 getNextReadPosition() const override
    {
        return currentPosition;
    }

    juce::int64 getTotalLength() const override
    {
        // Return length from first non-empty stem, or 0 if all empty
        for (int i = 0; i < 6; ++i)
        {
            if (stemBuffers[i].getNumSamples() > 0)
                return stemBuffers[i].getNumSamples();
        }
        return 0;
    }

    bool isLooping() const override { return looping; }
    void setLooping (bool shouldLoop) override { looping = shouldLoop; }

private:
    std::array<juce::AudioBuffer<float>, 6>& stemBuffers;
    StemperatorProcessor& processor;
    juce::int64 currentPosition = 0;
    double currentSampleRate = 44100.0;
    bool looping = false;
    std::array<std::atomic<float>, 6> stemLevels;  // For visualizer (6-stem support)
};

//==============================================================================
// AboutOverlay - Custom borderless About screen that closes on click
class AboutOverlay : public juce::Component
{
public:
    AboutOverlay (StemperatorProcessor& proc)
        : processor (proc)
    {
        setOpaque (false);
        setWantsKeyboardFocus (true);
    }

    void paint (juce::Graphics& g) override
    {
        auto bounds = getLocalBounds().toFloat();

        // Semi-transparent dark overlay
        g.setColour (juce::Colour (0xcc000008));
        g.fillAll();

        // Center panel dimensions
        float panelWidth = juce::jmin (600.0f, bounds.getWidth() * 0.7f);
        float panelHeight = juce::jmin (500.0f, bounds.getHeight() * 0.8f);
        auto panelBounds = juce::Rectangle<float> (
            (bounds.getWidth() - panelWidth) / 2,
            (bounds.getHeight() - panelHeight) / 2,
            panelWidth, panelHeight);

        // Panel background with gradient
        juce::ColourGradient bgGradient (
            juce::Colour (0xff151522), panelBounds.getCentreX(), panelBounds.getY(),
            juce::Colour (0xff0a0a10), panelBounds.getCentreX(), panelBounds.getBottom(), false);
        g.setGradientFill (bgGradient);
        g.fillRoundedRectangle (panelBounds, 16.0f);

        // Panel border with accent glow
        g.setColour (juce::Colour (0xff7b68ee).withAlpha (0.6f));
        g.drawRoundedRectangle (panelBounds.reduced (1), 16.0f, 2.0f);

        // Content area
        auto contentArea = panelBounds.reduced (40);
        float y = contentArea.getY();

        // Title: STEMPERATOR with colorful letters matching stem colors
        // Cycle through: Vocals(red), Drums(blue), Bass(green), Other(orange)
        const juce::Colour letterColors[] = {
            juce::Colour (0xffff5555), // S - Vocals red
            juce::Colour (0xff5599ff), // T - Drums blue
            juce::Colour (0xff55ff99), // E - Bass green
            juce::Colour (0xffffaa33), // M - Other orange
            juce::Colour (0xffff5555), // P - Vocals red
            juce::Colour (0xff5599ff), // E - Drums blue
            juce::Colour (0xff55ff99), // R - Bass green
            juce::Colour (0xffffaa33), // A - Other orange
            juce::Colour (0xffff5555), // T - Vocals red
            juce::Colour (0xff5599ff), // O - Drums blue
            juce::Colour (0xff55ff99)  // R - Bass green
        };
        const char* letters = "STEMPERATOR";
        g.setFont (juce::FontOptions (48.0f).withStyle ("Bold"));

        // Calculate total width for centering
        float totalWidth = 0;
        for (int i = 0; letters[i] != '\0'; ++i)
        {
            juce::String letter = juce::String::charToString (letters[i]);
            totalWidth += g.getCurrentFont().getStringWidthFloat (letter);
        }

        // Draw each letter with its color
        float letterX = contentArea.getCentreX() - totalWidth / 2;
        for (int i = 0; letters[i] != '\0'; ++i)
        {
            juce::String letter = juce::String::charToString (letters[i]);
            float letterWidth = g.getCurrentFont().getStringWidthFloat (letter);
            g.setColour (letterColors[i]);
            g.drawText (letter, (int) letterX, (int) y, (int) letterWidth + 2, 60,
                        juce::Justification::centredLeft);
            letterX += letterWidth;
        }
        y += 55;

        // Subtitle
        g.setColour (juce::Colour (0xffaaaacc));
        g.setFont (juce::FontOptions (16.0f));
        g.drawText ("AI-POWERED STEM SEPARATION", contentArea.getX(), y, contentArea.getWidth(), 25,
                    juce::Justification::centred);
        y += 40;

        // Version
        g.setColour (juce::Colour (0xff7b68ee));
        g.setFont (juce::FontOptions (14.0f));
        g.drawText ("Version 1.0.0", contentArea.getX(), y, contentArea.getWidth(), 22,
                    juce::Justification::centred);
        y += 35;

        // Divider line
        g.setColour (juce::Colour (0xff7b68ee).withAlpha (0.4f));
        g.fillRect (contentArea.getCentreX() - 100, y, 200.0f, 2.0f);
        y += 25;

        // Stem icons/colors with labels
        float stemY = y;
        float stemSpacing = 35.0f;
        float iconSize = 12.0f;
        float iconX = contentArea.getCentreX() - 60;
        float textX = contentArea.getCentreX() - 40;

        const juce::Colour stemColors[] = {
            juce::Colour (0xffff5555), // Vocals - red
            juce::Colour (0xff5599ff), // Drums - blue
            juce::Colour (0xff55ff99), // Bass - green
            juce::Colour (0xffffaa33), // Other - orange
            juce::Colour (0xffffb450), // Guitar - golden
            juce::Colour (0xffff78c8)  // Piano - pink
        };
        const char* stemNames[] = { "Vocals", "Drums", "Bass", "Other", "Guitar", "Piano" };
        int numStems = processor.is6StemModel() ? 6 : 4;

        for (int i = 0; i < numStems; ++i)
        {
            // Color dot
            g.setColour (stemColors[i]);
            g.fillEllipse (iconX, stemY + (stemSpacing - iconSize) / 2, iconSize, iconSize);

            // Label
            g.setColour (juce::Colour (0xffccccdd));
            g.setFont (juce::FontOptions (15.0f));
            g.drawText (stemNames[i], textX, stemY, 100, (int) stemSpacing - 5,
                        juce::Justification::centredLeft);
            stemY += stemSpacing;
        }
        y = stemY + 15;

        // GPU/AI status - check for audio-separator (actual backend)
        g.setColour (juce::Colour (0xff666688));
        g.setFont (juce::FontOptions (12.0f));
        juce::String status = processor.getGPUInfo();

        // Check if audio-separator is available (the real AI backend)
        // Use same search strategy as findPythonEnvironment()
        bool aiAvailable = false;
        {
            auto executableFile = juce::File::getSpecialLocation (juce::File::currentExecutableFile);
            auto projectRoot = executableFile.getParentDirectory().getParentDirectory().getParentDirectory().getParentDirectory();
            auto venvPython = projectRoot.getChildFile (".venv/bin/python");
            auto separatorScript = projectRoot.getChildFile ("Source/AI/audio_separator_process.py");

            if (venvPython.existsAsFile() && separatorScript.existsAsFile())
                aiAvailable = true;

            // Also check STEMPERATOR_ROOT env var
            if (! aiAvailable)
            {
                auto envRoot = juce::SystemStats::getEnvironmentVariable ("STEMPERATOR_ROOT", "");
                if (envRoot.isNotEmpty())
                {
                    projectRoot = juce::File (envRoot);
                    venvPython = projectRoot.getChildFile (".venv/bin/python");
                    separatorScript = projectRoot.getChildFile ("Source/AI/audio_separator_process.py");
                    aiAvailable = venvPython.existsAsFile() && separatorScript.existsAsFile();
                }
            }
        }
        if (aiAvailable)
            status += " | Demucs Ready";
        else
            status += " | Demucs Not Found";
        g.drawText (status, contentArea.getX(), y, contentArea.getWidth(), 20,
                    juce::Justification::centred);
        y += 30;

        // Brand
        g.setColour (juce::Colour (0xff7b68ee));
        g.setFont (juce::FontOptions (20.0f).withStyle ("Bold"));
        g.drawText ("flarkAUDIO", contentArea.getX(), y, contentArea.getWidth(), 30,
                    juce::Justification::centred);

        // "Click anywhere to close" hint at bottom
        g.setColour (juce::Colour (0xff555566));
        g.setFont (juce::FontOptions (11.0f));
        g.drawText ("Click anywhere to close", panelBounds.getX(),
                    panelBounds.getBottom() - 30, panelBounds.getWidth(), 20,
                    juce::Justification::centred);
    }

    void mouseDown (const juce::MouseEvent&) override
    {
        // Close overlay when clicked
        if (auto* parent = getParentComponent())
        {
            parent->removeChildComponent (this);
            delete this;
        }
    }

    bool keyPressed (const juce::KeyPress& key) override
    {
        // Close on Escape or any key
        if (key == juce::KeyPress::escapeKey || key == juce::KeyPress::spaceKey)
        {
            if (auto* parent = getParentComponent())
            {
                parent->removeChildComponent (this);
                delete this;
            }
            return true;
        }
        return false;
    }

private:
    StemperatorProcessor& processor;
};

//==============================================================================
// ColorfulModeLabel implementation
void ColorfulModeLabel::paint (juce::Graphics& g)
{
    auto bounds = getLocalBounds().toFloat();

    // Draw background if set
    auto bgColour = findColour (juce::Label::backgroundColourId);
    if (! bgColour.isTransparent())
    {
        g.setColour (bgColour);
        g.fillRoundedRectangle (bounds, 4.0f);
    }

    // Hover highlight when clickable
    if (canToggle && isMouseOver())
    {
        g.setColour (juce::Colours::white.withAlpha (0.1f));
        g.fillRoundedRectangle (bounds, 4.0f);
    }

    juce::String text = getText();
    if (text.isEmpty())
        return;

    g.setFont (getFont());

    // Check if this is "Mode: STEMS" - draw STEMS in colorful letters
    if (text == "Mode: STEMS")
    {
        // Draw "Mode: " in normal color
        juce::String prefix = "Mode: ";
        float prefixWidth = g.getCurrentFont().getStringWidthFloat (prefix);
        g.setColour (findColour (juce::Label::textColourId));
        g.drawText (prefix, bounds.reduced (4, 0), juce::Justification::centredLeft);

        // Draw "STEMS" with stem colors
        const juce::Colour stemColors[] = {
            juce::Colour (0xffff5555), // S - Vocals red
            juce::Colour (0xff5599ff), // T - Drums blue
            juce::Colour (0xff55ff99), // E - Bass green
            juce::Colour (0xffffaa33), // M - Other orange
            juce::Colour (0xffff5555)  // S - Vocals red
        };
        const char* letters = "STEMS";

        float x = bounds.getX() + 4 + prefixWidth;
        for (int i = 0; letters[i] != '\0'; ++i)
        {
            juce::String letter = juce::String::charToString (letters[i]);
            float letterWidth = g.getCurrentFont().getStringWidthFloat (letter);
            g.setColour (stemColors[i]);
            g.drawText (letter, (int) x, (int) bounds.getY(), (int) letterWidth + 1,
                        (int) bounds.getHeight(), juce::Justification::centredLeft);
            x += letterWidth;
        }
    }
    // Check if this is "Mode: LIVE" - draw LIVE in colorful letters
    else if (text == "Mode: LIVE")
    {
        // Draw "Mode: " in normal color
        juce::String prefix = "Mode: ";
        float prefixWidth = g.getCurrentFont().getStringWidthFloat (prefix);
        g.setColour (findColour (juce::Label::textColourId));
        g.drawText (prefix, bounds.reduced (4, 0), juce::Justification::centredLeft);

        // Draw "LIVE" with warm yellow/orange gradient colors
        const juce::Colour liveColors[] = {
            juce::Colour (0xffffd700), // L - Gold
            juce::Colour (0xffffa500), // I - Orange
            juce::Colour (0xffff8c00), // V - Dark orange
            juce::Colour (0xffffd700)  // E - Gold
        };
        const char* letters = "LIVE";

        float x = bounds.getX() + 4 + prefixWidth;
        for (int i = 0; letters[i] != '\0'; ++i)
        {
            juce::String letter = juce::String::charToString (letters[i]);
            float letterWidth = g.getCurrentFont().getStringWidthFloat (letter);
            g.setColour (liveColors[i]);
            g.drawText (letter, (int) x, (int) bounds.getY(), (int) letterWidth + 1,
                        (int) bounds.getHeight(), juce::Justification::centredLeft);
            x += letterWidth;
        }
    }
    else
    {
        // Normal text rendering
        g.setColour (findColour (juce::Label::textColourId));
        g.drawText (text, bounds.reduced (4, 0), getJustificationType());
    }
}

void ColorfulModeLabel::mouseEnter (const juce::MouseEvent&)
{
    if (canToggle)
    {
        setMouseCursor (juce::MouseCursor::PointingHandCursor);
        repaint();
    }
}

void ColorfulModeLabel::mouseExit (const juce::MouseEvent&)
{
    setMouseCursor (juce::MouseCursor::NormalCursor);
    repaint();
}

void ColorfulModeLabel::mouseUp (const juce::MouseEvent& e)
{
    if (canToggle && e.mouseWasClicked() && onClick)
        onClick();
}

//==============================================================================
// Cancelled overlay - styled notification for cancelled operations
class CancelledOverlay : public juce::Component
{
public:
    CancelledOverlay (const juce::String& message, std::function<void()> onDismiss)
        : messageText (message), dismissCallback (onDismiss)
    {
        setOpaque (false);
        setWantsKeyboardFocus (true);

        okButton.setButtonText ("OK");
        okButton.onClick = [this]() { dismiss(); };
        addAndMakeVisible (okButton);
    }

    void paint (juce::Graphics& g) override
    {
        auto bounds = getLocalBounds().toFloat();

        // Semi-transparent dark overlay
        g.setColour (juce::Colour (0xcc000008));
        g.fillAll();

        // Center panel - smaller for simple message
        float panelWidth = juce::jmin (400.0f, bounds.getWidth() * 0.7f);
        float panelHeight = 200.0f;
        panelBounds = juce::Rectangle<float> (
            (bounds.getWidth() - panelWidth) / 2,
            (bounds.getHeight() - panelHeight) / 2,
            panelWidth, panelHeight);

        // Panel background with gradient
        juce::ColourGradient bgGradient (
            juce::Colour (0xff151522), panelBounds.getCentreX(), panelBounds.getY(),
            juce::Colour (0xff0a0a10), panelBounds.getCentreX(), panelBounds.getBottom(), false);
        g.setGradientFill (bgGradient);
        g.fillRoundedRectangle (panelBounds, 16.0f);

        // Panel border with orange/amber glow (cancelled = warning color)
        g.setColour (juce::Colour (0xffffaa33).withAlpha (0.6f));
        g.drawRoundedRectangle (panelBounds.reduced (1), 16.0f, 2.0f);

        auto contentArea = panelBounds.reduced (30);
        float y = contentArea.getY();

        // X icon
        g.setColour (juce::Colour (0xffffaa33));
        float iconSize = 50.0f;
        float iconX = contentArea.getCentreX() - iconSize / 2;
        juce::Path xPath;
        xPath.startNewSubPath (iconX + 10, y + 10);
        xPath.lineTo (iconX + iconSize - 10, y + iconSize - 10);
        xPath.startNewSubPath (iconX + iconSize - 10, y + 10);
        xPath.lineTo (iconX + 10, y + iconSize - 10);
        g.strokePath (xPath, juce::PathStrokeType (5.0f, juce::PathStrokeType::curved,
                                                    juce::PathStrokeType::rounded));
        y += 60;

        // Title: "Cancelled" in orange
        g.setColour (juce::Colour (0xffffaa33));
        g.setFont (juce::FontOptions (28.0f).withStyle ("Bold"));
        g.drawText ("Cancelled", contentArea.getX(), (int) y, (int) contentArea.getWidth(), 35,
                    juce::Justification::centred);
        y += 40;

        // Message text
        g.setColour (juce::Colour (0xffccccdd));
        g.setFont (juce::FontOptions (14.0f));
        g.drawText (messageText, contentArea.getX(), (int) y, (int) contentArea.getWidth(), 30,
                    juce::Justification::centred);
    }

    void resized() override
    {
        auto bounds = getLocalBounds().toFloat();
        float panelWidth = juce::jmin (400.0f, bounds.getWidth() * 0.7f);
        float panelHeight = 200.0f;
        panelBounds = juce::Rectangle<float> (
            (bounds.getWidth() - panelWidth) / 2,
            (bounds.getHeight() - panelHeight) / 2,
            panelWidth, panelHeight);

        float buttonY = panelBounds.getBottom() - 50;
        float buttonWidth = 100.0f;
        float buttonX = panelBounds.getCentreX() - buttonWidth / 2;
        okButton.setBounds ((int) buttonX, (int) buttonY, (int) buttonWidth, 35);
    }

    bool keyPressed (const juce::KeyPress& key) override
    {
        if (key == juce::KeyPress::escapeKey || key == juce::KeyPress::returnKey)
        {
            dismiss();
            return true;
        }
        return false;
    }

private:
    juce::String messageText;
    std::function<void()> dismissCallback;
    juce::Rectangle<float> panelBounds;
    juce::TextButton okButton;

    void dismiss()
    {
        if (dismissCallback)
            dismissCallback();

        if (auto* parent = getParentComponent())
        {
            parent->removeChildComponent (this);
            delete this;
        }
    }
};

//==============================================================================
// Export Complete overlay - styled like About screen
class ExportCompleteOverlay : public juce::Component
{
public:
    ExportCompleteOverlay (const juce::String& stats, const juce::File& stemFolder,
                           std::function<void(int)> onAction)
        : statsText (stats), folder (stemFolder), actionCallback (onAction)
    {
        setOpaque (false);
        setWantsKeyboardFocus (true);

        // Create styled buttons
        playButton.setButtonText ("Play Stems");
        playButton.onClick = [this]() { handleAction (1); };
        addAndMakeVisible (playButton);

        openButton.setButtonText ("Open Folder");
        openButton.onClick = [this]() { handleAction (2); };
        addAndMakeVisible (openButton);

        okButton.setButtonText ("OK");
        okButton.onClick = [this]() { handleAction (3); };
        addAndMakeVisible (okButton);

        quitButton.setButtonText ("Quit");
        quitButton.onClick = [this]() { handleAction (4); };
        addAndMakeVisible (quitButton);
    }

    void paint (juce::Graphics& g) override
    {
        auto bounds = getLocalBounds().toFloat();

        // Semi-transparent dark overlay
        g.setColour (juce::Colour (0xcc000008));
        g.fillAll();

        // Center panel dimensions - 2x larger for better readability
        float panelWidth = juce::jmin (750.0f, bounds.getWidth() * 0.85f);
        float panelHeight = juce::jmin (550.0f, bounds.getHeight() * 0.85f);
        panelBounds = juce::Rectangle<float> (
            (bounds.getWidth() - panelWidth) / 2,
            (bounds.getHeight() - panelHeight) / 2,
            panelWidth, panelHeight);

        // Panel background with gradient
        juce::ColourGradient bgGradient (
            juce::Colour (0xff151522), panelBounds.getCentreX(), panelBounds.getY(),
            juce::Colour (0xff0a0a10), panelBounds.getCentreX(), panelBounds.getBottom(), false);
        g.setGradientFill (bgGradient);
        g.fillRoundedRectangle (panelBounds, 16.0f);

        // Panel border with success green glow
        g.setColour (juce::Colour (0xff55ff99).withAlpha (0.6f));
        g.drawRoundedRectangle (panelBounds.reduced (1), 16.0f, 2.0f);

        // Content area
        auto contentArea = panelBounds.reduced (40);
        float y = contentArea.getY();

        // Checkmark icon - larger
        g.setColour (juce::Colour (0xff55ff99));
        float checkSize = 70.0f;
        float checkX = contentArea.getCentreX() - checkSize / 2;
        juce::Path checkPath;
        checkPath.startNewSubPath (checkX + 14, y + 40);
        checkPath.lineTo (checkX + 30, y + 56);
        checkPath.lineTo (checkX + 58, y + 20);
        g.strokePath (checkPath, juce::PathStrokeType (7.0f, juce::PathStrokeType::curved,
                                                        juce::PathStrokeType::rounded));
        y += 75;

        // Title: "Export Complete" with colorful letters
        const juce::Colour letterColors[] = {
            juce::Colour (0xff55ff99), // E - green
            juce::Colour (0xff5599ff), // x - blue
            juce::Colour (0xffffaa33), // p - orange
            juce::Colour (0xffff5555), // o - red
            juce::Colour (0xff55ff99), // r - green
            juce::Colour (0xff5599ff), // t - blue
            juce::Colour (0xffffffff), // (space)
            juce::Colour (0xff55ff99), // C - green
            juce::Colour (0xffffaa33), // o - orange
            juce::Colour (0xff5599ff), // m - blue
            juce::Colour (0xffff5555), // p - red
            juce::Colour (0xff55ff99), // l - green
            juce::Colour (0xffffaa33), // e - orange
            juce::Colour (0xff5599ff), // t - blue
            juce::Colour (0xffff5555)  // e - red
        };
        const char* title = "Export Complete";
        g.setFont (juce::FontOptions (42.0f).withStyle ("Bold"));

        // Calculate total width for centering
        float totalWidth = 0;
        for (int i = 0; title[i] != '\0'; ++i)
        {
            juce::String letter = juce::String::charToString (title[i]);
            totalWidth += g.getCurrentFont().getStringWidthFloat (letter);
        }

        // Draw each letter with its color
        float letterX = contentArea.getCentreX() - totalWidth / 2;
        for (int i = 0; title[i] != '\0'; ++i)
        {
            juce::String letter = juce::String::charToString (title[i]);
            float letterWidth = g.getCurrentFont().getStringWidthFloat (letter);
            g.setColour (letterColors[i]);
            g.drawText (letter, (int) letterX, (int) y, (int) letterWidth + 2, 50,
                        juce::Justification::centredLeft);
            letterX += letterWidth;
        }
        y += 60;

        // Stats text - larger and more space
        g.setColour (juce::Colour (0xffccccdd));
        g.setFont (juce::FontOptions (16.0f));
        g.drawFittedText (statsText, (int) contentArea.getX(), (int) y,
                          (int) contentArea.getWidth(), 180,
                          juce::Justification::centred, 10);
        y += 190;

        // Divider line
        g.setColour (juce::Colour (0xff55ff99).withAlpha (0.4f));
        g.fillRect (contentArea.getCentreX() - 150, y, 300.0f, 2.0f);
    }

    void resized() override
    {
        auto bounds = getLocalBounds().toFloat();

        // Calculate panel bounds (same as in paint)
        float panelWidth = juce::jmin (750.0f, bounds.getWidth() * 0.85f);
        float panelHeight = juce::jmin (550.0f, bounds.getHeight() * 0.85f);
        panelBounds = juce::Rectangle<float> (
            (bounds.getWidth() - panelWidth) / 2,
            (bounds.getHeight() - panelHeight) / 2,
            panelWidth, panelHeight);

        auto contentArea = panelBounds.reduced (40);
        float buttonY = panelBounds.getBottom() - 70;
        float buttonWidth = 130.0f;
        float buttonHeight = 40.0f;
        float spacing = 15.0f;
        float totalButtonWidth = buttonWidth * 4 + spacing * 3;
        float startX = contentArea.getCentreX() - totalButtonWidth / 2;

        playButton.setBounds ((int) startX, (int) buttonY, (int) buttonWidth, (int) buttonHeight);
        openButton.setBounds ((int) (startX + buttonWidth + spacing), (int) buttonY, (int) buttonWidth, (int) buttonHeight);
        okButton.setBounds ((int) (startX + (buttonWidth + spacing) * 2), (int) buttonY, (int) buttonWidth, (int) buttonHeight);
        quitButton.setBounds ((int) (startX + (buttonWidth + spacing) * 3), (int) buttonY, (int) buttonWidth, (int) buttonHeight);
    }

    bool keyPressed (const juce::KeyPress& key) override
    {
        if (key == juce::KeyPress::escapeKey)
        {
            handleAction (3);  // Same as OK
            return true;
        }
        if (key == juce::KeyPress::returnKey)
        {
            handleAction (1);  // Play Stems
            return true;
        }
        return false;
    }

private:
    juce::String statsText;
    juce::File folder;
    std::function<void(int)> actionCallback;
    juce::Rectangle<float> panelBounds;

    juce::TextButton playButton, openButton, okButton, quitButton;

    void handleAction (int action)
    {
        if (actionCallback)
            actionCallback (action);

        if (auto* parent = getParentComponent())
        {
            parent->removeChildComponent (this);
            delete this;
        }
    }
};

StemperatorEditor::StemperatorEditor (StemperatorProcessor& p)
    : AudioProcessorEditor (&p), processor (p)
{
    // Load UI font settings from file (before applying look and feel)
    UISettings::getInstance().loadFromFile();

    // Apply premium look and feel
    setLookAndFeel (&premiumLookAndFeel);

    // Initialize format manager for audio file loading
    formatManager = std::make_unique<juce::AudioFormatManager>();
    formatManager->registerBasicFormats();

    // Setup menu bar for standalone mode
    if (isStandalone())
    {
        commandManager.registerAllCommandsForTarget (this);
        // Always use this editor as the command target, regardless of focus state
        // This prevents menu items from being greyed out when window loses focus
        commandManager.setFirstCommandTarget (this);
        menuBar = std::make_unique<juce::MenuBarComponent> (this);
        addAndMakeVisible (*menuBar);

        // Setup transport controls
        setupTransportControls();
    }

    // Create stem channels with premium colors (supports 6 stems for htdemucs_6s model)
    const char* names[] = { "VOCALS", "DRUMS", "BASS", "OTHER", "GUITAR", "PIANO" };
    const char* gainIDs[] = { "vocalsGain", "drumsGain", "bassGain", "otherGain", "guitarGain", "pianoGain" };
    const char* muteIDs[] = { "vocalsMute", "drumsMute", "bassMute", "otherMute", "guitarMute", "pianoMute" };
    const char* soloIDs[] = { "vocalsSolo", "drumsSolo", "bassSolo", "otherSolo", "guitarSolo", "pianoSolo" };

    // Create all 6 stem channels (Guitar/Piano hidden unless 6-stem model selected)
    for (int i = 0; i < 6; ++i)
    {
        stemChannels[i] = std::make_unique<StemChannel> (names[i], stemColours[static_cast<size_t> (i)]);
        stemChannels[i]->attachToParameters (processor.getParameters(), gainIDs[i], muteIDs[i], soloIDs[i]);
        addAndMakeVisible (*stemChannels[i]);
        // Hide Guitar/Piano channels initially (shown when 6-stem model is selected)
        if (i >= 4)
        {
            stemChannels[i]->setVisible (processor.is6StemModel());
            // Mark Guitar/Piano as needing AI separation (not available in real-time preview)
            stemChannels[i]->setNeedsAISeparation (true);
        }

        // Setup Reaper-style mute/solo callbacks with modifier keys
        stemChannels[i]->onMuteChanged = [this, i] (bool state, bool ctrlDown, bool /*shiftDown*/) {
            if (ctrlDown)
            {
                // Ctrl+Click: Mute/Unmute ALL stems
                int numStems = processor.is6StemModel() ? 6 : 4;
                for (int j = 0; j < numStems; ++j)
                {
                    stemChannels[static_cast<size_t> (j)]->getMuteButton().setToggleState (state, juce::sendNotification);
                }
            }
            // Normal click: just toggle this stem (already handled by button)
        };

        stemChannels[i]->onSoloChanged = [this, i] (bool state, bool /*ctrlDown*/, bool shiftDown) {
            if (shiftDown && state)
            {
                // Shift+Click: Exclusive solo - solo only this, unsolo all others
                int numStems = processor.is6StemModel() ? 6 : 4;
                for (int j = 0; j < numStems; ++j)
                {
                    bool shouldSolo = (j == i);
                    stemChannels[static_cast<size_t> (j)]->getSoloButton().setToggleState (shouldSolo, juce::sendNotification);
                }
            }
            // Normal click: just toggle this stem (already handled by button)
        };
    }

    // Visualizer removed - stem channels have individual level meters

    // Master slider - vertical fader style (white for uniformity)
    setupSlider (masterSlider, juce::Colours::white);
    masterSlider.setSliderStyle (juce::Slider::LinearVertical);
    // Note: Don't set suffix - the parameter's stringFromValue already adds " dB"
    masterSlider.setTooltip ("Master output volume (double-click to reset to 0 dB)");
    masterSlider.setDoubleClickReturnValue (true, 0.0);  // Double-click resets to 0 dB

    // Create attachment BEFORE setting other properties - it sets range and default value
    masterAttachment = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment> (
        processor.getParameters(), "masterGain", masterSlider);

    masterLabel.setJustificationType (juce::Justification::centred);
    masterLabel.setColour (juce::Label::textColourId, PremiumLookAndFeel::Colours::textBright);
    addAndMakeVisible (masterLabel);

    // Master mute button (for visual consistency with stem channels)
    masterMuteButton.setClickingTogglesState (true);
    masterMuteButton.setColour (juce::TextButton::buttonColourId, PremiumLookAndFeel::Colours::bgPanel);
    masterMuteButton.setColour (juce::TextButton::buttonOnColourId, PremiumLookAndFeel::Colours::mute);
    masterMuteButton.setColour (juce::TextButton::textColourOnId, juce::Colours::white);
    masterMuteButton.setColour (juce::TextButton::textColourOffId, PremiumLookAndFeel::Colours::textMid);
    masterMuteButton.setTooltip ("Mute master output");
    masterMuteButton.onClick = [this] {
        // When master mute is toggled
        if (masterMuteButton.getToggleState())
        {
            // Store current value before muting
            previousMasterGain = masterSlider.getValue();
            masterSlider.setValue (-60.0, juce::sendNotification);
        }
        else
        {
            // Restore previous value when unmuting
            masterSlider.setValue (previousMasterGain, juce::sendNotification);
        }
    };
    addAndMakeVisible (masterMuteButton);

    // Master solo button (for visual consistency - functionally a bypass/solo-all)
    masterSoloButton.setClickingTogglesState (true);
    masterSoloButton.setColour (juce::TextButton::buttonColourId, PremiumLookAndFeel::Colours::bgPanel);
    masterSoloButton.setColour (juce::TextButton::buttonOnColourId, PremiumLookAndFeel::Colours::solo);
    masterSoloButton.setColour (juce::TextButton::textColourOnId, juce::Colours::black);
    masterSoloButton.setColour (juce::TextButton::textColourOffId, PremiumLookAndFeel::Colours::textMid);
    masterSoloButton.setTooltip ("Solo master (bypass stem separation)");
    addAndMakeVisible (masterSoloButton);

    // Reset All button - resets all stem faders to 0 dB and clears mute/solo
    resetAllButton.setColour (juce::TextButton::buttonColourId, PremiumLookAndFeel::Colours::bgPanel);
    resetAllButton.setColour (juce::TextButton::textColourOnId, PremiumLookAndFeel::Colours::accent);
    resetAllButton.setColour (juce::TextButton::textColourOffId, PremiumLookAndFeel::Colours::textMid);
    resetAllButton.setTooltip ("Reset all stem faders to 0 dB and clear mute/solo states");
    resetAllButton.onClick = [this] {
        // Reset all stem faders to 0 dB and clear mute/solo
        int numStems = processor.is6StemModel() ? 6 : 4;
        for (int i = 0; i < numStems; ++i)
        {
            stemChannels[static_cast<size_t> (i)]->getGainSlider().setValue (0.0, juce::sendNotification);
            stemChannels[static_cast<size_t> (i)]->getMuteButton().setToggleState (false, juce::sendNotification);
            stemChannels[static_cast<size_t> (i)]->getSoloButton().setToggleState (false, juce::sendNotification);
        }
        // Also reset master to 0 dB and clear master mute
        masterSlider.setValue (0.0, juce::sendNotification);
        masterMuteButton.setToggleState (false, juce::sendNotification);
        masterSoloButton.setToggleState (false, juce::sendNotification);
    };
    addAndMakeVisible (resetAllButton);

    // Focus controls - rotary knobs
    setupKnob (vocalsFocusSlider, vocalsFocusLabel, "VOCAL FOCUS", stemColours[0]);
    setupKnob (bassCutoffSlider, bassCutoffLabel, "BASS CUTOFF", stemColours[2]);
    setupKnob (drumSensSlider, drumSensLabel, "DRUM SENS", stemColours[1]);

    // Tooltips for focus controls
    vocalsFocusSlider.setTooltip ("Adjust how much center-channel content goes to vocals (real-time preview only)");
    bassCutoffSlider.setTooltip ("Set the frequency cutoff for bass separation (real-time preview only)");
    drumSensSlider.setTooltip ("Adjust drum/transient detection sensitivity (real-time preview only)");

    vocalsFocusAttachment = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment> (
        processor.getParameters(), "vocalsFocus", vocalsFocusSlider);
    bassCutoffAttachment = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment> (
        processor.getParameters(), "bassCutoff", bassCutoffSlider);
    drumSensAttachment = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment> (
        processor.getParameters(), "drumSensitivity", drumSensSlider);

    // Quality selector (three-way toggle button)
    qualityButton.setColour (juce::TextButton::buttonColourId, PremiumLookAndFeel::Colours::bgPanel);
    qualityButton.setColour (juce::TextButton::textColourOnId, PremiumLookAndFeel::Colours::textBright);
    qualityButton.setColour (juce::TextButton::textColourOffId, PremiumLookAndFeel::Colours::textBright);
    qualityButton.setTooltip ("Click to cycle: Fast -> Balanced -> Best");
    qualityButton.onClick = [this] { onQualityButtonClicked(); };
    addAndMakeVisible (qualityButton);

    qualityLabel.setJustificationType (juce::Justification::centred);
    qualityLabel.setColour (juce::Label::textColourId, PremiumLookAndFeel::Colours::textMid);
    addAndMakeVisible (qualityLabel);

    // Quality button doesn't use attachment - controlled by currentQuality member

    // Model selector (4-stem vs 6-stem)
    modelBox.addItem ("4 Stems", 1);
    modelBox.addItem ("6 Stems", 2);
    modelBox.setSelectedId (1);  // Default to 4-stem
    modelBox.onChange = [this] { onModelChanged(); };
    modelBox.setTooltip ("4 Stems: Vocals, Drums, Bass, Other | 6 Stems: adds Guitar, Piano (uses htdemucs_6s model)");
    addAndMakeVisible (modelBox);

    // Title - large and prominent
    titleLabel.setColour (juce::Label::textColourId, PremiumLookAndFeel::Colours::textBright);
    titleLabel.setJustificationType (juce::Justification::centredLeft);
    addAndMakeVisible (titleLabel);

    // Subtitle - show GPU and AI status
    juce::String subtitle = "AI-POWERED STEM SEPARATION | " + processor.getGPUInfo();

    // Add Demucs status - check for audio-separator (actual backend)
    {
        auto pyEnv = findPythonEnvironment();
        if (pyEnv.isValid())
            subtitle += " | Demucs: Ready";
    }

    subtitleLabel.setText (subtitle, juce::dontSendNotification);
    subtitleLabel.setColour (juce::Label::textColourId, PremiumLookAndFeel::Colours::textDim);
    subtitleLabel.setJustificationType (juce::Justification::centredLeft);
    addAndMakeVisible (subtitleLabel);

    // Brand label (right-aligned)
    brandLabel.setColour (juce::Label::textColourId, PremiumLookAndFeel::Colours::accent);
    brandLabel.setJustificationType (juce::Justification::centredRight);
    addAndMakeVisible (brandLabel);

    // Initialize export stem levels
    for (auto& level : exportStemLevels)
        level.store (0.0f);

    // Register keyboard listener for Escape to cancel and Space to play
    // Enable keyboard focus so we can receive key events
    setWantsKeyboardFocus (true);
    addKeyListener (this);

    // Start timer for level updates - very slow at idle, will speed up when playing
    startTimerHz (2);  // Idle mode: 2 Hz (just for transport updates)

    // Optimize rendering - cache components to reduce GPU load when idle
    setBufferedToImage (true);
    setOpaque (true);  // Don't need transparency, enables faster rendering

    // Scale selector (ComboBox) - 50% to 300% in steps (base = 1440x810)
    scaleBox.addItem ("50%", 1);
    scaleBox.addItem ("75%", 2);
    scaleBox.addItem ("100%", 3);
    scaleBox.addItem ("125%", 4);
    scaleBox.addItem ("150%", 5);
    scaleBox.addItem ("200%", 6);
    scaleBox.addItem ("250%", 7);
    scaleBox.addItem ("300%", 8);
    scaleBox.setSelectedId (3);  // Default to 100% = 1440x810
    scaleBox.onChange = [this] { onScaleChanged(); };
    scaleBox.setTooltip ("Window scale: 50% (720x405) to 300% (4320x2430)");
    addAndMakeVisible (scaleBox);

    scaleLabel.setJustificationType (juce::Justification::centred);
    scaleLabel.setColour (juce::Label::textColourId, PremiumLookAndFeel::Colours::textMid);
    addAndMakeVisible (scaleLabel);

    // Resizable with wide range for small laptops to 4K monitors
    setResizable (true, true);
    setResizeLimits (720, 405, 4320, 2430);  // 50% to 300% of 1440x810
    setSize (1440, 810);  // Default to 100% = 1440x810

    // Load persistent settings
    loadSettings();
}

StemperatorEditor::~StemperatorEditor()
{
    // Save settings before exit
    saveSettings();

    setLookAndFeel (nullptr);
    stopTimer();
    transportSource.setSource (nullptr);
}

//==============================================================================
// Persistent settings
void StemperatorEditor::loadSettings()
{
    juce::PropertiesFile::Options options;
    options.applicationName = "Stemperator";
    options.folderName = "flarkAUDIO";
    options.filenameSuffix = ".settings";
    options.osxLibrarySubFolder = "Application Support";

    appSettings = std::make_unique<juce::PropertiesFile> (options);

    // Load last used folders
    juce::String stemFolderPath = appSettings->getValue ("lastStemFolder", "");
    if (stemFolderPath.isNotEmpty())
        lastStemFolder = juce::File (stemFolderPath);

    juce::String audioFolderPath = appSettings->getValue ("lastAudioFolder", "");
    if (audioFolderPath.isNotEmpty())
        lastAudioFolder = juce::File (audioFolderPath);

    // Load default stem folder setting
    juce::String defaultFolderPath = appSettings->getValue ("defaultStemFolder", "");
    if (defaultFolderPath.isNotEmpty())
        defaultStemFolder = juce::File (defaultFolderPath);

    // Load default project folder setting
    juce::String defaultProjectPath = appSettings->getValue ("defaultProjectFolder", "");
    if (defaultProjectPath.isNotEmpty())
        defaultProjectFolder = juce::File (defaultProjectPath);

    // Load default batch folder setting
    juce::String defaultBatchPath = appSettings->getValue ("defaultBatchFolder", "");
    if (defaultBatchPath.isNotEmpty())
        defaultBatchFolder = juce::File (defaultBatchPath);

    // Load recent stem folders
    juce::String recentFoldersStr = appSettings->getValue ("recentStemFolders", "");
    if (recentFoldersStr.isNotEmpty())
    {
        recentStemFolders.clear();
        recentStemFolders.addTokens (recentFoldersStr, "|", "");
        // Remove any non-existing folders
        for (int i = recentStemFolders.size() - 1; i >= 0; --i)
        {
            if (! juce::File (recentStemFolders[i]).isDirectory())
                recentStemFolders.remove (i);
        }
    }

    // Load recent project files
    juce::String recentProjectsStr = appSettings->getValue ("recentProjects", "");
    if (recentProjectsStr.isNotEmpty())
    {
        recentProjects.clear();
        recentProjects.addTokens (recentProjectsStr, "|", "");
        // Remove any non-existing files
        for (int i = recentProjects.size() - 1; i >= 0; --i)
        {
            if (! juce::File (recentProjects[i]).existsAsFile())
                recentProjects.remove (i);
        }
    }

    // Load recent batch output folders
    juce::String recentBatchFoldersStr = appSettings->getValue ("recentBatchOutputFolders", "");
    if (recentBatchFoldersStr.isNotEmpty())
    {
        recentBatchOutputFolders.clear();
        recentBatchOutputFolders.addTokens (recentBatchFoldersStr, "|", "");
        // Remove any non-existing folders
        for (int i = recentBatchOutputFolders.size() - 1; i >= 0; --i)
        {
            if (! juce::File (recentBatchOutputFolders[i]).isDirectory())
                recentBatchOutputFolders.remove (i);
        }
    }

    // Load saved window position (standalone mode only)
    if (isStandalone())
    {
        int windowX = appSettings->getIntValue ("windowX", -1);
        int windowY = appSettings->getIntValue ("windowY", -1);
        int windowW = appSettings->getIntValue ("windowW", 0);
        int windowH = appSettings->getIntValue ("windowH", 0);

        if (windowX >= 0 && windowY >= 0 && windowW > 0 && windowH > 0)
        {
            // Verify the position is still on a valid display
            auto displays = juce::Desktop::getInstance().getDisplays();
            juce::Rectangle<int> savedBounds (windowX, windowY, windowW, windowH);

            for (const auto& display : displays.displays)
            {
                if (display.userArea.intersects (savedBounds))
                {
                    // Position is valid - will be applied in parentHierarchyChanged
                    savedWindowBounds = savedBounds;
                    break;
                }
            }
        }
    }
}

void StemperatorEditor::saveSettings()
{
    if (appSettings)
    {
        if (lastStemFolder.exists())
            appSettings->setValue ("lastStemFolder", lastStemFolder.getFullPathName());

        if (lastAudioFolder.exists())
            appSettings->setValue ("lastAudioFolder", lastAudioFolder.getFullPathName());

        if (defaultStemFolder.exists())
            appSettings->setValue ("defaultStemFolder", defaultStemFolder.getFullPathName());
        else
            appSettings->removeValue ("defaultStemFolder");

        if (defaultProjectFolder.exists())
            appSettings->setValue ("defaultProjectFolder", defaultProjectFolder.getFullPathName());
        else
            appSettings->removeValue ("defaultProjectFolder");

        if (defaultBatchFolder.exists())
            appSettings->setValue ("defaultBatchFolder", defaultBatchFolder.getFullPathName());
        else
            appSettings->removeValue ("defaultBatchFolder");

        // Save recent stem folders as pipe-separated string
        if (recentStemFolders.size() > 0)
            appSettings->setValue ("recentStemFolders", recentStemFolders.joinIntoString ("|"));

        // Save recent projects as pipe-separated string
        if (recentProjects.size() > 0)
            appSettings->setValue ("recentProjects", recentProjects.joinIntoString ("|"));

        // Save recent batch output folders as pipe-separated string
        if (recentBatchOutputFolders.size() > 0)
            appSettings->setValue ("recentBatchOutputFolders", recentBatchOutputFolders.joinIntoString ("|"));

        // Save window position (standalone mode only)
        if (isStandalone())
        {
            if (auto* topLevel = getTopLevelComponent())
            {
                auto bounds = topLevel->getBounds();
                appSettings->setValue ("windowX", bounds.getX());
                appSettings->setValue ("windowY", bounds.getY());
                appSettings->setValue ("windowW", bounds.getWidth());
                appSettings->setValue ("windowH", bounds.getHeight());
            }
        }

        appSettings->saveIfNeeded();
    }
}

void StemperatorEditor::addToRecentStems (const juce::File& folder)
{
    if (! folder.isDirectory())
        return;

    juce::String folderPath = folder.getFullPathName();

    // Remove if already exists (we'll add at front)
    recentStemFolders.removeString (folderPath);

    // Add to front
    recentStemFolders.insert (0, folderPath);

    // Keep only max items
    while (recentStemFolders.size() > maxRecentFolders)
        recentStemFolders.remove (recentStemFolders.size() - 1);

    saveSettings();
}

void StemperatorEditor::addToRecentProjects (const juce::File& projectFile)
{
    if (! projectFile.existsAsFile())
        return;

    juce::String filePath = projectFile.getFullPathName();

    // Remove if already exists (we'll add at front)
    recentProjects.removeString (filePath);

    // Add to front
    recentProjects.insert (0, filePath);

    // Keep only max items
    while (recentProjects.size() > maxRecentFolders)
        recentProjects.remove (recentProjects.size() - 1);

    saveSettings();
}

void StemperatorEditor::addToRecentBatchOutputFolders (const juce::File& folder)
{
    if (! folder.isDirectory())
        return;

    juce::String folderPath = folder.getFullPathName();

    // Remove if already exists (we'll add at front)
    recentBatchOutputFolders.removeString (folderPath);

    // Add to front
    recentBatchOutputFolders.insert (0, folderPath);

    // Keep only max items
    while (recentBatchOutputFolders.size() > maxRecentFolders)
        recentBatchOutputFolders.remove (recentBatchOutputFolders.size() - 1);

    saveSettings();
}

//==============================================================================
// Focus handling - ensure menu works immediately
void StemperatorEditor::parentHierarchyChanged()
{
    AudioProcessorEditor::parentHierarchyChanged();

    // When we get a parent (window), bring to front but don't grab keyboard focus
    // This allows menu bar clicks to work immediately on Linux
    if (isStandalone() && getParentComponent() != nullptr)
    {
        // Apply saved window position only once, on first appearance
        if (! windowPositionApplied && ! savedWindowBounds.isEmpty())
        {
            windowPositionApplied = true;

            // Use a short delay to ensure the window hierarchy is fully set up
            juce::Timer::callAfterDelay (50, [this]()
            {
                if (auto* topLevel = getTopLevelComponent())
                {
                    // Verify position is still valid
                    auto displays = juce::Desktop::getInstance().getDisplays();
                    bool positionValid = false;

                    for (const auto& display : displays.displays)
                    {
                        if (display.userArea.intersects (savedWindowBounds))
                        {
                            positionValid = true;
                            break;
                        }
                    }

                    if (positionValid)
                    {
                        topLevel->setBounds (savedWindowBounds);
                    }
                }
            });
        }

        juce::Timer::callAfterDelay (100, [this]()
        {
            if (auto* peer = getPeer())
            {
                peer->toFront (true);
            }
        });
    }
}

void StemperatorEditor::visibilityChanged()
{
    AudioProcessorEditor::visibilityChanged();
    // Don't grab focus on visibility change - allows menu bar to work on Linux
}

//==============================================================================
// Standalone detection
bool StemperatorEditor::isStandalone() const
{
    return juce::PluginHostType().isInterAppAudioConnected() == false
        && juce::JUCEApplicationBase::isStandaloneApp();
}

//==============================================================================
// MenuBarModel implementation
juce::StringArray StemperatorEditor::getMenuBarNames()
{
    return { "File", "Edit", "Export", "Help" };
}

juce::PopupMenu StemperatorEditor::getMenuForIndex (int menuIndex, const juce::String&)
{
    juce::PopupMenu menu;

    if (menuIndex == 0)  // File menu
    {
        menu.addCommandItem (&commandManager, cmdLoadFile);
        menu.addCommandItem (&commandManager, cmdBatchProcess);
        menu.addSeparator();
        menu.addCommandItem (&commandManager, cmdSaveProject);
        menu.addCommandItem (&commandManager, cmdSaveProjectAs);
        menu.addCommandItem (&commandManager, cmdLoadProject);

        // Recent Projects submenu
        if (recentProjects.size() > 0)
        {
            juce::PopupMenu recentProjectsMenu;
            for (int i = 0; i < recentProjects.size(); ++i)
            {
                juce::File file (recentProjects[i]);
                juce::String displayName = file.getFileNameWithoutExtension();
                recentProjectsMenu.addItem (2000 + i, displayName);
            }
            recentProjectsMenu.addSeparator();
            recentProjectsMenu.addItem (1999, "Clear Recent Projects");
            menu.addSubMenu ("Recent Projects", recentProjectsMenu, true);
        }

        menu.addSeparator();
        menu.addCommandItem (&commandManager, cmdQuit);
    }
    else if (menuIndex == 1)  // Edit menu
    {
        menu.addCommandItem (&commandManager, cmdUndo);
        menu.addCommandItem (&commandManager, cmdRedo);
        menu.addSeparator();
        menu.addCommandItem (&commandManager, cmdResetStems);
        menu.addCommandItem (&commandManager, cmdDeleteStems);
    }
    else if (menuIndex == 2)  // Export menu
    {
        menu.addCommandItem (&commandManager, cmdExportAllStems);
        menu.addCommandItem (&commandManager, cmdExportMix);
        menu.addSeparator();
        menu.addCommandItem (&commandManager, cmdExportVocals);
        menu.addCommandItem (&commandManager, cmdExportDrums);
        menu.addCommandItem (&commandManager, cmdExportBass);
        menu.addCommandItem (&commandManager, cmdExportOther);
        if (processor.getNumStems() == 6)
        {
            menu.addCommandItem (&commandManager, cmdExportGuitar);
            menu.addCommandItem (&commandManager, cmdExportPiano);
        }
        menu.addSeparator();

        // STEMS folder submenu
        {
            juce::PopupMenu stemsFolderMenu;
            bool hasStemsFolder = lastStemFolder.exists() && lastStemFolder.isDirectory();
            bool hasDefaultStems = defaultStemFolder.exists();
            stemsFolderMenu.addItem (3001, "Reveal STEMS Folder", hasStemsFolder);
            if (hasDefaultStems)
                stemsFolderMenu.addItem (3004, "Reveal Default Folder");
            stemsFolderMenu.addSeparator();
            stemsFolderMenu.addItem (3002, "Set Default STEMS Folder...");
            if (hasDefaultStems)
                stemsFolderMenu.addItem (3003, "Clear Default Folder");

            juce::String stemsLabel = "STEMS Folder";
            if (lastStemFolder.exists())
                stemsLabel += " (" + lastStemFolder.getFileName() + ")";
            else if (hasDefaultStems)
                stemsLabel += " [" + defaultStemFolder.getFileName() + "]";
            menu.addSubMenu (stemsLabel, stemsFolderMenu, true);
        }

        // PROJECT folder submenu
        {
            juce::PopupMenu projectFolderMenu;
            bool hasProjectFolder = currentProjectFile.existsAsFile();
            bool hasDefaultProject = defaultProjectFolder.exists();
            projectFolderMenu.addItem (3010, "Reveal Project Folder", hasProjectFolder);
            if (hasDefaultProject)
                projectFolderMenu.addItem (3013, "Reveal Default Folder");
            projectFolderMenu.addSeparator();
            projectFolderMenu.addItem (3011, "Set Default PROJECT Folder...");
            if (hasDefaultProject)
                projectFolderMenu.addItem (3012, "Clear Default Folder");

            juce::String projectLabel = "PROJECT Folder";
            if (hasProjectFolder)
                projectLabel += " (" + currentProjectFile.getParentDirectory().getFileName() + ")";
            else if (hasDefaultProject)
                projectLabel += " [" + defaultProjectFolder.getFileName() + "]";
            menu.addSubMenu (projectLabel, projectFolderMenu, true);
        }

        // BATCH folder submenu
        {
            juce::PopupMenu batchFolderMenu;
            bool hasBatchFolders = recentBatchOutputFolders.size() > 0;
            bool hasDefaultBatch = defaultBatchFolder.exists();

            // Most recent batch folder at top
            if (hasBatchFolders)
            {
                juce::File mostRecent (recentBatchOutputFolders[0]);
                batchFolderMenu.addItem (3020, "Reveal BATCH Folder", mostRecent.exists());
            }
            else
            {
                batchFolderMenu.addItem (3020, "Reveal BATCH Folder", false);  // Greyed out
            }

            if (hasDefaultBatch)
                batchFolderMenu.addItem (3023, "Reveal Default Folder");

            if (hasBatchFolders)
            {
                batchFolderMenu.addSeparator();

                // Recent batch folders
                juce::PopupMenu recentBatchMenu;
                for (int i = 0; i < recentBatchOutputFolders.size(); ++i)
                {
                    juce::File folder (recentBatchOutputFolders[i]);
                    recentBatchMenu.addItem (3030 + i, folder.getFileName(), folder.exists());
                }
                recentBatchMenu.addSeparator();
                recentBatchMenu.addItem (3029, "Clear Recent Folders");
                batchFolderMenu.addSubMenu ("Recent BATCH Folders", recentBatchMenu, true);
            }

            batchFolderMenu.addSeparator();
            batchFolderMenu.addItem (3021, "Set Default BATCH Folder...");
            if (hasDefaultBatch)
                batchFolderMenu.addItem (3022, "Clear Default Folder");

            juce::String batchLabel = "BATCH Folder";
            if (hasBatchFolders)
            {
                juce::File mostRecent (recentBatchOutputFolders[0]);
                batchLabel += " (" + mostRecent.getFileName() + ")";
            }
            else if (hasDefaultBatch)
            {
                batchLabel += " [" + defaultBatchFolder.getFileName() + "]";
            }
            menu.addSubMenu (batchLabel, batchFolderMenu, true);
        }
    }
    else if (menuIndex == 3)  // Help menu
    {
        menu.addCommandItem (&commandManager, cmdUISettings);
        menu.addSeparator();
        menu.addCommandItem (&commandManager, cmdAbout);
    }

    return menu;
}

void StemperatorEditor::menuItemSelected (int menuItemID, int /*topLevelMenuIndex*/)
{
    // Handle recent projects (IDs 2000+)
    if (menuItemID >= 2000 && menuItemID < 2000 + recentProjects.size())
    {
        int index = menuItemID - 2000;
        juce::File file (recentProjects[index]);
        if (file.existsAsFile())
            loadProject (file);
        return;
    }

    // Handle clear recent projects list
    if (menuItemID == 1999)
    {
        recentProjects.clear();
        saveSettings();
        return;
    }

    // Handle STEMS folder menu items (3001-3009)
    if (menuItemID == 3001)  // Reveal STEMS folder
    {
        if (lastStemFolder.exists())
            lastStemFolder.revealToUser();
        return;
    }
    if (menuItemID == 3002)  // Set default STEMS folder
    {
        fileChooser = std::make_unique<juce::FileChooser> (
            "Select default folder for stem export...",
            defaultStemFolder.exists() ? defaultStemFolder : juce::File::getSpecialLocation (juce::File::userMusicDirectory),
            "",
            true);

        fileChooser->launchAsync (juce::FileBrowserComponent::openMode | juce::FileBrowserComponent::canSelectDirectories,
            [this] (const juce::FileChooser& c)
            {
                auto folder = c.getResult();
                if (folder != juce::File() && folder.isDirectory())
                {
                    defaultStemFolder = folder;
                    saveSettings();
                }
            });
        return;
    }
    if (menuItemID == 3003)  // Clear default STEMS folder
    {
        defaultStemFolder = juce::File();
        saveSettings();
        return;
    }
    if (menuItemID == 3004)  // Reveal default STEMS folder
    {
        if (defaultStemFolder.exists())
            defaultStemFolder.revealToUser();
        return;
    }

    // Handle PROJECT folder menu items (3010-3019)
    if (menuItemID == 3010)  // Reveal PROJECT folder
    {
        if (currentProjectFile.existsAsFile())
            currentProjectFile.getParentDirectory().revealToUser();
        return;
    }
    if (menuItemID == 3011)  // Set default PROJECT folder
    {
        fileChooser = std::make_unique<juce::FileChooser> (
            "Select default folder for project files...",
            defaultProjectFolder.exists() ? defaultProjectFolder : juce::File::getSpecialLocation (juce::File::userDocumentsDirectory),
            "",
            true);

        fileChooser->launchAsync (juce::FileBrowserComponent::openMode | juce::FileBrowserComponent::canSelectDirectories,
            [this] (const juce::FileChooser& c)
            {
                auto folder = c.getResult();
                if (folder != juce::File() && folder.isDirectory())
                {
                    defaultProjectFolder = folder;
                    saveSettings();
                }
            });
        return;
    }
    if (menuItemID == 3012)  // Clear default PROJECT folder
    {
        defaultProjectFolder = juce::File();
        saveSettings();
        return;
    }
    if (menuItemID == 3013)  // Reveal default PROJECT folder
    {
        if (defaultProjectFolder.exists())
            defaultProjectFolder.revealToUser();
        return;
    }

    // Handle BATCH folder menu items (3020-3029)
    if (menuItemID == 3020)  // Reveal most recent BATCH folder
    {
        if (recentBatchOutputFolders.size() > 0)
        {
            juce::File folder (recentBatchOutputFolders[0]);
            if (folder.exists())
                folder.revealToUser();
        }
        return;
    }
    if (menuItemID == 3021)  // Set default BATCH folder
    {
        fileChooser = std::make_unique<juce::FileChooser> (
            "Select default folder for batch output...",
            defaultBatchFolder.exists() ? defaultBatchFolder : juce::File::getSpecialLocation (juce::File::userMusicDirectory),
            "",
            true);

        fileChooser->launchAsync (juce::FileBrowserComponent::openMode | juce::FileBrowserComponent::canSelectDirectories,
            [this] (const juce::FileChooser& c)
            {
                auto folder = c.getResult();
                if (folder != juce::File() && folder.isDirectory())
                {
                    defaultBatchFolder = folder;
                    saveSettings();
                }
            });
        return;
    }
    if (menuItemID == 3022)  // Clear default BATCH folder
    {
        defaultBatchFolder = juce::File();
        saveSettings();
        return;
    }
    if (menuItemID == 3023)  // Reveal default BATCH folder
    {
        if (defaultBatchFolder.exists())
            defaultBatchFolder.revealToUser();
        return;
    }
    if (menuItemID == 3029)  // Clear recent BATCH folders
    {
        recentBatchOutputFolders.clear();
        saveSettings();
        return;
    }

    // Handle recent BATCH folder selection (3030+)
    if (menuItemID >= 3030 && menuItemID < 3030 + recentBatchOutputFolders.size())
    {
        int index = menuItemID - 3030;
        juce::File folder (recentBatchOutputFolders[index]);
        if (folder.exists())
            folder.revealToUser();
        return;
    }

    // Other items handled by command manager
}

void StemperatorEditor::onModelChanged()
{
    // Set model based on selection (1 = 4 stems, 2 = 6 stems)
    int selected = modelBox.getSelectedId();
    if (selected == 1)
        processor.getDemucsProcessor().setModel (DemucsProcessor::HTDemucs);
    else
        processor.getDemucsProcessor().setModel (DemucsProcessor::HTDemucs_6S);

    // Trigger layout update to show/hide Guitar and Piano channels
    resized();
}

void StemperatorEditor::onScaleChanged()
{
    // Map ComboBox ID to scale percentage (base = 1440x810)
    int scalePercents[] = { 50, 75, 100, 125, 150, 200, 250, 300 };
    int selectedIndex = scaleBox.getSelectedId() - 1;  // 0-based index

    if (selectedIndex < 0 || selectedIndex >= 8)
        return;

    float scaleFactor = static_cast<float> (scalePercents[selectedIndex]) / 100.0f;

    // Base size is 1440x810
    int newWidth = juce::roundToInt (1440 * scaleFactor);
    int newHeight = juce::roundToInt (810 * scaleFactor);

    // Set the new size
    setSize (newWidth, newHeight);
}

void StemperatorEditor::onQualityButtonClicked()
{
    // Cycle through: Fast (0) -> Balanced (1) -> Best (2) -> Fast (0) ...
    currentQuality = (currentQuality + 1) % 3;

    const char* qualityNames[] = { "Fast", "Balanced", "Best" };
    qualityButton.setButtonText (qualityNames[currentQuality]);

    // Update processor parameter
    if (auto* param = processor.getParameters().getParameter ("quality"))
        param->setValueNotifyingHost (static_cast<float> (currentQuality) / 2.0f);  // Normalize to 0-1
}

//==============================================================================
// ApplicationCommandTarget implementation
void StemperatorEditor::getAllCommands (juce::Array<juce::CommandID>& commands)
{
    commands.addArray ({
        cmdLoadFile,
        cmdSeparate,
        cmdBatchProcess,
        cmdSaveProject,
        cmdSaveProjectAs,
        cmdLoadProject,
        cmdExportAllStems,
        cmdExportMix,
        cmdExportVocals,
        cmdExportDrums,
        cmdExportBass,
        cmdExportOther,
        cmdExportGuitar,
        cmdExportPiano,
        cmdPlay,
        cmdStop,
        cmdResetStems,
        cmdDeleteStems,
        cmdUndo,
        cmdRedo,
        cmdAbout,
        cmdUISettings,
        cmdQuit
    });
}

void StemperatorEditor::getCommandInfo (juce::CommandID commandID, juce::ApplicationCommandInfo& result)
{
    switch (commandID)
    {
        case cmdLoadFile:
            result.setInfo ("Load Audio File...", "Load an audio file for stem separation", "File", 0);
            result.addDefaultKeypress ('o', juce::ModifierKeys::commandModifier);
            break;
        case cmdSeparate:
            result.setInfo ("Separate Into Stems", "Separate file into stems for playback", "File", 0);
            result.addDefaultKeypress ('s', juce::ModifierKeys::commandModifier | juce::ModifierKeys::shiftModifier);
            result.setActive (hasLoadedFile && ! isExporting.load());
            break;
        case cmdBatchProcess:
            result.setInfo ("Batch Process...", "Process multiple audio files into stems", "File", 0);
            result.addDefaultKeypress ('b', juce::ModifierKeys::commandModifier | juce::ModifierKeys::shiftModifier);
            result.setActive (! isExporting.load());
            break;
        case cmdSaveProject:
            result.setInfo ("Save Project", "Quick save to current project file", "File", 0);
            result.addDefaultKeypress ('s', juce::ModifierKeys::commandModifier);
            result.setActive (hasLoadedFile || hasSeparatedStems);
            break;
        case cmdSaveProjectAs:
            result.setInfo ("Save Project As...", "Save project as new .stemperator file", "File", 0);
            result.addDefaultKeypress ('s', juce::ModifierKeys::commandModifier | juce::ModifierKeys::shiftModifier);
            result.setActive (hasLoadedFile || hasSeparatedStems);
            break;
        case cmdLoadProject:
            result.setInfo ("Load Project...", "Load a .stemperator project file", "File", 0);
            result.addDefaultKeypress ('o', juce::ModifierKeys::commandModifier | juce::ModifierKeys::shiftModifier);
            break;
        case cmdExportAllStems:
            {
                int numStems = processor.getNumStems();
                juce::String label = "Export " + juce::String (numStems) + " Stems...";
                result.setInfo (label, "Export all separated stems to files", "Export", 0);
                result.addDefaultKeypress ('e', juce::ModifierKeys::commandModifier | juce::ModifierKeys::shiftModifier);
                result.setActive (hasLoadedFile);
            }
            break;
        case cmdExportVocals:
            result.setInfo ("Export Vocals...", "Export vocals stem", "Export", 0);
            result.setActive (hasLoadedFile);
            break;
        case cmdExportDrums:
            result.setInfo ("Export Drums...", "Export drums stem", "Export", 0);
            result.setActive (hasLoadedFile);
            break;
        case cmdExportBass:
            result.setInfo ("Export Bass...", "Export bass stem", "Export", 0);
            result.setActive (hasLoadedFile);
            break;
        case cmdExportOther:
            result.setInfo ("Export Other...", "Export other/instruments stem", "Export", 0);
            result.setActive (hasLoadedFile);
            break;
        case cmdExportGuitar:
            result.setInfo ("Export Guitar...", "Export guitar stem (6-stem model)", "Export", 0);
            result.setActive (hasLoadedFile && processor.getNumStems() == 6);
            break;
        case cmdExportPiano:
            result.setInfo ("Export Piano...", "Export piano stem (6-stem model)", "Export", 0);
            result.setActive (hasLoadedFile && processor.getNumStems() == 6);
            break;
        case cmdExportMix:
            result.setInfo ("Export Mix...", "Export stems merged with current volume/mute settings", "Export", 0);
            result.addDefaultKeypress ('m', juce::ModifierKeys::commandModifier | juce::ModifierKeys::shiftModifier);
            result.setActive (hasSeparatedStems);
            break;
        case cmdResetStems:
            result.setInfo ("Reset All Faders", "Reset all stem faders to 0 dB", "Edit", 0);
            break;
        case cmdDeleteStems:
            result.setInfo ("Delete STEMS...", "Delete separated stems from memory and disk", "Edit", 0);
            result.setActive (hasSeparatedStems);
            break;
        case cmdUndo:
            {
                juce::String undoLabel = hasUndoableAction ? "Undo " + undoActionName : "Undo";
                result.setInfo (undoLabel, "Undo last action", "Edit", 0);
                result.addDefaultKeypress ('z', juce::ModifierKeys::commandModifier);
                result.setActive (hasUndoableAction);
            }
            break;
        case cmdRedo:
            result.setInfo ("Redo", "Redo last undone action", "Edit", 0);
            result.addDefaultKeypress ('z', juce::ModifierKeys::commandModifier | juce::ModifierKeys::shiftModifier);
            result.setActive (false);  // We don't support redo in our simple implementation
            break;
        case cmdQuit:
            result.setInfo ("Quit", "Exit the application", "File", 0);
            result.addDefaultKeypress ('q', juce::ModifierKeys::commandModifier);
            break;
        case cmdPlay:
            {
                // Smart play: stems if available, otherwise original
                juce::String playLabel = hasSeparatedStems ? "Play Stems" : "Play";
                juce::String playDesc = hasSeparatedStems
                    ? "Play separated stems (use mute/solo/volume controls)"
                    : "Play the loaded audio file";
                result.setInfo (playLabel, playDesc, "Transport", 0);
                result.addDefaultKeypress (juce::KeyPress::spaceKey, juce::ModifierKeys::noModifiers);
                result.setActive (hasLoadedFile || hasSeparatedStems);
            }
            break;
        case cmdStop:
            result.setInfo ("Stop", "Stop playback", "Transport", 0);
            result.setActive (hasLoadedFile || hasSeparatedStems);
            break;
        case cmdAbout:
            result.setInfo ("About Stemperator", "Show application info", "Help", 0);
            break;
        case cmdUISettings:
            result.setInfo ("UI Settings...", "Configure font sizes and UI appearance", "Help", 0);
            break;
        default:
            break;
    }
}

bool StemperatorEditor::perform (const juce::ApplicationCommandTarget::InvocationInfo& info)
{
    switch (info.commandID)
    {
        case cmdLoadFile:
            loadAudioFile();
            return true;
        case cmdSeparate:
            separateCurrentFile();
            return true;
        case cmdBatchProcess:
            batchProcessFiles();
            return true;
        case cmdExportAllStems:
            exportStems (-1);
            return true;
        case cmdExportVocals:
            exportStems (0);
            return true;
        case cmdExportDrums:
            exportStems (1);
            return true;
        case cmdExportBass:
            exportStems (2);
            return true;
        case cmdExportOther:
            exportStems (3);
            return true;
        case cmdExportGuitar:
            exportStems (4);  // Guitar is stem index 4 in 6-stem model
            return true;
        case cmdExportPiano:
            exportStems (5);  // Piano is stem index 5 in 6-stem model
            return true;
        case cmdExportMix:
            exportMixedStems();
            return true;
        case cmdSaveProject:
            saveProject();
            return true;
        case cmdSaveProjectAs:
            saveProjectAs();
            return true;
        case cmdLoadProject:
            loadProject();
            return true;
        case cmdResetStems:
            // Reset all stem faders to 0 dB using the RESET button handler
            if (resetAllButton.onClick)
                resetAllButton.onClick();
            return true;
        case cmdDeleteStems:
            deleteStems();
            return true;
        case cmdUndo:
            performUndo();
            return true;
        case cmdRedo:
            // Not implemented - we only have simple single-action undo
            return true;
        case cmdQuit:
            if (projectNeedsSave)
            {
                // Show styled save prompt dialog in huisstijl
                new SavePromptDialog ("Unsaved Changes",
                    "You have unsaved changes.\nDo you want to save before quitting?",
                    [this] (int result)
                    {
                        if (result == 0)  // Save
                        {
                            // If we have a current project file, save directly and quit
                            if (currentProjectFile.existsAsFile())
                            {
                                saveProjectToFile (currentProjectFile);
                                juce::JUCEApplication::getInstance()->systemRequestedQuit();
                            }
                            else
                            {
                                // Need to show Save As dialog - set flag to quit after save
                                quitAfterSave = true;
                                saveProjectAs();
                            }
                        }
                        else if (result == 1)  // Don't Save
                        {
                            projectNeedsSave = false;  // Allow quit without saving
                            juce::JUCEApplication::getInstance()->systemRequestedQuit();
                        }
                        // result == 2 is Cancel - do nothing
                    });
            }
            else
            {
                juce::JUCEApplication::getInstance()->systemRequestedQuit();
            }
            return true;
        case cmdPlay:
            // Smart play/pause toggle: stems if available, otherwise original
            {
                // If already playing, pause (toggle)
                if (transportSource.isPlaying())
                {
                    transportSource.stop();
                    return true;
                }

                bool needsSetup = (transportSource.getTotalLength() == 0);

                if (needsSetup)
                {
                    transportSource.stop();
                    if (hasSeparatedStems)
                    {
                        // Play separated stems with mute/solo/volume controls
                        if (! stemMixerSource)
                            stemMixerSource = std::make_unique<StemMixerSource> (separatedStems, processor);
                        transportSource.setSource (stemMixerSource.get(), 0, nullptr, loadedSampleRate);
                    }
                    else if (readerSource)
                    {
                        // Play original audio file
                        transportSource.setSource (readerSource.get(), 0, nullptr, loadedSampleRate);
                    }
                    // Connect to processor for audio output
                    if (isStandalone())
                        processor.setPlaybackSource (&transportSource);
                    transportSource.setPosition (0.0);
                }
                transportSource.start();
            }
            return true;
        case cmdStop:
            transportSource.stop();
            transportSource.setPosition (0.0);
            return true;
        case cmdAbout:
        {
            // Show custom borderless About overlay
            auto* aboutOverlay = new AboutOverlay (processor);
            addAndMakeVisible (aboutOverlay);
            aboutOverlay->setBounds (getLocalBounds());
            aboutOverlay->toFront (true);
            aboutOverlay->grabKeyboardFocus();
            return true;
        }
        case cmdUISettings:
        {
            // Open UI Settings dialog - changes apply in real-time via callback
            new UISettingsDialog (
                [this]()
                {
                    updateFontSizes();
                    repaint();
                },
                [this]()
                {
                    // Quit callback - trigger proper quit flow with unsaved project check
                    commandManager.invokeDirectly (cmdQuit, false);
                });
            return true;
        }
        default:
            return false;
    }
}

//==============================================================================
// Helper to update window title in standalone mode
static void updateWindowTitle (juce::Component* component, const juce::String& title)
{
    // Find the top-level DocumentWindow and set its name
    auto* topLevel = component->getTopLevelComponent();
    if (auto* docWindow = dynamic_cast<juce::DocumentWindow*> (topLevel))
        docWindow->setName (title);
}

//==============================================================================
// Central window title management
void StemperatorEditor::refreshWindowTitle()
{
    juce::String title = "Stemperator";

    // Add filename if loaded
    if (hasLoadedFile && currentAudioFile.exists())
    {
        title += " - " + currentAudioFile.getFileNameWithoutExtension();

        // Add [STEMMED] if stems exist (in any mode)
        if (hasSeparatedStems)
            title += " [STEMMED]";
    }

    // Add unsaved indicator
    if (projectNeedsSave)
        title += " *";

    updateWindowTitle (this, title);
}

//==============================================================================
// File handling
void StemperatorEditor::loadAudioFile()
{
    // Check for unsaved project first
    if (projectNeedsSave)
    {
        new SavePromptDialog ("Unsaved Changes",
            "You have unsaved changes.\nDo you want to save before loading a new file?",
            [this] (int result)
            {
                if (result == 0)  // Save
                {
                    if (currentProjectFile.existsAsFile())
                    {
                        saveProjectToFile (currentProjectFile);
                        loadAudioFile();  // Retry after save
                    }
                    else
                    {
                        saveProjectAs();
                    }
                }
                else if (result == 1)  // Don't Save
                {
                    projectNeedsSave = false;
                    loadAudioFile();  // Proceed with load
                }
                // result == 2 is Cancel - do nothing
            });
        return;
    }

    // Use native file dialog with common audio formats including MP3
    fileChooser = std::make_unique<juce::FileChooser> (
        "Select an audio file to separate...",
        lastAudioFolder.exists() ? lastAudioFolder : juce::File::getSpecialLocation (juce::File::userMusicDirectory),
        "*.wav;*.mp3;*.flac;*.aiff;*.aif;*.ogg;*.m4a;*.wma;*.opus",
        true);  // useNativeDialogs = true for speed

    auto chooserFlags = juce::FileBrowserComponent::openMode | juce::FileBrowserComponent::canSelectFiles;

    fileChooser->launchAsync (chooserFlags, [this] (const juce::FileChooser& c)
    {
        auto file = c.getResult();
        if (file != juce::File())
        {
            lastAudioFolder = file.getParentDirectory();
            loadAudioFile (file);
        }
    });
}

void StemperatorEditor::loadAudioFile (const juce::File& file)
{
    if (! file.existsAsFile())
        return;

    // Prevent loading while processing
    if (isExporting.load())
    {
        StyledDialogWindow::showMessageBoxAsync (
            juce::MessageBoxIconType::WarningIcon,
            "Busy",
            "Cannot load audio file while processing.\nPlease wait for current operation to complete or press Escape to cancel.");
        return;
    }

    // Stop any current playback first to avoid race conditions
    transportSource.stop();
    transportSource.setSource (nullptr);

    // Disconnect from processor
    if (isStandalone())
        processor.setPlaybackSource (nullptr);

    // Clear old sources
    readerSource.reset();
    stemMixerSource.reset();

    // Update UI immediately
    if (fileNameLabel)
        fileNameLabel->setText ("Loading: " + file.getFileName(), juce::dontSendNotification);

    auto* reader = formatManager->createReaderFor (file);
    if (reader != nullptr)
    {
        currentAudioFile = file;
        hasLoadedFile = true;
        projectNeedsSave = true;  // Mark as needing save
        loadedSampleRate = reader->sampleRate;

        // Load entire file into buffer for processing
        loadedAudioBuffer.setSize ((int) reader->numChannels, (int) reader->lengthInSamples);
        reader->read (&loadedAudioBuffer, 0, (int) reader->lengthInSamples, 0, true, true);

        // Setup transport source for playback
        readerSource = std::make_unique<juce::AudioFormatReaderSource> (reader, true);
        transportSource.setSource (readerSource.get(), 0, nullptr, reader->sampleRate);

        // Connect transport to processor for audio output (standalone only)
        if (isStandalone())
            processor.setPlaybackSource (&transportSource);

        // Update UI with colorful LIVE message
        setLiveLoadedMessage();

        // Update window title with filename
        refreshWindowTitle();

        commandManager.commandStatusChanged();

        // Show duration in time label
        auto duration = loadedAudioBuffer.getNumSamples() / reader->sampleRate;
        auto minutes = (int) (duration / 60.0);
        auto seconds = (int) duration % 60;

        if (transportBar)
            transportBar->setTimeText ("0:00 / " + juce::String (minutes) + ":" +
                juce::String (seconds).paddedLeft ('0', 2));

        // Clear any previous separated stems
        hasSeparatedStems = false;
        playingStemsMode = false;  // Start in LIVE mode for new audio
        processor.setSkipSeparation (false);  // Enable spectral separation for original audio

        // Calculate loudness normalization gain (for playback only, not export)
        calculateNormalizationGain();
        processor.setNormalizationGain (normalizeGain);

        // Update mode indicator
        updateModeIndicator();

        // Grab keyboard focus so Space works for play/pause
        grabKeyboardFocus();
    }
    else
    {
        StyledDialogWindow::showMessageBoxAsync (
            juce::MessageBoxIconType::WarningIcon,
            "Load Failed",
            "Could not load: " + file.getFileName() + "\n\n"
            "Supported formats:\n"
            "  WAV, FLAC, AIFF, OGG, MP3, M4A, WMA, OPUS\n\n"
            "Make sure the file is not corrupted and is a valid audio file.");
    }
}

//==============================================================================
// Loudness normalization - calculates gain to bring track to target LUFS
// This is for PLAYBACK ONLY - export files are never affected
void StemperatorEditor::calculateNormalizationGain()
{
    if (loadedAudioBuffer.getNumSamples() == 0)
    {
        normalizeGain = 1.0f;
        measuredLUFS = targetLUFS;
        return;
    }

    // Calculate RMS-based loudness approximation (simplified LUFS)
    // True LUFS requires K-weighting filter, but RMS is close enough for normalization
    double sumSquares = 0.0;
    int numChannels = loadedAudioBuffer.getNumChannels();
    int numSamples = loadedAudioBuffer.getNumSamples();

    for (int ch = 0; ch < numChannels; ++ch)
    {
        const float* data = loadedAudioBuffer.getReadPointer (ch);
        for (int i = 0; i < numSamples; ++i)
            sumSquares += (double) data[i] * (double) data[i];
    }

    double rms = std::sqrt (sumSquares / (double) (numSamples * numChannels));

    // Convert RMS to approximate LUFS (RMS in dB - 0.691 is the K-weighting offset approximation)
    // For stereo music, RMS dB ≈ LUFS + 3 dB (rough approximation)
    float rmsDb = (rms > 0.0001f) ? (float) (20.0 * std::log10 (rms)) : -60.0f;
    measuredLUFS = rmsDb - 3.0f;  // Approximate LUFS from RMS

    // Calculate gain needed to reach target
    float gainDb = targetLUFS - measuredLUFS;

    // Clamp gain to prevent extreme boosting of very quiet tracks
    gainDb = juce::jlimit (-12.0f, maxNormalizeGain, gainDb);

    normalizeGain = juce::Decibels::decibelsToGain (gainDb);

    // Debug output
    std::cerr << "Loudness normalization: measured " << measuredLUFS << " LUFS, "
              << "target " << targetLUFS << " LUFS, "
              << "applying " << gainDb << " dB gain" << std::endl;
}

void StemperatorEditor::exportStems (int stemIndex)
{
    if (! hasLoadedFile)
    {
        StyledDialogWindow::showMessageBoxAsync (
            juce::MessageBoxIconType::WarningIcon,
            "No File Loaded",
            "Please load an audio file first using File > Load Audio File");
        return;
    }

    juce::String title = (stemIndex < 0) ? "Select folder for stem export" : "Save " + juce::String (StemperatorProcessor::stemNames[stemIndex]) + " stem";
    juce::String defaultName = currentAudioFile.getFileNameWithoutExtension();

    if (stemIndex < 0)
    {
        // Export all stems - choose folder
        // Priority: defaultStemFolder (user setting) → lastStemFolder → audio file directory
        juce::File baseFolder;
        if (defaultStemFolder.exists())
            baseFolder = defaultStemFolder;
        else if (lastStemFolder.exists())
            baseFolder = lastStemFolder.getParentDirectory();  // Go up from /tmp/song_stems to /tmp
        else
            baseFolder = currentAudioFile.getParentDirectory();
        juce::File startFolder = baseFolder.getChildFile (defaultName + "_stems");

        // Use openMode for directory selection (more compatible on Linux)
        fileChooser = std::make_unique<juce::FileChooser> (
            title,
            startFolder,
            "",
            true);  // useNativeDialogs

        fileChooser->launchAsync (juce::FileBrowserComponent::openMode | juce::FileBrowserComponent::canSelectDirectories,
            [this] (const juce::FileChooser& c)
            {
                auto folder = c.getResult();

                if (folder == juce::File())
                    return;

                // Create folder if needed
                folder.createDirectory();

                // Show progress
                if (fileNameLabel)
                    fileNameLabel->setText ("Preparing AI separation...", juce::dontSendNotification);

                // Copy data for thread safety
                auto bufferCopy = std::make_shared<juce::AudioBuffer<float>> (loadedAudioBuffer);
                auto sampleRate = loadedSampleRate;
                auto inputFile = currentAudioFile;

                // Get quality setting - maps to model selection
                int qualityIndex = currentQuality;
                const char* qualityNames[] = { "Fast", "Balanced", "Best" };
                juce::String qualityName = qualityNames[qualityIndex];

                // Map quality to Demucs model
                juce::String modelName;
                if (qualityIndex == 0)
                    modelName = "htdemucs";       // Fast
                else if (qualityIndex == 1)
                    modelName = "htdemucs";       // Balanced (same model, good balance)
                else
                    modelName = "htdemucs_ft";    // Best (fine-tuned, slower but better)

                juce::Thread::launch ([this, folder, bufferCopy, sampleRate, inputFile, qualityName, modelName]()
                {
                    // Set export state
                    isExporting.store (true);
                    cancelExport.store (false);
                    exportProgress.store (0.0f);
                    for (auto& level : exportStemLevels)
                        level.store (0.0f);

                    try
                    {
                        auto startTime = juce::Time::getMillisecondCounterHiRes();

                        const int totalSamples = bufferCopy->getNumSamples();
                        double audioDurationSec = (double) totalSamples / sampleRate;
                        int mins = (int) (audioDurationSec / 60.0);
                        int secs = (int) audioDurationSec % 60;
                        juce::String durationStr = juce::String (mins) + ":" + juce::String (secs).paddedLeft ('0', 2);

                        // Find the Python environment
                        auto pyEnv = findPythonEnvironment();
                        bool useAI = pyEnv.isValid();
                        juce::String accelInfo = useAI ? "Demucs AI (" + modelName + ")" : "Spectral (AI unavailable)";

                        // Debug output
                        std::cerr << "Export All - useAI: " << (useAI ? "yes" : "no")
                                  << " pythonExe: " << pyEnv.pythonExe.getFullPathName().toStdString() << std::endl;

                        // Show initial status - reset to standard label first for progress display
                        juce::MessageManager::callAsync ([this, accelInfo, qualityName, durationStr]()
                        {
                            resetFileNameLabel();
                            if (fileNameLabel)
                            {
                                fileNameLabel->setText ("Separating " + durationStr + " | " + qualityName + " | " + accelInfo + " | ESC=cancel", juce::dontSendNotification);
                                fileNameLabel->setTooltip ("Starting AI stem separation.\n"
                                    "Duration: " + durationStr + "\n"
                                    "Quality: " + qualityName + "\n"
                                    "Acceleration: " + accelInfo + "\n\n"
                                    "Press ESC to cancel.");
                            }
                        });

                        const char* stemNames[] = { "Vocals", "Drums", "Bass", "Other", "Guitar", "Piano" };
                        const char* stemFileNames[] = { "vocals", "drums", "bass", "other", "guitar", "piano" };
                        std::array<float, 6> peakLevels = { 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f };
                        std::array<juce::int64, 6> fileSizes = { 0, 0, 0, 0, 0, 0 };
                        int savedCount = 0;
                        bool is6Stem = processor.is6StemModel();
                        int numStemsToProcess = is6Stem ? 6 : 4;
                        bool wasCancelled = false;

                        if (useAI)
                        {
                            // === AI-BASED SEPARATION (Demucs) ===

                            // Create a temp directory for processing
                            auto tempDir = juce::File::getSpecialLocation (juce::File::tempDirectory)
                                              .getChildFile ("stemperator_" + juce::String (juce::Random::getSystemRandom().nextInt64()));
                            tempDir.createDirectory();

                            // Save input audio to temp WAV file
                            auto tempInputFile = tempDir.getChildFile ("input.wav");

                            juce::MessageManager::callAsync ([this]()
                            {
                                if (fileNameLabel)
                                {
                                    fileNameLabel->setText ("Saving audio for AI processing...", juce::dontSendNotification);
                                    fileNameLabel->setTooltip ("Preparing audio for AI model.\n"
                                        "Converting to WAV format for Demucs processing.\n\n"
                                        "This may take a moment for longer files.");
                                }
                            });

                            // Write input to temp file
                            {
                                juce::WavAudioFormat wavFormat;
                                auto outputStream = std::make_unique<juce::FileOutputStream> (tempInputFile);
                                if (outputStream->openedOk())
                                {
                                    auto writer = std::unique_ptr<juce::AudioFormatWriter> (
                                        wavFormat.createWriterFor (
                                            outputStream.release(),
                                            sampleRate,
                                            static_cast<unsigned int> (std::min (2, bufferCopy->getNumChannels())),
                                            24, {}, 0));

                                    if (writer)
                                        writer->writeFromAudioSampleBuffer (*bufferCopy, 0, bufferCopy->getNumSamples());
                                }
                            }

                            exportProgress.store (0.1f);

                            // Check for cancel
                            if (cancelExport.load())
                            {
                                wasCancelled = true;
                                tempDir.deleteRecursively();
                            }
                            else
                            {
                                // Run separation via Python subprocess
                                juce::MessageManager::callAsync ([this, modelName]()
                                {
                                    resetFileNameLabel();
                                    if (fileNameLabel)
                                    {
                                        fileNameLabel->setText ("Processing (" + modelName + ")... | ESC=cancel", juce::dontSendNotification);
                                        fileNameLabel->setTooltip ("Running Demucs AI separation.\n\n"
                                            "Model: " + modelName + "\n\n"
                                            "The AI neural network is analyzing the audio\n"
                                            "and separating it into individual stems.\n\n"
                                            "This is the most time-consuming step.\n"
                                            "Press ESC to cancel.");
                                    }
                                });

                                // Animate stem levels during processing
                                for (int i = 0; i < 6; ++i)
                                    exportStemLevels[i].store (0.3f);

                                // Build command arguments as StringArray for proper handling of spaces
                                // -u flag enables unbuffered stdout for real-time progress output
                                juce::StringArray args;
                                args.add (pyEnv.pythonExe.getFullPathName());
                                args.add ("-u");
                                args.add (pyEnv.separatorScript.getFullPathName());
                                args.add (tempInputFile.getFullPathName());
                                args.add (tempDir.getFullPathName());
                                args.add ("--model");
                                args.add (modelName);

                                std::cerr << "Export args: " << args.joinIntoString (" | ").toStdString() << std::endl;
                                std::cerr << "Temp input file exists: " << (tempInputFile.existsAsFile() ? "yes" : "no")
                                          << " size: " << tempInputFile.getSize() << std::endl;

                                // Run the separation process
                                juce::ChildProcess process;
                                bool started = process.start (args);

                                if (started)
                                {
                                    // Wait for completion with real progress from Python
                                    int currentPercent = 10;
                                    juce::String currentStage = "Starting";
                                    juce::String processOutput;

                                    while (process.isRunning())
                                    {
                                        // Check for cancel
                                        if (cancelExport.load())
                                        {
                                            process.kill();
                                            wasCancelled = true;
                                            break;
                                        }

                                        // Read available output from process (progress lines)
                                        char buffer[256];
                                        auto bytesRead = process.readProcessOutput (buffer, sizeof (buffer) - 1);
                                        if (bytesRead > 0)
                                        {
                                            buffer[bytesRead] = '\0';
                                            processOutput += buffer;

                                            // Parse progress lines: PROGRESS:<percent>:<stage>
                                            while (processOutput.contains ("\n"))
                                            {
                                                auto newlinePos = processOutput.indexOf ("\n");
                                                auto line = processOutput.substring (0, newlinePos).trim();
                                                processOutput = processOutput.substring (newlinePos + 1);

                                                if (line.startsWith ("PROGRESS:"))
                                                {
                                                    // Format: PROGRESS:<percent>:<stage>
                                                    // Stage may contain colons (e.g., "AI (0:15 | ETA 1:30)")
                                                    // So we only split on the first colon after PROGRESS:
                                                    auto content = line.substring (9);  // After "PROGRESS:"
                                                    auto colonPos = content.indexOf (":");
                                                    if (colonPos > 0)
                                                    {
                                                        currentPercent = content.substring (0, colonPos).getIntValue();
                                                        currentStage = content.substring (colonPos + 1);
                                                    }
                                                    else
                                                    {
                                                        currentPercent = content.getIntValue();
                                                    }
                                                }
                                            }
                                        }

                                        // Update progress display
                                        exportProgress.store (currentPercent / 100.0f);

                                        // Animate stem levels based on progress
                                        float animPhase = currentPercent / 100.0f;
                                        for (int i = 0; i < 6; ++i)
                                        {
                                            float level = 0.3f + 0.4f * std::sin (animPhase * 10.0f + i * 1.5f);
                                            exportStemLevels[i].store (std::max (0.1f, level));
                                        }

                                        // Python script now provides timing info in currentStage
                                        juce::String status = juce::String (currentPercent) + "% | " + currentStage + " | ESC=cancel";
                                        int pct = currentPercent;

                                        juce::MessageManager::callAsync ([this, status, pct]()
                                        {
                                            if (fileNameLabel)
                                            {
                                                fileNameLabel->setText (status, juce::dontSendNotification);
                                                fileNameLabel->setTooltip ("AI Separation Progress: " + juce::String (pct) + "%\n\n"
                                                    "The neural network is processing the audio.\n"
                                                    "Speed depends on your CPU/GPU and audio length.\n\n"
                                                    "Press ESC to cancel the operation.");
                                            }
                                        });

                                        juce::Thread::sleep (100);
                                    }

                                    if (! wasCancelled)
                                    {
                                        // Read output from Python (JSON with file paths)
                                        juce::String output = process.readAllProcessOutput();
                                        int exitCode = process.getExitCode();

                                        if (exitCode == 0)
                                        {
                                            exportProgress.store (0.9f);

                                            // Copy stems to output folder
                                            juce::MessageManager::callAsync ([this]()
                                            {
                                                if (fileNameLabel)
                                                    fileNameLabel->setText ("Copying stems to output folder...", juce::dontSendNotification);
                                            });

                                            juce::AudioFormatManager formatMgr;
                                            formatMgr.registerBasicFormats();

                                            // Get original filename without extension for naming stems
                                            auto baseFileName = inputFile.getFileNameWithoutExtension();

                                            // Loop through all 6 stems - non-existent stems (4-stem model) will be skipped
                                            for (int i = 0; i < 6; ++i)
                                            {
                                                auto stemSrcFile = tempDir.getChildFile (juce::String (stemFileNames[i]) + ".wav");
                                                // Name stems as: originalfilename_stemname.wav
                                                auto stemDstFile = folder.getChildFile (baseFileName + "_" + juce::String (stemFileNames[i]) + ".wav");

                                                if (stemSrcFile.existsAsFile())
                                                {
                                                    // Read the stem file to get peak level
                                                    auto* reader = formatMgr.createReaderFor (stemSrcFile);
                                                    if (reader)
                                                    {
                                                        juce::AudioBuffer<float> stemBuffer ((int) reader->numChannels, (int) reader->lengthInSamples);
                                                        reader->read (&stemBuffer, 0, (int) reader->lengthInSamples, 0, true, true);

                                                        // Calculate peak
                                                        for (int ch = 0; ch < stemBuffer.getNumChannels(); ++ch)
                                                            peakLevels[static_cast<size_t> (i)] = std::max (peakLevels[static_cast<size_t> (i)], stemBuffer.getMagnitude (ch, 0, stemBuffer.getNumSamples()));

                                                        delete reader;
                                                    }

                                                    // Copy file to output folder
                                                    stemDstFile.deleteFile();
                                                    stemSrcFile.copyFileTo (stemDstFile);
                                                    fileSizes[static_cast<size_t> (i)] = stemDstFile.getSize();
                                                    savedCount++;

                                                    // Update visual feedback
                                                    exportStemLevels[static_cast<size_t> (i)].store (std::min (1.0f, peakLevels[static_cast<size_t> (i)] * 3.0f));
                                                }
                                            }

                                            // Check if any stems were actually saved
                                            if (savedCount == 0)
                                            {
                                                wasCancelled = true;

                                                // List files in temp dir for debugging
                                                juce::StringArray tempFiles;
                                                for (const auto& file : tempDir.findChildFiles (juce::File::findFiles, false))
                                                    tempFiles.add (file.getFileName());

                                                juce::MessageManager::callAsync ([this, tempFiles, output]()
                                                {
                                                    juce::String debugInfo = "Expected stems: vocals.wav, drums.wav, bass.wav, other.wav\n";
                                                    debugInfo += "Files found in temp dir: " + tempFiles.joinIntoString (", ") + "\n\n";
                                                    debugInfo += "Python output:\n" + output.substring (0, 500);
                                                    StyledDialogWindow::showMessageBoxAsync (
                                                        juce::MessageBoxIconType::WarningIcon,
                                                        "AI Separation Failed",
                                                        "AI reported success but no stem files were created.\n\n" + debugInfo);
                                                });
                                            }
                                        }
                                        else
                                        {
                                            // AI failed - mark as cancelled to prevent success dialog
                                            wasCancelled = true;

                                            juce::MessageManager::callAsync ([this, output, exitCode]()
                                            {
                                                StyledDialogWindow::showMessageBoxAsync (
                                                    juce::MessageBoxIconType::WarningIcon,
                                                    "AI Separation Failed",
                                                    "The AI model returned an error (exit code " + juce::String (exitCode) + ").\n\n"
                                                    "Check that audio-separator is installed correctly.\n\n"
                                                    "Output: " + output.substring (0, 500));
                                            });
                                        }
                                    }
                                }
                                else
                                {
                                    // Failed to start process
                                    juce::MessageManager::callAsync ([this]()
                                    {
                                        StyledDialogWindow::showMessageBoxAsync (
                                            juce::MessageBoxIconType::WarningIcon,
                                            "AI Separation Unavailable",
                                            "Could not start the AI separation process.\n\n"
                                            "Make sure the Python virtual environment is set up:\n"
                                            "cd /path/to/Stemperator && python3 -m venv .venv\n"
                                            ".venv/bin/pip install audio-separator[gpu]");
                                    });
                                    wasCancelled = true;
                                }

                                // Clean up temp directory
                                tempDir.deleteRecursively();
                            }
                        }
                        else
                        {
                            // === FALLBACK: SPECTRAL SEPARATION ===
                            // (When AI is not available)

                            const int numChannels = std::min (2, bufferCopy->getNumChannels());
                            const int blockSize = 2048;
                            const int totalBlocks = (totalSamples + blockSize - 1) / blockSize;

#if USE_HIP || USE_OPENCL
                            GPUStemSeparator gpuSeparator;
                            gpuSeparator.prepare (sampleRate, blockSize);
                            bool useGPU = gpuSeparator.isUsingGPU();
#else
                            bool useGPU = false;
#endif
                            StemSeparator cpuSeparator;
                            cpuSeparator.prepare (sampleRate, blockSize);

                            std::array<juce::AudioBuffer<float>, 4> outputStems;
                            for (auto& stem : outputStems)
                            {
                                stem.setSize (numChannels, totalSamples);
                                stem.clear();
                            }

                            int blockCount = 0;

                            for (int startSample = 0; startSample < totalSamples; startSample += blockSize)
                            {
                                if (cancelExport.load())
                                {
                                    wasCancelled = true;
                                    break;
                                }

                                int samplesToProcess = std::min (blockSize, totalSamples - startSample);

                                juce::AudioBuffer<float> blockBuffer (numChannels, samplesToProcess);
                                for (int ch = 0; ch < numChannels; ++ch)
                                    blockBuffer.copyFrom (ch, 0, *bufferCopy, ch, startSample, samplesToProcess);

                                std::array<juce::AudioBuffer<float>, 4>* stemsPtr;
#if USE_HIP || USE_OPENCL
                                if (useGPU)
                                {
                                    gpuSeparator.process (blockBuffer);
                                    stemsPtr = &gpuSeparator.getStems();
                                }
                                else
#endif
                                {
                                    cpuSeparator.process (blockBuffer);
                                    stemsPtr = &cpuSeparator.getStems();
                                }
                                auto& stems = *stemsPtr;

                                for (int stemIdx = 0; stemIdx < 4; ++stemIdx)
                                {
                                    int samplesToCopy = std::min (samplesToProcess, stems[stemIdx].getNumSamples());
                                    for (int ch = 0; ch < numChannels; ++ch)
                                    {
                                        if (samplesToCopy > 0)
                                        {
                                            outputStems[stemIdx].copyFrom (ch, startSample, stems[stemIdx], ch, 0, samplesToCopy);
                                            float peak = stems[stemIdx].getMagnitude (ch, 0, samplesToCopy);
                                            peakLevels[stemIdx] = std::max (peakLevels[stemIdx], peak);
                                        }
                                    }
                                    float currentLevel = stems[stemIdx].getMagnitude (0, 0, std::min (samplesToProcess, stems[stemIdx].getNumSamples()));
                                    exportStemLevels[stemIdx].store (std::min (1.0f, currentLevel * 3.0f));
                                }

                                blockCount++;
                                float progress = (float) blockCount / (float) totalBlocks;
                                exportProgress.store (progress);

                                if (blockCount % 5 == 0 || blockCount == totalBlocks)
                                {
                                    int percent = (int) (progress * 100.0f);
                                    double elapsed = (juce::Time::getMillisecondCounterHiRes() - startTime) / 1000.0;
                                    double eta = elapsed > 0.1 ? (elapsed / progress) - elapsed : 0.0;

                                    juce::String status = juce::String (percent) + "% | ETA: " + juce::String ((int) eta) + "s | ESC=cancel";

                                    juce::MessageManager::callAsync ([this, status]()
                                    {
                                        if (fileNameLabel)
                                            fileNameLabel->setText (status, juce::dontSendNotification);
                                    });
                                }
                            }

                            // Save stems
                            if (! wasCancelled)
                            {
                                juce::WavAudioFormat wavFormat;
                                auto baseFileName = inputFile.getFileNameWithoutExtension();

                                for (int i = 0; i < 4; ++i)
                                {
                                    if (outputStems[i].getNumSamples() == 0)
                                        continue;

                                    // Name stems as: originalfilename_stemname.wav
                                    auto stemFile = folder.getChildFile (baseFileName + "_" + juce::String (stemFileNames[i]) + ".wav");
                                    stemFile.deleteFile();

                                    auto outputStream = std::make_unique<juce::FileOutputStream> (stemFile);
                                    if (outputStream->openedOk())
                                    {
                                        auto writer = std::unique_ptr<juce::AudioFormatWriter> (
                                            wavFormat.createWriterFor (
                                                outputStream.release(),
                                                sampleRate,
                                                static_cast<unsigned int> (outputStems[i].getNumChannels()),
                                                24, {}, 0));

                                        if (writer)
                                        {
                                            writer->writeFromAudioSampleBuffer (outputStems[i], 0, outputStems[i].getNumSamples());
                                            savedCount++;
                                            fileSizes[i] = stemFile.getSize();
                                        }
                                    }
                                }
                            }
                        }

                        // Handle cancellation
                        if (wasCancelled)
                        {
                            isExporting.store (false);
                            juce::MessageManager::callAsync ([this]()
                            {
                                if (fileNameLabel)
                                    fileNameLabel->setText ("Export cancelled", juce::dontSendNotification);

                                // Show styled cancelled overlay
                                auto* overlay = new CancelledOverlay ("Export was cancelled by user.", nullptr);
                                addAndMakeVisible (overlay);
                                overlay->setBounds (getLocalBounds());
                                overlay->grabKeyboardFocus();
                            });
                            return;
                        }

                        // Calculate processing stats
                        double processingTime = (juce::Time::getMillisecondCounterHiRes() - startTime) / 1000.0;
                        double audioDuration = (double) totalSamples / sampleRate;
                        double speedMultiplier = audioDuration / processingTime;

                        // Build stats string
                        juce::String statsStr = "Separation complete!\n\n";
                        statsStr += "Method: " + accelInfo + "\n";
                        statsStr += "Duration: " + juce::String (audioDuration, 1) + "s processed in "
                                 + juce::String (processingTime, 1) + "s ("
                                 + juce::String (speedMultiplier, 2) + "x realtime)\n\n";
                        statsStr += "Stem Statistics:\n";

                        // Display stats for stems that were actually exported
                        for (int i = 0; i < 6; ++i)
                        {
                            if (fileSizes[static_cast<size_t> (i)] > 0)  // Only show stems that were exported
                            {
                                float peakDb = juce::Decibels::gainToDecibels (peakLevels[static_cast<size_t> (i)], -60.0f);
                                juce::String sizeStr = juce::File::descriptionOfSizeInBytes (fileSizes[static_cast<size_t> (i)]);
                                statsStr += "  " + juce::String (stemNames[i]) + ": Peak "
                                         + juce::String (peakDb, 1) + " dB | " + sizeStr + "\n";
                            }
                        }

                        statsStr += "\nExported to:\n" + folder.getFullPathName();

                        // Reset export state
                        isExporting.store (false);
                        for (auto& level : exportStemLevels)
                            level.store (0.0f);

                        // Remember the actual stems folder (not parent!) for Load Created Stems
                        lastStemFolder = folder;
                        saveSettings();

                        juce::MessageManager::callAsync ([this, folder, savedCount, statsStr]()
                        {
                            if (fileNameLabel)
                                fileNameLabel->setText (currentAudioFile.getFileName(), juce::dontSendNotification);

                            // Show styled Export Complete overlay (matching About screen style)
                            auto folderCopy = folder;
                            auto* overlay = new ExportCompleteOverlay (statsStr, folder,
                                [this, folderCopy] (int result)
                                {
                                    if (result == 1)  // "Play Stems" button
                                    {
                                        loadStemsAfterExport (folderCopy);
                                    }
                                    else if (result == 2)  // "Open Folder" button
                                    {
                                        #if JUCE_LINUX
                                        std::system (("xdg-open " + folderCopy.getFullPathName().quoted()).toRawUTF8());
                                        #else
                                        folderCopy.revealToUser();
                                        #endif
                                    }
                                    else if (result == 4)  // "Quit" button
                                    {
                                        juce::JUCEApplication::getInstance()->systemRequestedQuit();
                                    }
                                    // result == 3 is "OK" - do nothing
                                });
                            addAndMakeVisible (overlay);
                            overlay->setBounds (getLocalBounds());
                            overlay->toFront (true);
                            overlay->grabKeyboardFocus();
                        });
                    }
                    catch (...)
                    {
                        isExporting.store (false);
                        juce::MessageManager::callAsync ([this]()
                        {
                            if (fileNameLabel)
                                fileNameLabel->setText (currentAudioFile.getFileName(), juce::dontSendNotification);

                            StyledDialogWindow::showMessageBoxAsync (
                                juce::MessageBoxIconType::WarningIcon,
                                "Export Failed",
                                "An error occurred during stem separation.");
                        });
                    }
                });
            });
    }
    else
    {
        // Export single stem - use AI separation for best results
        fileChooser = std::make_unique<juce::FileChooser> (
            title,
            currentAudioFile.getParentDirectory().getChildFile (
                defaultName + "_" + StemperatorProcessor::stemNames[stemIndex] + ".wav"),
            "*.wav",
            true);  // useNativeDialogs

        // Get quality setting for model selection
        int qualityIndex = currentQuality;
        juce::String modelName;
        if (qualityIndex == 0)
            modelName = "htdemucs";       // Fast
        else if (qualityIndex == 1)
            modelName = "htdemucs";       // Balanced
        else
            modelName = "htdemucs_ft";    // Best

        fileChooser->launchAsync (juce::FileBrowserComponent::saveMode,
            [this, stemIndex, modelName] (const juce::FileChooser& c)
            {
                auto file = c.getResult();

                if (file == juce::File())
                    return;

                // Show progress
                if (fileNameLabel)
                    fileNameLabel->setText ("Preparing AI separation for " + juce::String (StemperatorProcessor::stemNames[stemIndex]) + "...", juce::dontSendNotification);

                auto bufferCopy = std::make_shared<juce::AudioBuffer<float>> (loadedAudioBuffer);
                auto sampleRate = loadedSampleRate;

                juce::Thread::launch ([this, stemIndex, file, bufferCopy, sampleRate, modelName]()
                {
                    isExporting.store (true);
                    cancelExport.store (false);

                    try
                    {
                        const char* stemFileNames[] = { "vocals", "drums", "bass", "other", "guitar", "piano" };
                        auto startTime = juce::Time::getMillisecondCounterHiRes();

                        // Find the Python environment
                        auto pyEnv = findPythonEnvironment();
                        bool useAI = pyEnv.isValid();

                        // Debug: log paths to stderr
                        std::cerr << "Project root: " << pyEnv.projectRoot.getFullPathName().toStdString() << std::endl;
                        std::cerr << "pythonExe: " << pyEnv.pythonExe.getFullPathName().toStdString()
                                  << " exists: " << (pyEnv.pythonExe.existsAsFile() ? "yes" : "no") << std::endl;
                        std::cerr << "useAI: " << (useAI ? "yes" : "no") << std::endl;

                        if (useAI)
                        {
                            // AI-based separation
                            auto tempDir = juce::File::getSpecialLocation (juce::File::tempDirectory)
                                              .getChildFile ("stemperator_" + juce::String (juce::Random::getSystemRandom().nextInt64()));
                            tempDir.createDirectory();

                            auto tempInputFile = tempDir.getChildFile ("input.wav");

                            // Show writing status
                            juce::MessageManager::callAsync ([this]()
                            {
                                if (fileNameLabel)
                                    fileNameLabel->setText ("Writing temp audio file...", juce::dontSendNotification);
                            });

                            // Write input to temp file
                            {
                                juce::WavAudioFormat wavFormat;
                                auto outputStream = std::make_unique<juce::FileOutputStream> (tempInputFile);
                                if (outputStream->openedOk())
                                {
                                    auto writer = std::unique_ptr<juce::AudioFormatWriter> (
                                        wavFormat.createWriterFor (
                                            outputStream.release(),
                                            sampleRate,
                                            static_cast<unsigned int> (std::min (2, bufferCopy->getNumChannels())),
                                            24, {}, 0));

                                    if (writer)
                                        writer->writeFromAudioSampleBuffer (*bufferCopy, 0, bufferCopy->getNumSamples());
                                }
                            }

                            juce::MessageManager::callAsync ([this, modelName]()
                            {
                                resetFileNameLabel();
                                if (fileNameLabel)
                                    fileNameLabel->setText ("Processing (" + modelName + ")... | ESC=cancel", juce::dontSendNotification);
                            });

                            // Build command arguments as StringArray for proper handling of spaces
                            // -u flag enables unbuffered stdout for real-time progress output
                            juce::StringArray args;
                            args.add (pyEnv.pythonExe.getFullPathName());
                            args.add ("-u");
                            args.add (pyEnv.separatorScript.getFullPathName());
                            args.add (tempInputFile.getFullPathName());
                            args.add (tempDir.getFullPathName());
                            args.add ("--model");
                            args.add (modelName);

                            juce::ChildProcess process;
                            bool started = process.start (args);
                            bool wasCancelled = false;

                            if (started)
                            {
                                while (process.isRunning())
                                {
                                    if (cancelExport.load())
                                    {
                                        process.kill();
                                        wasCancelled = true;
                                        break;
                                    }

                                    double elapsed = (juce::Time::getMillisecondCounterHiRes() - startTime) / 1000.0;
                                    juce::String status = "Processing... " + juce::String ((int) elapsed) + "s | ESC=cancel";

                                    juce::MessageManager::callAsync ([this, status]()
                                    {
                                        if (fileNameLabel)
                                            fileNameLabel->setText (status, juce::dontSendNotification);
                                    });

                                    juce::Thread::sleep (200);
                                }

                                if (! wasCancelled && process.getExitCode() == 0)
                                {
                                    // Copy the requested stem to output file
                                    auto stemSrcFile = tempDir.getChildFile (juce::String (stemFileNames[stemIndex]) + ".wav");
                                    if (stemSrcFile.existsAsFile())
                                    {
                                        file.deleteFile();
                                        stemSrcFile.copyFileTo (file);
                                    }
                                }
                            }

                            tempDir.deleteRecursively();

                            if (wasCancelled)
                            {
                                isExporting.store (false);
                                juce::MessageManager::callAsync ([this]()
                                {
                                    if (fileNameLabel)
                                        fileNameLabel->setText ("Export cancelled", juce::dontSendNotification);
                                });
                                return;
                            }
                        }
                        else
                        {
                            // Fallback to spectral separation
                            StemSeparator separator;

                            const int totalSamples = bufferCopy->getNumSamples();
                            const int numChannels = std::min (2, bufferCopy->getNumChannels());
                            const int blockSize = 2048;

                            separator.prepare (sampleRate, blockSize);

                            juce::AudioBuffer<float> outputStem (numChannels, totalSamples);
                            outputStem.clear();

                            for (int startSample = 0; startSample < totalSamples; startSample += blockSize)
                            {
                                if (cancelExport.load())
                                {
                                    isExporting.store (false);
                                    juce::MessageManager::callAsync ([this]()
                                    {
                                        if (fileNameLabel)
                                            fileNameLabel->setText ("Export cancelled", juce::dontSendNotification);
                                    });
                                    return;
                                }

                                int samplesToProcess = std::min (blockSize, totalSamples - startSample);

                                juce::AudioBuffer<float> blockBuffer (numChannels, samplesToProcess);
                                for (int ch = 0; ch < numChannels; ++ch)
                                    blockBuffer.copyFrom (ch, 0, *bufferCopy, ch, startSample, samplesToProcess);

                                separator.process (blockBuffer);
                                auto& stems = separator.getStems();

                                int samplesToCopy = std::min (samplesToProcess, stems[stemIndex].getNumSamples());
                                for (int ch = 0; ch < numChannels; ++ch)
                                {
                                    if (samplesToCopy > 0)
                                        outputStem.copyFrom (ch, startSample, stems[stemIndex], ch, 0, samplesToCopy);
                                }
                            }

                            juce::WavAudioFormat wavFormat;
                            file.deleteFile();

                            auto outputStream = std::make_unique<juce::FileOutputStream> (file);
                            if (outputStream->openedOk() && outputStem.getNumSamples() > 0)
                            {
                                auto writer = std::unique_ptr<juce::AudioFormatWriter> (
                                    wavFormat.createWriterFor (
                                        outputStream.release(),
                                        sampleRate,
                                        static_cast<unsigned int> (outputStem.getNumChannels()),
                                        24, {}, 0));

                                if (writer)
                                    writer->writeFromAudioSampleBuffer (outputStem, 0, outputStem.getNumSamples());
                            }
                        }

                        isExporting.store (false);

                        juce::MessageManager::callAsync ([this, file]()
                        {
                            if (fileNameLabel)
                                fileNameLabel->setText (currentAudioFile.getFileName(), juce::dontSendNotification);

                            StyledDialogWindow::showMessageBoxAsync (
                                juce::MessageBoxIconType::InfoIcon,
                                "Export Complete",
                                "Stem exported to:\n" + file.getFullPathName());
                        });
                    }
                    catch (...)
                    {
                        isExporting.store (false);
                        juce::MessageManager::callAsync ([this]()
                        {
                            if (fileNameLabel)
                                fileNameLabel->setText (currentAudioFile.getFileName(), juce::dontSendNotification);

                            StyledDialogWindow::showMessageBoxAsync (
                                juce::MessageBoxIconType::WarningIcon,
                                "Export Failed",
                                "An error occurred during export.");
                        });
                    }
                });
            });
    }
}

void StemperatorEditor::showExportProgress (const juce::String& message)
{
    // Simple progress indication - could be replaced with a progress bar
    DBG (message);
}

//==============================================================================
// Transport controls
void StemperatorEditor::setupTransportControls()
{
    // YouTube-style transport bar
    transportBar = std::make_unique<TransportBar>();
    transportBar->onPlayPause = [this]() { commandManager.invokeDirectly (cmdPlay, false); };
    transportBar->onStop = [this]() { commandManager.invokeDirectly (cmdStop, false); };
    transportBar->onSeek = [this] (float normalizedPos)
    {
        if (hasLoadedFile || hasSeparatedStems)
        {
            auto length = transportSource.getLengthInSeconds();
            if (length > 0)
                transportSource.setPosition (normalizedPos * length);
        }
    };
    // Set progress bar colour based on mode (red for YouTube style)
    transportBar->setProgressColour (juce::Colour (0xFFE53935));  // YouTube red
    addAndMakeVisible (*transportBar);

    // File name label (above transport bar) - 28pt bold to match STEMS/LIVE messages
    fileNameLabel = std::make_unique<juce::Label> ("", "No file loaded - drag & drop audio or use File menu");
    fileNameLabel->setJustificationType (juce::Justification::centredLeft);
    fileNameLabel->setColour (juce::Label::textColourId, PremiumLookAndFeel::Colours::textBright);
    fileNameLabel->setFont (juce::FontOptions (28.0f).withStyle ("Bold"));
    addAndMakeVisible (*fileNameLabel);

    // Mode indicator label - shows STEMS (colorful) or LIVE, clickable to toggle
    modeLabel = std::make_unique<ColorfulModeLabel>();
    modeLabel->setJustificationType (juce::Justification::centred);
    modeLabel->setFont (juce::FontOptions (16.0f).withStyle ("Bold"));
    modeLabel->onClick = [this]() { togglePlaybackMode(); };
    addAndMakeVisible (*modeLabel);

    // Delete STEMS button - red button, only visible when stems are available
    deleteStemsButton = std::make_unique<juce::TextButton> ("Delete STEMS");
    deleteStemsButton->setColour (juce::TextButton::buttonColourId, juce::Colour (0xFFB71C1C));  // Dark red
    deleteStemsButton->setColour (juce::TextButton::buttonOnColourId, juce::Colour (0xFFD32F2F));  // Lighter red
    deleteStemsButton->setColour (juce::TextButton::textColourOffId, juce::Colours::white);
    deleteStemsButton->setColour (juce::TextButton::textColourOnId, juce::Colours::white);
    deleteStemsButton->setTooltip ("Delete separated stems from memory and disk");
    deleteStemsButton->onClick = [this]() { deleteStems(); };
    deleteStemsButton->setVisible (false);  // Hidden until stems are available
    addAndMakeVisible (*deleteStemsButton);
}

void StemperatorEditor::updateTransportDisplay()
{
    if (! isStandalone() || ! transportBar)
        return;

    // Update transport bar even without loaded file (to show stopped state)
    if (! hasLoadedFile && ! hasSeparatedStems)
    {
        transportBar->setProgress (0.0f);
        transportBar->setPlaying (false);
        transportBar->setTimeText ("0:00 / 0:00");
        return;
    }

    auto position = transportSource.getCurrentPosition();
    auto length = transportSource.getLengthInSeconds();

    if (length > 0)
    {
        transportBar->setProgress ((float) (position / length));
        transportBar->setPlaying (transportSource.isPlaying());

        auto formatTime = [] (double seconds) {
            int mins = (int) (seconds / 60.0);
            int secs = (int) seconds % 60;
            return juce::String (mins) + ":" + juce::String (secs).paddedLeft ('0', 2);
        };

        transportBar->setTimeText (formatTime (position) + " / " + formatTime (length));
    }
}

void StemperatorEditor::updateModeIndicator()
{
    if (! modeLabel)
        return;

    // Enable click when: file loaded (to separate) OR both stems and file available (to toggle)
    bool canClickToSeparate = hasLoadedFile && ! hasSeparatedStems;
    bool canToggle = hasSeparatedStems && hasLoadedFile;
    modeLabel->setCanToggle (canClickToSeparate || canToggle);

    // Show/hide delete stems button based on whether stems exist
    if (deleteStemsButton)
        deleteStemsButton->setVisible (hasSeparatedStems);

    if (playingStemsMode && hasSeparatedStems)
    {
        // Mode: STEMS - AI-separated stems are playing (colorful STEMS text)
        modeLabel->setText ("Mode: STEMS", juce::dontSendNotification);
        modeLabel->setColour (juce::Label::textColourId, PremiumLookAndFeel::Colours::accent);
        modeLabel->setColour (juce::Label::backgroundColourId, PremiumLookAndFeel::Colours::accent.withAlpha (0.2f));
        if (canToggle)
            modeLabel->setTooltip ("Click to switch to LIVE mode (original audio)");
        else
            modeLabel->setTooltip ("Playing AI-separated stems - full quality separation");
    }
    else if (hasLoadedFile)
    {
        // Mode: LIVE - real-time spectral separation
        modeLabel->setText ("Mode: LIVE", juce::dontSendNotification);
        modeLabel->setColour (juce::Label::textColourId, PremiumLookAndFeel::Colours::solo);
        modeLabel->setColour (juce::Label::backgroundColourId, PremiumLookAndFeel::Colours::solo.withAlpha (0.2f));
        if (canToggle)
            modeLabel->setTooltip ("Click to switch to STEMS mode (AI-separated)");
        else if (canClickToSeparate)
            modeLabel->setTooltip ("Click to separate into stems (AI processing)");
        else
            modeLabel->setTooltip ("Real-time spectral separation");
    }
    else
    {
        // No file loaded
        modeLabel->setText ("", juce::dontSendNotification);
        modeLabel->setColour (juce::Label::backgroundColourId, juce::Colours::transparentBlack);
    }
}

void StemperatorEditor::togglePlaybackMode()
{
    // If we have a file but no stems yet, offer to separate
    if (hasLoadedFile && ! hasSeparatedStems)
    {
        // Start separation process (same as File > Separate)
        commandManager.invokeDirectly (cmdSeparate, false);
        return;
    }

    // Can only toggle if we have both stems and original file
    if (! hasSeparatedStems || ! hasLoadedFile)
        return;

    // Stop playback first
    bool wasPlaying = transportSource.isPlaying();
    double currentPosition = transportSource.getCurrentPosition();
    transportSource.stop();

    // Toggle mode
    playingStemsMode = ! playingStemsMode;

    // Switch the audio source
    if (playingStemsMode)
    {
        // Switch to stems
        if (! stemMixerSource)
            stemMixerSource = std::make_unique<StemMixerSource> (separatedStems, processor);
        transportSource.setSource (stemMixerSource.get(), 0, nullptr, loadedSampleRate);
        processor.setSkipSeparation (true);  // Skip GPU processing for pre-separated stems

        // Update the info label
        setStemsLoadedMessage();
    }
    else
    {
        // Switch to original (LIVE mode)
        if (readerSource)
            transportSource.setSource (readerSource.get(), 0, nullptr, loadedSampleRate);
        processor.setSkipSeparation (false);  // Enable real-time separation

        // Update the info label
        if (currentAudioFile.exists())
            setLiveLoadedMessage();
    }

    // Update window title
    refreshWindowTitle();

    // Restore position
    transportSource.setPosition (currentPosition);

    // Resume playback if it was playing
    if (wasPlaying)
        transportSource.start();

    // Update UI
    updateModeIndicator();
    commandManager.commandStatusChanged();
}

void StemperatorEditor::deleteStems()
{
    if (! hasSeparatedStems)
        return;

    // Confirm deletion
    ConfirmDialog::showOkCancelBox (
        "Delete STEMS",
        "Are you sure you want to delete the separated stems?\n\n"
        "This will remove stems from memory" +
        juce::String (lastStemFolder.isDirectory() ? " and delete stem files from disk." : "."),
        StyledDialogWindow::IconType::Warning,
        [this] (bool confirmed)
        {
            if (! confirmed)
                return;

            // Backup stems for undo BEFORE deleting
            for (int i = 0; i < 6; ++i)
                undoStemBackup[i] = separatedStems[i];  // Deep copy
            undoStemFolder = lastStemFolder;
            undoWasPlayingStemsMode = playingStemsMode;
            hasUndoableAction = true;
            undoActionName = "Delete STEMS";
            commandManager.commandStatusChanged();  // Update undo menu item

            // Stop playback
            transportSource.stop();

            // If we're in STEMS mode, switch to LIVE mode first
            if (playingStemsMode && hasLoadedFile)
            {
                playingStemsMode = false;
                if (readerSource)
                    transportSource.setSource (readerSource.get(), 0, nullptr, loadedSampleRate);
                processor.setSkipSeparation (false);
            }
            else
            {
                transportSource.setSource (nullptr);
            }

            // Clear stem mixer
            stemMixerSource.reset();

            // Clear stem buffers
            for (int i = 0; i < 6; ++i)
                separatedStems[i].setSize (0, 0);

            // Delete stem files from disk if they exist
            if (lastStemFolder.isDirectory())
            {
                // Only delete if it's a _stems folder we created
                if (lastStemFolder.getFileName().endsWith ("_stems"))
                {
                    lastStemFolder.deleteRecursively();
                }
                else
                {
                    // Just delete the stem files, not the whole folder
                    juce::String prefix = currentAudioFile.exists() ? currentAudioFile.getFileNameWithoutExtension() : "";
                    const char* stemNames[] = { "vocals", "drums", "bass", "other", "guitar", "piano" };
                    for (int i = 0; i < 6; ++i)
                    {
                        juce::File stemFile = prefix.isEmpty()
                            ? lastStemFolder.getChildFile (juce::String (stemNames[i]) + ".wav")
                            : lastStemFolder.getChildFile (prefix + "_" + juce::String (stemNames[i]) + ".wav");
                        stemFile.deleteFile();
                    }
                }
            }

            // Clear state
            hasSeparatedStems = false;
            lastStemFolder = juce::File();
            projectNeedsSave = true;

            // Update UI
            updateModeIndicator();
            refreshWindowTitle();  // Update title (removes [STEMMED], adds unsaved *)
            commandManager.commandStatusChanged();

            if (hasLoadedFile && currentAudioFile.exists())
                setLiveLoadedMessage();
            else
            {
                resetFileNameLabel();
                fileNameLabel->setText ("STEMS deleted - load audio to separate again", juce::dontSendNotification);
            }
        });
}

void StemperatorEditor::performUndo()
{
    if (! hasUndoableAction)
        return;

    // Restore stems from backup
    for (int i = 0; i < 6; ++i)
        separatedStems[i] = undoStemBackup[i];  // Restore from backup

    // Restore state
    lastStemFolder = undoStemFolder;
    hasSeparatedStems = true;

    // Recreate stem mixer
    stemMixerSource = std::make_unique<StemMixerSource> (separatedStems, processor);

    // If we had STEMS mode before, switch back to it
    if (undoWasPlayingStemsMode && hasLoadedFile)
    {
        playingStemsMode = true;
        transportSource.setSource (stemMixerSource.get(), 0, nullptr, loadedSampleRate);
        processor.setSkipSeparation (true);
        setStemsLoadedMessage();
    }
    else
    {
        // Stay in LIVE mode but stems are available
        if (hasLoadedFile && currentAudioFile.exists())
            setLiveLoadedMessage();
    }

    // Clear undo state
    hasUndoableAction = false;
    undoActionName = "";

    // Clear backup to free memory
    for (int i = 0; i < 6; ++i)
        undoStemBackup[i].setSize (0, 0);
    undoStemFolder = juce::File();

    // Update UI
    updateModeIndicator();
    refreshWindowTitle();
    commandManager.commandStatusChanged();

    StyledDialogWindow::showMessageBoxAsync (
        juce::MessageBoxIconType::InfoIcon,
        "Undo",
        "Delete STEMS has been undone.\nStems restored to memory.");
}

void StemperatorEditor::performRedo()
{
    // Not implemented - we only support single-action undo
}

void StemperatorEditor::setupSlider (juce::Slider& slider, juce::Colour colour)
{
    slider.setColour (juce::Slider::thumbColourId, colour);
    slider.setColour (juce::Slider::trackColourId, colour.darker (0.3f));
    slider.setColour (juce::Slider::textBoxTextColourId, PremiumLookAndFeel::Colours::textBright);
    slider.setColour (juce::Slider::textBoxOutlineColourId, juce::Colours::transparentBlack);
    slider.setColour (juce::Slider::textBoxBackgroundColourId, PremiumLookAndFeel::Colours::bgPanel);
    addAndMakeVisible (slider);
}

void StemperatorEditor::setupKnob (juce::Slider& slider, juce::Label& label, const juce::String& text, juce::Colour colour)
{
    // Horizontal slider style (like Quality/Model/Scale controls)
    slider.setSliderStyle (juce::Slider::LinearHorizontal);
    slider.setTextBoxStyle (juce::Slider::TextBoxRight, false, 55, 20);
    setupSlider (slider, colour);

    label.setText (text, juce::dontSendNotification);
    label.setJustificationType (juce::Justification::centred);
    label.setColour (juce::Label::textColourId, PremiumLookAndFeel::Colours::textMid);
    addAndMakeVisible (label);
}

void StemperatorEditor::updateFontSizes()
{
    float scale = getScaleFactor();
    auto& ui = UISettings::getInstance();

    // Title fonts scale with window - use UISettings values
    titleLabel.setFont (juce::FontOptions (ui.titleFont * scale).withStyle ("Bold"));
    subtitleLabel.setFont (juce::FontOptions (ui.subtitleFont * scale));
    brandLabel.setFont (juce::FontOptions (ui.brandFont * scale).withStyle ("Bold"));
    masterLabel.setFont (juce::FontOptions (ui.masterLabelFont).withStyle ("Bold"));  // Fixed size matches StemChannel

    // Control labels - 50% larger (10 -> 15)
    float labelSize = 15.0f * scale;
    vocalsFocusLabel.setFont (juce::FontOptions (labelSize).withStyle ("Bold"));
    bassCutoffLabel.setFont (juce::FontOptions (labelSize).withStyle ("Bold"));
    drumSensLabel.setFont (juce::FontOptions (labelSize).withStyle ("Bold"));

    // Footer selector labels - BIGGER for better visibility
    float selectorLabelSize = 16.0f * scale;
    qualityLabel.setFont (juce::FontOptions (selectorLabelSize).withStyle ("Bold"));
    scaleLabel.setFont (juce::FontOptions (selectorLabelSize).withStyle ("Bold"));

    // Slider text boxes scale - use 65 to match StemChannel and fit " dB" suffix
    int textBoxWidth = 65;  // Fixed width matching StemChannel
    int textBoxHeight = 18;  // Fixed height matching StemChannel
    masterSlider.setTextBoxStyle (juce::Slider::TextBoxAbove, false, textBoxWidth, textBoxHeight);

    // Horizontal sliders use TextBoxRight
    int sliderTextWidth = scaled (55);
    int sliderTextHeight = scaled (20);
    int bassTextWidth = scaled (65);  // Wider for "150 Hz"
    vocalsFocusSlider.setTextBoxStyle (juce::Slider::TextBoxRight, false, sliderTextWidth, sliderTextHeight);
    bassCutoffSlider.setTextBoxStyle (juce::Slider::TextBoxRight, false, bassTextWidth, sliderTextHeight);
    drumSensSlider.setTextBoxStyle (juce::Slider::TextBoxRight, false, sliderTextWidth, sliderTextHeight);

    // Update file name label if it exists
    if (fileNameLabel)
        fileNameLabel->setFont (juce::FontOptions (ui.fileNameFont * scale).withStyle ("Bold"));

    // Update mode label if it exists
    if (modeLabel)
        modeLabel->setFont (juce::FontOptions (ui.modeLabelFont * scale).withStyle ("Bold"));

    // Update stem channels
    for (auto& channel : stemChannels)
    {
        if (channel)
            channel->updateFontSizes();
    }
}

void StemperatorEditor::paint (juce::Graphics& g)
{
    float scale = getScaleFactor();
    // COMPACT LAYOUT - controls at top, transport at bottom
    int headerControlsHeight = scaled (60);  // Controls at top
    int margin = scaled (4);
    int spacing = scaled (3);

    // Calculate transport height for standalone mode (at bottom)
    int transportHeight = 0;
    if (isStandalone() && transportBar)
        transportHeight = scaled (70);

    // Premium gradient background
    juce::ColourGradient bgGradient (
        PremiumLookAndFeel::Colours::bgDark, 0, 0,
        PremiumLookAndFeel::Colours::bgMid, 0, (float) getHeight(), false);
    bgGradient.addColour (0.5, PremiumLookAndFeel::Colours::bgLight.interpolatedWith (
        PremiumLookAndFeel::Colours::bgDark, 0.7f));
    g.setGradientFill (bgGradient);
    g.fillAll();

    // Subtle grid pattern for depth (scales with size)
    int gridSpacing = juce::jmax (2, scaled (3));
    g.setColour (PremiumLookAndFeel::Colours::textDim.withAlpha (0.03f));
    for (int y = 0; y < getHeight(); y += gridSpacing)
        g.drawHorizontalLine (y, 0, (float) getWidth());

    // Menu bar height
    int menuBarHeight = isStandalone() && menuBar ? scaled (24) : 0;

    // Separator below header controls
    int headerControlsBottom = menuBarHeight + headerControlsHeight;
    juce::ColourGradient separatorGradient (
        PremiumLookAndFeel::Colours::accent.withAlpha (0.0f), 0, (float) headerControlsBottom,
        PremiumLookAndFeel::Colours::accent.withAlpha (0.5f), getWidth() * 0.5f, (float) headerControlsBottom, false);
    separatorGradient.addColour (1.0, PremiumLookAndFeel::Colours::accent.withAlpha (0.0f));
    g.setGradientFill (separatorGradient);
    g.fillRect (0, headerControlsBottom, getWidth(), 1);

    // Panel backgrounds for stem channels area (including Master)
    // Must match resized() - COMPACT layout
    int numVisibleStems = processor.getNumStems();
    int numChannelsTotal = numVisibleStems + 1;  // +1 for Master
    float stemAreaPercent = numVisibleStems == 6 ? 0.98f : 0.96f;  // Match resized()
    int totalStemWidth = juce::roundToInt (getWidth() * stemAreaPercent);
    int channelWidth = (totalStemWidth - scaled (4)) / numChannelsTotal;
    int availableWidth = getWidth() - margin * 2;
    int stemStartX = margin + (availableWidth - totalStemWidth) / 2;  // Center all channels
    int channelTopY = menuBarHeight + headerControlsHeight + spacing;
    int channelHeight = getHeight() - channelTopY - transportHeight - spacing * 2;

    // No panel background - let channels have their own backgrounds

    // Draw Master channel background panel (same style as stem channels)
    // Master is at position numVisibleStems (right after the last stem)
    auto masterPanelArea = juce::Rectangle<int> (
        stemStartX + numVisibleStems * channelWidth + spacing / 2,
        channelTopY,
        channelWidth - spacing,
        channelHeight);

    // Master channel background with white accent at top (like stem channels)
    juce::ColourGradient masterBgGradient (
        PremiumLookAndFeel::Colours::bgLight.withAlpha (0.6f), masterPanelArea.toFloat().getX(), masterPanelArea.toFloat().getY(),
        PremiumLookAndFeel::Colours::bgDark.withAlpha (0.8f), masterPanelArea.toFloat().getX(), masterPanelArea.toFloat().getBottom(), false);
    g.setGradientFill (masterBgGradient);
    g.fillRoundedRectangle (masterPanelArea.toFloat(), 8.0f);

    // Border
    g.setColour (juce::Colours::white.withAlpha (0.4f));
    g.drawRoundedRectangle (masterPanelArea.toFloat().reduced (1.0f), 8.0f, 1.5f);

    // Top accent line (white for Master) - same style as stem channels
    // StemChannel uses bounds.getY() + 2 - use exact same offset
    g.setColour (juce::Colours::white);
    g.fillRoundedRectangle (masterPanelArea.toFloat().getX() + 10, masterPanelArea.toFloat().getY() + 2,
                            masterPanelArea.toFloat().getWidth() - 20, 3.0f, 1.5f);

    // ==========================================================================
    // MASTER VU METER - LED style meter (right side of Master channel)
    // ==========================================================================
    {
        auto meterWidth = 14.0f;
        auto meterX = masterPanelArea.toFloat().getRight() - meterWidth - 8.0f;
        auto meterTop = masterPanelArea.toFloat().getY() + 40.0f;
        auto meterBottom = masterPanelArea.toFloat().getBottom() - 85.0f;
        auto meterHeight = meterBottom - meterTop;

        // LED segment parameters
        int numSegments = 24;
        float segmentHeight = meterHeight / numSegments;
        float segmentGap = 2.0f;
        float ledHeight = segmentHeight - segmentGap;

        // Meter background/housing
        g.setColour (PremiumLookAndFeel::Colours::bgDark.darker (0.3f));
        g.fillRoundedRectangle (meterX - 2, meterTop - 2, meterWidth + 4, meterHeight + 4, 4.0f);

        // Draw LED segments from bottom to top
        int litSegments = (int) (masterDisplayLevel * numSegments);
        int peakSegment = (int) (masterPeakLevel * numSegments);

        for (int i = 0; i < numSegments; ++i)
        {
            float segmentY = meterBottom - (i + 1) * segmentHeight + segmentGap / 2;
            auto segmentRect = juce::Rectangle<float> (meterX, segmentY, meterWidth, ledHeight);

            // Determine LED color based on position (white at bottom, yellow, red at top)
            juce::Colour ledColour;
            float segmentRatio = (float) i / numSegments;

            if (segmentRatio > 0.9f)
                ledColour = PremiumLookAndFeel::Colours::mute;  // Top 10% = red (clip)
            else if (segmentRatio > 0.75f)
                ledColour = juce::Colour (0xffffcc00);  // 75-90% = yellow (warning)
            else
                ledColour = juce::Colours::white;  // Rest = white (for uniformity with fader)

            bool isLit = (i < litSegments);
            bool isPeak = (i == peakSegment - 1) && (masterPeakLevel > 0.01f);

            if (isLit || isPeak)
            {
                // Lit LED with glow effect
                g.setColour (ledColour.withAlpha (0.4f));
                g.fillRoundedRectangle (segmentRect.expanded (2.0f, 1.0f), 3.0f);

                // Main LED body - bright
                g.setColour (ledColour);
                g.fillRoundedRectangle (segmentRect, 2.0f);

                // LED highlight (top reflection)
                g.setColour (juce::Colours::white.withAlpha (0.3f));
                g.fillRoundedRectangle (segmentRect.getX() + 1, segmentRect.getY(),
                                        segmentRect.getWidth() - 2, ledHeight * 0.3f, 1.0f);
            }
            else
            {
                // Unlit LED - dark with subtle color hint
                g.setColour (ledColour.withAlpha (0.15f));
                g.fillRoundedRectangle (segmentRect, 2.0f);

                // Subtle inset shadow
                g.setColour (juce::Colours::black.withAlpha (0.3f));
                g.drawRoundedRectangle (segmentRect.reduced (0.5f), 2.0f, 0.5f);
            }
        }

        // dB markings
        g.setColour (PremiumLookAndFeel::Colours::textDim);
        g.setFont (juce::FontOptions (10.0f));

        const float dbMarks[] = { 0.0f, -6.0f, -12.0f, -24.0f, -48.0f };
        for (float db : dbMarks)
        {
            float normalizedDb = (db + 60.0f) / 72.0f;  // -60 to +12 dB range
            float y = meterBottom - (normalizedDb * meterHeight);
            g.drawText (juce::String ((int) db), (int) (meterX - 26), (int) (y - 6), 22, 12,
                        juce::Justification::centredRight, false);
        }
    }

    // ==========================================================================
    // SECTION DIVIDERS - subtle lines to separate content areas
    // ==========================================================================

    // Divider above transport bar (if standalone)
    if (isStandalone() && transportBar)
    {
        auto dividerColor = PremiumLookAndFeel::Colours::textDim.withAlpha (0.15f);
        int transportTop = getHeight() - transportHeight;
        float dividerThickness = juce::jmax (1.0f, scaled (1.5f));

        // Gradient horizontal divider (fades at edges)
        juce::ColourGradient transportDividerGradient (
            dividerColor.withAlpha (0.0f), (float) margin, (float) transportTop,
            dividerColor, (float) (getWidth() / 2), (float) transportTop, false);
        transportDividerGradient.addColour (1.0, dividerColor.withAlpha (0.0f));
        g.setGradientFill (transportDividerGradient);
        g.fillRect ((float) margin, (float) transportTop, (float) (getWidth() - margin * 2), dividerThickness);
    }
}

void StemperatorEditor::resized()
{
    // Update font sizes for current scale
    updateFontSizes();

    float scale = getScaleFactor();
    auto bounds = getLocalBounds();

    // Menu bar for standalone mode
    int menuBarHeight = 0;
    if (isStandalone() && menuBar)
    {
        menuBarHeight = scaled (24);
        menuBar->setBounds (bounds.removeFromTop (menuBarHeight));
    }

    // Scaled dimensions - COMPACT layout
    int headerControlsHeight = scaled (60);  // Controls at top (was footer)
    int transportHeight = isStandalone() && transportBar ? scaled (70) : 0;  // Transport at bottom
    int margin = scaled (4);
    int spacing = scaled (3);

    // Hide title/subtitle labels (no header space)
    titleLabel.setVisible (false);
    subtitleLabel.setVisible (false);

    // Stem channels + Master - all same width, Master is last channel
    int numVisibleStems = processor.getNumStems();
    int numChannelsTotal = numVisibleStems + 1;  // +1 for Master
    // Use nearly full screen width for channels (96% for 4-stem, 98% for 6-stem)
    float stemAreaPercent = numVisibleStems == 6 ? 0.98f : 0.96f;
    int totalStemWidth = juce::roundToInt (getWidth() * stemAreaPercent);
    int channelWidth = (totalStemWidth - scaled (4)) / numChannelsTotal;  // Minimal padding

    // Calculate stem channel positions - CENTERED in the available space
    int availableWidth = getWidth() - margin * 2;
    int stemStartX = margin + (availableWidth - totalStemWidth) / 2;  // Center all channels

    // Channel vertical positioning - controls at top, transport at bottom
    int channelTopY = menuBarHeight + headerControlsHeight + spacing;
    int channelHeight = getHeight() - channelTopY - transportHeight - spacing * 2;

    std::array<juce::Rectangle<int>, 6> stemBounds;
    for (int i = 0; i < numVisibleStems; ++i)
    {
        stemBounds[static_cast<size_t> (i)] = juce::Rectangle<int> (
            stemStartX + i * channelWidth + spacing / 2,
            channelTopY,
            channelWidth - spacing,
            channelHeight);
    }

    // Master channel bounds - same size as stem channels, positioned right after last stem
    auto masterBounds = juce::Rectangle<int> (
        stemStartX + numVisibleStems * channelWidth + spacing / 2,
        channelTopY,
        channelWidth - spacing,
        channelHeight);

    // Show/hide Guitar and Piano channels based on model
    for (int i = 0; i < 6; ++i)
    {
        stemChannels[static_cast<size_t> (i)]->setVisible (i < numVisibleStems);
    }

    // Position stem channels
    for (int i = 0; i < numVisibleStems; ++i)
    {
        stemChannels[static_cast<size_t> (i)]->setBounds (stemBounds[static_cast<size_t> (i)]);
    }

    // Header controls - positioned ABOVE stems (between menu and stems)
    auto headerControls = juce::Rectangle<int> (0, menuBarHeight, getWidth(), headerControlsHeight);
    auto controlsArea = headerControls.reduced (margin, spacing);

    // Knob size - full channel width
    int knobWidth = channelWidth - spacing;
    int knobHeight = controlsArea.getHeight();

    // ========================================================================
    // STEM CONTROL KNOBS - Positioned ABOVE corresponding stem channels
    // ========================================================================

    // Control height
    int controlHeight = scaled (32);
    int labelHeight = scaled (16);

    // Vocal Focus - above Vocals stem (index 0)
    auto vocalSliderArea = juce::Rectangle<int> (
        stemBounds[0].getX(), controlsArea.getY(),
        knobWidth, knobHeight).reduced (spacing / 2, spacing);
    vocalsFocusLabel.setBounds (vocalSliderArea.removeFromTop (labelHeight));
    vocalSliderArea.removeFromTop (spacing / 2);
    vocalsFocusSlider.setBounds (vocalSliderArea.removeFromTop (controlHeight));

    // Drum Sensitivity - above Drums stem (index 1)
    auto drumSliderArea = juce::Rectangle<int> (
        stemBounds[1].getX(), controlsArea.getY(),
        knobWidth, knobHeight).reduced (spacing / 2, spacing);
    drumSensLabel.setBounds (drumSliderArea.removeFromTop (labelHeight));
    drumSliderArea.removeFromTop (spacing / 2);
    drumSensSlider.setBounds (drumSliderArea.removeFromTop (controlHeight));

    // Bass Cutoff - above Bass stem (index 2)
    auto bassSliderArea = juce::Rectangle<int> (
        stemBounds[2].getX(), controlsArea.getY(),
        knobWidth, knobHeight).reduced (spacing / 2, spacing);
    bassCutoffLabel.setBounds (bassSliderArea.removeFromTop (labelHeight));
    bassSliderArea.removeFromTop (spacing);
    bassCutoffSlider.setBounds (bassSliderArea.removeFromTop (controlHeight));

    // ========================================================================
    // QUALITY, MODEL, SCALE selectors - positioned ABOVE OTHER and MASTER
    // ========================================================================
    int selectorWidth = knobWidth;  // Use full channel width

    // Quality + Model combined - spans OTHER stem area (wider for 2 controls)
    // For 4-stem mode: spans from OTHER to before MASTER
    // For 6-stem mode: spans OTHER and Guitar stems
    int qualityModelX = stemBounds[3].getX();
    int qualityModelWidth = numVisibleStems == 6
        ? (stemBounds[4].getRight() - qualityModelX)  // OTHER + Guitar
        : (masterBounds.getX() - qualityModelX - spacing);  // OTHER to Master gap

    auto qualityModelArea = juce::Rectangle<int> (
        qualityModelX, controlsArea.getY(),
        qualityModelWidth, knobHeight).reduced (spacing / 2, spacing);

    // Combined label at top
    qualityLabel.setBounds (qualityModelArea.removeFromTop (labelHeight));
    qualityModelArea.removeFromTop (spacing / 2);

    // Quality button and Model box side by side
    auto controlsRow = qualityModelArea.removeFromTop (controlHeight);
    int halfWidth = (controlsRow.getWidth() - spacing) / 2;
    qualityButton.setBounds (controlsRow.removeFromLeft (halfWidth));
    controlsRow.removeFromLeft (spacing);
    modelBox.setBounds (controlsRow);

    // Scale selector - above MASTER channel
    auto scaleArea = juce::Rectangle<int> (
        masterBounds.getX(), controlsArea.getY(),
        selectorWidth, knobHeight).reduced (spacing / 2, spacing);
    scaleLabel.setBounds (scaleArea.removeFromTop (labelHeight));
    scaleArea.removeFromTop (spacing / 2);
    scaleBox.setBounds (scaleArea.removeFromTop (controlHeight));

    // ========================================================================
    // MASTER FADER - positioned next to stems (same size and style)
    // ========================================================================
    // Master label at same height as stem channel names
    // StemChannel uses reduced(6) + removeFromTop(5) for accent line + 24px label
    auto masterLabelArea = masterBounds.reduced (6);  // Match StemChannel's fixed 6px
    masterLabelArea.removeFromTop (5);  // Space for accent line (matches StemChannel)
    // Label needs to be centered excluding the meter area on the right
    auto masterLabelBounds = masterLabelArea.removeFromTop (24);  // Fixed 24px matches StemChannel
    masterLabelBounds.removeFromRight (28);  // Exclude LED meter area (matches StemChannel)
    masterLabel.setBounds (masterLabelBounds);
    // No extra spacing - fader starts immediately after name (like StemChannel)

    // M/S buttons positioned ABSOLUTELY at bottom to align with stem channels
    // BIGGER buttons matching StemChannel's new sizes
    int buttonHeight = 38;  // Matches StemChannel (was 32)
    int buttonSpacing = 6;
    int bottomMargin = 8;
    int buttonWidth = juce::jmin (masterBounds.getWidth() - 12, 70);  // Wider buttons (was 60)
    int buttonX = masterBounds.getX() + (masterBounds.getWidth() - buttonWidth) / 2;

    // Solo button at very bottom (matches StemChannel: getHeight() - bottomMargin - buttonHeight - 6)
    int soloY = masterBounds.getBottom() - bottomMargin - buttonHeight - 6;  // -6 for reduced(6) offset
    masterSoloButton.setBounds (buttonX, soloY, buttonWidth, buttonHeight);

    // Mute button above solo
    int muteY = soloY - buttonSpacing - buttonHeight;
    masterMuteButton.setBounds (buttonX, muteY, buttonWidth, buttonHeight);

    // Reset button above mute - where the dB text value would be on stem channels
    int resetY = muteY - buttonSpacing - 20;  // 20px height for reset (compact)
    int resetWidth = juce::jmin (masterBounds.getWidth() - 8, 65);
    int resetX = masterBounds.getX() + (masterBounds.getWidth() - resetWidth) / 2;
    resetAllButton.setBounds (resetX, resetY, resetWidth, 20);

    // Calculate slider area: between label and buttons (with reset button space)
    // Match StemChannel layout exactly
    int buttonAreaHeight = (buttonHeight * 2) + buttonSpacing + 26;  // Same as StemChannel: 2 buttons + spacing + 26 for dB text
    auto sliderArea = masterLabelArea;
    sliderArea.removeFromRight (28);  // Exclude LED meter area (matches StemChannel)
    sliderArea.removeFromBottom (buttonAreaHeight);
    masterSlider.setBounds (sliderArea);  // No extra reduction (matches StemChannel)

    // ========================================================================
    // TRANSPORT BAR - YouTube-style at bottom (standalone only)
    // ========================================================================
    if (isStandalone() && transportBar)
    {
        // Transport area at bottom edge
        int transportY = getHeight() - transportHeight;
        auto transportArea = juce::Rectangle<int> (0, transportY, getWidth(), transportHeight);
        transportArea = transportArea.reduced (scaled (12), scaled (4));

        // Transport bar at top of this area
        transportBar->setBounds (transportArea.removeFromTop (scaled (34)));

        // Small spacing
        transportArea.removeFromTop (scaled (4));

        // Bottom row: filename and mode indicator
        auto bottomRow = transportArea;

        // Mode indicator on the right
        if (modeLabel)
        {
            modeLabel->setBounds (bottomRow.removeFromRight (scaled (130)));
            bottomRow.removeFromRight (scaled (8));
        }

        // Delete STEMS button (left of mode label, only visible when stems exist)
        if (deleteStemsButton)
        {
            deleteStemsButton->setBounds (bottomRow.removeFromRight (scaled (100)));
            bottomRow.removeFromRight (scaled (8));
        }

        // File name takes remaining bottom row space
        fileNameLabel->setBounds (bottomRow);
    }

    // ========================================================================
    // FLARKAUDIO BRAND - hidden in compact layout mode
    // ========================================================================
    brandLabel.setVisible (false);  // Hide in compact layout

    // Notify stem channels to update their internal scaling
    for (auto& channel : stemChannels)
        channel->repaint();
}

void StemperatorEditor::timerCallback()
{
    // Determine if we're active (playing or exporting)
    bool isPlaying = transportSource.isPlaying();
    bool exporting = isExporting.load();
    bool isActive = isPlaying || exporting;

    // Visualizer removed - stem channels have individual level meters

    // Adjust timer frequency based on activity
    static bool wasActive = false;
    if (isActive != wasActive)
    {
        wasActive = isActive;
        if (isActive)
            startTimerHz (30);  // Full speed when playing/exporting
        else
            startTimerHz (2);   // Very slow when idle (just for transport updates)
    }

    // During export: show export stem levels as visual feedback
    int numStems = processor.getNumStems();
    if (exporting)
    {
        for (int i = 0; i < numStems; ++i)
        {
            float level = exportStemLevels[static_cast<size_t> (i)].load();
            stemChannels[static_cast<size_t> (i)]->setLevel (level);
        }

    }
    else if (isPlaying)
    {
        // Check if we're in STEMS mode (playing via StemMixerSource) or LIVE mode (original file)
        if (playingStemsMode && stemMixerSource)
        {
            // STEMS mode: get levels from StemMixerSource
            for (int i = 0; i < numStems; ++i)
            {
                float level = stemMixerSource->getStemLevel (i);
                stemChannels[static_cast<size_t> (i)]->setLevel (level);
            }

        }
        else
        {
            // LIVE mode: show processor levels (real-time spectral separation)
            for (int i = 0; i < numStems; ++i)
            {
                float level = processor.getStemLevel (static_cast<StemperatorProcessor::Stem> (i));
                stemChannels[static_cast<size_t> (i)]->setLevel (level);
            }

        }
    }

    // Update master VU meter - calculate from sum of stem levels
    if (isPlaying || exporting)
    {
        float maxLevel = 0.0f;
        for (int i = 0; i < numStems; ++i)
        {
            float stemLevel = 0.0f;
            if (exporting)
                stemLevel = exportStemLevels[static_cast<size_t> (i)].load();
            else if (hasSeparatedStems && stemMixerSource)
                stemLevel = stemMixerSource->getStemLevel (i);
            else
                stemLevel = processor.getStemLevel (static_cast<StemperatorProcessor::Stem> (i));
            maxLevel = std::max (maxLevel, stemLevel);
        }

        // Apply master gain to the level (convert from dB)
        float masterGainDb = static_cast<float> (masterSlider.getValue());
        float masterGain = juce::Decibels::decibelsToGain (masterGainDb);
        masterCurrentLevel = maxLevel * masterGain;

        // Smooth level display with faster attack, slower release
        if (masterCurrentLevel > masterDisplayLevel)
            masterDisplayLevel = masterCurrentLevel;  // Fast attack
        else
            masterDisplayLevel = masterDisplayLevel * 0.92f + masterCurrentLevel * 0.08f;  // Slow release

        // Peak hold
        if (masterCurrentLevel >= masterPeakLevel)
        {
            masterPeakLevel = masterCurrentLevel;
            masterPeakHoldCount = 0;
        }
        else
        {
            masterPeakHoldCount++;
            if (masterPeakHoldCount > masterPeakHoldTime)
                masterPeakLevel *= 0.95f;  // Decay peak
        }
    }
    else
    {
        // Decay when not playing
        masterDisplayLevel *= 0.9f;
        masterPeakLevel *= 0.95f;
    }

    // Repaint master meter area (right side of the UI where master panel is)
    // The master meter is in the rightmost 120px + padding area
    auto bounds = getLocalBounds();
    int masterWidth = scaled (120);
    repaint (bounds.getWidth() - masterWidth - scaled (8), 0, masterWidth + scaled (8), bounds.getHeight());

    // Update transport display in standalone mode
    updateTransportDisplay();

    // Update mode indicator (STEMS vs LIVE)
    updateModeIndicator();

    // Enable/disable focus controls based on whether we're playing pre-separated stems
    // These controls only affect real-time spectral separation, not pre-separated AI stems
    // Only update if state changed to avoid unnecessary repaints
    static bool lastControlsEnabled = true;
    bool controlsEnabled = ! hasSeparatedStems;
    if (controlsEnabled != lastControlsEnabled)
    {
        lastControlsEnabled = controlsEnabled;
        vocalsFocusSlider.setEnabled (controlsEnabled);
        bassCutoffSlider.setEnabled (controlsEnabled);
        drumSensSlider.setEnabled (controlsEnabled);
        qualityButton.setEnabled (controlsEnabled);
        modelBox.setEnabled (controlsEnabled);

        // Update visual appearance to show greyed-out state
        float alpha = controlsEnabled ? 1.0f : 0.35f;
        vocalsFocusSlider.setAlpha (alpha);
        bassCutoffSlider.setAlpha (alpha);
        drumSensSlider.setAlpha (alpha);
        qualityButton.setAlpha (alpha);
        modelBox.setAlpha (alpha);
        vocalsFocusLabel.setAlpha (alpha);
        bassCutoffLabel.setAlpha (alpha);
        drumSensLabel.setAlpha (alpha);
        qualityLabel.setAlpha (alpha);
    }
}

bool StemperatorEditor::keyPressed (const juce::KeyPress& key, juce::Component*)
{
    if (key == juce::KeyPress::escapeKey && isExporting.load())
    {
        cancelExport.store (true);

        if (fileNameLabel)
            fileNameLabel->setText ("Cancelling...", juce::dontSendNotification);

        return true;
    }

    // Spacebar for play/pause toggle
    if (key == juce::KeyPress::spaceKey)
    {
        if (transportSource.isPlaying())
        {
            // Pause - just stop without resetting position
            transportSource.stop();
        }
        else if (hasSeparatedStems || hasLoadedFile)
        {
            // Use cmdPlay which handles source setup and starts playback
            commandManager.invokeDirectly (cmdPlay, false);
        }
        return true;
    }

    // Arrow keys for seeking
    if (key == juce::KeyPress::leftKey || key == juce::KeyPress::rightKey)
    {
        double totalSeconds = transportSource.getLengthInSeconds();
        if (totalSeconds > 0)
        {
            double currentSeconds = transportSource.getCurrentPosition();

            // Seek amount: 5 seconds, or 1 second with Ctrl/Cmd, or 30 seconds with Shift
            double seekSeconds = 5.0;
            auto mods = juce::ModifierKeys::currentModifiers;
            if (mods.isCtrlDown() || mods.isCommandDown())
                seekSeconds = 1.0;
            else if (mods.isShiftDown())
                seekSeconds = 30.0;

            double newSeconds;
            if (key == juce::KeyPress::leftKey)
                newSeconds = juce::jmax (0.0, currentSeconds - seekSeconds);
            else
                newSeconds = juce::jmin (totalSeconds, currentSeconds + seekSeconds);

            transportSource.setPosition (newSeconds);
        }
        return true;
    }

    // M+1-6 for mute toggle, Shift+1-6 for solo toggle
    // (Vocals=1, Drums=2, Bass=3, Other=4, Guitar=5, Piano=6)
    static bool waitingForMuteNumber = false;

    // Track M key press for mute (without shift, as Shift+M is not used)
    auto mods = key.getModifiers();
    if ((key.getTextCharacter() == 'm' || key.getTextCharacter() == 'M') && ! mods.isShiftDown())
    {
        waitingForMuteNumber = true;
        return true;  // Consume the M key, wait for number
    }

    // Check for number keys 1-6 (both via text character and key code)
    int stemIndex = -1;
    juce::juce_wchar ch = key.getTextCharacter();
    int keyCode = key.getKeyCode();

    // Check text character first
    if (ch >= '1' && ch <= '6')
        stemIndex = ch - '1';  // 0-5
    // Also check key codes for number row (handles Shift+number cases)
    else if (keyCode >= '1' && keyCode <= '6')
        stemIndex = keyCode - '1';  // 0-5

    if (stemIndex >= 0 && stemIndex < processor.getNumStems())
    {
        if (waitingForMuteNumber)
        {
            // M then number: Toggle mute for this stem
            auto& muteButton = stemChannels[static_cast<size_t> (stemIndex)]->getMuteButton();
            muteButton.setToggleState (! muteButton.getToggleState(), juce::sendNotification);
            waitingForMuteNumber = false;
            return true;
        }
        else if (mods.isShiftDown())
        {
            // Shift+number: Toggle solo for this stem
            auto& soloButton = stemChannels[static_cast<size_t> (stemIndex)]->getSoloButton();
            soloButton.setToggleState (! soloButton.getToggleState(), juce::sendNotification);
            return true;
        }
    }

    // Reset mute waiting state if any other key is pressed
    if (waitingForMuteNumber && stemIndex < 0)
        waitingForMuteNumber = false;

    return false;
}

//==============================================================================
// Mouse click handler - grab keyboard focus
void StemperatorEditor::mouseDown (const juce::MouseEvent& event)
{
    juce::ignoreUnused (event);
    // Grab keyboard focus when user clicks anywhere in the editor
    // This ensures Space works for play/pause after clicking
    grabKeyboardFocus();
}

//==============================================================================
// FileDragAndDropTarget
bool StemperatorEditor::isInterestedInFileDrag (const juce::StringArray& files)
{
    // Accept audio files (same formats as filesDropped and loadAudioFile)
    for (const auto& file : files)
    {
        juce::File f (file);
        auto ext = f.getFileExtension().toLowerCase();
        if (ext == ".wav" || ext == ".mp3" || ext == ".flac" ||
            ext == ".aiff" || ext == ".aif" || ext == ".ogg" ||
            ext == ".m4a" || ext == ".wma" || ext == ".opus")
            return true;
    }
    return false;
}

void StemperatorEditor::filesDropped (const juce::StringArray& files, int, int)
{
    // Collect valid audio files
    juce::Array<juce::File> audioFiles;
    for (const auto& file : files)
    {
        juce::File f (file);
        auto ext = f.getFileExtension().toLowerCase();
        if (ext == ".wav" || ext == ".mp3" || ext == ".flac" ||
            ext == ".aiff" || ext == ".ogg" || ext == ".m4a" ||
            ext == ".aif" || ext == ".wma" || ext == ".opus")
        {
            audioFiles.add (f);
        }
    }

    if (audioFiles.isEmpty())
        return;

    // If multiple files dropped, open batch editor (no project warning needed for batch)
    if (audioFiles.size() > 1)
    {
        showBatchWindow();
        // Pre-populate with dropped files
        if (batchEditorWindow != nullptr)
            batchEditorWindow->addFilesToBatch (audioFiles);
        return;
    }

    // Single file - check for unsaved project first
    if (projectNeedsSave)
    {
        auto fileToLoad = audioFiles[0];
        new SavePromptDialog ("Unsaved Changes",
            "You have unsaved changes.\nDo you want to save before loading a new file?",
            [this, fileToLoad] (int result)
            {
                if (result == 0)  // Save
                {
                    if (currentProjectFile.existsAsFile())
                    {
                        saveProjectToFile (currentProjectFile);
                        loadAudioFile (fileToLoad);
                    }
                    else
                    {
                        // Need to save as first - store file for later
                        // For simplicity, just proceed with load after save dialog
                        saveProjectAs();
                        // Note: loadAudioFile will be called manually after save
                    }
                }
                else if (result == 1)  // Don't Save
                {
                    projectNeedsSave = false;
                    loadAudioFile (fileToLoad);
                }
                // result == 2 is Cancel - do nothing
            });
        return;
    }

    // No unsaved changes, just load the file
    loadAudioFile (audioFiles[0]);
}

//==============================================================================
// Stem separation and playback
void StemperatorEditor::separateCurrentFile()
{
    if (! hasLoadedFile)
    {
        StyledDialogWindow::showMessageBoxAsync (
            juce::MessageBoxIconType::WarningIcon,
            "No File Loaded",
            "Please load an audio file first using File > Load Audio File");
        return;
    }

    // Get quality setting for model selection
    int qualityIndex = currentQuality;
    juce::String modelName = (qualityIndex >= 2) ? "htdemucs_ft" : "htdemucs";

    auto bufferCopy = std::make_shared<juce::AudioBuffer<float>> (loadedAudioBuffer);
    auto sampleRate = loadedSampleRate;

    if (fileNameLabel)
        fileNameLabel->setText ("Preparing AI separation...", juce::dontSendNotification);

    juce::Thread::launch ([this, bufferCopy, sampleRate, modelName]()
    {
        isExporting.store (true);
        cancelExport.store (false);

        try
        {
            auto startTime = juce::Time::getMillisecondCounterHiRes();

            // Find the Python environment
            auto pyEnv = findPythonEnvironment();
            if (! pyEnv.isValid())
            {
                juce::MessageManager::callAsync ([this]()
                {
                    StyledDialogWindow::showMessageBoxAsync (
                        juce::MessageBoxIconType::WarningIcon,
                        "AI Not Available",
                        "Could not find the Python environment.\n\n"
                        "Please set up the virtual environment first,\n"
                        "or set the STEMPERATOR_ROOT environment variable.");
                    isExporting.store (false);
                });
                return;
            }

            // Create temp directory
            auto tempDir = juce::File::getSpecialLocation (juce::File::tempDirectory)
                              .getChildFile ("stemperator_sep_" + juce::String (juce::Random::getSystemRandom().nextInt64()));
            tempDir.createDirectory();

            auto tempInputFile = tempDir.getChildFile ("input.wav");

            // Write input to temp file
            {
                juce::WavAudioFormat wavFormat;
                auto outputStream = std::make_unique<juce::FileOutputStream> (tempInputFile);
                if (outputStream->openedOk())
                {
                    auto writer = std::unique_ptr<juce::AudioFormatWriter> (
                        wavFormat.createWriterFor (
                            outputStream.release(),
                            sampleRate,
                            static_cast<unsigned int> (std::min (2, bufferCopy->getNumChannels())),
                            24, {}, 0));

                    if (writer)
                        writer->writeFromAudioSampleBuffer (*bufferCopy, 0, bufferCopy->getNumSamples());
                }
            }

            juce::MessageManager::callAsync ([this, modelName]()
            {
                resetFileNameLabel();
                if (fileNameLabel)
                {
                    fileNameLabel->setText ("Processing (" + modelName + ")... | ESC=cancel", juce::dontSendNotification);
                    fileNameLabel->setTooltip ("Running Demucs AI separation.\n\n"
                        "Model: " + modelName + "\n\n"
                        "The AI neural network is analyzing the audio\n"
                        "and separating it into individual stems.\n\n"
                        "Press ESC to cancel.");
                }
            });

            // Animate stem levels during processing
            for (int i = 0; i < 6; ++i)
                exportStemLevels[i].store (0.3f);

            // Build command arguments as StringArray for proper handling of spaces
            // -u flag enables unbuffered stdout for real-time progress output
            juce::StringArray args;
            args.add (pyEnv.pythonExe.getFullPathName());
            args.add ("-u");
            args.add (pyEnv.separatorScript.getFullPathName());
            args.add (tempInputFile.getFullPathName());
            args.add (tempDir.getFullPathName());
            args.add ("--model");
            args.add (modelName);

            juce::ChildProcess process;
            bool started = process.start (args);
            bool wasCancelled = false;

            if (started)
            {
                // Wait for completion with real progress from Python
                int currentPercent = 10;
                juce::String currentStage = "Starting";
                juce::String processOutput;

                while (process.isRunning())
                {
                    if (cancelExport.load())
                    {
                        process.kill();
                        wasCancelled = true;
                        break;
                    }

                    // Read available output from process (progress lines)
                    char buffer[256];
                    auto bytesRead = process.readProcessOutput (buffer, sizeof (buffer) - 1);
                    if (bytesRead > 0)
                    {
                        buffer[bytesRead] = '\0';
                        processOutput += buffer;

                        // Parse progress lines: PROGRESS:<percent>:<stage>
                        while (processOutput.contains ("\n"))
                        {
                            auto newlinePos = processOutput.indexOf ("\n");
                            auto line = processOutput.substring (0, newlinePos).trim();
                            processOutput = processOutput.substring (newlinePos + 1);

                            if (line.startsWith ("PROGRESS:"))
                            {
                                auto parts = juce::StringArray::fromTokens (line.substring (9), ":", "");
                                if (parts.size() >= 1)
                                    currentPercent = parts[0].getIntValue();
                                if (parts.size() >= 2)
                                    currentStage = parts[1];
                            }
                        }
                    }

                    // Update progress display
                    exportProgress.store (currentPercent / 100.0f);

                    // Animate stem levels based on progress
                    float animPhase = currentPercent / 100.0f;
                    for (int i = 0; i < 4; ++i)
                    {
                        float level = 0.3f + 0.4f * std::sin (animPhase * 10.0f + i * 1.5f);
                        exportStemLevels[i].store (std::max (0.1f, level));
                    }

                    double elapsed = (juce::Time::getMillisecondCounterHiRes() - startTime) / 1000.0;
                    int mins = (int) elapsed / 60;
                    int secs = (int) elapsed % 60;
                    juce::String status = juce::String (currentPercent) + "% | " + currentStage + " | "
                        + juce::String (mins) + ":" + juce::String (secs).paddedLeft ('0', 2) + " | ESC=cancel";
                    int pct = currentPercent;

                    juce::MessageManager::callAsync ([this, status, pct]()
                    {
                        if (fileNameLabel)
                        {
                            fileNameLabel->setText (status, juce::dontSendNotification);
                            fileNameLabel->setTooltip ("AI Separation Progress: " + juce::String (pct) + "%\n\n"
                                "The neural network is processing the audio.\n"
                                "Speed depends on your CPU/GPU and audio length.\n\n"
                                "Press ESC to cancel the operation.");
                        }
                    });

                    juce::Thread::sleep (100);
                }

                if (! wasCancelled && process.getExitCode() == 0)
                {
                    // Load stems into memory
                    juce::MessageManager::callAsync ([this]()
                    {
                        if (fileNameLabel)
                            fileNameLabel->setText ("Loading stems into memory...", juce::dontSendNotification);
                    });

                    const char* stemFileNames[] = { "vocals", "drums", "bass", "other", "guitar", "piano" };
                    juce::AudioFormatManager formatMgr;
                    formatMgr.registerBasicFormats();

                    int loadedCount = 0;
                    // Loop through all 6 - non-existent stems will be skipped (4-stem models don't have guitar/piano)
                    for (int i = 0; i < 6; ++i)
                    {
                        auto stemFile = tempDir.getChildFile (juce::String (stemFileNames[i]) + ".wav");
                        if (stemFile.existsAsFile())
                        {
                            auto* reader = formatMgr.createReaderFor (stemFile);
                            if (reader)
                            {
                                separatedStems[i].setSize ((int) reader->numChannels, (int) reader->lengthInSamples);
                                reader->read (&separatedStems[i], 0, (int) reader->lengthInSamples, 0, true, true);
                                delete reader;
                                exportStemLevels[i].store (0.8f);
                                loadedCount++;
                            }
                        }
                        else
                        {
                            // Clear buffer for non-existent stems (guitar/piano in 4-stem models)
                            separatedStems[i].setSize (0, 0);
                        }
                    }

                    // Need at least the 4 basic stems (vocals, drums, bass, other)
                    bool allLoaded = (loadedCount >= 4);

                    if (allLoaded)
                    {
                        hasSeparatedStems = true;
                        playingStemsMode = true;  // Switch to stems mode
                        projectNeedsSave = true;  // Mark project as needing save
                        lastStemFolder = tempDir;
                        addToRecentStems (tempDir);

                        double processingTime = (juce::Time::getMillisecondCounterHiRes() - startTime) / 1000.0;

                        juce::MessageManager::callAsync ([this, processingTime]()
                        {
                            // Update info label with colorful STEMS message
                            setStemsLoadedMessage();

                            commandManager.commandStatusChanged();
                            updateModeIndicator();
                            refreshWindowTitle();

                            // Automatically create stem mixer and start playback
                            stemMixerSource = std::make_unique<StemMixerSource> (separatedStems, processor);
                            transportSource.stop();
                            transportSource.setSource (stemMixerSource.get(), 0, nullptr, loadedSampleRate);

                            // Skip spectral separation - stems are already AI-separated
                            processor.setSkipSeparation (true);
                        });
                    }
                    else
                    {
                        // Failed to load stems
                        juce::MessageManager::callAsync ([this, loadedCount]()
                        {
                            resetFileNameLabel();
                            if (fileNameLabel)
                                fileNameLabel->setText ("Failed to load stems (found " + juce::String (loadedCount) + " of 4)", juce::dontSendNotification);
                        });
                    }
                }
                else if (wasCancelled)
                {
                    juce::MessageManager::callAsync ([this]()
                    {
                        if (fileNameLabel)
                            fileNameLabel->setText ("Separation cancelled", juce::dontSendNotification);
                    });
                }
            }

            // Clean up temp files (but keep stems in memory)
            tempDir.deleteRecursively();

            isExporting.store (false);
            for (auto& level : exportStemLevels)
                level.store (0.0f);
        }
        catch (...)
        {
            isExporting.store (false);
            juce::MessageManager::callAsync ([this]()
            {
                if (fileNameLabel)
                    fileNameLabel->setText (currentAudioFile.getFileName(), juce::dontSendNotification);

                StyledDialogWindow::showMessageBoxAsync (
                    juce::MessageBoxIconType::WarningIcon,
                    "Separation Failed",
                    "An error occurred during separation.");
            });
        }
    });
}

void StemperatorEditor::loadStemsFromFolder (const juce::File& folder)
{
    if (! folder.isDirectory())
        return;

    // First, find all distinct song prefixes in the folder
    // Files are named: songname_vocals.wav, songname_drums.wav, etc.
    // Or standard: vocals.wav, drums.wav, etc.

    juce::StringArray songPrefixes;
    bool hasStandardStems = folder.getChildFile ("vocals.wav").existsAsFile();

    if (hasStandardStems)
        songPrefixes.add ("");  // Empty prefix for standard naming

    // Find all *_vocals.wav files to detect song prefixes
    auto vocalFiles = folder.findChildFiles (juce::File::findFiles, false, "*_vocals.wav");
    for (const auto& file : vocalFiles)
    {
        juce::String filename = file.getFileNameWithoutExtension();
        // Remove "_vocals" suffix to get prefix
        if (filename.endsWith ("_vocals"))
        {
            juce::String prefix = filename.dropLastCharacters (7);  // "_vocals" = 7 chars
            if (prefix.isNotEmpty() && ! songPrefixes.contains (prefix))
                songPrefixes.add (prefix);
        }
    }

    if (songPrefixes.isEmpty())
    {
        StyledDialogWindow::showMessageBoxAsync (
            juce::MessageBoxIconType::WarningIcon,
            "No Stems Found",
            "Could not find any stem files in this folder.\n\n"
            "Expected files named: vocals.wav, drums.wav, bass.wav, other.wav\n"
            "or: songname_vocals.wav, songname_drums.wav, etc.");
        return;
    }

    // If multiple songs found, show selection popup
    if (songPrefixes.size() > 1)
    {
        juce::PopupMenu menu;
        menu.addSectionHeader ("Select song to load:");
        menu.addSeparator();

        for (int i = 0; i < songPrefixes.size(); ++i)
        {
            juce::String displayName = songPrefixes[i].isEmpty() ? "(standard stems)" : songPrefixes[i];
            menu.addItem (i + 1, displayName);
        }

        menu.showMenuAsync (juce::PopupMenu::Options().withTargetComponent (this),
            [this, folder, songPrefixes] (int result)
            {
                if (result > 0 && result <= songPrefixes.size())
                {
                    loadStemsWithPrefix (folder, songPrefixes[result - 1]);
                }
            });
        return;
    }

    // Single song - load directly
    loadStemsWithPrefix (folder, songPrefixes[0]);
}

void StemperatorEditor::loadStemsWithPrefix (const juce::File& folder, const juce::String& prefix)
{
    const char* stemFileNames[] = { "vocals", "drums", "bass", "other", "guitar", "piano" };
    juce::AudioFormatManager formatMgr;
    formatMgr.registerBasicFormats();

    bool allLoaded = true;
    double sampleRate = 44100.0;

    juce::String displayName = prefix.isEmpty() ? folder.getFileName() : prefix;

    if (fileNameLabel)
        fileNameLabel->setText ("Loading stems: " + displayName + "...", juce::dontSendNotification);

    // Clear all stem buffers first
    for (int i = 0; i < 6; ++i)
        separatedStems[static_cast<size_t>(i)].setSize (0, 0);

    // Load the 4 main stems (required)
    for (int i = 0; i < 4; ++i)
    {
        juce::File stemFile;

        if (prefix.isEmpty())
            stemFile = folder.getChildFile (juce::String (stemFileNames[i]) + ".wav");
        else
            stemFile = folder.getChildFile (prefix + "_" + juce::String (stemFileNames[i]) + ".wav");

        if (stemFile.existsAsFile())
        {
            auto* reader = formatMgr.createReaderFor (stemFile);
            if (reader)
            {
                separatedStems[static_cast<size_t>(i)].setSize ((int) reader->numChannels, (int) reader->lengthInSamples);
                reader->read (&separatedStems[static_cast<size_t>(i)], 0, (int) reader->lengthInSamples, 0, true, true);
                sampleRate = reader->sampleRate;
                delete reader;
            }
            else
            {
                allLoaded = false;
                std::cerr << "Failed to read: " << stemFile.getFullPathName().toStdString() << std::endl;
            }
        }
        else
        {
            allLoaded = false;
            std::cerr << "Stem not found: " << stemFile.getFullPathName().toStdString() << std::endl;
        }
    }

    // Try to load optional 6-stem model stems (guitar, piano)
    for (int i = 4; i < 6; ++i)
    {
        juce::File stemFile;

        if (prefix.isEmpty())
            stemFile = folder.getChildFile (juce::String (stemFileNames[i]) + ".wav");
        else
            stemFile = folder.getChildFile (prefix + "_" + juce::String (stemFileNames[i]) + ".wav");

        if (stemFile.existsAsFile())
        {
            auto* reader = formatMgr.createReaderFor (stemFile);
            if (reader)
            {
                separatedStems[static_cast<size_t>(i)].setSize ((int) reader->numChannels, (int) reader->lengthInSamples);
                reader->read (&separatedStems[static_cast<size_t>(i)], 0, (int) reader->lengthInSamples, 0, true, true);
                delete reader;
                std::cerr << "Loaded 6-stem: " << stemFile.getFileName().toStdString() << std::endl;
            }
        }
    }

    if (allLoaded)
    {
        hasSeparatedStems = true;
        playingStemsMode = true;  // Switch to stems mode
        projectNeedsSave = true;  // Mark project as needing save
        lastStemFolder = folder;
        loadedSampleRate = sampleRate;
        addToRecentStems (folder);

        // Clear AI separation badge for channels that have stems loaded
        for (int i = 0; i < 6; ++i)
        {
            if (stemChannels[static_cast<size_t>(i)] != nullptr &&
                separatedStems[static_cast<size_t>(i)].getNumSamples() > 0)
            {
                stemChannels[static_cast<size_t>(i)]->setNeedsAISeparation (false);
            }
        }

        // Stop current playback
        transportSource.stop();

        // Clear original audio source so we use stems instead
        if (isStandalone())
            processor.setPlaybackSource (nullptr);

        // Create stem mixer
        stemMixerSource = std::make_unique<StemMixerSource> (separatedStems, processor);
        transportSource.setSource (stemMixerSource.get(), 0, nullptr, loadedSampleRate);

        // Connect to processor for audio output
        if (isStandalone())
        {
            processor.setPlaybackSource (&transportSource);
            processor.setSkipSeparation (true);  // Skip GPU processing - stems already AI-separated
        }

        // Update info label with colorful STEMS message
        setStemsLoadedMessage();

        // Update window title
        refreshWindowTitle();

        // Save the folder for next time
        saveSettings();

        commandManager.commandStatusChanged();
        updateModeIndicator();
    }
    else
    {
        StyledDialogWindow::showMessageBoxAsync (
            juce::MessageBoxIconType::WarningIcon,
            "Load Failed",
            "Could not load all stem files for: " + displayName + "\n\n"
            "Expected: " + (prefix.isEmpty() ? "" : prefix + "_") + "vocals.wav, drums.wav, bass.wav, other.wav");
    }
}

void StemperatorEditor::updateStemPlayback()
{
    // This is called when mute/solo/volume changes
    // The StemMixerSource reads parameters directly, so we just need to repaint
    for (auto& channel : stemChannels)
        channel->repaint();
}

//==============================================================================
// Batch processing
void StemperatorEditor::batchProcessFiles()
{
    if (isExporting.load())
    {
        StyledDialogWindow::showMessageBoxAsync (
            juce::MessageBoxIconType::WarningIcon,
            "Busy",
            "Already processing. Please wait for current operation to complete.");
        return;
    }

    showBatchWindow();
}

void StemperatorEditor::showBatchWindow()
{
    // Get current model name from processor
    auto& demucs = processor.getDemucsProcessor();
    juce::String modelName = (demucs.getModel() == DemucsProcessor::HTDemucs_6S) ? "htdemucs_6s" : "htdemucs";

    // Create or reuse batch window
    if (batchEditorWindow == nullptr)
    {
        batchEditorWindow = std::make_unique<BatchEditorWindow> (modelName);

        // Use SafePointer for the async callbacks
        juce::Component::SafePointer<BatchEditorWindow> safeBatchWindow (batchEditorWindow.get());

        batchEditorWindow->onStartBatch = [this, safeBatchWindow] (const juce::Array<juce::File>& files,
                                                     const juce::String& model,
                                                     const juce::File& customOutputFolder)
    {
        // Start batch processing - stems saved next to originals or custom folder
        auto filesToProcess = std::make_shared<juce::Array<juce::File>> (files);
        auto outputDir = customOutputFolder;

        juce::Thread::launch ([this, safeBatchWindow, filesToProcess, model, outputDir]()
                    {
                        isExporting.store (true);
                        cancelExport.store (false);

                        // Find the Python environment
                        auto pyEnv = findPythonEnvironment();
                        if (! pyEnv.isValid())
                        {
                            juce::MessageManager::callAsync ([this]()
                            {
                                StyledDialogWindow::showMessageBoxAsync (
                                    juce::MessageBoxIconType::WarningIcon,
                                    "AI Not Available",
                                    "Could not find the Python environment.\n\n"
                                    "Please set up the virtual environment first,\n"
                                    "or set the STEMPERATOR_ROOT environment variable.");
                                isExporting.store (false);
                            });
                            return;
                        }

                        int totalFiles = filesToProcess->size();
                        int processedFiles = 0;
                        int failedFiles = 0;
                        auto batchStartTime = juce::Time::getMillisecondCounterHiRes();

                        for (const auto& inputFile : *filesToProcess)
                        {
                            if (cancelExport.load())
                                break;

                            // Skip directories - only process actual files
                            if (! inputFile.existsAsFile())
                            {
                                std::cerr << "Skipping non-file: " << inputFile.getFullPathName().toStdString() << std::endl;
                                continue;
                            }

                            processedFiles++;
                            juce::String statusMsg = "Batch: " + juce::String (processedFiles) + "/" + juce::String (totalFiles) +
                                " - " + inputFile.getFileName() + " | ESC=cancel";

                            juce::MessageManager::callAsync ([this, statusMsg]()
                            {
                                if (fileNameLabel)
                                    fileNameLabel->setText (statusMsg, juce::dontSendNotification);
                            });

                            // Update batch window progress
                            if (safeBatchWindow != nullptr)
                                safeBatchWindow->setProgress (processedFiles - 1, totalFiles, statusMsg);

                            // Create output folder - either custom or next to source file
                            juce::File stemFolder;
                            if (outputDir.exists())
                                stemFolder = outputDir.getChildFile (inputFile.getFileNameWithoutExtension() + "_stems");
                            else
                                stemFolder = inputFile.getParentDirectory().getChildFile (inputFile.getFileNameWithoutExtension() + "_stems");
                            stemFolder.createDirectory();

                            // Check if the input path has problematic characters (unicode, special chars)
                            // If so, create a symlink in /tmp to avoid shell escaping issues
                            auto actualInputPath = inputFile.getFullPathName();
                            juce::File tempLink;
                            bool useTempLink = false;

                            // Check for non-ASCII or special shell characters in path
                            bool hasProblematic = false;
                            for (int c = 0; c < actualInputPath.length(); ++c)
                            {
                                auto ch = actualInputPath[c];
                                // Check for non-ASCII (unicode) or shell-special characters
                                if (ch > 127 || ch == '[' || ch == ']' || ch == '(' || ch == ')' ||
                                    ch == '&' || ch == ';' || ch == '|' || ch == '$' || ch == '`' ||
                                    ch == '!' || ch == '*' || ch == '?' || ch == '{' || ch == '}')
                                {
                                    hasProblematic = true;
                                    break;
                                }
                            }

                            if (hasProblematic)
                            {
                                // Create symlink with safe name in temp directory
                                auto safeExt = inputFile.getFileExtension();
                                tempLink = juce::File::getSpecialLocation (juce::File::tempDirectory)
                                              .getChildFile ("stemperator_batch_" + juce::String (juce::Random::getSystemRandom().nextInt64()) + safeExt);

                                // Try to create symlink first (faster, no copy)
                                juce::String linkCmd = "ln -sf " + inputFile.getFullPathName().quoted() + " " + tempLink.getFullPathName().quoted();
                                int result = std::system (linkCmd.toRawUTF8());

                                if (result == 0 && tempLink.existsAsFile())
                                {
                                    useTempLink = true;
                                    actualInputPath = tempLink.getFullPathName();
                                    std::cerr << "Batch: Using symlink for file with special characters: " << actualInputPath.toStdString() << std::endl;
                                }
                                else
                                {
                                    std::cerr << "Batch: Symlink failed, processing file directly" << std::endl;
                                }
                            }

                            std::cerr << "Batch processing: " << actualInputPath.toStdString() << std::endl;

                            // Build command
                            // -u flag enables unbuffered stdout for real-time progress output
                            juce::StringArray args;
                            args.add (pyEnv.pythonExe.getFullPathName());
                            args.add ("-u");
                            args.add (pyEnv.separatorScript.getFullPathName());
                            args.add (actualInputPath);
                            args.add (stemFolder.getFullPathName());
                            args.add ("--model");
                            args.add (model);

                            std::cerr << "Args: " << args.joinIntoString (" | ").toStdString() << std::endl;

                            juce::ChildProcess process;
                            bool started = process.start (args);

                            if (started)
                            {
                                auto fileStartTime = juce::Time::getMillisecondCounterHiRes();

                                // Animate while processing
                                while (process.isRunning())
                                {
                                    if (cancelExport.load())
                                    {
                                        process.kill();
                                        break;
                                    }

                                    double elapsed = (juce::Time::getMillisecondCounterHiRes() - fileStartTime) / 1000.0;
                                    static const char* dots[] = { "   ", ".  ", ".. ", "..." };
                                    int dotIdx = ((int) (elapsed * 2)) % 4;

                                    int mins = (int) elapsed / 60;
                                    int secs = (int) elapsed % 60;

                                    juce::String animStatus = "Batch " + juce::String (processedFiles) + "/" + juce::String (totalFiles) +
                                        ": " + inputFile.getFileNameWithoutExtension() + dots[dotIdx] + " " +
                                        juce::String (mins) + ":" + juce::String (secs).paddedLeft ('0', 2) + " | ESC=cancel";

                                    juce::MessageManager::callAsync ([this, animStatus]()
                                    {
                                        if (fileNameLabel)
                                            fileNameLabel->setText (animStatus, juce::dontSendNotification);
                                    });

                                    // Animate stem levels
                                    for (int i = 0; i < 4; ++i)
                                    {
                                        float level = 0.3f + 0.4f * std::sin ((float) elapsed * 2.0f + i * 1.5f);
                                        exportStemLevels[i].store (std::max (0.1f, level));
                                    }

                                    juce::Thread::sleep (200);
                                }

                                if (process.getExitCode() == 0 && ! cancelExport.load())
                                {
                                    // Rename stems to include original filename: songname_vocals.wav, etc.
                                    const char* stemNames[] = { "vocals", "drums", "bass", "other", "guitar", "piano" };
                                    auto baseFileName = inputFile.getFileNameWithoutExtension();
                                    int numStems = (model == "htdemucs_6s") ? 6 : 4;

                                    for (int si = 0; si < numStems; ++si)
                                    {
                                        auto oldFile = stemFolder.getChildFile (juce::String (stemNames[si]) + ".wav");
                                        auto newFile = stemFolder.getChildFile (baseFileName + "_" + juce::String (stemNames[si]) + ".wav");

                                        if (oldFile.existsAsFile() && oldFile != newFile)
                                            oldFile.moveFileTo (newFile);
                                    }

                                    // Create .stemperator project file
                                    juce::DynamicObject::Ptr project = new juce::DynamicObject();
                                    project->setProperty ("version", 1);
                                    project->setProperty ("app", "Stemperator");
                                    project->setProperty ("audioFile", inputFile.getFullPathName());
                                    project->setProperty ("stemsFolder", stemFolder.getFullPathName());
                                    project->setProperty ("playingStemsMode", true);
                                    project->setProperty ("hasSeparatedStems", true);
                                    project->setProperty ("numStems", numStems);
                                    project->setProperty ("quality", 1);  // Balanced

                                    // Default channel settings (all at 0dB, no mute/solo)
                                    juce::Array<juce::var> channelSettings;
                                    for (int ch = 0; ch < numStems; ++ch)
                                    {
                                        juce::DynamicObject::Ptr channel = new juce::DynamicObject();
                                        channel->setProperty ("volume", 0.0);
                                        channel->setProperty ("mute", false);
                                        channel->setProperty ("solo", false);
                                        channelSettings.add (juce::var (channel.get()));
                                    }
                                    project->setProperty ("channels", channelSettings);
                                    project->setProperty ("masterVolume", 0.0);

                                    juce::var projectVar (project.get());
                                    juce::String jsonStr = juce::JSON::toString (projectVar, true);

                                    auto projectFile = inputFile.getParentDirectory().getChildFile (baseFileName + ".stemperator");
                                    projectFile.replaceWithText (jsonStr);
                                }
                                else if (! cancelExport.load())
                                {
                                    failedFiles++;
                                }
                            }
                            else
                            {
                                failedFiles++;
                            }

                            // Clean up temp symlink if used
                            if (useTempLink && tempLink.existsAsFile())
                                tempLink.deleteFile();
                        }

                        // Clear stem level animation
                        for (auto& level : exportStemLevels)
                            level.store (0.0f);

                        double totalTime = (juce::Time::getMillisecondCounterHiRes() - batchStartTime) / 1000.0;
                        int successCount = processedFiles - failedFiles;

                        // Update batch window that processing is complete
                        if (safeBatchWindow != nullptr)
                            safeBatchWindow->processingComplete (successCount, failedFiles);

                        // Determine the output path description
                        juce::String outputPathDesc = outputDir.exists()
                            ? outputDir.getFullPathName()
                            : "next to source files";
                        juce::File outputFolderToOpen = outputDir;

                        juce::MessageManager::callAsync ([this, successCount, failedFiles, totalTime, totalFiles, outputPathDesc, outputFolderToOpen, safeBatchWindow]()
                        {
                            isExporting.store (false);

                            if (cancelExport.load())
                            {
                                if (fileNameLabel)
                                    fileNameLabel->setText ("Batch cancelled", juce::dontSendNotification);

                                // Close batch window and clear files after cancel
                                if (safeBatchWindow != nullptr)
                                {
                                    safeBatchWindow->clearFiles();
                                    safeBatchWindow->setVisible (false);
                                }
                            }
                            else
                            {
                                int mins = (int) totalTime / 60;
                                int secs = (int) totalTime % 60;

                                juce::String summary = "Batch complete: " + juce::String (successCount) + "/" + juce::String (totalFiles) +
                                    " files in " + juce::String (mins) + ":" + juce::String (secs).paddedLeft ('0', 2);

                                if (failedFiles > 0)
                                    summary += " (" + juce::String (failedFiles) + " failed)";

                                if (fileNameLabel)
                                    fileNameLabel->setText (summary, juce::dontSendNotification);

                                // Completion dialog with correct output path and Open Folder callback
                                // Capture SafePointer to batch window to close it after opening folder
                                new BatchCompleteDialog (
                                    successCount, totalFiles, failedFiles, outputPathDesc, totalTime,
                                    outputFolderToOpen.exists() ? [outputFolderToOpen, safeBatchWindow]() {
                                        outputFolderToOpen.revealToUser();
                                        // Close batch window and clear files after opening folder
                                        if (safeBatchWindow != nullptr)
                                        {
                                            safeBatchWindow->clearFiles();
                                            safeBatchWindow->setVisible (false);
                                        }
                                    } : std::function<void()>(nullptr),
                                    // onClose callback - also close batch window
                                    [safeBatchWindow]() {
                                        if (safeBatchWindow != nullptr)
                                        {
                                            safeBatchWindow->clearFiles();
                                            safeBatchWindow->setVisible (false);
                                        }
                                    });
                            }

                            commandManager.commandStatusChanged();
                        });
                    });
        };

        // Callback to get recent output folders
        batchEditorWindow->onGetRecentOutputFolders = [this]()
        {
            return recentBatchOutputFolders;
        };

        // Callback when a folder is used (to add to recent list)
        batchEditorWindow->onOutputFolderUsed = [this] (const juce::File& folder)
        {
            addToRecentBatchOutputFolders (folder);
            // Refresh the batch window's combo box
            if (batchEditorWindow != nullptr)
                batchEditorWindow->refreshRecentOutputFolders();
        };

        // Initialize with current recent folders
        batchEditorWindow->refreshRecentOutputFolders();
    }

    // Show the window (whether newly created or existing)
    batchEditorWindow->setVisible (true);
    batchEditorWindow->toFront (true);
}

//==============================================================================
// Load stems after export for immediate playback
void StemperatorEditor::loadStemsAfterExport (const juce::File& folder)
{
    if (! folder.isDirectory())
        return;

    const char* stemFileNames[] = { "vocals", "drums", "bass", "other", "guitar", "piano" };
    juce::AudioFormatManager formatMgr;
    formatMgr.registerBasicFormats();

    bool allLoaded = true;
    double sampleRate = 44100.0;

    // Get the base name of the current audio file for matching
    juce::String baseName = currentAudioFile.existsAsFile()
        ? currentAudioFile.getFileNameWithoutExtension()
        : "";

    std::cerr << "loadStemsAfterExport: folder=" << folder.getFullPathName().toStdString()
              << " baseName=" << baseName.toStdString() << std::endl;

    if (fileNameLabel)
        fileNameLabel->setText ("Loading stems from " + folder.getFileName() + "...", juce::dontSendNotification);

    // Try to find stem files - they should be named as:
    // 1. baseName_vocals.wav (from export - preferred)
    // 2. vocals.wav (standard)
    // 3. Any file ending with _stemname.wav (fallback)

    for (int i = 0; i < 4; ++i)
    {
        juce::File stemFile;

        // First try: exact match with base name (baseName_vocals.wav)
        if (baseName.isNotEmpty())
        {
            stemFile = folder.getChildFile (baseName + "_" + juce::String (stemFileNames[i]) + ".wav");
            std::cerr << "  Try 1: " << stemFile.getFullPathName().toStdString()
                      << " exists=" << (stemFile.existsAsFile() ? "yes" : "no") << std::endl;
        }

        // Second try: exact match (vocals.wav, drums.wav, etc.)
        if (! stemFile.existsAsFile())
        {
            stemFile = folder.getChildFile (juce::String (stemFileNames[i]) + ".wav");
            std::cerr << "  Try 2: " << stemFile.getFullPathName().toStdString()
                      << " exists=" << (stemFile.existsAsFile() ? "yes" : "no") << std::endl;
        }

        // Third try: find any file ending with _stemname.wav (use most recent)
        if (! stemFile.existsAsFile())
        {
            auto files = folder.findChildFiles (juce::File::findFiles, false, "*_" + juce::String (stemFileNames[i]) + ".wav");
            std::cerr << "  Try 3: found " << files.size() << " files matching *_" << stemFileNames[i] << ".wav" << std::endl;
            if (! files.isEmpty())
            {
                // Sort by modification time, newest first
                files.sort();
                stemFile = files.getLast();  // Get most recent
                std::cerr << "    Using: " << stemFile.getFullPathName().toStdString() << std::endl;
            }
        }

        if (stemFile.existsAsFile())
        {
            auto* reader = formatMgr.createReaderFor (stemFile);
            if (reader)
            {
                separatedStems[i].setSize ((int) reader->numChannels, (int) reader->lengthInSamples);
                reader->read (&separatedStems[i], 0, (int) reader->lengthInSamples, 0, true, true);
                sampleRate = reader->sampleRate;
                std::cerr << "  Loaded " << stemFileNames[i] << ": " << reader->lengthInSamples << " samples" << std::endl;
                delete reader;
            }
            else
            {
                std::cerr << "  Failed to create reader for " << stemFile.getFullPathName().toStdString() << std::endl;
                allLoaded = false;
            }
        }
        else
        {
            std::cerr << "  Could not find " << stemFileNames[i] << " stem file" << std::endl;
            allLoaded = false;
        }
    }

    if (allLoaded)
    {
        std::cerr << "loadStemsAfterExport: All 4 stems loaded successfully" << std::endl;
        for (int i = 0; i < 4; ++i)
        {
            std::cerr << "  Stem " << i << ": " << separatedStems[i].getNumSamples()
                      << " samples, " << separatedStems[i].getNumChannels() << " channels" << std::endl;
        }

        hasSeparatedStems = true;
        playingStemsMode = true;  // Switch to stems mode
        projectNeedsSave = true;  // Mark project as needing save
        lastStemFolder = folder;
        loadedSampleRate = sampleRate;
        addToRecentStems (folder);

        std::cerr << "  Step 1: Stopping transport" << std::endl;
        // Stop current playback
        transportSource.stop();

        std::cerr << "  Step 2: Clearing playback source from processor" << std::endl;
        // IMPORTANT: Disconnect from processor FIRST to prevent audio callback from using invalid source
        if (isStandalone())
            processor.setPlaybackSource (nullptr);

        std::cerr << "  Step 3: Releasing transport resources" << std::endl;
        // Release resources to fully disconnect from old source
        transportSource.releaseResources();

        std::cerr << "  Step 4: Clearing transport source" << std::endl;
        // Clear the current source from transport BEFORE resetting the reader
        transportSource.setSource (nullptr);

        std::cerr << "  Step 5: Resetting old sources" << std::endl;
        // Now safely clear the original file reader and old stem mixer
        readerSource.reset();
        stemMixerSource.reset();

        std::cerr << "  Step 6: Creating stem mixer" << std::endl;
        // Create stem mixer
        stemMixerSource = std::make_unique<StemMixerSource> (separatedStems, processor);

        std::cerr << "  Step 7: Preparing stem mixer for " << loadedSampleRate << "Hz" << std::endl;
        // Prepare the stem mixer source before connecting
        stemMixerSource->prepareToPlay (512, loadedSampleRate);

        std::cerr << "  Step 8: Preparing transport source" << std::endl;
        // Prepare transport source before setting its source
        transportSource.prepareToPlay (512, loadedSampleRate);

        std::cerr << "  Step 9: Setting transport source (total length: "
                  << stemMixerSource->getTotalLength() << ")" << std::endl;
        transportSource.setSource (stemMixerSource.get(), 0, nullptr, loadedSampleRate);

        std::cerr << "  Step 10: Connecting to processor" << std::endl;
        // Connect to processor for audio output
        if (isStandalone())
        {
            processor.setPlaybackSource (&transportSource);
            processor.setSkipSeparation (true);  // Skip GPU processing - stems already AI-separated
        }

        std::cerr << "  Step 11: Updating UI" << std::endl;
        setStemsLoadedMessage();  // Set colorful "STEMS" label
        updateModeIndicator();
        refreshWindowTitle();

        std::cerr << "  Step 12: Updating command status" << std::endl;
        commandManager.commandStatusChanged();

        std::cerr << "  Step 13: Starting playback" << std::endl;
        // Auto-start playback
        transportSource.setPosition (0.0);
        transportSource.start();

        std::cerr << "loadStemsAfterExport: Playback started" << std::endl;
    }
    else
    {
        std::cerr << "loadStemsAfterExport: Failed to load all stems" << std::endl;
        StyledDialogWindow::showMessageBoxAsync (
            juce::MessageBoxIconType::WarningIcon,
            "Load Failed",
            "Could not find all stem files in folder.\n\n"
            "Expected files matching: vocals.wav, drums.wav, bass.wav, other.wav\n"
            "or: *_vocals.wav, *_drums.wav, *_bass.wav, *_other.wav");
    }
}

//==============================================================================
// Export mixed stems with current volume/mute/solo settings
void StemperatorEditor::exportMixedStems()
{
    if (! hasSeparatedStems)
    {
        StyledDialogWindow::showMessageBoxAsync (
            juce::MessageBoxIconType::WarningIcon,
            "No Stems Available",
            "Please separate or load stems first.");
        return;
    }

    // Default file name
    juce::String defaultName = currentAudioFile.existsAsFile()
        ? currentAudioFile.getFileNameWithoutExtension() + "_mix"
        : "stems_mix";

    // Default folder
    juce::File defaultFolder = lastStemFolder.exists()
        ? lastStemFolder
        : juce::File::getSpecialLocation (juce::File::userMusicDirectory);

    // Show export options dialog
    ExportOptionsDialog::show (this, defaultName, defaultFolder, loadedSampleRate,
        [this] (const ExportOptionsDialog::ExportSettings& settings, const juce::File& file)
        {
            // Get current mute/solo/gain states
            auto& apvts = processor.getParameters();

            std::array<bool, 6> muted, soloed;
            std::array<float, 6> gains;
            bool anySoloed = false;

            const char* muteIDs[] = { "vocalsMute", "drumsMute", "bassMute", "otherMute", "guitarMute", "pianoMute" };
            const char* soloIDs[] = { "vocalsSolo", "drumsSolo", "bassSolo", "otherSolo", "guitarSolo", "pianoSolo" };
            const char* gainIDs[] = { "vocalsGain", "drumsGain", "bassGain", "otherGain", "guitarGain", "pianoGain" };

            int numStems = processor.getNumStems();  // 4 or 6
            for (int i = 0; i < numStems; ++i)
            {
                muted[i] = apvts.getRawParameterValue (muteIDs[i])->load() > 0.5f;
                soloed[i] = apvts.getRawParameterValue (soloIDs[i])->load() > 0.5f;
                gains[i] = juce::Decibels::decibelsToGain (apvts.getRawParameterValue (gainIDs[i])->load());
                if (soloed[i])
                    anySoloed = true;
            }

            float masterGain = juce::Decibels::decibelsToGain (apvts.getRawParameterValue ("masterGain")->load());

            // Find the longest stem
            int maxSamples = 0;
            int numChannels = 2;
            for (int i = 0; i < numStems; ++i)
            {
                maxSamples = std::max (maxSamples, separatedStems[i].getNumSamples());
                numChannels = std::max (numChannels, separatedStems[i].getNumChannels());
            }

            if (maxSamples == 0)
            {
                StyledDialogWindow::showMessageBoxAsync (
                    juce::MessageBoxIconType::WarningIcon,
                    "Export Failed",
                    "Stems are empty. Nothing to export.");
                return;
            }

            // Create mix buffer
            juce::AudioBuffer<float> mixBuffer (numChannels, maxSamples);
            mixBuffer.clear();

            // Mix stems
            for (int stemIdx = 0; stemIdx < numStems; ++stemIdx)
            {
                // Check if this stem should be included
                bool shouldPlay = ! muted[stemIdx];
                if (anySoloed)
                    shouldPlay = soloed[stemIdx];

                if (! shouldPlay)
                    continue;

                float finalGain = gains[stemIdx] * masterGain;
                auto& stemBuffer = separatedStems[stemIdx];
                int stemChCount = stemBuffer.getNumChannels();
                int stemSamples = stemBuffer.getNumSamples();

                for (int ch = 0; ch < numChannels; ++ch)
                {
                    int srcCh = std::min (ch, stemChCount - 1);
                    mixBuffer.addFrom (ch, 0, stemBuffer, srcCh, 0, stemSamples, finalGain);
                }
            }

            // Determine output sample rate
            double outputSampleRate = (settings.sampleRate > 0) ? settings.sampleRate : loadedSampleRate;

            // Resample if needed
            juce::AudioBuffer<float> outputBuffer;
            if (settings.sampleRate > 0 && settings.sampleRate != (int) loadedSampleRate)
            {
                // Simple resampling - for production, use proper resampler
                double ratio = outputSampleRate / loadedSampleRate;
                int newNumSamples = (int) (maxSamples * ratio);
                outputBuffer.setSize (numChannels, newNumSamples);

                for (int ch = 0; ch < numChannels; ++ch)
                {
                    const float* src = mixBuffer.getReadPointer (ch);
                    float* dst = outputBuffer.getWritePointer (ch);
                    for (int i = 0; i < newNumSamples; ++i)
                    {
                        double srcPos = i / ratio;
                        int idx = (int) srcPos;
                        float frac = (float) (srcPos - idx);
                        if (idx + 1 < maxSamples)
                            dst[i] = src[idx] * (1.0f - frac) + src[idx + 1] * frac;
                        else
                            dst[i] = src[std::min (idx, maxSamples - 1)];
                    }
                }
                maxSamples = newNumSamples;
            }
            else
            {
                outputBuffer = std::move (mixBuffer);
            }

            // Write to file based on format
            file.deleteFile();
            auto outputStream = std::make_unique<juce::FileOutputStream> (file);

            if (! outputStream->openedOk())
            {
                StyledDialogWindow::showMessageBoxAsync (
                    juce::MessageBoxIconType::WarningIcon,
                    "Export Failed",
                    "Could not open file for writing:\n" + file.getFullPathName());
                return;
            }

            std::unique_ptr<juce::AudioFormatWriter> writer;

            if (settings.format == "WAV")
            {
                juce::WavAudioFormat wavFormat;
                writer.reset (wavFormat.createWriterFor (
                    outputStream.release(),
                    outputSampleRate,
                    static_cast<unsigned int> (numChannels),
                    settings.bitDepth, {}, 0));
            }
            else if (settings.format == "FLAC")
            {
                juce::FlacAudioFormat flacFormat;
                writer.reset (flacFormat.createWriterFor (
                    outputStream.release(),
                    outputSampleRate,
                    static_cast<unsigned int> (numChannels),
                    settings.bitDepth, {}, 0));
            }
            else if (settings.format == "OGG")
            {
                juce::OggVorbisAudioFormat oggFormat;
                // OGG uses quality 0-10 (we store 0.0-1.0, convert to 0-10)
                int oggQuality = (int) (settings.oggQuality * 10.0f);
                writer.reset (oggFormat.createWriterFor (
                    outputStream.release(),
                    outputSampleRate,
                    static_cast<unsigned int> (numChannels),
                    oggFormat.getPossibleBitDepths()[0],  // OGG determines bit depth internally
                    {}, oggQuality));
            }

            if (writer)
            {
                writer->writeFromAudioSampleBuffer (outputBuffer, 0, maxSamples);

                // Build description of what was included
                juce::StringArray includedStems;
                const char* stemNames[] = { "Vocals", "Drums", "Bass", "Other", "Guitar", "Piano" };
                for (int i = 0; i < numStems; ++i)
                {
                    bool included = ! muted[i];
                    if (anySoloed)
                        included = soloed[i];
                    if (included)
                    {
                        float gainDb = juce::Decibels::gainToDecibels (gains[i]);
                        includedStems.add (juce::String (stemNames[i]) + " (" +
                            juce::String (gainDb, 1) + " dB)");
                    }
                }

                float masterDb = juce::Decibels::gainToDecibels (masterGain);
                juce::String desc = "Format: " + settings.format +
                    (settings.format != "OGG" ? " " + juce::String (settings.bitDepth) + "-bit" : "") +
                    " @ " + juce::String ((int) outputSampleRate) + " Hz\n\n" +
                    "Included stems:\n- " + includedStems.joinIntoString ("\n- ") +
                    "\n\nMaster: " + juce::String (masterDb, 1) + " dB\n\n" +
                    "Exported to:\n" + file.getFullPathName();

                StyledDialogWindow::showMessageBoxAsync (
                    juce::MessageBoxIconType::InfoIcon,
                    "Export Complete",
                    desc);
            }
            else
            {
                StyledDialogWindow::showMessageBoxAsync (
                    juce::MessageBoxIconType::WarningIcon,
                    "Export Failed",
                    "Could not create audio writer for " + settings.format + " format.");
            }
        });
}

//==============================================================================
// Reset fileNameLabel to a standard label (for progress messages)
void StemperatorEditor::resetFileNameLabel()
{
    if (! fileNameLabel)
        return;

    // Save bounds before replacing
    auto bounds = fileNameLabel->getBounds();

    // Remove old label
    removeChildComponent (fileNameLabel.get());

    // Create standard label
    fileNameLabel = std::make_unique<juce::Label> ("", "");
    fileNameLabel->setJustificationType (juce::Justification::centredLeft);
    fileNameLabel->setColour (juce::Label::textColourId, PremiumLookAndFeel::Colours::textBright);
    fileNameLabel->setFont (juce::FontOptions (28.0f).withStyle ("Bold"));
    fileNameLabel->setBounds (bounds);
    addAndMakeVisible (*fileNameLabel);
}

//==============================================================================
// Set colorful "STEMS" message with each letter in stem colors
void StemperatorEditor::setStemsLoadedMessage()
{
    if (! fileNameLabel)
        return;

    // Create a custom component that draws the colorful text
    // We use a LookAndFeel override to draw attributed string
    class ColorfulLabel : public juce::Label
    {
    public:
        ColorfulLabel (const std::array<juce::Colour, 6>& colours)
            : stemColours (colours) {}

        void paint (juce::Graphics& g) override
        {
            auto bounds = getLocalBounds().toFloat();

            // Create attributed string with colored STEM letters
            juce::AttributedString attr;
            auto boldFont = getFont().withStyle (juce::Font::bold);

            // S - Vocals (cyan)
            attr.append ("S", boldFont, stemColours[0]);
            // T - Drums (orange)
            attr.append ("T", boldFont, stemColours[1]);
            // E - Bass (purple)
            attr.append ("E", boldFont, stemColours[2]);
            // M - Other (green)
            attr.append ("M", boldFont, stemColours[3]);
            // S - White
            attr.append ("S", boldFont, juce::Colours::white);

            // Rest of the message in white bold
            attr.append (" | Press Space to play | Use mute/solo/volume",
                         boldFont, juce::Colours::white);

            attr.setJustification (juce::Justification::centredLeft);
            attr.draw (g, bounds);
        }

    private:
        const std::array<juce::Colour, 6>& stemColours;
    };

    // Remove old label and create colorful one
    removeChildComponent (fileNameLabel.get());

    auto colorfulLabel = std::make_unique<ColorfulLabel> (stemColours);
    colorfulLabel->setFont (juce::FontOptions (28.0f));
    colorfulLabel->setBounds (fileNameLabel->getBounds());
    addAndMakeVisible (*colorfulLabel);

    // Transfer ownership
    fileNameLabel = std::move (colorfulLabel);
}

//==============================================================================
// Set colorful "LIVE" message with gold/orange gradient
void StemperatorEditor::setLiveLoadedMessage()
{
    if (! fileNameLabel)
        return;

    // Determine the message based on whether stems are already available
    bool stemsAvailable = hasSeparatedStems;

    // Create a custom component that draws the colorful LIVE text
    class LiveLabel : public juce::Label
    {
    public:
        LiveLabel (bool hasStemsAlready) : stemsAlreadySeparated (hasStemsAlready) {}

        void paint (juce::Graphics& g) override
        {
            auto bounds = getLocalBounds().toFloat();

            // Create attributed string with colored LIVE letters
            juce::AttributedString attr;
            auto boldFont = getFont().withStyle (juce::Font::bold);

            // LIVE in gold/orange colors
            attr.append ("L", boldFont, juce::Colour (0xffffd700));  // Gold
            attr.append ("I", boldFont, juce::Colour (0xffffa500));  // Orange
            attr.append ("V", boldFont, juce::Colour (0xffff8c00));  // Dark orange
            attr.append ("E", boldFont, juce::Colour (0xffffd700));  // Gold

            // Message depends on whether stems are already available
            if (stemsAlreadySeparated)
            {
                // Stems exist, just playing original - can switch back to stems mode
                attr.append (" | Press Space to play | Click Mode for STEMS",
                             boldFont, juce::Colours::white);
            }
            else
            {
                // No stems yet - offer to separate
                attr.append (" | Press Space to play or click Mode to separate",
                             boldFont, juce::Colours::white);
            }

            attr.setJustification (juce::Justification::centredLeft);
            attr.draw (g, bounds);
        }

    private:
        bool stemsAlreadySeparated;
    };

    // Remove old label and create colorful one
    removeChildComponent (fileNameLabel.get());

    auto liveLabel = std::make_unique<LiveLabel> (stemsAvailable);
    liveLabel->setFont (juce::FontOptions (28.0f));
    liveLabel->setBounds (fileNameLabel->getBounds());
    addAndMakeVisible (*liveLabel);

    // Transfer ownership
    fileNameLabel = std::move (liveLabel);
}

//==============================================================================
// Project save/load functions
void StemperatorEditor::saveProject()
{
    // Quick save: if we have a current project file, save to it directly
    if (currentProjectFile.existsAsFile())
    {
        saveProjectToFile (currentProjectFile);
    }
    else
    {
        // No current file, use Save As
        saveProjectAs();
    }
}

void StemperatorEditor::saveProjectAs()
{
    // Determine default filename from loaded audio file or stems folder
    juce::String defaultName = "untitled";
    if (currentAudioFile.exists())
        defaultName = currentAudioFile.getFileNameWithoutExtension();
    else if (lastStemFolder.exists())
        defaultName = lastStemFolder.getFileName();

    juce::File defaultLocation = lastStemFolder.exists() ? lastStemFolder
                                : lastAudioFolder.exists() ? lastAudioFolder
                                : juce::File::getSpecialLocation (juce::File::userMusicDirectory);

    fileChooser = std::make_unique<juce::FileChooser> (
        "Save Project As...",
        defaultLocation.getChildFile (defaultName + ".stemperator"),
        "*.stemperator",
        true);

    fileChooser->launchAsync (juce::FileBrowserComponent::saveMode | juce::FileBrowserComponent::canSelectFiles,
        [this] (const juce::FileChooser& c)
        {
            auto file = c.getResult();
            if (file == juce::File())
            {
                quitAfterSave = false;  // User cancelled, don't quit
                return;
            }

            // Ensure .stemperator extension
            if (! file.hasFileExtension (".stemperator"))
                file = file.withFileExtension (".stemperator");

            saveProjectToFile (file);

            // If we were saving before quit, now quit
            if (quitAfterSave)
            {
                quitAfterSave = false;
                juce::JUCEApplication::getInstance()->systemRequestedQuit();
            }
        });
}

void StemperatorEditor::saveProjectToFile (const juce::File& file)
{
    // Build project JSON
    juce::DynamicObject::Ptr project = new juce::DynamicObject();

    // Project metadata
    project->setProperty ("version", 1);
    project->setProperty ("app", "Stemperator");

    // Audio file info
    if (currentAudioFile.exists())
        project->setProperty ("audioFile", currentAudioFile.getFullPathName());

    // If we have separated stems in memory but no permanent folder, save them next to the project
    if (hasSeparatedStems && separatedStems[0].getNumSamples() > 0)
    {
        // Check if lastStemFolder exists and contains the stems
        bool stemsExist = false;
        if (lastStemFolder.isDirectory())
        {
            juce::String prefix = currentAudioFile.exists() ? currentAudioFile.getFileNameWithoutExtension() : "";
            juce::File vocalsFile = prefix.isEmpty()
                ? lastStemFolder.getChildFile ("vocals.wav")
                : lastStemFolder.getChildFile (prefix + "_vocals.wav");
            stemsExist = vocalsFile.existsAsFile();
        }

        // If stems don't exist on disk, save them next to the project file
        if (! stemsExist)
        {
            juce::String baseName = file.getFileNameWithoutExtension();
            juce::File stemsFolder = file.getParentDirectory().getChildFile (baseName + "_stems");
            stemsFolder.createDirectory();

            juce::String prefix = currentAudioFile.exists() ? currentAudioFile.getFileNameWithoutExtension() : baseName;
            const char* stemNames[] = { "vocals", "drums", "bass", "other", "guitar", "piano" };

            juce::WavAudioFormat wavFormat;
            for (size_t i = 0; i < 6; ++i)
            {
                if (separatedStems[i].getNumSamples() > 0)
                {
                    juce::File stemFile = stemsFolder.getChildFile (prefix + "_" + juce::String (stemNames[i]) + ".wav");
                    auto outputStream = std::make_unique<juce::FileOutputStream> (stemFile);
                    if (outputStream->openedOk())
                    {
                        auto writer = std::unique_ptr<juce::AudioFormatWriter> (
                            wavFormat.createWriterFor (
                                outputStream.release(),
                                loadedSampleRate,
                                static_cast<unsigned int> (separatedStems[i].getNumChannels()),
                                24, {}, 0));
                        if (writer)
                            writer->writeFromAudioSampleBuffer (separatedStems[i], 0, separatedStems[i].getNumSamples());
                    }
                }
            }
            lastStemFolder = stemsFolder;
            addToRecentStems (stemsFolder);
        }
    }

    // Stems folder info
    if (lastStemFolder.exists())
        project->setProperty ("stemsFolder", lastStemFolder.getFullPathName());

    // Stem prefix (for loading correct stems from folder with multiple songs)
    if (currentAudioFile.exists())
        project->setProperty ("stemPrefix", currentAudioFile.getFileNameWithoutExtension());

    // Current playback state
    project->setProperty ("playingStemsMode", playingStemsMode);
    project->setProperty ("hasSeparatedStems", hasSeparatedStems);

    // Channel settings (volume, mute, solo for each stem)
    juce::Array<juce::var> channelSettings;
    int numStems = processor.getNumStems();
    for (int i = 0; i < numStems; ++i)
    {
        juce::DynamicObject::Ptr channel = new juce::DynamicObject();

        // Get values from UI components
        if (stemChannels[static_cast<size_t> (i)])
        {
            channel->setProperty ("volume", stemChannels[static_cast<size_t> (i)]->getGainSlider().getValue());
            channel->setProperty ("mute", stemChannels[static_cast<size_t> (i)]->getMuteButton().getToggleState());
            channel->setProperty ("solo", stemChannels[static_cast<size_t> (i)]->getSoloButton().getToggleState());
        }

        channelSettings.add (juce::var (channel.get()));
    }
    project->setProperty ("channels", channelSettings);

    // Master volume
    project->setProperty ("masterVolume", masterSlider.getValue());

    // Model setting
    project->setProperty ("numStems", numStems);

    // Quality setting
    project->setProperty ("quality", currentQuality);

    // Write JSON to file
    juce::var projectVar (project.get());
    juce::String jsonStr = juce::JSON::toString (projectVar, true);

    if (file.replaceWithText (jsonStr))
    {
        currentProjectFile = file;  // Remember for quick save
        projectNeedsSave = false;   // Project is now saved
        refreshWindowTitle();       // Remove unsaved * from title
        addToRecentProjects (file);  // Add to recent projects list
        resetFileNameLabel();
        fileNameLabel->setText ("Project saved: " + file.getFileName(), juce::dontSendNotification);
    }
    else
    {
        juce::AlertWindow::showMessageBoxAsync (juce::AlertWindow::WarningIcon,
            "Save Error", "Failed to save project file.");
    }
}

void StemperatorEditor::loadProject()
{
    // Prevent loading while processing
    if (isExporting.load())
    {
        StyledDialogWindow::showMessageBoxAsync (
            juce::MessageBoxIconType::WarningIcon,
            "Busy",
            "Cannot load project while processing.\nPlease wait for current operation to complete or press Escape to cancel.");
        return;
    }

    juce::File defaultLocation = lastStemFolder.exists() ? lastStemFolder
                                : lastAudioFolder.exists() ? lastAudioFolder
                                : juce::File::getSpecialLocation (juce::File::userMusicDirectory);

    fileChooser = std::make_unique<juce::FileChooser> (
        "Load Project...",
        defaultLocation,
        "*.stemperator",
        true);

    fileChooser->launchAsync (juce::FileBrowserComponent::openMode | juce::FileBrowserComponent::canSelectFiles,
        [this] (const juce::FileChooser& c)
        {
            auto file = c.getResult();
            if (file == juce::File() || ! file.existsAsFile())
                return;

            loadProject (file);
        });
}

void StemperatorEditor::loadProject (const juce::File& file)
{
    // Prevent loading while processing
    if (isExporting.load())
    {
        StyledDialogWindow::showMessageBoxAsync (
            juce::MessageBoxIconType::WarningIcon,
            "Busy",
            "Cannot load project while processing.\nPlease wait for current operation to complete or press Escape to cancel.");
        return;
    }

    // Parse JSON
    juce::String jsonStr = file.loadFileAsString();
    juce::var projectVar = juce::JSON::parse (jsonStr);

    if (! projectVar.isObject())
    {
        juce::AlertWindow::showMessageBoxAsync (juce::AlertWindow::WarningIcon,
            "Load Error", "Invalid project file format.");
        return;
    }

    auto* project = projectVar.getDynamicObject();
    if (! project)
        return;

    // Remember this project file for quick save
    currentProjectFile = file;
    addToRecentProjects (file);  // Add to recent projects list

    resetFileNameLabel();
    fileNameLabel->setText ("Loading project: " + file.getFileName(), juce::dontSendNotification);

    // Stop any current playback
    transportSource.stop();
    transportSource.setSource (nullptr);

    // Load audio file if specified
    juce::String audioPath = project->getProperty ("audioFile").toString();
    if (audioPath.isNotEmpty())
    {
        juce::File audioFile (audioPath);
        if (audioFile.existsAsFile())
        {
            loadAudioFile (audioFile);
        }
        else
        {
            // Try relative path from project file location
            juce::File relativeAudio = file.getParentDirectory().getChildFile (audioFile.getFileName());
            if (relativeAudio.existsAsFile())
                loadAudioFile (relativeAudio);
        }
    }

    // Load stems folder if specified (with prefix for direct loading)
    juce::String stemsPath = project->getProperty ("stemsFolder").toString();
    juce::String stemPrefix = project->getProperty ("stemPrefix").toString();
    if (stemsPath.isNotEmpty())
    {
        juce::File stemsFolder (stemsPath);
        if (! stemsFolder.isDirectory())
        {
            // Try relative path from project file location
            stemsFolder = file.getParentDirectory().getChildFile (juce::File (stemsPath).getFileName());
        }

        if (stemsFolder.isDirectory())
        {
            // Use loadStemsWithPrefix directly to avoid popup selection
            loadStemsWithPrefix (stemsFolder, stemPrefix);
        }
    }

    // Restore channel settings
    auto channelsVar = project->getProperty ("channels");
    if (channelsVar.isArray())
    {
        auto* channels = channelsVar.getArray();

        for (int i = 0; i < channels->size() && i < 6; ++i)
        {
            auto channelVar = (*channels)[i];
            if (channelVar.isObject() && stemChannels[static_cast<size_t> (i)])
            {
                auto* channel = channelVar.getDynamicObject();

                if (channel->hasProperty ("volume"))
                    stemChannels[static_cast<size_t> (i)]->getGainSlider().setValue (
                        (double) channel->getProperty ("volume"), juce::sendNotification);

                if (channel->hasProperty ("mute"))
                    stemChannels[static_cast<size_t> (i)]->getMuteButton().setToggleState (
                        (bool) channel->getProperty ("mute"), juce::sendNotification);

                if (channel->hasProperty ("solo"))
                    stemChannels[static_cast<size_t> (i)]->getSoloButton().setToggleState (
                        (bool) channel->getProperty ("solo"), juce::sendNotification);
            }
        }
    }

    // Restore master volume
    if (project->hasProperty ("masterVolume"))
        masterSlider.setValue ((double) project->getProperty ("masterVolume"), juce::sendNotification);

    // Restore quality setting
    if (project->hasProperty ("quality"))
    {
        currentQuality = (int) project->getProperty ("quality");
        juce::String qualityNames[] = { "Fast", "Balanced", "Best" };
        if (currentQuality >= 0 && currentQuality < 3)
            qualityButton.setButtonText (qualityNames[currentQuality]);
    }

    // Restore playback mode
    playingStemsMode = (bool) project->getProperty ("playingStemsMode");

    // Update UI
    updateModeIndicator();
    commandManager.commandStatusChanged();

    // Show completion message
    juce::MessageManager::callAsync ([this, file]()
    {
        if (hasSeparatedStems)
            setStemsLoadedMessage();
        else if (hasLoadedFile && currentAudioFile.exists())
            setLiveLoadedMessage();
        else
        {
            resetFileNameLabel();
            fileNameLabel->setText ("Project loaded: " + file.getFileName(), juce::dontSendNotification);
        }
    });
}

//==============================================================================
// Find Python environment for AI separation
StemperatorEditor::PythonEnvironment StemperatorEditor::findPythonEnvironment() const
{
    PythonEnvironment env;

    // Strategy 1: Relative to executable (deployed app or build directory)
    auto executableFile = juce::File::getSpecialLocation (juce::File::currentExecutableFile);
    auto executableDir = executableFile.getParentDirectory();

    // Try build structure: build/Stemperator_artefacts/Standalone/Stemperator
    auto projectRoot = executableDir.getParentDirectory().getParentDirectory().getParentDirectory();
    auto venvPython = projectRoot.getChildFile (".venv/bin/python");
    auto separatorScript = projectRoot.getChildFile ("Source/AI/audio_separator_process.py");

    if (venvPython.existsAsFile() && separatorScript.existsAsFile())
    {
        env.projectRoot = projectRoot;
        env.pythonExe = venvPython;
        env.separatorScript = separatorScript;
        return env;
    }

    // Strategy 2: Check STEMPERATOR_ROOT environment variable
    auto envRoot = juce::SystemStats::getEnvironmentVariable ("STEMPERATOR_ROOT", "");
    if (envRoot.isNotEmpty())
    {
        projectRoot = juce::File (envRoot);
        venvPython = projectRoot.getChildFile (".venv/bin/python");
        separatorScript = projectRoot.getChildFile ("Source/AI/audio_separator_process.py");

        if (venvPython.existsAsFile() && separatorScript.existsAsFile())
        {
            env.projectRoot = projectRoot;
            env.pythonExe = venvPython;
            env.separatorScript = separatorScript;
            return env;
        }
    }

    // Strategy 3: Check ~/.config/stemperator/python_path (user config)
    auto configDir = juce::File::getSpecialLocation (juce::File::userApplicationDataDirectory)
                        .getChildFile ("stemperator");
    auto pythonPathFile = configDir.getChildFile ("python_path");
    if (pythonPathFile.existsAsFile())
    {
        auto customPath = pythonPathFile.loadFileAsString().trim();
        if (customPath.isNotEmpty())
        {
            projectRoot = juce::File (customPath);
            venvPython = projectRoot.getChildFile (".venv/bin/python");
            separatorScript = projectRoot.getChildFile ("Source/AI/audio_separator_process.py");

            if (venvPython.existsAsFile() && separatorScript.existsAsFile())
            {
                env.projectRoot = projectRoot;
                env.pythonExe = venvPython;
                env.separatorScript = separatorScript;
                return env;
            }
        }
    }

    // Strategy 4: Common installation paths
    const juce::String commonPaths[] = {
        "/usr/share/stemperator",
        "/opt/stemperator",
        "/usr/local/share/stemperator",
        juce::File::getSpecialLocation (juce::File::userHomeDirectory).getChildFile (".stemperator").getFullPathName()
    };

    for (const auto& path : commonPaths)
    {
        projectRoot = juce::File (path);
        venvPython = projectRoot.getChildFile (".venv/bin/python");
        separatorScript = projectRoot.getChildFile ("Source/AI/audio_separator_process.py");

        if (venvPython.existsAsFile() && separatorScript.existsAsFile())
        {
            env.projectRoot = projectRoot;
            env.pythonExe = venvPython;
            env.separatorScript = separatorScript;
            return env;
        }
    }

    // Not found - return empty (invalid) environment
    return env;
}
