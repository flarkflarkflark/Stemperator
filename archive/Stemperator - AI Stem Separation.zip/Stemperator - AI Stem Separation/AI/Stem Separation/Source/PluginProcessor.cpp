#include "PluginProcessor.h"
#include "PluginEditor.h"
#include <cmath>

StemperatorProcessor::StemperatorProcessor()
#if JucePlugin_Build_Standalone
    // Standalone mode: no live input needed, just file processing
    : AudioProcessor (BusesProperties()
                      .withOutput ("Output", juce::AudioChannelSet::stereo(), true)),
#else
    // Plugin mode: multi-output for DAW stem routing
    : AudioProcessor (BusesProperties()
                      .withInput  ("Input",  juce::AudioChannelSet::stereo(), true)
                      .withOutput ("Vocals", juce::AudioChannelSet::stereo(), true)
                      .withOutput ("Drums",  juce::AudioChannelSet::stereo(), true)
                      .withOutput ("Bass",   juce::AudioChannelSet::stereo(), true)
                      .withOutput ("Other",  juce::AudioChannelSet::stereo(), true)),
#endif
      parameters (*this, nullptr, "Stemperator", createParameterLayout())
{
    // Initialize atomic levels
    for (auto& level : stemLevels)
        level.store (0.0f);

    // Register parameter listeners
    parameters.addParameterListener ("vocalsGain", this);
    parameters.addParameterListener ("drumsGain", this);
    parameters.addParameterListener ("bassGain", this);
    parameters.addParameterListener ("otherGain", this);
    parameters.addParameterListener ("guitarGain", this);
    parameters.addParameterListener ("pianoGain", this);
    parameters.addParameterListener ("masterGain", this);
}

StemperatorProcessor::~StemperatorProcessor()
{
    parameters.removeParameterListener ("vocalsGain", this);
    parameters.removeParameterListener ("drumsGain", this);
    parameters.removeParameterListener ("bassGain", this);
    parameters.removeParameterListener ("otherGain", this);
    parameters.removeParameterListener ("guitarGain", this);
    parameters.removeParameterListener ("pianoGain", this);
    parameters.removeParameterListener ("masterGain", this);
}

juce::AudioProcessorValueTreeState::ParameterLayout StemperatorProcessor::createParameterLayout()
{
    std::vector<std::unique_ptr<juce::RangedAudioParameter>> params;

    // Stem gain controls (dB)
    params.push_back (std::make_unique<juce::AudioParameterFloat> (
        "vocalsGain", "Vocals", juce::NormalisableRange<float> (-60.0f, 12.0f, 0.1f), 0.0f,
        juce::String(), juce::AudioProcessorParameter::genericParameter,
        [] (float v, int) { return juce::String (v, 1) + " dB"; }));

    params.push_back (std::make_unique<juce::AudioParameterFloat> (
        "drumsGain", "Drums", juce::NormalisableRange<float> (-60.0f, 12.0f, 0.1f), 0.0f,
        juce::String(), juce::AudioProcessorParameter::genericParameter,
        [] (float v, int) { return juce::String (v, 1) + " dB"; }));

    params.push_back (std::make_unique<juce::AudioParameterFloat> (
        "bassGain", "Bass", juce::NormalisableRange<float> (-60.0f, 12.0f, 0.1f), 0.0f,
        juce::String(), juce::AudioProcessorParameter::genericParameter,
        [] (float v, int) { return juce::String (v, 1) + " dB"; }));

    params.push_back (std::make_unique<juce::AudioParameterFloat> (
        "otherGain", "Other", juce::NormalisableRange<float> (-60.0f, 12.0f, 0.1f), 0.0f,
        juce::String(), juce::AudioProcessorParameter::genericParameter,
        [] (float v, int) { return juce::String (v, 1) + " dB"; }));

    // Guitar and Piano gain (6-stem model)
    params.push_back (std::make_unique<juce::AudioParameterFloat> (
        "guitarGain", "Guitar", juce::NormalisableRange<float> (-60.0f, 12.0f, 0.1f), 0.0f,
        juce::String(), juce::AudioProcessorParameter::genericParameter,
        [] (float v, int) { return juce::String (v, 1) + " dB"; }));

    params.push_back (std::make_unique<juce::AudioParameterFloat> (
        "pianoGain", "Piano", juce::NormalisableRange<float> (-60.0f, 12.0f, 0.1f), 0.0f,
        juce::String(), juce::AudioProcessorParameter::genericParameter,
        [] (float v, int) { return juce::String (v, 1) + " dB"; }));

    // Mute/Solo
    params.push_back (std::make_unique<juce::AudioParameterBool> ("vocalsMute", "Vocals Mute", false));
    params.push_back (std::make_unique<juce::AudioParameterBool> ("drumsMute", "Drums Mute", false));
    params.push_back (std::make_unique<juce::AudioParameterBool> ("bassMute", "Bass Mute", false));
    params.push_back (std::make_unique<juce::AudioParameterBool> ("otherMute", "Other Mute", false));
    params.push_back (std::make_unique<juce::AudioParameterBool> ("guitarMute", "Guitar Mute", false));
    params.push_back (std::make_unique<juce::AudioParameterBool> ("pianoMute", "Piano Mute", false));

    params.push_back (std::make_unique<juce::AudioParameterBool> ("vocalsSolo", "Vocals Solo", false));
    params.push_back (std::make_unique<juce::AudioParameterBool> ("drumsSolo", "Drums Solo", false));
    params.push_back (std::make_unique<juce::AudioParameterBool> ("bassSolo", "Bass Solo", false));
    params.push_back (std::make_unique<juce::AudioParameterBool> ("otherSolo", "Other Solo", false));
    params.push_back (std::make_unique<juce::AudioParameterBool> ("guitarSolo", "Guitar Solo", false));
    params.push_back (std::make_unique<juce::AudioParameterBool> ("pianoSolo", "Piano Solo", false));

    // Master gain
    params.push_back (std::make_unique<juce::AudioParameterFloat> (
        "masterGain", "Master", juce::NormalisableRange<float> (-60.0f, 12.0f, 0.1f), 0.0f,
        juce::String(), juce::AudioProcessorParameter::genericParameter,
        [] (float v, int) { return juce::String (v, 1) + " dB"; }));

    // Separation quality
    params.push_back (std::make_unique<juce::AudioParameterChoice> (
        "quality", "Quality", juce::StringArray { "Fast", "Balanced", "Best" }, 1));

    // Focus controls for fine-tuning separation (with units for clarity)
    params.push_back (std::make_unique<juce::AudioParameterFloat> (
        juce::ParameterID { "vocalsFocus", 1 }, "Vocals Focus",
        juce::NormalisableRange<float> (0.0f, 100.0f, 1.0f), 50.0f,
        juce::String(), juce::AudioProcessorParameter::genericParameter,
        [] (float v, int) { return juce::String (static_cast<int> (v)) + " %"; }));
    params.push_back (std::make_unique<juce::AudioParameterFloat> (
        juce::ParameterID { "bassCutoff", 1 }, "Bass Cutoff",
        juce::NormalisableRange<float> (60.0f, 300.0f, 1.0f), 150.0f,
        juce::String(), juce::AudioProcessorParameter::genericParameter,
        [] (float v, int) { return juce::String (static_cast<int> (v)) + " Hz"; }));
    params.push_back (std::make_unique<juce::AudioParameterFloat> (
        juce::ParameterID { "drumSensitivity", 1 }, "Drum Sensitivity",
        juce::NormalisableRange<float> (0.0f, 100.0f, 1.0f), 50.0f,
        juce::String(), juce::AudioProcessorParameter::genericParameter,
        [] (float v, int) { return juce::String (static_cast<int> (v)) + " %"; }));

    return { params.begin(), params.end() };
}

void StemperatorProcessor::prepareToPlay (double sampleRate, int samplesPerBlock)
{
    currentSampleRate = sampleRate;
    currentBlockSize = samplesPerBlock;

    separator.prepare (sampleRate, samplesPerBlock);

    // Initialize smoothed values for all possible stems (including 6-stem mode)
    for (int i = 0; i < MaxStems; ++i)
    {
        stemGains[i].reset (sampleRate, 0.02);  // 20ms smoothing
        stemGains[i].setCurrentAndTargetValue (1.0f);
    }
    masterGain.reset (sampleRate, 0.02);
    masterGain.setCurrentAndTargetValue (1.0f);
}

void StemperatorProcessor::releaseResources()
{
    separator.reset();
}

bool StemperatorProcessor::isBusesLayoutSupported (const BusesLayout& layouts) const
{
    // Input must be stereo
    if (layouts.getMainInputChannelSet() != juce::AudioChannelSet::stereo())
        return false;

    // All outputs must be stereo (4 stems for real-time spectral separation)
    for (int i = 0; i < NumStems4; ++i)
    {
        if (layouts.getChannelSet (false, i) != juce::AudioChannelSet::stereo())
            return false;
    }

    return true;
}

void StemperatorProcessor::processBlock (juce::AudioBuffer<float>& buffer, juce::MidiBuffer&)
{
    juce::ScopedNoDenormals noDenormals;

#if JucePlugin_Build_Standalone
    // In standalone mode, get audio from playback source
    if (playbackSource != nullptr)
    {
        // Get audio from the playback source
        juce::AudioSourceChannelInfo info (&buffer, 0, buffer.getNumSamples());
        playbackSource->getNextAudioBlock (info);

        // Apply loudness normalization (playback only - this does NOT affect export files)
        if (normalizationGain != 1.0f)
            buffer.applyGain (normalizationGain);

        // Get level for metering (after normalization so meters reflect actual output)
        float inLevel = 0.0f;
        for (int ch = 0; ch < buffer.getNumChannels(); ++ch)
            inLevel = std::max (inLevel, buffer.getMagnitude (ch, 0, buffer.getNumSamples()));
        inputLevel.store (inLevel);

        // When playing pre-separated stems (StemMixerSource), skip spectral separation
        // The stems are already separated by AI - no GPU processing needed
        if (skipSeparation)
        {
            // StemMixerSource already applies mute/solo/gain, just pass through
            return;
        }

        // Get mute/solo states first to check if we need spectral processing
        bool mutes[NumStems4] = {
            parameters.getRawParameterValue ("vocalsMute")->load() > 0.5f,
            parameters.getRawParameterValue ("drumsMute")->load() > 0.5f,
            parameters.getRawParameterValue ("bassMute")->load() > 0.5f,
            parameters.getRawParameterValue ("otherMute")->load() > 0.5f
        };

        bool solos[NumStems4] = {
            parameters.getRawParameterValue ("vocalsSolo")->load() > 0.5f,
            parameters.getRawParameterValue ("drumsSolo")->load() > 0.5f,
            parameters.getRawParameterValue ("bassSolo")->load() > 0.5f,
            parameters.getRawParameterValue ("otherSolo")->load() > 0.5f
        };

        bool anySolo = solos[0] || solos[1] || solos[2] || solos[3];
        bool anyMute = mutes[0] || mutes[1] || mutes[2] || mutes[3];

        // Get gain values (convert from dB)
        float gains[NumStems4] = {
            juce::Decibels::decibelsToGain (parameters.getRawParameterValue ("vocalsGain")->load()),
            juce::Decibels::decibelsToGain (parameters.getRawParameterValue ("drumsGain")->load()),
            juce::Decibels::decibelsToGain (parameters.getRawParameterValue ("bassGain")->load()),
            juce::Decibels::decibelsToGain (parameters.getRawParameterValue ("otherGain")->load())
        };

        // Master gain
        float master = juce::Decibels::decibelsToGain (parameters.getRawParameterValue ("masterGain")->load());

        // ALWAYS run spectral processing for consistent sound
        // (No bypass mode - this ensures no audible difference when adjusting faders)

        // Get parameters for spectral separation
        float bassCutoff = parameters.getRawParameterValue ("bassCutoff")->load();
        float vocalsFocus = parameters.getRawParameterValue ("vocalsFocus")->load();
        float drumSens = parameters.getRawParameterValue ("drumSensitivity")->load();

        // Update separator parameters
        separator.setBassCutoff (bassCutoff);
        separator.setVocalsFocus (vocalsFocus / 100.0f);
        separator.setDrumSensitivity (drumSens / 100.0f);

        // Process spectral separation (GPU accelerated)
        separator.process (buffer);
        auto& stems = separator.getStems();

        // Mix stems to output based on mute/solo/gain
        buffer.clear();
        const int numSamples = buffer.getNumSamples();
        const int numChannels = std::min (buffer.getNumChannels(), 2);

        // Spectral separation always needs compensation to match original level
        // The separation + reconstruction process adds gain, so we compensate here
        // This compensation is CONSTANT regardless of how many stems are playing
        // to ensure consistent levels when toggling solo/mute
        // Lower value = more headroom, less clipping when all stems play together
        // Reduced from 0.5 to 0.42 to better match STEMS mode output level
        constexpr float stemCompensation = 0.42f;  // ~7.5dB reduction for headroom

        for (int stem = 0; stem < NumStems4; ++stem)
        {
            bool shouldPlay = anySolo ? solos[stem] : !mutes[stem];
            float gain = shouldPlay ? gains[stem] * master * stemCompensation : 0.0f;

            for (int ch = 0; ch < numChannels; ++ch)
            {
                if (stems[stem].getNumChannels() > ch)
                {
                    buffer.addFrom (ch, 0, stems[stem], ch, 0, numSamples, gain);
                }
            }

            // Update level meter
            // Attenuate LIVE mode meters to match STEMS mode visual levels
            constexpr float liveMeterAttenuation = 0.65f;  // ~-3.7 dB reduction for visual balance
            float level = 0.0f;
            for (int ch = 0; ch < numChannels; ++ch)
            {
                if (stems[stem].getNumChannels() > ch)
                    level = std::max (level, stems[stem].getMagnitude (ch, 0, numSamples));
            }
            stemLevels[stem].store (level * gain * liveMeterAttenuation);
        }

        // Apply soft limiting to prevent clipping from stem summing
        // Use a smooth limiter that starts compressing earlier for a more transparent sound
        for (int ch = 0; ch < numChannels; ++ch)
        {
            auto* data = buffer.getWritePointer (ch);
            for (int i = 0; i < numSamples; ++i)
            {
                float x = data[i];
                // Soft knee limiter: starts gentle compression at 0.5, full limiting by 1.0
                // This prevents harsh clipping while maintaining dynamics
                float absX = std::abs (x);
                if (absX > 0.5f)
                {
                    // Soft knee compression from 0.5 to 1.0, then hard tanh limiting
                    // Maps 0.5->0.5, 1.0->0.85, >1.0->asymptotic to 1.0
                    float compressed = 0.5f + 0.35f * std::tanh ((absX - 0.5f) * 2.0f);
                    data[i] = (x > 0) ? compressed : -compressed;
                }
            }
        }

        return;
    }
    else
    {
        // No playback source, output silence
        buffer.clear();
        inputLevel.store (0.0f);
        for (int i = 0; i < NumStems4; ++i)
            stemLevels[i].store (0.0f);
        return;
    }
#endif

    // Plugin mode: Real-time separation processing
    // Get input level for metering
    float inLevel = 0.0f;
    for (int ch = 0; ch < buffer.getNumChannels(); ++ch)
        inLevel = std::max (inLevel, buffer.getMagnitude (ch, 0, buffer.getNumSamples()));
    inputLevel.store (inLevel);

    // Get parameters
    float bassCutoff = parameters.getRawParameterValue ("bassCutoff")->load();
    float vocalsFocus = parameters.getRawParameterValue ("vocalsFocus")->load();
    float drumSens = parameters.getRawParameterValue ("drumSensitivity")->load();

    // Update separator parameters
    separator.setBassCutoff (bassCutoff);
    separator.setVocalsFocus (vocalsFocus / 100.0f);
    separator.setDrumSensitivity (drumSens / 100.0f);

    // Process separation
    separator.process (buffer);

    // Get separated stems
    auto& stems = separator.getStems();

    // Get mute/solo states
    bool mutes[NumStems4] = {
        parameters.getRawParameterValue ("vocalsMute")->load() > 0.5f,
        parameters.getRawParameterValue ("drumsMute")->load() > 0.5f,
        parameters.getRawParameterValue ("bassMute")->load() > 0.5f,
        parameters.getRawParameterValue ("otherMute")->load() > 0.5f
    };

    bool solos[NumStems4] = {
        parameters.getRawParameterValue ("vocalsSolo")->load() > 0.5f,
        parameters.getRawParameterValue ("drumsSolo")->load() > 0.5f,
        parameters.getRawParameterValue ("bassSolo")->load() > 0.5f,
        parameters.getRawParameterValue ("otherSolo")->load() > 0.5f
    };

    bool anySolo = solos[0] || solos[1] || solos[2] || solos[3];

    // Get gain values (convert from dB)
    float gains[NumStems4] = {
        juce::Decibels::decibelsToGain (parameters.getRawParameterValue ("vocalsGain")->load()),
        juce::Decibels::decibelsToGain (parameters.getRawParameterValue ("drumsGain")->load()),
        juce::Decibels::decibelsToGain (parameters.getRawParameterValue ("bassGain")->load()),
        juce::Decibels::decibelsToGain (parameters.getRawParameterValue ("otherGain")->load())
    };

    float master = juce::Decibels::decibelsToGain (parameters.getRawParameterValue ("masterGain")->load());

    // Route stems to outputs
    const int numSamples = buffer.getNumSamples();

    for (int stem = 0; stem < NumStems4; ++stem)
    {
        // Determine if this stem should be audible
        bool shouldPlay = anySolo ? solos[stem] : !mutes[stem];
        float gain = shouldPlay ? gains[stem] * master : 0.0f;

        // Get output bus for this stem
        auto* outputBus = getBus (false, stem);
        if (outputBus == nullptr || !outputBus->isEnabled())
            continue;

        int outputStartChannel = getChannelIndexInProcessBlockBuffer (false, stem, 0);

        // Copy stem to output with gain
        for (int ch = 0; ch < 2; ++ch)
        {
            int outCh = outputStartChannel + ch;
            if (outCh < buffer.getNumChannels() && stems[stem].getNumChannels() > ch)
            {
                buffer.copyFrom (outCh, 0, stems[stem], ch, 0, numSamples);
                buffer.applyGain (outCh, 0, numSamples, gain);
            }
        }

        // Update level meter
        // Attenuate LIVE mode meters to match STEMS mode visual levels
        constexpr float liveMeterAttenuation = 0.65f;  // ~-3.7 dB reduction for visual balance
        float level = 0.0f;
        for (int ch = 0; ch < 2; ++ch)
        {
            int outCh = outputStartChannel + ch;
            if (outCh < buffer.getNumChannels())
                level = std::max (level, buffer.getMagnitude (outCh, 0, numSamples));
        }
        stemLevels[stem].store (level * gain * liveMeterAttenuation);
    }
}

juce::AudioProcessorEditor* StemperatorProcessor::createEditor()
{
    return new StemperatorEditor (*this);
}

void StemperatorProcessor::getStateInformation (juce::MemoryBlock& destData)
{
    auto state = parameters.copyState();
    std::unique_ptr<juce::XmlElement> xml (state.createXml());
    copyXmlToBinary (*xml, destData);
}

void StemperatorProcessor::setStateInformation (const void* data, int sizeInBytes)
{
#if JucePlugin_Build_Standalone
    // In standalone mode, don't restore state - always start with default values (0 dB)
    juce::ignoreUnused (data, sizeInBytes);
#else
    // In plugin mode, restore saved state for DAW recall
    std::unique_ptr<juce::XmlElement> xml (getXmlFromBinary (data, sizeInBytes));
    if (xml && xml->hasTagName (parameters.state.getType()))
        parameters.replaceState (juce::ValueTree::fromXml (*xml));
#endif
}

void StemperatorProcessor::parameterChanged (const juce::String& parameterID, float newValue)
{
    // Handle parameter changes if needed
    juce::ignoreUnused (parameterID, newValue);
}

void StemperatorProcessor::setPlaybackSource (juce::AudioSource* source)
{
    playbackSource = source;
    if (source != nullptr)
    {
        source->prepareToPlay ((int) currentBlockSize, currentSampleRate);
        playbackBuffer.setSize (2, currentBlockSize);
    }
}

juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter()
{
    return new StemperatorProcessor();
}
