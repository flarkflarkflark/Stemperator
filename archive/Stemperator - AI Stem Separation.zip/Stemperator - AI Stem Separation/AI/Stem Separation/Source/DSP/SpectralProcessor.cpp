#include "SpectralProcessor.h"
// GPU acceleration will be added here
