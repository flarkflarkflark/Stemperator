-- @description STEMperator
-- @author flarkAUDIO
-- @version 1.5.0
-- @changelog
--   v1.5.0: Improved cross-platform support
--   - Better Python detection (Homebrew, Windows venvs, user paths)
--   - Added ~/.stemperator/.venv support for global installation
--   - macOS: Added /opt/homebrew paths for Apple Silicon
--   - Windows: Better AppData Python detection
--   - Run "Stemperator: Setup AI Backend" to verify installation
--   v1.4.0: Time selection support
--   - Can now separate time selections (not just media items)
--   - If no item selected, uses time selection instead
--   - Stems are placed at the time selection position
--   v1.3.0: 6-stem model support with Guitar/Piano
--   - Guitar and Piano checkboxes appear when 6-stem model selected
--   - Keys 5/6 toggle Guitar/Piano stems
--   v1.2.0: Scalable/resizable GUI
--   - Window is now resizable (drag edges/corners)
--   - All elements scale proportionally with window size
--   v1.1.0: Major update
--   - Persist settings between sessions (REAPER ExtState)
--   - Keyboard shortcuts: 1-4 toggle stems, K=Karaoke, I=Instrumental
--   v1.0.0: Initial release
-- @provides
--   [main] .
--   [nomain] audio_separator_process.py
-- @link Repository https://github.com/flarkflarkflark/Stemperator
-- @about
--   # Stemperator - AI Stem Separation
--
--   High-quality AI-powered stem separation using Demucs/audio-separator.
--   Separates the selected media item (or time selection) into stems:
--   Vocals, Drums, Bass, Other (and optionally Guitar, Piano with 6-stem model).
--
--   ## Features
--   - Processes ONLY the selected item portion (respects splits!)
--   - Choose which stems to extract via checkboxes or presets
--   - Quick presets: Karaoke, Instrumental, Drums Only
--   - Keyboard shortcuts for fast workflow
--   - Settings persist between sessions
--   - Option to create new tracks or replace in-place (as takes)
--   - GPU acceleration support (NVIDIA CUDA, AMD ROCm)
--
--   ## Keyboard Shortcuts (in dialog)
--   - 1-4: Toggle Vocals/Drums/Bass/Other
--   - K: Karaoke preset (instrumental only)
--   - I: Instrumental preset (no vocals)
--   - D: Drums Only preset
--   - Enter: Start separation
--   - Escape: Cancel
--
--   ## Requirements
--   - Python 3.9+ with audio-separator:
--     `pip install audio-separator[gpu]`
--   - ffmpeg installed and in PATH
--
--   ## License
--   MIT License - https://opensource.org/licenses/MIT

local SCRIPT_NAME = "Stemperator"
local EXT_SECTION = "Stemperator"  -- For ExtState persistence

-- Debug mode - set to true to enable debug logging
local DEBUG_MODE = true
local DEBUG_LOG_PATH = nil  -- Set during init

local function debugLog(msg)
    if not DEBUG_MODE then return end
    if not DEBUG_LOG_PATH then
        local tempDir = os.getenv("TEMP") or os.getenv("TMP") or os.getenv("TMPDIR") or "/tmp"
        DEBUG_LOG_PATH = tempDir .. (package.config:sub(1,1) == "\\" and "\\" or "/") .. "stemperator_debug.log"
    end
    local f = io.open(DEBUG_LOG_PATH, "a")
    if f then
        f:write(os.date("[%Y-%m-%d %H:%M:%S] ") .. tostring(msg) .. "\n")
        f:close()
    end
end

-- Clear debug log on script start
local function clearDebugLog()
    if not DEBUG_MODE then return end
    local tempDir = os.getenv("TEMP") or os.getenv("TMP") or os.getenv("TMPDIR") or "/tmp"
    DEBUG_LOG_PATH = tempDir .. (package.config:sub(1,1) == "\\" and "\\" or "/") .. "stemperator_debug.log"
    local f = io.open(DEBUG_LOG_PATH, "w")
    if f then
        f:write("=== Stemperator Debug Log ===\n")
        f:write("Started: " .. os.date("%Y-%m-%d %H:%M:%S") .. "\n\n")
        f:close()
    end
end

clearDebugLog()
debugLog("Script loaded")

-- Get script path for finding audio_separator_process.py
local info = debug.getinfo(1, "S")
local script_path = info.source:match("@?(.*[/\\])")
if not script_path then script_path = "" end

-- Detect OS
local function getOS()
    local sep = package.config:sub(1,1)
    if sep == "\\" then return "Windows"
    elseif reaper.GetOS():match("OSX") or reaper.GetOS():match("macOS") then return "macOS"
    else return "Linux"
    end
end

local OS = getOS()
local PATH_SEP = OS == "Windows" and "\\" or "/"

-- Get home directory (cross-platform)
local function getHome()
    if OS == "Windows" then
        return os.getenv("USERPROFILE") or "C:\\Users\\Default"
    else
        return os.getenv("HOME") or "/tmp"
    end
end

-- Configuration - Auto-detect paths (cross-platform)
local function findPython()
    local paths = {}
    local home = getHome()

    if OS == "Windows" then
        -- Windows paths - check venvs first
        table.insert(paths, script_path .. ".venv\\Scripts\\python.exe")
        table.insert(paths, home .. "\\Documents\\Stemperator\\.venv\\Scripts\\python.exe")
        table.insert(paths, "C:\\Users\\Administrator\\Documents\\Stemperator\\.venv\\Scripts\\python.exe")
        table.insert(paths, home .. "\\.stemperator\\.venv\\Scripts\\python.exe")
        table.insert(paths, script_path .. "..\\..\\..\\venv\\Scripts\\python.exe")
        -- Standard Python locations
        local localAppData = os.getenv("LOCALAPPDATA") or ""
        table.insert(paths, localAppData .. "\\Programs\\Python\\Python312\\python.exe")
        table.insert(paths, localAppData .. "\\Programs\\Python\\Python311\\python.exe")
        table.insert(paths, localAppData .. "\\Programs\\Python\\Python310\\python.exe")
        table.insert(paths, "python")
    else
        -- Linux/macOS paths - check venvs first
        table.insert(paths, script_path .. ".venv/bin/python")
        table.insert(paths, home .. "/.stemperator/.venv/bin/python")
        table.insert(paths, script_path .. "../.venv/bin/python")
        -- Homebrew on macOS
        if OS == "macOS" then
            table.insert(paths, "/opt/homebrew/bin/python3")
            table.insert(paths, "/usr/local/opt/python@3.12/bin/python3")
        end
        -- User local and system paths
        table.insert(paths, home .. "/.local/bin/python3")
        table.insert(paths, "/usr/local/bin/python3")
        table.insert(paths, "/usr/bin/python3")
        table.insert(paths, "python3")
        table.insert(paths, "python")
    end

    for _, p in ipairs(paths) do
        local f = io.open(p, "r")
        if f then f:close(); return p end
    end
    return OS == "Windows" and "python" or "python3"
end

local function findSeparatorScript()
    local home = getHome()
    local paths = {
        script_path .. "audio_separator_process.py",
        script_path .. ".." .. PATH_SEP .. "AI" .. PATH_SEP .. "audio_separator_process.py",
        script_path .. ".." .. PATH_SEP .. ".." .. PATH_SEP .. "Source" .. PATH_SEP .. "AI" .. PATH_SEP .. "audio_separator_process.py",
        home .. PATH_SEP .. "Documents" .. PATH_SEP .. "Stemperator" .. PATH_SEP .. "scripts" .. PATH_SEP .. "reaper" .. PATH_SEP .. "audio_separator_process.py",
        home .. PATH_SEP .. "Documents" .. PATH_SEP .. "Stemperator" .. PATH_SEP .. "Source" .. PATH_SEP .. "AI" .. PATH_SEP .. "audio_separator_process.py",
    }
    for _, p in ipairs(paths) do
        local f = io.open(p, "r")
        if f then f:close(); return p end
    end
    return script_path .. "audio_separator_process.py"
end

local PYTHON_PATH = findPython()
local SEPARATOR_SCRIPT = findSeparatorScript()

-- Stem configuration (with selection state)
-- First 4 are always shown, Guitar/Piano only for 6-stem model
local STEMS = {
    { name = "Vocals", color = {255, 100, 100}, file = "vocals.wav", selected = true, key = "1", sixStemOnly = false },
    { name = "Drums",  color = {100, 200, 255}, file = "drums.wav", selected = true, key = "2", sixStemOnly = false },
    { name = "Bass",   color = {150, 100, 255}, file = "bass.wav", selected = true, key = "3", sixStemOnly = false },
    { name = "Other",  color = {100, 255, 150}, file = "other.wav", selected = true, key = "4", sixStemOnly = false },
    { name = "Guitar", color = {255, 180, 80},  file = "guitar.wav", selected = true, key = "5", sixStemOnly = true },
    { name = "Piano",  color = {255, 120, 200}, file = "piano.wav", selected = true, key = "6", sixStemOnly = true },
}

-- App version (single source of truth)
local APP_VERSION = "1.5.0"

-- Available models
local MODELS = {
    { id = "htdemucs", name = "Fast", desc = "htdemucs - Fastest model, good quality (4 stems)" },
    { id = "htdemucs_ft", name = "Quality", desc = "htdemucs_ft - Best quality, slower (4 stems)" },
    { id = "htdemucs_6s", name = "6-Stem", desc = "htdemucs_6s - Adds Guitar & Piano separation" },
}

-- Settings (persist between runs)
local SETTINGS = {
    model = "htdemucs",
    createNewTracks = true,
    createFolder = false,
    muteOriginal = false,      -- Mute original item(s) after separation
    muteSelection = false,     -- Mute only the selection portion (splits item)
    deleteOriginal = false,
    deleteSelection = false,   -- Delete only the selection portion (splits item)
    deleteOriginalTrack = false,
    darkMode = true,           -- Dark/Light theme toggle
    parallelProcessing = true, -- Process multiple tracks in parallel (uses more GPU memory)
    language = "en",           -- UI language: en, nl, de
    visualFX = true,           -- Enable/disable visual effects (procedural art backgrounds)
}

-- ========== INTERNATIONALIZATION (i18n) ==========
-- Load language strings from external file
local LANGUAGES = nil
local LANG = nil  -- Current language table

-- Load language file
local function loadLanguages()
    local lang_file = script_path .. "lang" .. PATH_SEP .. "i18n.lua"
    local f = io.open(lang_file, "r")
    if f then
        f:close()
        -- Use dofile to load the language table
        local ok, result = pcall(dofile, lang_file)
        if ok and result then
            LANGUAGES = result
            debugLog("Loaded languages from " .. lang_file)
            return true
        else
            debugLog("Failed to load languages: " .. tostring(result))
        end
    else
        debugLog("Language file not found: " .. lang_file)
    end
    return false
end

-- Set active language
local function setLanguage(lang_code)
    if not LANGUAGES then loadLanguages() end
    if LANGUAGES and LANGUAGES[lang_code] then
        LANG = LANGUAGES[lang_code]
        SETTINGS.language = lang_code
        debugLog("Language set to: " .. lang_code)
    else
        -- Fallback to English
        if LANGUAGES and LANGUAGES.en then
            LANG = LANGUAGES.en
        else
            -- Ultimate fallback - empty table (strings will use hardcoded defaults)
            LANG = {}
        end
        debugLog("Language fallback to English (requested: " .. tostring(lang_code) .. ")")
    end
end

-- Get translated string (with fallback to key)
local function T(key)
    if LANG and LANG[key] then
        return LANG[key]
    end
    -- Fallback: return key with underscores replaced by spaces
    return key:gsub("_", " ")
end

-- Get list of available languages
local function getAvailableLanguages()
    if not LANGUAGES then loadLanguages() end
    local langs = {}
    if LANGUAGES then
        for code, _ in pairs(LANGUAGES) do
            table.insert(langs, code)
        end
    end
    table.sort(langs)
    return langs
end

-- Theme colors (will be set based on darkMode)
local THEME = {}

local function updateTheme()
    if SETTINGS.darkMode then
        -- Dark theme
        THEME = {
            bg = {0.18, 0.18, 0.20},
            bgGradientTop = {0.10, 0.10, 0.12},
            bgGradientBottom = {0.18, 0.18, 0.20},
            inputBg = {0.12, 0.12, 0.14},
            text = {1, 1, 1},
            textDim = {0.7, 0.7, 0.7},
            textHint = {0.5, 0.5, 0.5},
            accent = {0.3, 0.5, 0.8},
            accentHover = {0.4, 0.6, 0.9},
            checkbox = {0.3, 0.3, 0.3},
            checkboxChecked = {0.3, 0.5, 0.7},
            button = {0.2, 0.4, 0.7},
            buttonHover = {0.3, 0.5, 0.8},
            buttonPrimary = {0.2, 0.5, 0.3},
            buttonPrimaryHover = {0.3, 0.6, 0.4},
            border = {0.6, 0.6, 0.6},
        }
    else
        -- Light theme
        THEME = {
            bg = {0.92, 0.92, 0.94},
            bgGradientTop = {0.96, 0.96, 0.98},
            bgGradientBottom = {0.88, 0.88, 0.90},
            inputBg = {0.85, 0.85, 0.87},
            text = {0.1, 0.1, 0.1},
            textDim = {0.3, 0.3, 0.3},
            textHint = {0.5, 0.5, 0.5},
            accent = {0.2, 0.4, 0.7},
            accentHover = {0.3, 0.5, 0.8},
            checkbox = {0.8, 0.8, 0.8},
            checkboxChecked = {0.3, 0.5, 0.7},
            button = {0.3, 0.5, 0.75},
            buttonHover = {0.4, 0.6, 0.85},
            buttonPrimary = {0.25, 0.55, 0.35},
            buttonPrimaryHover = {0.35, 0.65, 0.45},
            border = {0.4, 0.4, 0.4},
        }
    end
end

-- Initialize theme
updateTheme()

-- GUI state
local GUI = {
    running = false,
    result = nil,
    wasMouseDown = false,
    logoWasClicked = false,
    -- Scaling
    baseW = 340,
    baseH = 346,
    minW = 340,
    minH = 346,
    maxW = 1360,  -- Up to 4x scale
    maxH = 1384,
    scale = 1.0,
    -- Tooltip
    tooltip = nil,
    tooltipX = 0,
    tooltipY = 0,
}

-- Store last dialog position for subsequent windows (progress, result, messages)
local lastDialogX, lastDialogY, lastDialogW, lastDialogH = nil, nil, 380, 340

-- Track auto-selected items and tracks for restore on cancel
local autoSelectedItems = {}
local autoSelectionTracks = {}  -- Tracks that were selected when we auto-selected items

-- Store playback state to restore after processing
local savedPlaybackState = 0  -- 0=stopped, 1=playing, 2=paused, 5=recording, 6=record paused

-- Time selection mode state (declared early for visibility in dialogLoop)
local timeSelectionMode = false  -- true when processing time selection instead of item
local timeSelectionStart = nil   -- Start time of selection
local timeSelectionEnd = nil     -- End time of selection

-- Load settings from ExtState
local function loadSettings()
    local model = reaper.GetExtState(EXT_SECTION, "model")
    if model ~= "" then SETTINGS.model = model end

    local createNewTracks = reaper.GetExtState(EXT_SECTION, "createNewTracks")
    if createNewTracks ~= "" then SETTINGS.createNewTracks = (createNewTracks == "1") end

    local createFolder = reaper.GetExtState(EXT_SECTION, "createFolder")
    if createFolder ~= "" then SETTINGS.createFolder = (createFolder == "1") end

    local muteOriginal = reaper.GetExtState(EXT_SECTION, "muteOriginal")
    if muteOriginal ~= "" then SETTINGS.muteOriginal = (muteOriginal == "1") end

    local muteSelection = reaper.GetExtState(EXT_SECTION, "muteSelection")
    if muteSelection ~= "" then SETTINGS.muteSelection = (muteSelection == "1") end

    local deleteOriginal = reaper.GetExtState(EXT_SECTION, "deleteOriginal")
    if deleteOriginal ~= "" then SETTINGS.deleteOriginal = (deleteOriginal == "1") end

    local deleteSelection = reaper.GetExtState(EXT_SECTION, "deleteSelection")
    if deleteSelection ~= "" then SETTINGS.deleteSelection = (deleteSelection == "1") end

    local deleteOriginalTrack = reaper.GetExtState(EXT_SECTION, "deleteOriginalTrack")
    if deleteOriginalTrack ~= "" then SETTINGS.deleteOriginalTrack = (deleteOriginalTrack == "1") end

    local darkMode = reaper.GetExtState(EXT_SECTION, "darkMode")
    if darkMode ~= "" then SETTINGS.darkMode = (darkMode == "1") end
    updateTheme()

    local parallelProcessing = reaper.GetExtState(EXT_SECTION, "parallelProcessing")
    if parallelProcessing ~= "" then SETTINGS.parallelProcessing = (parallelProcessing == "1") end

    local visualFX = reaper.GetExtState(EXT_SECTION, "visualFX")
    if visualFX ~= "" then SETTINGS.visualFX = (visualFX == "1") end

    -- Load language setting and initialize i18n
    local language = reaper.GetExtState(EXT_SECTION, "language")
    if language ~= "" then SETTINGS.language = language end
    setLanguage(SETTINGS.language)

    -- Load stem selections
    for i, stem in ipairs(STEMS) do
        local sel = reaper.GetExtState(EXT_SECTION, "stem_" .. stem.name)
        if sel ~= "" then STEMS[i].selected = (sel == "1") end
    end

    -- Load window size and position
    local winW = reaper.GetExtState(EXT_SECTION, "windowWidth")
    local winH = reaper.GetExtState(EXT_SECTION, "windowHeight")
    local winX = reaper.GetExtState(EXT_SECTION, "windowX")
    local winY = reaper.GetExtState(EXT_SECTION, "windowY")
    if winW ~= "" then
        GUI.savedW = tonumber(winW)
        lastDialogW = GUI.savedW
    end
    if winH ~= "" then
        GUI.savedH = tonumber(winH)
        lastDialogH = GUI.savedH
    end
    if winX ~= "" then
        GUI.savedX = tonumber(winX)
        lastDialogX = GUI.savedX
    end
    if winY ~= "" then
        GUI.savedY = tonumber(winY)
        lastDialogY = GUI.savedY
    end
end

-- Save settings to ExtState
local function saveSettings()
    reaper.SetExtState(EXT_SECTION, "model", SETTINGS.model, true)
    reaper.SetExtState(EXT_SECTION, "createNewTracks", SETTINGS.createNewTracks and "1" or "0", true)
    reaper.SetExtState(EXT_SECTION, "createFolder", SETTINGS.createFolder and "1" or "0", true)
    reaper.SetExtState(EXT_SECTION, "muteOriginal", SETTINGS.muteOriginal and "1" or "0", true)
    reaper.SetExtState(EXT_SECTION, "muteSelection", SETTINGS.muteSelection and "1" or "0", true)
    reaper.SetExtState(EXT_SECTION, "deleteOriginal", SETTINGS.deleteOriginal and "1" or "0", true)
    reaper.SetExtState(EXT_SECTION, "deleteSelection", SETTINGS.deleteSelection and "1" or "0", true)
    reaper.SetExtState(EXT_SECTION, "deleteOriginalTrack", SETTINGS.deleteOriginalTrack and "1" or "0", true)
    reaper.SetExtState(EXT_SECTION, "darkMode", SETTINGS.darkMode and "1" or "0", true)
    reaper.SetExtState(EXT_SECTION, "parallelProcessing", SETTINGS.parallelProcessing and "1" or "0", true)
    reaper.SetExtState(EXT_SECTION, "visualFX", SETTINGS.visualFX and "1" or "0", true)
    reaper.SetExtState(EXT_SECTION, "language", SETTINGS.language, true)

    for _, stem in ipairs(STEMS) do
        reaper.SetExtState(EXT_SECTION, "stem_" .. stem.name, stem.selected and "1" or "0", true)
    end

    -- Save window size and position
    -- Prefer gfx.w/h if window is open, otherwise use lastDialogW/H
    local saveW = (gfx.w and gfx.w > 0) and gfx.w or lastDialogW
    local saveH = (gfx.h and gfx.h > 0) and gfx.h or lastDialogH
    if saveW and saveW > 0 then
        reaper.SetExtState(EXT_SECTION, "windowWidth", tostring(math.floor(saveW)), true)
    end
    if saveH and saveH > 0 then
        reaper.SetExtState(EXT_SECTION, "windowHeight", tostring(math.floor(saveH)), true)
    end
    -- Save position from lastDialogX/Y (updated continuously in window loop)
    if lastDialogX and lastDialogY then
        reaper.SetExtState(EXT_SECTION, "windowX", tostring(math.floor(lastDialogX)), true)
        reaper.SetExtState(EXT_SECTION, "windowY", tostring(math.floor(lastDialogY)), true)
    end
end

-- Preset functions
local function applyPresetKaraoke()
    -- Instrumental only (no vocals) - includes Guitar+Piano in 6-stem mode
    STEMS[1].selected = false  -- Vocals OFF
    STEMS[2].selected = true   -- Drums
    STEMS[3].selected = true   -- Bass
    STEMS[4].selected = true   -- Other
    if STEMS[5] then STEMS[5].selected = true end   -- Guitar (6-stem)
    if STEMS[6] then STEMS[6].selected = true end   -- Piano (6-stem)
end

local function applyPresetInstrumental()
    -- Same as karaoke but clearer name
    applyPresetKaraoke()
end

local function applyPresetDrumsOnly()
    STEMS[1].selected = false  -- Vocals
    STEMS[2].selected = true   -- Drums ONLY
    STEMS[3].selected = false  -- Bass
    STEMS[4].selected = false  -- Other
    if STEMS[5] then STEMS[5].selected = false end  -- Guitar
    if STEMS[6] then STEMS[6].selected = false end  -- Piano
end

local function applyPresetVocalsOnly()
    STEMS[1].selected = true   -- Vocals ONLY
    STEMS[2].selected = false  -- Drums
    STEMS[3].selected = false  -- Bass
    STEMS[4].selected = false  -- Other
    if STEMS[5] then STEMS[5].selected = false end  -- Guitar
    if STEMS[6] then STEMS[6].selected = false end  -- Piano
end

local function applyPresetBassOnly()
    STEMS[1].selected = false  -- Vocals
    STEMS[2].selected = false  -- Drums
    STEMS[3].selected = true   -- Bass ONLY
    STEMS[4].selected = false  -- Other
    if STEMS[5] then STEMS[5].selected = false end  -- Guitar
    if STEMS[6] then STEMS[6].selected = false end  -- Piano
end

local function applyPresetOtherOnly()
    STEMS[1].selected = false  -- Vocals
    STEMS[2].selected = false  -- Drums
    STEMS[3].selected = false  -- Bass
    STEMS[4].selected = true   -- Other ONLY
    if STEMS[5] then STEMS[5].selected = false end  -- Guitar
    if STEMS[6] then STEMS[6].selected = false end  -- Piano
end

local function applyPresetGuitarOnly()
    -- Only works with 6-stem model
    STEMS[1].selected = false  -- Vocals
    STEMS[2].selected = false  -- Drums
    STEMS[3].selected = false  -- Bass
    STEMS[4].selected = false  -- Other
    STEMS[5].selected = true   -- Guitar ONLY
    STEMS[6].selected = false  -- Piano
end

local function applyPresetPianoOnly()
    -- Only works with 6-stem model
    STEMS[1].selected = false  -- Vocals
    STEMS[2].selected = false  -- Drums
    STEMS[3].selected = false  -- Bass
    STEMS[4].selected = false  -- Other
    STEMS[5].selected = false  -- Guitar
    STEMS[6].selected = true   -- Piano ONLY
end

local function applyPresetAll()
    for i = 1, #STEMS do
        STEMS[i].selected = true
    end
end

local function rgbToReaperColor(r, g, b)
    return reaper.ColorToNative(r, g, b) | 0x1000000
end

-- Get monitor bounds at a specific screen position (for multi-monitor support)
-- Returns screenLeft, screenTop, screenRight, screenBottom
local function getMonitorBoundsAt(x, y)
    local screenLeft, screenTop, screenRight, screenBottom = nil, nil, nil, nil

    -- Ensure integer coordinates
    x = math.floor(x)
    y = math.floor(y)

    -- Method 1: SWS BR_Win32_GetMonitorRectFromRect (most reliable for multi-monitor)
    if reaper.BR_Win32_GetMonitorRectFromRect then
        local retval, mLeft, mTop, mRight, mBottom = reaper.BR_Win32_GetMonitorRectFromRect(true, x, y, x+1, y+1)
        if retval and mLeft and mTop and mRight and mBottom and mRight > mLeft and mBottom > mTop then
            return mLeft, mTop, mRight, mBottom
        end
    end

    -- Method 2: JS_Window API to find monitor from point
    if reaper.JS_Window_GetRect then
        local mainHwnd = reaper.GetMainHwnd()
        if mainHwnd then
            local retval, left, top, right, bottom = reaper.JS_Window_GetRect(mainHwnd)
            if retval and left and top and right and bottom then
                -- Check if mouse is within REAPER main window area
                if x >= left and x <= right and y >= top and y <= bottom then
                    screenLeft, screenTop = left, top
                    screenRight, screenBottom = right, bottom
                else
                    -- Mouse is on a different monitor - estimate based on mouse position
                    -- Assume standard monitor size around the mouse position
                    local monitorW, monitorH = 1920, 1080
                    screenLeft = math.floor(x / monitorW) * monitorW
                    screenTop = math.floor(y / monitorH) * monitorH
                    screenRight = screenLeft + monitorW
                    screenBottom = screenTop + monitorH
                end
            end
        end
    end

    -- Fallback: estimate monitor based on mouse position
    if not screenLeft then
        local monitorW, monitorH = 1920, 1080
        -- Handle negative coordinates (monitors to the left/above primary)
        if x >= 0 then
            screenLeft = math.floor(x / monitorW) * monitorW
        else
            screenLeft = math.floor((x + 1) / monitorW) * monitorW - monitorW
        end
        if y >= 0 then
            screenTop = math.floor(y / monitorH) * monitorH
        else
            screenTop = math.floor((y + 1) / monitorH) * monitorH - monitorH
        end
        screenRight = screenLeft + monitorW
        screenBottom = screenTop + monitorH
    end

    return screenLeft, screenTop, screenRight, screenBottom
end

-- Clamp window position to stay fully on screen
local function clampToScreen(winX, winY, winW, winH, refX, refY)
    local screenLeft, screenTop, screenRight, screenBottom = getMonitorBoundsAt(refX, refY)
    local margin = 20

    winX = math.max(screenLeft + margin, winX)
    winY = math.max(screenTop + margin, winY)
    winX = math.min(screenRight - winW - margin, winX)
    winY = math.min(screenBottom - winH - margin, winY)

    return winX, winY
end

-- Check if there's a valid time selection
local function hasTimeSelection()
    local startTime, endTime = reaper.GetSet_LoopTimeRange(false, false, 0, 0, false)
    return endTime > startTime
end

-- Message window state (for errors, warnings, info)
local messageWindowState = {
    title = "",
    message = "",
    icon = "info",  -- "info", "warning", "error"
    wasMouseDown = false,
    startTime = 0,
    monitorSelection = false,  -- When true, auto-close and open main dialog on selection
}

-- Forward declarations (functions defined later in file)
local main
local showMessage

-- STEM colors for window borders (used by all windows)
local STEM_BORDER_COLORS = {
    {255, 100, 100},  -- Red (Vocals)
    {100, 200, 255},  -- Blue (Drums)
    {150, 100, 255},  -- Purple (Bass)
    {100, 255, 150},  -- Green (Other)
}

-- Draw colored STEM gradient border at top of window
local function drawStemBorder(x, y, w, thickness)
    thickness = thickness or 3
    for i = 0, w - 1 do
        local colorIdx = math.floor(i / w * 4) + 1
        colorIdx = math.min(4, math.max(1, colorIdx))
        local c = STEM_BORDER_COLORS[colorIdx]
        gfx.set(c[1]/255, c[2]/255, c[3]/255, 0.9)
        gfx.line(x + i, y, x + i, y + thickness - 1)
    end
end

-- Help system state (replaces Art Gallery)
local helpState = {
    currentTab = 1,  -- 1=Welcome, 2=Quick Start, 3=Stems, 4=Art Gallery
    wasMouseDown = false,
    wasRightMouseDown = false,
    startTime = 0,
    -- Art gallery sub-state
    currentArt = 1,
    -- Camera controls for art gallery
    zoom = 1.0,
    panX = 0,
    panY = 0,
    targetZoom = 1.0,
    targetPanX = 0,
    targetPanY = 0,
    isDragging = false,
    dragStartX = 0,
    dragStartY = 0,
    dragStartPanX = 0,
    dragStartPanY = 0,
    lastMouseWheel = 0,
    -- Rotation (right-click drag)
    rotation = 0,
    targetRotation = 0,
    isRotating = false,
    rotateStartX = 0,
    rotateStartY = 0,
    rotateStartAngle = 0,
    -- Click vs drag detection
    clickStartX = 0,
    clickStartY = 0,
    wasDrag = false,
    -- Text zoom for non-gallery tabs
    textZoom = 1.0,
    targetTextZoom = 1.0,
    -- Text pan for non-gallery tabs (left-click drag)
    textPanX = 0,
    textPanY = 0,
    targetTextPanX = 0,
    targetTextPanY = 0,
    textDragging = false,
    textDragStartX = 0,
    textDragStartY = 0,
    textDragStartPanX = 0,
    textDragStartPanY = 0,
    -- Track where help was opened from (for correct return)
    openedFrom = "start",  -- "start" or "dialog"
    -- Gallery controls fade (for immersive mode)
    controlsOpacity = 1.0,
    targetControlsOpacity = 1.0,
}

-- Keep artGalleryState as alias for compatibility
local artGalleryState = helpState

-- Main dialog background art state
local mainDialogArt = {
    -- Camera controls
    zoom = 1.0,
    targetZoom = 1.0,
    panX = 0,
    panY = 0,
    targetPanX = 0,
    targetPanY = 0,
    rotation = 0,
    targetRotation = 0,
    -- Mouse interaction state
    isDragging = false,
    isRotating = false,
    dragStartX = 0,
    dragStartY = 0,
    dragStartPanX = 0,
    dragStartPanY = 0,
    rotateStartX = 0,
    rotateStartAngle = 0,
    lastMouseWheel = 0,
    -- Click vs drag detection
    clickStartX = 0,
    clickStartY = 0,
    clickStartTime = 0,
    wasDrag = false,
    wasMouseDown = false,
    wasRightMouseDown = false,
}

-- ============================================
-- AUDIO REACTIVITY SYSTEM (real-time peak detection)
-- ============================================
local audioReactive = {
    enabled = true,
    peakL = 0,          -- Current left channel peak (0-1)
    peakR = 0,          -- Current right channel peak (0-1)
    peakMono = 0,       -- Combined mono peak
    smoothPeakL = 0,    -- Smoothed left peak (for animation)
    smoothPeakR = 0,    -- Smoothed right peak
    smoothPeakMono = 0, -- Smoothed mono peak
    bass = 0,           -- Simulated bass (low freq) energy
    mid = 0,            -- Simulated mid freq energy
    high = 0,           -- Simulated high freq energy
    smoothBass = 0,
    smoothMid = 0,
    smoothHigh = 0,
    beatDetected = false,
    lastBeatTime = 0,
    beatDecay = 0,      -- Visual decay after beat
    history = {},       -- Peak history for beat detection
    historySize = 20,
    -- MilkDrop-style waveform buffer (circular display)
    waveformHistory = {},    -- 120 samples for circular waveform display
    waveformSize = 120,      -- Number of points in waveform ring
    waveformIndex = 1,       -- Current write position (circular buffer)
}

-- Update audio reactivity from master track
local function updateAudioReactivity()
    if not audioReactive.enabled then return end

    -- Get master track
    local masterTrack = reaper.GetMasterTrack(0)
    if not masterTrack then return end

    -- Get peak info for left and right channels
    -- Channel 0 = left, channel 1 = right
    local peakL = reaper.Track_GetPeakInfo(masterTrack, 0) or 0
    local peakR = reaper.Track_GetPeakInfo(masterTrack, 1) or 0

    -- Store raw peaks
    audioReactive.peakL = peakL
    audioReactive.peakR = peakR
    audioReactive.peakMono = (peakL + peakR) / 2

    -- Smooth interpolation (fast attack, slow decay)
    local attackSpeed = 0.5
    local decaySpeed = 0.08

    -- Left channel
    if peakL > audioReactive.smoothPeakL then
        audioReactive.smoothPeakL = audioReactive.smoothPeakL + (peakL - audioReactive.smoothPeakL) * attackSpeed
    else
        audioReactive.smoothPeakL = audioReactive.smoothPeakL + (peakL - audioReactive.smoothPeakL) * decaySpeed
    end

    -- Right channel
    if peakR > audioReactive.smoothPeakR then
        audioReactive.smoothPeakR = audioReactive.smoothPeakR + (peakR - audioReactive.smoothPeakR) * attackSpeed
    else
        audioReactive.smoothPeakR = audioReactive.smoothPeakR + (peakR - audioReactive.smoothPeakR) * decaySpeed
    end

    -- Mono
    local mono = audioReactive.peakMono
    if mono > audioReactive.smoothPeakMono then
        audioReactive.smoothPeakMono = audioReactive.smoothPeakMono + (mono - audioReactive.smoothPeakMono) * attackSpeed
    else
        audioReactive.smoothPeakMono = audioReactive.smoothPeakMono + (mono - audioReactive.smoothPeakMono) * decaySpeed
    end

    -- Simulate frequency bands from peak variations (pseudo-spectral)
    -- This is an approximation - real FFT would need more complex setup
    local now = os.clock()
    table.insert(audioReactive.history, mono)
    if #audioReactive.history > audioReactive.historySize then
        table.remove(audioReactive.history, 1)
    end

    -- Calculate variance for "energy" simulation
    if #audioReactive.history >= 5 then
        local avg = 0
        for _, v in ipairs(audioReactive.history) do avg = avg + v end
        avg = avg / #audioReactive.history

        -- Bass = slower changes (low variance in recent samples)
        local recentAvg = (audioReactive.history[#audioReactive.history] +
                          (audioReactive.history[#audioReactive.history - 1] or 0) +
                          (audioReactive.history[#audioReactive.history - 2] or 0)) / 3
        audioReactive.bass = math.min(1, recentAvg * 1.5)

        -- High = fast changes (difference between consecutive samples)
        local diff = math.abs((audioReactive.history[#audioReactive.history] or 0) -
                              (audioReactive.history[#audioReactive.history - 1] or 0))
        audioReactive.high = math.min(1, diff * 5)

        -- Mid = everything else
        audioReactive.mid = math.min(1, avg * 1.2)
    end

    -- Smooth frequency bands
    audioReactive.smoothBass = audioReactive.smoothBass + (audioReactive.bass - audioReactive.smoothBass) * 0.15
    audioReactive.smoothMid = audioReactive.smoothMid + (audioReactive.mid - audioReactive.smoothMid) * 0.2
    audioReactive.smoothHigh = audioReactive.smoothHigh + (audioReactive.high - audioReactive.smoothHigh) * 0.3

    -- Simple beat detection (sudden increase in mono peak)
    if #audioReactive.history >= 3 then
        local current = audioReactive.history[#audioReactive.history] or 0
        local previous = audioReactive.history[#audioReactive.history - 2] or 0
        local threshold = 0.15

        if current - previous > threshold and (now - audioReactive.lastBeatTime) > 0.1 then
            audioReactive.beatDetected = true
            audioReactive.lastBeatTime = now
            audioReactive.beatDecay = 1.0
        else
            audioReactive.beatDetected = false
        end
    end

    -- Decay beat visual
    audioReactive.beatDecay = audioReactive.beatDecay * 0.9

    -- Update waveform history (circular buffer for MilkDrop-style display)
    audioReactive.waveformHistory[audioReactive.waveformIndex] = mono
    audioReactive.waveformIndex = (audioReactive.waveformIndex % audioReactive.waveformSize) + 1
end

-- ============================================
-- PROCEDURAL ART GENERATOR (shared across all windows)
-- ============================================
local proceduralArt = {
    seed = 0,
    style = 0,  -- Start at 0 so first generation picks any style
    lastClick = 0,
    elements = {},
    time = 0,
    title = "",
    subtitle = "",
    subtitleIdx = 0,  -- Track subtitle to avoid repeats
}

-- ============================================
-- MEGA ANIMATION NAME GENERATOR (1000+ unique names!)
-- Combines adjectives + nouns + modifiers for infinite variety
-- ============================================
local animNameParts = {
    -- Adjectives (will be combined)
    adjectives = {
        EN = {"Cosmic", "Quantum", "Neural", "Crystal", "Spiral", "Fractal", "Harmonic",
              "Digital", "Neon", "Electric", "Psychedelic", "Hypnotic", "Ethereal", "Astral",
              "Prismatic", "Holographic", "Bioluminescent", "Chromatic", "Kinetic", "Pulsating",
              "Shimmering", "Cascading", "Orbiting", "Floating", "Dancing", "Swirling",
              "Glitching", "Morphing", "Breathing", "Dreaming", "Exploding", "Imploding",
              "Infinite", "Chaotic", "Serene", "Turbulent", "Liquid", "Crystalline", "Molten",
              "Frozen", "Temporal", "Spatial", "Dimensional", "Parallel", "Inverted", "Mirrored"},
        NL = {"Kosmische", "Quantum", "Neurale", "Kristallen", "Spiraal", "Fractale", "Harmonische",
              "Digitale", "Neon", "Elektrische", "Psychedelische", "Hypnotische", "Etherische", "Astrale",
              "Prismatische", "Holografische", "Bioluminescente", "Chromatische", "Kinetische", "Pulserende",
              "Glinsterende", "Vallende", "Orbiterende", "Zwevende", "Dansende", "Wervelende",
              "Glitchende", "Morfende", "Ademende", "Dromende", "Exploderende", "Imploderende",
              "Oneindige", "Chaotische", "Serene", "Turbulente", "Vloeibare", "Kristallijne", "Gesmolten",
              "Bevroren", "Temporele", "Ruimtelijke", "Dimensionale", "Parallelle", "Omgekeerde", "Gespiegelde"},
        DE = {"Kosmische", "Quanten", "Neurale", "Kristall", "Spiral", "Fraktale", "Harmonische",
              "Digitale", "Neon", "Elektrische", "Psychedelische", "Hypnotische", "Ätherische", "Astrale",
              "Prismatische", "Holographische", "Biolumineszente", "Chromatische", "Kinetische", "Pulsierende",
              "Schimmernde", "Kaskadierende", "Orbitierende", "Schwebende", "Tanzende", "Wirbelnde",
              "Glitchende", "Morphende", "Atmende", "Träumende", "Explodierende", "Implodierende",
              "Unendliche", "Chaotische", "Ruhige", "Turbulente", "Flüssige", "Kristalline", "Geschmolzene",
              "Gefrorene", "Temporale", "Räumliche", "Dimensionale", "Parallele", "Invertierte", "Gespiegelte"},
    },
    -- Nouns (the main thing)
    nouns = {
        EN = {"Waves", "Network", "Formation", "Galaxy", "Dream", "Storm", "Pulse", "Light",
              "Flow", "Sculpture", "Rain", "Field", "Ripples", "Echo", "Bloom", "Stream",
              "Vortex", "Nebula", "Matrix", "Cascade", "Aurora", "Plasma", "Waveform", "Spectrum",
              "Lattice", "Constellation", "Supernova", "Helix", "Mandala", "Tessellation", "Geometry",
              "Particles", "Ribbons", "Threads", "Filaments", "Bubbles", "Orbs", "Crystals", "Flames",
              "Shadows", "Reflections", "Fractals", "Patterns", "Symmetry", "Chaos", "Order", "Entropy",
              "Resonance", "Vibration", "Oscillation", "Frequency", "Amplitude", "Phase", "Harmonics"},
        NL = {"Golven", "Netwerk", "Formatie", "Melkweg", "Droom", "Storm", "Puls", "Licht",
              "Stroom", "Sculptuur", "Regen", "Veld", "Rimpelingen", "Echo", "Bloei", "Stroom",
              "Vortex", "Nevel", "Matrix", "Cascade", "Noorderlicht", "Plasma", "Golfvorm", "Spectrum",
              "Rooster", "Sterrenbeeld", "Supernova", "Helix", "Mandala", "Tessellatie", "Geometrie",
              "Deeltjes", "Linten", "Draden", "Filamenten", "Bellen", "Bollen", "Kristallen", "Vlammen",
              "Schaduwen", "Reflecties", "Fractals", "Patronen", "Symmetrie", "Chaos", "Orde", "Entropie",
              "Resonantie", "Trilling", "Oscillatie", "Frequentie", "Amplitude", "Fase", "Harmonieën"},
        DE = {"Wellen", "Netzwerk", "Formation", "Galaxie", "Traum", "Sturm", "Puls", "Licht",
              "Fluss", "Skulptur", "Regen", "Feld", "Wellen", "Echo", "Blüte", "Strom",
              "Wirbel", "Nebel", "Matrix", "Kaskade", "Polarlicht", "Plasma", "Wellenform", "Spektrum",
              "Gitter", "Sternbild", "Supernova", "Helix", "Mandala", "Tessellation", "Geometrie",
              "Partikel", "Bänder", "Fäden", "Filamente", "Blasen", "Kugeln", "Kristalle", "Flammen",
              "Schatten", "Reflexionen", "Fraktale", "Muster", "Symmetrie", "Chaos", "Ordnung", "Entropie",
              "Resonanz", "Schwingung", "Oszillation", "Frequenz", "Amplitude", "Phase", "Harmonien"},
    },
    -- Fun modifiers (sometimes added)
    modifiers = {
        EN = {"of Infinity", "from Beyond", "in Motion", "Reborn", "Unleashed", "Awakening",
              "X", "2.0", "Redux", "Remixed", "Evolved", "Transcendent", "Ultimate", "Prime",
              "at Dawn", "at Dusk", "in Flux", "Ascending", "Descending", "Converging", "Diverging",
              "Amplified", "Distorted", "Filtered", "Unfiltered", "Raw", "Pure", "Mixed", "Blended"},
        NL = {"van Oneindigheid", "uit het Niets", "in Beweging", "Herboren", "Ontketend", "Ontwakend",
              "X", "2.0", "Redux", "Geremixt", "Geëvolueerd", "Transcendent", "Ultiem", "Prime",
              "bij Dageraad", "bij Schemering", "in Flux", "Stijgend", "Dalend", "Convergerend", "Divergerend",
              "Versterkt", "Vervormd", "Gefilterd", "Ongefilterd", "Rauw", "Puur", "Gemixt", "Gemengd"},
        DE = {"der Unendlichkeit", "aus dem Nichts", "in Bewegung", "Wiedergeboren", "Entfesselt", "Erwachend",
              "X", "2.0", "Redux", "Remixed", "Evolviert", "Transzendent", "Ultimativ", "Prime",
              "bei Morgengrauen", "bei Dämmerung", "im Fluss", "Aufsteigend", "Absteigend", "Konvergierend", "Divergierend",
              "Verstärkt", "Verzerrt", "Gefiltert", "Ungefiltert", "Roh", "Rein", "Gemischt", "Vermischt"},
    },
    -- Silly/funny prefixes (rarely added for humor)
    sillyPrefixes = {
        EN = {"Mega", "Ultra", "Super", "Hyper", "Turbo", "Giga", "Über", "Extra", "Meta", "Proto",
              "Neo", "Retro", "Pseudo", "Quasi", "Semi", "Anti", "Counter", "Post", "Pre", "Trans"},
        NL = {"Mega", "Ultra", "Super", "Hyper", "Turbo", "Giga", "Über", "Extra", "Meta", "Proto",
              "Neo", "Retro", "Pseudo", "Quasi", "Semi", "Anti", "Contra", "Post", "Pre", "Trans"},
        DE = {"Mega", "Ultra", "Super", "Hyper", "Turbo", "Giga", "Über", "Extra", "Meta", "Proto",
              "Neo", "Retro", "Pseudo", "Quasi", "Semi", "Anti", "Kontra", "Post", "Prä", "Trans"},
    },
}

-- Generate a unique random art name based on seed
local function generateArtName(seed, lang)
    lang = lang or "EN"
    local adj = animNameParts.adjectives[lang] or animNameParts.adjectives.EN
    local noun = animNameParts.nouns[lang] or animNameParts.nouns.EN
    local mod = animNameParts.modifiers[lang] or animNameParts.modifiers.EN
    local silly = animNameParts.sillyPrefixes[lang] or animNameParts.sillyPrefixes.EN

    -- Use seed to pick consistently but randomly
    local adjIdx = math.floor(seed % #adj) + 1
    local nounIdx = math.floor((seed / 100) % #noun) + 1
    local modIdx = math.floor((seed / 10000) % #mod) + 1
    local sillyIdx = math.floor((seed / 1000000) % #silly) + 1

    local name = adj[adjIdx] .. " " .. noun[nounIdx]

    -- 30% chance to add modifier
    if (seed % 10) < 3 then
        name = name .. " " .. mod[modIdx]
    end

    -- 10% chance to add silly prefix
    if (seed % 100) < 10 then
        name = silly[sillyIdx] .. "-" .. name
    end

    -- Add unique number suffix (always different)
    local uniqueNum = seed % 10000
    if (seed % 5) == 0 then
        name = name .. " #" .. uniqueNum
    end

    return name
end

-- Legacy art style names (for backwards compatibility, now generated dynamically)
local artStyles = {
    "Cosmic Waves", "Neural Network", "Crystal Formation", "Spiral Galaxy",
    "Mandala Dream", "Particle Storm", "Geometric Pulse", "Prism Light",
    "Abstract Flow", "Sound Sculpture", "Digital Rain", "Quantum Field",
    "Harmonic Ripples", "Fractal Echo", "Neon Bloom", "Data Stream",
}

-- Seeded random number generator
local function seededRandom(seed, index)
    local x = math.sin(seed * 12.9898 + index * 78.233) * 43758.5453
    return x - math.floor(x)
end

-- Generate new random art with unique procedurally generated name!
local function generateNewArt()
    -- Save old art for crossfade transition
    if proceduralArt.seed and proceduralArt.seed ~= 0 then
        proceduralArt.oldSeed = proceduralArt.seed
        proceduralArt.oldStyle = proceduralArt.style
        proceduralArt.oldElements = proceduralArt.elements
        proceduralArt.oldTime = proceduralArt.time
        proceduralArt.transitionProgress = 0  -- Start crossfade
        proceduralArt.transitionDuration = 1.5  -- 1.5 seconds crossfade
    end

    proceduralArt.seed = os.time() * 1000 + math.random(1, 999999)

    -- Pick a DIFFERENT style than the current one (now 1-1000 for 100 MilkDrop-inspired patterns!)
    local oldStyle = proceduralArt.style or 0
    local newStyle
    repeat
        newStyle = math.random(1, 1000)
    until newStyle ~= oldStyle

    proceduralArt.style = newStyle
    proceduralArt.time = 0

    -- Generate unique art name based on current language!
    local lang = SETTINGS and SETTINGS.language or "EN"
    proceduralArt.title = generateArtName(proceduralArt.seed, lang)

    -- Generate subtitle with variation
    local subtitleParts = {
        EN = {"by STEMperator AI", "flarkAUDIO creation", "Algorithmic beauty",
              "Digital impression", "Sound visualization", "Audio to visual",
              "Stem separation art", "Processing dreams", "Infinite creativity",
              "Unique vision", "Generated moment", "Ephemeral beauty",
              "Sonic canvas", "Frequency art", "Waveform poetry"},
        NL = {"door STEMperator AI", "flarkAUDIO creatie", "Algoritmische schoonheid",
              "Digitale impressie", "Geluidsvisualisatie", "Audio naar beeld",
              "Stem separatie kunst", "Verwerkingsdromen", "Oneindige creativiteit",
              "Unieke visie", "Gegenereerd moment", "Vergankelijke schoonheid",
              "Sonisch canvas", "Frequentie kunst", "Golfvorm poëzie"},
        DE = {"von STEMperator AI", "flarkAUDIO Kreation", "Algorithmische Schönheit",
              "Digitaler Eindruck", "Klangvisualisierung", "Audio zu Bild",
              "Stem Trennungskunst", "Verarbeitungsträume", "Unendliche Kreativität",
              "Einzigartige Vision", "Generierter Moment", "Vergängliche Schönheit",
              "Sonische Leinwand", "Frequenzkunst", "Wellenformpoesie"},
    }
    local subs = subtitleParts[lang] or subtitleParts.EN
    local subIdx = (proceduralArt.seed % #subs) + 1
    proceduralArt.subtitle = subs[subIdx] .. " #" .. (proceduralArt.seed % 10000)

    -- Pre-generate elements based on style (more elements for richer animations)
    proceduralArt.elements = {}
    local seed = proceduralArt.seed

    -- Generate 80 elements for more complex animations
    for i = 1, 80 do
        -- Clamp random values to prevent out-of-bounds array access
        local colorVal = math.min(3.999, seededRandom(seed, i * 13) * 4)
        local shapeVal = math.min(5.999, seededRandom(seed, i * 17) * 6)  -- More shape variety
        local elem = {
            x = seededRandom(seed, i * 3) * 2 - 1,
            y = seededRandom(seed, i * 3 + 1) * 2 - 1,
            size = seededRandom(seed, i * 3 + 2) * 0.4 + 0.03,
            speed = seededRandom(seed, i * 7) * 3 + 0.3,
            phase = seededRandom(seed, i * 11) * math.pi * 2,
            colorIdx = math.floor(colorVal) + 1,  -- 1-4
            shape = math.floor(shapeVal) + 1,     -- 1-6 (more shapes!)
            rotation = seededRandom(seed, i * 19) * math.pi * 2,
            rotSpeed = (seededRandom(seed, i * 23) - 0.5) * 3,
            -- New parameters for audio reactivity
            audioSensitivity = seededRandom(seed, i * 29) * 2,  -- How much it reacts to audio
            frequencyBand = math.floor(seededRandom(seed, i * 31) * 3) + 1,  -- 1=bass, 2=mid, 3=high
            pulseRate = seededRandom(seed, i * 37) * 4 + 1,
            trailLength = math.floor(seededRandom(seed, i * 41) * 5),
        }
        table.insert(proceduralArt.elements, elem)
    end
end

-- Draw procedural art in a given area (MEGA VERSION with 100+ styles + audio reactivity!)
-- rotation: optional rotation angle in radians (applied to animated elements)
-- skipBackground: if true, don't draw the dark background (caller handles it)
-- alphaMult: optional alpha multiplier for crossfade transitions (0-1)
-- overrideSeed/overrideStyle: optional overrides for drawing old pattern during crossfade
local function drawProceduralArtInternal(x, y, w, h, time, rotation, skipBackground, alphaMult, overrideSeed, overrideStyle)
    rotation = rotation or 0
    alphaMult = alphaMult or 1.0
    local seed = overrideSeed or proceduralArt.seed
    local style = overrideStyle or proceduralArt.style
    local cx, cy = x + w/2, y + h/2
    local radius = math.min(w, h) / 2 * 0.9

    -- Get audio reactive values (if available)
    updateAudioReactivity()
    local audioPeak = audioReactive.smoothPeakMono or 0
    local audioBass = audioReactive.smoothBass or 0
    local audioMid = audioReactive.smoothMid or 0
    local audioHigh = audioReactive.smoothHigh or 0
    local audioBeat = audioReactive.beatDecay or 0

    -- Helper: rotate point around center
    local function rotatePoint(px, py)
        if rotation == 0 then return px, py end
        local dx, dy = px - cx, py - cy
        local cos_r, sin_r = math.cos(rotation), math.sin(rotation)
        return cx + dx * cos_r - dy * sin_r, cy + dx * sin_r + dy * cos_r
    end

    -- Rainbow color cycling (psychedelic!)
    local function rainbowShift(baseColor, phase)
        local r = baseColor[1] + math.sin(phase) * 0.3
        local g = baseColor[2] + math.sin(phase + 2.1) * 0.3
        local b = baseColor[3] + math.sin(phase + 4.2) * 0.3
        return math.max(0, math.min(1, r)), math.max(0, math.min(1, g)), math.max(0, math.min(1, b))
    end

    -- STEM colors for art
    local colors = {
        {1.0, 0.4, 0.4},   -- Vocals red
        {0.4, 0.8, 1.0},   -- Drums blue
        {0.6, 0.4, 1.0},   -- Bass purple
        {0.4, 1.0, 0.6},   -- Other green
    }

    -- Dark semi-transparent background for art area (unless caller handles it)
    if not skipBackground then
        gfx.set(0.05, 0.05, 0.08, 0.95)
        gfx.rect(x, y, w, h, 1)
    end

    -- Decompose style into components for 1000 combinations (100 MilkDrop-inspired patterns!)
    -- style 1-1000 maps to: basePattern (1-100) x variation (1-10)
    local basePattern = ((style - 1) % 100) + 1
    local variation = math.floor((style - 1) / 100) + 1

    -- Audio-responsive modifiers based on variation
    local audioMult = 1 + (variation / 10) * audioPeak * 2
    local speedMult = 1 + (variation % 3) * 0.3 + audioMid * 0.5
    local sizeMult = 1 + (variation % 4) * 0.2 + audioBass * 0.6
    local colorShift = time * (variation % 5) * 0.5 + audioPeak * 3

    -- === BASE PATTERN 1: Cosmic Waves ===
    if basePattern == 1 then
        local layers = 6 + (variation % 5)
        for layer = 1, layers do
            local col = colors[(layer % 4) + 1]
            local r, g, b = rainbowShift(col, colorShift + layer * 0.5)
            local alpha = (0.1 + (layer / layers) * 0.25 + audioBeat * 0.15) * audioMult
            gfx.set(r, g, b, math.min(0.8, alpha))

            local waveFreq = 4 + (variation % 4) * 2
            local waveAmp = radius * (0.2 + audioBass * 0.3)

            for i = 0, w, 2 do
                local wave = math.sin((i / w) * waveFreq * math.pi + time * speedMult * 2 + layer * 0.5) * waveAmp
                local wave2 = math.cos((i / w) * (waveFreq - 2) * math.pi - time * speedMult * 1.5) * waveAmp * 0.6
                local yPos = cy + wave + wave2 + (layer - layers/2) * (12 + audioHigh * 10)
                local px, py = rotatePoint(x + i, yPos)
                local dotSize = (2 + layer * 0.3 + audioPeak * 3) * sizeMult
                gfx.circle(px, py, dotSize, 1, 1)
            end
        end

    -- === BASE PATTERN 2: Neural Network ===
    elseif basePattern == 2 then
        local nodeCount = 15 + variation * 3
        local nodes = {}
        for i = 1, nodeCount do
            local nx = cx + seededRandom(seed, i) * w * 0.8 - w * 0.4
            local ny = cy + seededRandom(seed, i + 100) * h * 0.8 - h * 0.4
            -- Audio-reactive node movement
            nx = nx + math.sin(time * speedMult + i) * (20 + audioBass * 30)
            ny = ny + math.cos(time * speedMult * 0.7 + i) * (15 + audioMid * 25)
            local px, py = rotatePoint(nx, ny)
            nodes[i] = {x = px, y = py, col = colors[(i % 4) + 1]}
        end

        local connectionDist = 100 + variation * 20 + audioPeak * 50
        for i = 1, #nodes do
            for j = i + 1, #nodes do
                local dist = math.sqrt((nodes[i].x - nodes[j].x)^2 + (nodes[i].y - nodes[j].y)^2)
                if dist < connectionDist then
                    local alpha = (1 - dist / connectionDist) * 0.4 * (0.5 + 0.5 * math.sin(time * 3 + i + j)) + audioBeat * 0.2
                    local r, g, b = rainbowShift(nodes[i].col, colorShift + i)
                    gfx.set(r, g, b, math.min(0.6, alpha))
                    gfx.line(nodes[i].x, nodes[i].y, nodes[j].x, nodes[j].y)
                end
            end
        end

        for i, node in ipairs(nodes) do
            local pulse = 1 + 0.4 * math.sin(time * 4 + i) + audioPeak * 0.5
            local r, g, b = rainbowShift(node.col, colorShift + i * 0.3)
            gfx.set(r, g, b, 0.7 + audioBeat * 0.3)
            gfx.circle(node.x, node.y, (4 + variation) * pulse * sizeMult, 1, 1)
        end

    -- === BASE PATTERN 3: Crystal Formation ===
    elseif basePattern == 3 then
        local crystalCount = 20 + variation * 5
        for i = 1, crystalCount do
            local angle = seededRandom(seed, i) * math.pi * 2 + time * 0.1 * speedMult
            local dist = seededRandom(seed, i + 50) * radius * (0.7 + audioBass * 0.4)
            local size = (seededRandom(seed, i + 100) * 25 + 8 + audioPeak * 20) * sizeMult
            local col = colors[(i % 4) + 1]
            local px = cx + math.cos(angle) * dist
            local py = cy + math.sin(angle) * dist
            px, py = rotatePoint(px, py)
            local rot = angle + time * 0.3 * speedMult

            local r, g, b = rainbowShift(col, colorShift + i * 0.2)
            local sides = 4 + (variation % 3)
            gfx.set(r, g, b, 0.35 + audioBeat * 0.2)

            for j = 0, sides - 1 do
                local a1 = rot + (j / sides) * math.pi * 2
                local a2 = rot + ((j + 1) / sides) * math.pi * 2
                local stretch = 0.4 + (variation % 4) * 0.15
                gfx.line(px + math.cos(a1) * size, py + math.sin(a1) * size * stretch,
                         px + math.cos(a2) * size, py + math.sin(a2) * size * stretch)
            end
        end

    -- === BASE PATTERN 4: Spiral Galaxy ===
    elseif basePattern == 4 then
        local arms = 2 + (variation % 4)
        local spiralTightness = 3 + variation
        for arm = 1, arms do
            local col = colors[(arm % 4) + 1]
            local armOffset = (arm - 1) * (math.pi * 2 / arms)
            local starCount = 150 + variation * 30

            for i = 0, starCount do
                local t = i / starCount
                local angle = t * math.pi * spiralTightness + armOffset + time * 0.2 * speedMult
                local dist = t * radius * (1 + audioBass * 0.3)
                local px = cx + math.cos(angle) * dist
                local py = cy + math.sin(angle) * dist * 0.5
                px, py = rotatePoint(px, py)

                local r, g, b = rainbowShift(col, colorShift + t * 2)
                local alpha = (1 - t) * 0.5 + audioBeat * 0.2
                local size = ((1 - t) * 3 + 1 + audioPeak * 2) * sizeMult
                gfx.set(r, g, b, math.min(0.8, alpha))
                gfx.circle(px, py, size, 1, 1)
            end
        end

        -- Audio-reactive center glow
        local glowSize = 25 + audioBass * 30
        for r = glowSize, 5, -3 do
            local glowAlpha = 0.08 + audioBeat * 0.1
            gfx.set(1, 0.9 + audioHigh * 0.1, 0.6 + audioPeak * 0.2, glowAlpha)
            gfx.circle(cx, cy, r, 1, 1)
        end

    -- === BASE PATTERN 5: Mandala Dream ===
    elseif basePattern == 5 then
        local segments = 8 + variation * 2
        local rings = 5 + (variation % 4)

        for ring = 1, rings do
            local ringRadius = ring * radius / (rings + 1) * (1 + audioBass * 0.3)
            local col = colors[(ring % 4) + 1]
            local ringSpeed = (ring % 2 == 0 and 1 or -1) * speedMult

            for seg = 0, segments - 1 do
                local angle = (seg / segments) * math.pi * 2 + time * 0.15 * ringSpeed
                local px = cx + math.cos(angle) * ringRadius
                local py = cy + math.sin(angle) * ringRadius
                px, py = rotatePoint(px, py)

                local r, g, b = rainbowShift(col, colorShift + ring + seg * 0.1)
                gfx.set(r, g, b, 0.4 + audioBeat * 0.2)
                local nodeSize = (4 + ring * 1.5 + audioPeak * 5) * sizeMult
                gfx.circle(px, py, nodeSize, 1, 1)

                -- Connecting lines
                if ring > 1 then
                    local innerRadius = (ring - 1) * radius / (rings + 1) * (1 + audioBass * 0.3)
                    local ix = cx + math.cos(angle) * innerRadius
                    local iy = cy + math.sin(angle) * innerRadius
                    ix, iy = rotatePoint(ix, iy)
                    gfx.set(r, g, b, 0.15 + audioMid * 0.1)
                    gfx.line(px, py, ix, iy)
                end
            end
        end

    -- === BASE PATTERN 6: Particle Storm ===
    elseif basePattern == 6 then
        for idx, elem in ipairs(proceduralArt.elements) do
            if idx > 60 then break end  -- Limit for performance
            local col = colors[elem.colorIdx]
            local audioBoost = elem.audioSensitivity * (
                elem.frequencyBand == 1 and audioBass or
                elem.frequencyBand == 2 and audioMid or audioHigh
            )

            local px = cx + elem.x * w * 0.45 + math.sin(time * elem.speed * speedMult + elem.phase) * (25 + audioBoost * 40)
            local py = cy + elem.y * h * 0.45 + math.cos(time * elem.speed * speedMult * 0.7 + elem.phase) * (20 + audioBoost * 30)
            px, py = rotatePoint(px, py)

            local size = elem.size * 18 * (1 + 0.4 * math.sin(time * elem.pulseRate + elem.phase) + audioBoost * 0.8) * sizeMult
            local r, g, b = rainbowShift(col, colorShift + elem.phase)
            gfx.set(r, g, b, 0.5 + audioBeat * 0.3)
            gfx.circle(px, py, size, 1, 1)

            -- Trails
            local trails = elem.trailLength + math.floor(audioPeak * 3)
            for trail = 1, trails do
                local tx = px - math.sin(time * elem.speed * speedMult + elem.phase) * trail * (6 + audioHigh * 4)
                local ty = py - math.cos(time * elem.speed * speedMult * 0.7 + elem.phase) * trail * (6 + audioHigh * 4)
                gfx.set(r, g, b, (0.15 + audioBeat * 0.1) / trail)
                gfx.circle(tx, ty, size * 0.6, 1, 1)
            end
        end

    -- === BASE PATTERN 7: Geometric Pulse ===
    elseif basePattern == 7 then
        local shapes = 6 + variation
        for i = 1, shapes do
            local col = colors[(i % 4) + 1]
            local pulse = 1 + 0.25 * math.sin(time * 2 * speedMult + i * 0.5) + audioBass * 0.4
            local size = (radius / shapes) * i * pulse * sizeMult
            local rot = time * 0.2 * speedMult * (i % 2 == 0 and 1 or -1) + i * 0.2 + rotation
            local sides = 3 + ((i + variation) % 5)

            local r, g, b = rainbowShift(col, colorShift + i * 0.4)
            gfx.set(r, g, b, 0.25 + audioBeat * 0.2)

            for j = 0, sides - 1 do
                local a1 = rot + (j / sides) * math.pi * 2
                local a2 = rot + ((j + 1) / sides) * math.pi * 2
                local x1, y1 = cx + math.cos(a1) * size, cy + math.sin(a1) * size
                local x2, y2 = cx + math.cos(a2) * size, cy + math.sin(a2) * size
                gfx.line(x1, y1, x2, y2)
            end
        end

    -- === BASE PATTERN 8: Prism Light ===
    elseif basePattern == 8 then
        local rays = 15 + variation * 3
        for ray = 1, rays do
            local angle = seededRandom(seed, ray) * math.pi * 2
            local col = colors[(ray % 4) + 1]
            local rayLen = radius * (0.4 + seededRandom(seed, ray + 50) * 0.5 + audioPeak * 0.3)
            local wobble = math.sin(time * 2 * speedMult + ray) * 0.15

            for band = 0, 4 do
                local bandAngle = angle + band * 0.04 + wobble + rotation
                local alpha = (0.12 - band * 0.02 + audioBeat * 0.1) * audioMult
                local r, g, b = rainbowShift(col, colorShift + band + ray * 0.1)
                gfx.set(r, g, b, math.min(0.5, alpha))
                gfx.line(cx, cy, cx + math.cos(bandAngle) * rayLen, cy + math.sin(bandAngle) * rayLen)
            end
        end

        -- Pulsing center
        local centerSize = 12 + audioBass * 15
        gfx.set(1, 1, 1, 0.25 + audioBeat * 0.3)
        gfx.circle(cx, cy, centerSize, 1, 1)

    -- === BASE PATTERN 9: Fluid Blobs ===
    elseif basePattern == 9 then
        local blobs = 4 + (variation % 4)
        for layer = 1, blobs do
            local col = colors[(layer % 4) + 1]
            local r, g, b = rainbowShift(col, colorShift + layer)
            gfx.set(r, g, b, 0.12 + audioBeat * 0.1)

            local offsetX = math.sin(time * speedMult + layer * 1.3) * (40 + audioBass * 50)
            local offsetY = math.cos(time * speedMult * 0.8 + layer * 1.7) * (30 + audioMid * 40)
            local blobSize = radius * (0.3 + layer * 0.08 + audioPeak * 0.2) * sizeMult

            local blobCx = cx + offsetX
            local blobCy = cy + offsetY

            local points = 60 + variation * 10
            for i = 0, points do
                local angle = (i / points) * math.pi * 2
                local noise = math.sin(angle * (3 + variation) + time * 2 * speedMult + layer) * 0.35
                local blobR = blobSize * (1 + noise + audioHigh * 0.3)
                local bx = blobCx + math.cos(angle + rotation) * blobR
                local by = blobCy + math.sin(angle + rotation) * blobR
                gfx.circle(bx, by, 2 + audioPeak * 2, 1, 1)
            end
        end

    -- === BASE PATTERN 10: Hypnotic Rings ===
    elseif basePattern == 10 then
        local ringCount = 8 + variation
        for i = 1, ringCount do
            local ringRadius = (radius / ringCount) * i * (1 + audioBass * 0.2)
            local col = colors[(i % 4) + 1]
            local r, g, b = rainbowShift(col, colorShift + i * 0.3)

            local phase = time * speedMult * (i % 2 == 0 and 1 or -1) + i * 0.3
            local thickness = 2 + (variation % 3) + audioPeak * 3
            local alpha = 0.2 + (i / ringCount) * 0.2 + audioBeat * 0.15

            gfx.set(r, g, b, math.min(0.7, alpha))

            -- Draw ring as series of points for rotation support
            local segments = 60
            for j = 0, segments - 1 do
                local a1 = (j / segments) * math.pi * 2 + phase + rotation
                local wobble = math.sin(a1 * (3 + variation % 4) + time * 3) * (5 + audioHigh * 10)
                local x1 = cx + math.cos(a1) * (ringRadius + wobble)
                local y1 = cy + math.sin(a1) * (ringRadius + wobble)
                gfx.circle(x1, y1, thickness, 1, 1)
            end
        end

    -- === BASE PATTERN 11: Feedback Tunnel (MilkDrop-inspired) ===
    elseif basePattern == 11 then
        -- Concentric rings zooming inward with warp
        local ringCount = 12 + variation
        local maxRadius = radius * (1.5 + audioBass * 0.5)

        for ring = 1, ringCount do
            -- Ring position oscillates based on time (zoom feedback effect)
            local ringPhase = (time * speedMult * 0.5 + ring * 0.15) % 1
            local ringRadius = maxRadius * ringPhase

            -- MilkDrop-style warp based on distance from center
            local warpAmount = 0.2 + audioMid * 0.3

            local col = colors[(ring % 4) + 1]
            local r, g, b = rainbowShift(col, colorShift + ring * 0.2 + ringPhase * 2)
            local alpha = (1 - ringPhase) * 0.4 + audioBeat * 0.2
            gfx.set(r, g, b, math.min(0.8, alpha))

            -- Draw ring with warp distortion
            local segments = 60
            for j = 0, segments - 1 do
                local angle = (j / segments) * math.pi * 2
                -- Warp effect: radius varies with angle
                local warp = 1 + math.sin(angle * (3 + variation) + time * 2) * warpAmount
                local warpedRadius = ringRadius * warp

                local x1 = cx + math.cos(angle + rotation) * warpedRadius
                local y1 = cy + math.sin(angle + rotation) * warpedRadius
                local dotSize = (3 - ringPhase * 2 + audioPeak * 2) * sizeMult
                gfx.circle(x1, y1, math.max(1, dotSize), 1, 1)
            end
        end

        -- Center glow (MilkDrop-style bright center)
        local centerGlow = 20 + audioBass * 30 + audioBeat * 20
        for r = centerGlow, 5, -3 do
            local glowAlpha = 0.1 + audioBeat * 0.15
            gfx.set(1, 0.9, 0.7, glowAlpha)
            gfx.circle(cx, cy, r, 1, 1)
        end

    -- === BASE PATTERN 12: Waveform Ring (MilkDrop-inspired audio visualization) ===
    elseif basePattern == 12 then
        -- Circular audio waveform display
        local waveRings = 3 + (variation % 3)

        for ring = 1, waveRings do
            local baseRadius = radius * (0.3 + ring * 0.2) * (1 + audioBass * 0.2)
            local col = colors[(ring % 4) + 1]
            local r, g, b = rainbowShift(col, colorShift + ring)

            -- Draw waveform ring using history buffer
            local points = audioReactive.waveformSize or 60
            local prevX, prevY

            for i = 0, points - 1 do
                local angle = (i / points) * math.pi * 2 + time * 0.3 * speedMult * (ring % 2 == 0 and 1 or -1)

                -- Get waveform value from history
                local histIdx = ((audioReactive.waveformIndex or 1) + i) % (audioReactive.waveformSize or 60) + 1
                local waveVal = (audioReactive.waveformHistory and audioReactive.waveformHistory[histIdx]) or audioPeak * 0.5

                -- Waveform modulates radius
                local waveRadius = baseRadius * (1 + waveVal * 0.5 * (1 + variation * 0.1))

                local wx = cx + math.cos(angle + rotation) * waveRadius
                local wy = cy + math.sin(angle + rotation) * waveRadius

                local alpha = 0.3 + waveVal * 0.4 + audioBeat * 0.2
                gfx.set(r, g, b, math.min(0.8, alpha))

                local dotSize = (2 + waveVal * 4 + audioPeak * 3) * sizeMult
                gfx.circle(wx, wy, dotSize, 1, 1)

                -- Connect dots with lines
                if prevX and i > 0 then
                    gfx.set(r, g, b, alpha * 0.5)
                    gfx.line(prevX, prevY, wx, wy)
                end
                prevX, prevY = wx, wy
            end

            -- Close the ring
            if prevX then
                local angle = rotation + time * 0.3 * speedMult * (ring % 2 == 0 and 1 or -1)
                local histIdx = ((audioReactive.waveformIndex or 1)) % (audioReactive.waveformSize or 60) + 1
                local waveVal = (audioReactive.waveformHistory and audioReactive.waveformHistory[histIdx]) or audioPeak * 0.5
                local waveRadius = baseRadius * (1 + waveVal * 0.5)
                local wx = cx + math.cos(angle + rotation) * waveRadius
                local wy = cy + math.sin(angle + rotation) * waveRadius
                gfx.set(r, g, b, 0.2)
                gfx.line(prevX, prevY, wx, wy)
            end
        end

    -- === BASE PATTERN 13: Supernova Burst ===
    elseif basePattern == 13 then
        -- Explosive rays from center with beat-triggered bursts
        local rayCount = 20 + variation * 4
        local burstIntensity = audioBeat > 0.3 and (audioBeat * 2) or 1

        for ray = 1, rayCount do
            local baseAngle = (ray / rayCount) * math.pi * 2 + time * 0.1 * speedMult
            local col = colors[(ray % 4) + 1]
            local r, g, b = rainbowShift(col, colorShift + ray * 0.15)

            -- Ray length pulses with audio
            local rayLen = radius * (0.3 + seededRandom(seed, ray) * 0.7)
            rayLen = rayLen * (1 + audioPeak * 0.5) * burstIntensity

            -- Multi-layered glow rays
            for layer = 1, 3 do
                local layerAngle = baseAngle + (layer - 2) * 0.02
                local layerLen = rayLen * (1 - layer * 0.1)
                local alpha = (0.3 / layer + audioBeat * 0.15) * audioMult

                gfx.set(r, g, b, math.min(0.6, alpha))

                local endX = cx + math.cos(layerAngle + rotation) * layerLen
                local endY = cy + math.sin(layerAngle + rotation) * layerLen
                gfx.line(cx, cy, endX, endY)
            end

            -- Particle debris at ray ends
            if audioBeat > 0.2 then
                local debrisAngle = baseAngle + seededRandom(seed, ray + 100) * 0.3
                local debrisLen = rayLen * (0.8 + seededRandom(seed, ray + 200) * 0.4)
                local dx = cx + math.cos(debrisAngle + rotation) * debrisLen
                local dy = cy + math.sin(debrisAngle + rotation) * debrisLen
                local debrisSize = (2 + audioPeak * 4) * sizeMult
                gfx.set(1, 1, 1, audioBeat * 0.5)
                gfx.circle(dx, dy, debrisSize, 1, 1)
            end
        end

        -- Pulsing center core
        local coreSize = 15 + audioBass * 25 + audioBeat * 30
        for r = coreSize, 5, -3 do
            local coreAlpha = 0.15 + audioBeat * 0.2
            gfx.set(1, 0.9 + audioHigh * 0.1, 0.5 + audioPeak * 0.3, coreAlpha)
            gfx.circle(cx, cy, r, 1, 1)
        end

    -- === BASE PATTERN 14: DNA Helix ===
    elseif basePattern == 14 then
        -- Double helix structure with connecting rungs
        local helixPoints = 40 + variation * 5
        local helixHeight = h * 0.8
        local helixWidth = radius * (0.6 + audioBass * 0.3)
        local startY = cy - helixHeight / 2

        for i = 0, helixPoints do
            local t = i / helixPoints
            local phase = t * math.pi * (3 + variation) + time * speedMult

            -- Two strands of the helix
            for strand = 1, 2 do
                local strandPhase = phase + (strand - 1) * math.pi
                local xOffset = math.sin(strandPhase) * helixWidth
                local zDepth = math.cos(strandPhase)  -- Simulated depth

                local hx = cx + xOffset + rotation * 50
                local hy = startY + t * helixHeight
                hx, hy = rotatePoint(hx, hy)

                -- Size and alpha based on "depth"
                local depthScale = 0.5 + (zDepth + 1) * 0.25
                local col = colors[strand == 1 and 1 or 3]  -- Red and Purple strands
                local r, g, b = rainbowShift(col, colorShift + t * 2)
                local alpha = (0.3 + depthScale * 0.4 + audioPeak * 0.2) * audioMult

                gfx.set(r, g, b, math.min(0.8, alpha))
                local dotSize = (4 + depthScale * 4 + audioPeak * 3) * sizeMult
                gfx.circle(hx, hy, dotSize, 1, 1)
            end

            -- Connecting rungs (base pairs) - every few points
            if i % 4 == 0 then
                local phase1 = (i / helixPoints) * math.pi * (3 + variation) + time * speedMult
                local phase2 = phase1 + math.pi

                local x1 = cx + math.sin(phase1) * helixWidth + rotation * 50
                local x2 = cx + math.sin(phase2) * helixWidth + rotation * 50
                local hy = startY + t * helixHeight

                local rungCol = colors[(math.floor(i / 4) % 4) + 1]
                local r, g, b = rainbowShift(rungCol, colorShift + i * 0.1)
                gfx.set(r, g, b, 0.2 + audioMid * 0.15)

                local rx1, ry1 = rotatePoint(x1, hy)
                local rx2, ry2 = rotatePoint(x2, hy)
                gfx.line(rx1, ry1, rx2, ry2)
            end
        end

    -- === BASE PATTERN 15: Fractal Tree ===
    elseif basePattern == 15 then
        -- Recursive branching structure with audio-reactive angles
        local maxDepth = 5 + (variation % 3)
        local branchAngle = math.pi / (4 + audioMid * 2)  -- Angle varies with mid frequencies
        local lengthRatio = 0.7 + audioBass * 0.15

        -- Iterative tree drawing (avoid actual recursion for performance)
        local branches = {{x = cx, y = cy + radius * 0.4, angle = -math.pi/2, len = radius * 0.4, depth = 0}}
        local drawnBranches = {}

        while #branches > 0 and #drawnBranches < 200 do
            local branch = table.remove(branches, 1)

            if branch.depth < maxDepth then
                local endX = branch.x + math.cos(branch.angle + rotation) * branch.len
                local endY = branch.y + math.sin(branch.angle + rotation) * branch.len

                -- Draw branch
                local col = colors[(branch.depth % 4) + 1]
                local r, g, b = rainbowShift(col, colorShift + branch.depth * 0.5)
                local alpha = (0.4 - branch.depth * 0.05 + audioPeak * 0.2) * audioMult
                local thickness = math.max(1, (maxDepth - branch.depth) * 1.5 * sizeMult)

                gfx.set(r, g, b, math.min(0.7, alpha))
                -- Draw thick line as multiple parallel lines
                for t = -thickness/2, thickness/2 do
                    gfx.line(branch.x + t * 0.3, branch.y, endX + t * 0.3, endY)
                end

                table.insert(drawnBranches, {x = endX, y = endY, depth = branch.depth})

                -- Add child branches
                local newLen = branch.len * lengthRatio
                local angleVar = (seededRandom(seed, #drawnBranches) - 0.5) * 0.3 + audioHigh * 0.2

                -- Left branch
                table.insert(branches, {
                    x = endX, y = endY,
                    angle = branch.angle - branchAngle + angleVar,
                    len = newLen, depth = branch.depth + 1
                })
                -- Right branch
                table.insert(branches, {
                    x = endX, y = endY,
                    angle = branch.angle + branchAngle - angleVar,
                    len = newLen, depth = branch.depth + 1
                })
            end
        end

        -- Draw leaves/particles at branch ends on beats
        if audioBeat > 0.2 then
            for _, branch in ipairs(drawnBranches) do
                if branch.depth >= maxDepth - 1 then
                    local col = colors[(branch.depth % 4) + 1]
                    local r, g, b = rainbowShift(col, colorShift + branch.depth)
                    gfx.set(r, g, b, audioBeat * 0.4)
                    local leafSize = (3 + audioPeak * 4) * sizeMult
                    gfx.circle(branch.x, branch.y, leafSize, 1, 1)
                end
            end
        end

    -- === BASE PATTERN 16: Plasma Field (MilkDrop classic) ===
    elseif basePattern == 16 then
        -- Classic plasma effect with sine wave interference
        local cellSize = math.max(4, 12 - variation) * sizeMult
        for px = x, x + w, cellSize do
            for py = y, y + h, cellSize do
                local dx = (px - cx) / radius
                local dy = (py - cy) / radius

                -- Multiple sine waves create plasma
                local v1 = math.sin(dx * 3 + time * speedMult)
                local v2 = math.sin(dy * 3 + time * speedMult * 0.7)
                local v3 = math.sin((dx + dy) * 2 + time * speedMult * 1.3)
                local v4 = math.sin(math.sqrt(dx*dx + dy*dy) * 4 - time * speedMult * 0.5 + audioBass * 2)
                local plasma = (v1 + v2 + v3 + v4) / 4

                local colorIdx = math.floor((plasma + 1) * 2) % 4 + 1
                local col = colors[colorIdx]
                local r, g, b = rainbowShift(col, colorShift + plasma * 2)
                local alpha = (0.3 + plasma * 0.2 + audioPeak * 0.2) * audioMult
                gfx.set(r, g, b, math.min(0.7, math.abs(alpha)))
                gfx.rect(px, py, cellSize - 1, cellSize - 1, 1)
            end
        end

    -- === BASE PATTERN 17: Starfield (MilkDrop 3D stars) ===
    elseif basePattern == 17 then
        local starCount = 100 + variation * 20
        for i = 1, starCount do
            -- 3D star position using seed
            local starSeed = seed + i * 7
            local starAngle = seededRandom(starSeed, 1) * math.pi * 2
            local starZ = ((seededRandom(starSeed, 2) + time * 0.1 * speedMult + i * 0.01) % 1)
            local starDist = seededRandom(starSeed, 3) * 0.8 + 0.1

            -- Project 3D to 2D (perspective)
            local perspective = 1 / (starZ + 0.3)
            local sx = cx + math.cos(starAngle) * starDist * radius * perspective
            local sy = cy + math.sin(starAngle) * starDist * radius * 0.5 * perspective

            if sx > x and sx < x + w and sy > y and sy < y + h then
                local starSize = (1 + (1 - starZ) * 3 + audioPeak * 2) * sizeMult
                local starAlpha = (1 - starZ) * 0.6 + audioBeat * 0.2

                local col = colors[(i % 4) + 1]
                local r, g, b = rainbowShift(col, colorShift + starZ * 3)
                gfx.set(r, g, b, math.min(0.9, starAlpha))
                gfx.circle(sx, sy, starSize, 1, 1)

                -- Star trail
                if starZ < 0.5 then
                    local trailLen = (0.5 - starZ) * 20 * sizeMult
                    gfx.set(r, g, b, starAlpha * 0.3)
                    local trailX = sx - math.cos(starAngle) * trailLen * perspective
                    local trailY = sy - math.sin(starAngle) * trailLen * 0.5 * perspective
                    gfx.line(sx, sy, trailX, trailY)
                end
            end
        end

    -- === BASE PATTERN 18: Tunnel Warp (MilkDrop zoom) ===
    elseif basePattern == 18 then
        local segments = 24 + variation * 4
        local rings = 15
        for ring = rings, 1, -1 do
            local ringZ = ((ring / rings) + time * 0.3 * speedMult) % 1
            local ringRadius = radius * (1 - ringZ) * 1.5

            -- Warp amount increases with distance
            local warp = 0.1 + ringZ * 0.3 + audioMid * 0.2

            local col = colors[(ring % 4) + 1]
            local r, g, b = rainbowShift(col, colorShift + ringZ * 4)
            local alpha = ringZ * 0.4 + audioBeat * 0.15
            gfx.set(r, g, b, math.min(0.6, alpha))

            for seg = 0, segments - 1 do
                local angle1 = (seg / segments) * math.pi * 2 + time * 0.2
                local angle2 = ((seg + 1) / segments) * math.pi * 2 + time * 0.2

                local warp1 = 1 + math.sin(angle1 * 3 + time * 2) * warp * (1 + audioBass)
                local warp2 = 1 + math.sin(angle2 * 3 + time * 2) * warp * (1 + audioBass)

                local x1 = cx + math.cos(angle1 + rotation) * ringRadius * warp1
                local y1 = cy + math.sin(angle1 + rotation) * ringRadius * warp1 * 0.6
                local x2 = cx + math.cos(angle2 + rotation) * ringRadius * warp2
                local y2 = cy + math.sin(angle2 + rotation) * ringRadius * warp2 * 0.6

                gfx.line(x1, y1, x2, y2)
            end
        end

    -- === BASE PATTERN 19: Kaleidoscope (MilkDrop symmetry) ===
    elseif basePattern == 19 then
        local symmetry = 6 + (variation % 4) * 2  -- 6, 8, 10, or 12 fold
        local elementCount = 20 + variation * 5

        for elem = 1, elementCount do
            local elemPhase = time * speedMult + elem * 0.3
            local elemDist = (seededRandom(seed, elem) * 0.7 + 0.2) * radius * (1 + audioBass * 0.3)
            local elemAngle = seededRandom(seed, elem + 100) * math.pi * 2 / symmetry + elemPhase * 0.1
            local elemSize = (seededRandom(seed, elem + 200) * 15 + 5 + audioPeak * 10) * sizeMult

            local col = colors[(elem % 4) + 1]
            local r, g, b = rainbowShift(col, colorShift + elem * 0.2)
            local alpha = (0.3 + math.sin(elemPhase * 2) * 0.15 + audioBeat * 0.2) * audioMult
            gfx.set(r, g, b, math.min(0.7, alpha))

            -- Draw element at all symmetry positions
            for sym = 0, symmetry - 1 do
                local symAngle = elemAngle + (sym / symmetry) * math.pi * 2
                local ex = cx + math.cos(symAngle + rotation) * elemDist
                local ey = cy + math.sin(symAngle + rotation) * elemDist
                gfx.circle(ex, ey, elemSize, 1, 1)
            end
        end

    -- === BASE PATTERN 20: Electric Arcs ===
    elseif basePattern == 20 then
        local arcCount = 8 + variation
        for arc = 1, arcCount do
            local arcPhase = time * speedMult * 0.5 + arc * 0.8
            local startAngle = (arc / arcCount) * math.pi * 2 + time * 0.1
            local arcLen = math.pi * (0.3 + seededRandom(seed, arc) * 0.5)

            local col = colors[(arc % 4) + 1]
            local r, g, b = rainbowShift(col, colorShift + arc)

            -- Draw jagged electric arc
            local segments = 20 + math.floor(audioPeak * 10)
            local prevX, prevY
            local arcRadius = radius * (0.5 + seededRandom(seed, arc + 50) * 0.4 + audioBass * 0.2)

            for seg = 0, segments do
                local t = seg / segments
                local angle = startAngle + t * arcLen
                local jitter = (seededRandom(seed, arc * 100 + seg) - 0.5) * 30 * (1 + audioHigh)
                local segRadius = arcRadius + jitter + math.sin(arcPhase + t * 10) * 10

                local ax = cx + math.cos(angle + rotation) * segRadius
                local ay = cy + math.sin(angle + rotation) * segRadius

                local alpha = (0.4 + math.sin(arcPhase + t * 5) * 0.2 + audioBeat * 0.3) * audioMult
                gfx.set(r, g, b, math.min(0.8, alpha))

                if prevX then
                    gfx.line(prevX, prevY, ax, ay)
                    -- Glow
                    gfx.set(r, g, b, alpha * 0.3)
                    gfx.line(prevX + 1, prevY + 1, ax + 1, ay + 1)
                end
                prevX, prevY = ax, ay
            end
        end

    -- === BASE PATTERN 21: Morphing Shapes ===
    elseif basePattern == 21 then
        local shapeCount = 5 + variation
        for shape = 1, shapeCount do
            local shapePhase = time * speedMult * 0.3 + shape * 1.2
            local shapeDist = radius * (0.2 + shape * 0.12) * (1 + audioBass * 0.3)

            -- Morph between different polygon sides
            local sidesBase = 3 + (shape % 5)
            local sidesMorph = sidesBase + math.sin(shapePhase) * 2
            local sides = math.max(3, math.floor(sidesMorph + 0.5))

            local col = colors[(shape % 4) + 1]
            local r, g, b = rainbowShift(col, colorShift + shape * 0.5)
            local alpha = (0.25 + audioBeat * 0.2) * audioMult
            gfx.set(r, g, b, math.min(0.6, alpha))

            local shapeRot = shapePhase * 0.5 + rotation
            for side = 0, sides do
                local a1 = shapeRot + (side / sides) * math.pi * 2
                local a2 = shapeRot + ((side + 1) / sides) * math.pi * 2

                local breathe = 1 + math.sin(shapePhase * 2 + side * 0.5) * 0.2 + audioPeak * 0.3
                local x1 = cx + math.cos(a1) * shapeDist * breathe
                local y1 = cy + math.sin(a1) * shapeDist * breathe
                local x2 = cx + math.cos(a2) * shapeDist * breathe
                local y2 = cy + math.sin(a2) * shapeDist * breathe

                gfx.line(x1, y1, x2, y2)
            end
        end

    -- === BASE PATTERN 22: Particle Vortex ===
    elseif basePattern == 22 then
        local particleCount = 150 + variation * 30
        for p = 1, particleCount do
            local pSeed = seed + p * 13
            local pAngle = seededRandom(pSeed, 1) * math.pi * 2
            local pDist = seededRandom(pSeed, 2)
            local pSpeed = seededRandom(pSeed, 3) * 0.5 + 0.5

            -- Spiral inward motion
            local spiralAngle = pAngle + time * pSpeed * speedMult + pDist * 3
            local spiralDist = pDist * radius * (1 + audioBass * 0.3)

            local px = cx + math.cos(spiralAngle + rotation) * spiralDist
            local py = cy + math.sin(spiralAngle + rotation) * spiralDist * 0.6

            local pSize = ((1 - pDist) * 4 + 1 + audioPeak * 3) * sizeMult
            local col = colors[(p % 4) + 1]
            local r, g, b = rainbowShift(col, colorShift + pDist * 2)
            local alpha = ((1 - pDist) * 0.4 + audioBeat * 0.2) * audioMult
            gfx.set(r, g, b, math.min(0.7, alpha))
            gfx.circle(px, py, pSize, 1, 1)
        end

    -- === BASE PATTERN 23: Liquid Metal ===
    elseif basePattern == 23 then
        local blobCount = 6 + variation
        for blob = 1, blobCount do
            local blobPhase = time * speedMult * 0.4 + blob * 1.5
            local blobCX = cx + math.sin(blobPhase * 0.7 + blob) * radius * 0.3 * (1 + audioBass * 0.5)
            local blobCY = cy + math.cos(blobPhase * 0.5 + blob * 0.7) * radius * 0.2 * (1 + audioMid * 0.5)
            local blobSize = radius * (0.15 + blob * 0.03 + audioPeak * 0.1)

            local col = colors[(blob % 4) + 1]

            -- Draw blob with noise distortion
            local points = 40 + variation * 5
            for i = 0, points do
                local angle = (i / points) * math.pi * 2
                local noise1 = math.sin(angle * 3 + blobPhase * 2) * 0.3
                local noise2 = math.sin(angle * 5 - blobPhase * 1.5 + audioHigh * 2) * 0.2
                local noise3 = math.sin(angle * 7 + blobPhase * 3) * 0.15
                local distort = 1 + noise1 + noise2 + noise3 + audioBass * 0.2

                local bx = blobCX + math.cos(angle + rotation) * blobSize * distort
                local by = blobCY + math.sin(angle + rotation) * blobSize * distort

                local r, g, b = rainbowShift(col, colorShift + angle + blob)
                local alpha = (0.15 + audioBeat * 0.1) * audioMult
                gfx.set(r, g, b, math.min(0.4, alpha))
                gfx.circle(bx, by, (3 + audioPeak * 2) * sizeMult, 1, 1)
            end
        end

    -- === BASE PATTERN 24: Grid Warp ===
    elseif basePattern == 24 then
        local gridSize = math.max(8, 25 - variation) * sizeMult
        local cols = math.ceil(w / gridSize)
        local rows = math.ceil(h / gridSize)

        for col = 0, cols do
            for row = 0, rows do
                local gx = x + col * gridSize
                local gy = y + row * gridSize

                -- Warp based on distance from center and audio
                local dx = (gx - cx) / radius
                local dy = (gy - cy) / radius
                local dist = math.sqrt(dx * dx + dy * dy)

                local warpX = math.sin(dist * 3 - time * speedMult + audioBass * 2) * gridSize * 0.3
                local warpY = math.cos(dist * 3 - time * speedMult * 0.8 + audioMid) * gridSize * 0.3

                local wx = gx + warpX * (1 + audioPeak * 0.5)
                local wy = gy + warpY * (1 + audioPeak * 0.5)

                local colorIdx = ((col + row) % 4) + 1
                local col = colors[colorIdx]
                local r, g, b = rainbowShift(col, colorShift + dist)
                local alpha = (0.2 + math.sin(dist * 5 + time * 2) * 0.1 + audioBeat * 0.15) * audioMult
                gfx.set(r, g, b, math.min(0.5, alpha))

                local dotSize = (2 + math.sin(dist * 4 + time * 3) * 1 + audioPeak * 2) * sizeMult
                gfx.circle(wx, wy, dotSize, 1, 1)
            end
        end

    -- === BASE PATTERN 25: Aurora Borealis ===
    elseif basePattern == 25 then
        local curtains = 5 + variation
        for curtain = 1, curtains do
            local curtainPhase = time * speedMult * 0.3 + curtain * 0.8
            local curtainX = x + (curtain / (curtains + 1)) * w
            local col = colors[(curtain % 4) + 1]

            -- Draw vertical wavy curtain
            local segments = 40
            local prevX, prevY
            for seg = 0, segments do
                local t = seg / segments
                local segY = y + t * h

                -- Multiple wave layers for aurora effect
                local wave1 = math.sin(t * 4 + curtainPhase + audioBass) * 30
                local wave2 = math.sin(t * 7 - curtainPhase * 1.3 + audioMid * 2) * 20
                local wave3 = math.sin(t * 2 + curtainPhase * 0.5) * 50
                local segX = curtainX + (wave1 + wave2 + wave3) * (1 + audioPeak * 0.5)

                local r, g, b = rainbowShift(col, colorShift + t * 2 + curtain)
                local alpha = (0.15 + math.sin(t * math.pi) * 0.2 + audioBeat * 0.1) * audioMult
                gfx.set(r, g, b, math.min(0.5, alpha))

                if prevX then
                    gfx.line(prevX, prevY, segX, segY)
                    -- Glow effect
                    for glow = 1, 3 do
                        gfx.set(r, g, b, alpha * (0.3 / glow))
                        gfx.line(prevX + glow * 2, prevY, segX + glow * 2, segY)
                        gfx.line(prevX - glow * 2, prevY, segX - glow * 2, segY)
                    end
                end
                prevX, prevY = segX, segY
            end
        end

    -- === CATEGORY: HYPNOTIC (26-35) ===

    -- === BASE PATTERN 26: Hypnotic Spiral ===
    elseif basePattern == 26 then
        local arms = 3 + (variation % 5)
        local spiralTightness = 0.15 + variation * 0.02
        for arm = 0, arms - 1 do
            local armAngle = (arm / arms) * math.pi * 2
            local col = colors[(arm % 4) + 1]
            for t = 0, 1, 0.008 do
                local spiralAngle = armAngle + t * math.pi * 8 + time * speedMult
                local spiralRadius = t * radius * (1 + audioBass * 0.3)
                local px = cx + math.cos(spiralAngle + rotation) * spiralRadius
                local py = cy + math.sin(spiralAngle + rotation) * spiralRadius
                local r, g, b = rainbowShift(col, colorShift + t * 3)
                local alpha = (0.4 + t * 0.3 + audioBeat * 0.2) * audioMult
                gfx.set(r, g, b, math.min(0.8, alpha))
                local dotSize = (2 + t * 4 + audioPeak * 3) * sizeMult
                gfx.circle(px, py, dotSize, 1, 1)
            end
        end

    -- === BASE PATTERN 27: Pulsing Rings ===
    elseif basePattern == 27 then
        local ringCount = 15 + variation * 2
        for ring = 1, ringCount do
            local ringPhase = time * speedMult + ring * 0.3
            local ringRadius = (ring / ringCount) * radius * (1 + math.sin(ringPhase) * 0.2 + audioBass * 0.3)
            local thickness = 2 + (variation % 3) + audioPeak * 2
            local col = colors[(ring % 4) + 1]
            local r, g, b = rainbowShift(col, colorShift + ring * 0.2)
            local alpha = (0.3 + math.sin(ringPhase * 2) * 0.15 + audioBeat * 0.2) * audioMult
            gfx.set(r, g, b, math.min(0.7, alpha))
            for angle = 0, math.pi * 2, 0.05 do
                local px = cx + math.cos(angle + rotation) * ringRadius
                local py = cy + math.sin(angle + rotation) * ringRadius
                gfx.circle(px, py, thickness * sizeMult, 1, 1)
            end
        end

    -- === BASE PATTERN 28: Moiré Interference ===
    elseif basePattern == 28 then
        local lineSpacing = 8 + variation
        local offset1 = time * 20 * speedMult
        local offset2 = time * 15 * speedMult + audioBass * 30
        -- First set of lines
        for i = -20, 20 do
            local lx = cx + i * lineSpacing + offset1
            local col = colors[(math.abs(i) % 4) + 1]
            local r, g, b = rainbowShift(col, colorShift + i * 0.1)
            gfx.set(r, g, b, 0.15 * audioMult)
            gfx.line(lx, y, lx + h * 0.3, y + h)
        end
        -- Second set (creates interference)
        for i = -20, 20 do
            local lx = cx + i * lineSpacing - offset2
            local col = colors[((math.abs(i) + 2) % 4) + 1]
            local r, g, b = rainbowShift(col, colorShift + i * 0.15)
            gfx.set(r, g, b, 0.15 * audioMult)
            gfx.line(lx, y, lx - h * 0.3, y + h)
        end

    -- === BASE PATTERN 29: Breathing Mandala ===
    elseif basePattern == 29 then
        local petals = 8 + (variation % 6) * 2
        local layers = 5 + variation
        for layer = layers, 1, -1 do
            local layerRadius = (layer / layers) * radius * (1 + audioBass * 0.2)
            local breathe = 1 + math.sin(time * 2 + layer * 0.5) * 0.15
            for petal = 0, petals - 1 do
                local petalAngle = (petal / petals) * math.pi * 2 + time * 0.2 * speedMult + layer * 0.1
                local px = cx + math.cos(petalAngle + rotation) * layerRadius * breathe
                local py = cy + math.sin(petalAngle + rotation) * layerRadius * breathe
                local col = colors[(petal % 4) + 1]
                local r, g, b = rainbowShift(col, colorShift + layer * 0.3)
                local alpha = (0.25 + audioBeat * 0.15) * audioMult
                gfx.set(r, g, b, math.min(0.6, alpha))
                local petalSize = (5 + layer * 2 + audioPeak * 5) * sizeMult
                gfx.circle(px, py, petalSize, 1, 1)
            end
        end

    -- === BASE PATTERN 30: Lissajous Curves ===
    elseif basePattern == 30 then
        local freqA = 3 + (variation % 4)
        local freqB = 2 + ((variation + 1) % 5)
        local curves = 4
        for curve = 1, curves do
            local phaseOffset = (curve / curves) * math.pi * 2
            local col = colors[curve]
            local prevX, prevY
            for t = 0, math.pi * 2, 0.02 do
                local lx = cx + math.sin(freqA * t + time * speedMult + phaseOffset + audioBass) * radius * 0.8
                local ly = cy + math.sin(freqB * t + time * speedMult * 0.7) * radius * 0.5
                local r, g, b = rainbowShift(col, colorShift + t)
                local alpha = (0.4 + audioBeat * 0.2) * audioMult
                gfx.set(r, g, b, math.min(0.7, alpha))
                if prevX then gfx.line(prevX, prevY, lx, ly) end
                prevX, prevY = lx, ly
            end
        end

    -- === BASE PATTERN 31: Concentric Polygons ===
    elseif basePattern == 31 then
        local sides = 3 + (variation % 6)
        local layers = 12 + variation
        for layer = layers, 1, -1 do
            local layerRadius = (layer / layers) * radius
            local layerRot = time * 0.3 * speedMult * (layer % 2 == 0 and 1 or -1) + rotation
            local col = colors[(layer % 4) + 1]
            local r, g, b = rainbowShift(col, colorShift + layer * 0.2)
            local alpha = (0.2 + audioPeak * 0.15) * audioMult
            gfx.set(r, g, b, math.min(0.5, alpha))
            for side = 0, sides do
                local a1 = layerRot + (side / sides) * math.pi * 2
                local a2 = layerRot + ((side + 1) / sides) * math.pi * 2
                local x1 = cx + math.cos(a1) * layerRadius * (1 + audioBass * 0.2)
                local y1 = cy + math.sin(a1) * layerRadius * (1 + audioBass * 0.2)
                local x2 = cx + math.cos(a2) * layerRadius * (1 + audioBass * 0.2)
                local y2 = cy + math.sin(a2) * layerRadius * (1 + audioBass * 0.2)
                gfx.line(x1, y1, x2, y2)
            end
        end

    -- === BASE PATTERN 32: Eye of the Storm ===
    elseif basePattern == 32 then
        -- Swirling particles around calm center
        local particleCount = 100 + variation * 20
        for p = 1, particleCount do
            local pSeed = seed + p * 17
            local pAngle = seededRandom(pSeed, 1) * math.pi * 2
            local pDist = seededRandom(pSeed, 2) * 0.9 + 0.1
            local swirlSpeed = (1 - pDist) * 2 + 0.5  -- Faster near edge
            local currentAngle = pAngle + time * swirlSpeed * speedMult
            local px = cx + math.cos(currentAngle + rotation) * pDist * radius
            local py = cy + math.sin(currentAngle + rotation) * pDist * radius * 0.7
            local col = colors[(p % 4) + 1]
            local r, g, b = rainbowShift(col, colorShift + pDist * 2)
            local alpha = (pDist * 0.5 + audioBeat * 0.2) * audioMult
            gfx.set(r, g, b, math.min(0.7, alpha))
            local pSize = ((1 - pDist) * 3 + 1 + audioPeak * 2) * sizeMult
            gfx.circle(px, py, pSize, 1, 1)
        end
        -- Calm glowing center
        for glow = 5, 1, -1 do
            local glowSize = (15 + glow * 8 + audioBass * 10) * sizeMult
            gfx.set(1, 1, 1, 0.1 / glow + audioBeat * 0.05)
            gfx.circle(cx, cy, glowSize, 1, 1)
        end

    -- === BASE PATTERN 33: Infinity Loop ===
    elseif basePattern == 33 then
        local loops = 3 + (variation % 3)
        for loop = 1, loops do
            local loopPhase = (loop / loops) * math.pi * 2
            local col = colors[loop]
            local prevX, prevY
            for t = 0, math.pi * 2, 0.02 do
                -- Figure-8 / infinity shape
                local scale = radius * (0.6 + loop * 0.1) * (1 + audioBass * 0.2)
                local ix = cx + math.sin(t + time * speedMult + loopPhase) * scale
                local iy = cy + math.sin(2 * t + time * speedMult * 0.5) * scale * 0.4
                local r, g, b = rainbowShift(col, colorShift + t + loop)
                local alpha = (0.4 + audioBeat * 0.2) * audioMult
                gfx.set(r, g, b, math.min(0.7, alpha))
                if prevX then gfx.line(prevX, prevY, ix, iy) end
                prevX, prevY = ix, iy
            end
        end

    -- === BASE PATTERN 34: Ripple Effect ===
    elseif basePattern == 34 then
        local ripples = 8 + variation
        for ripple = 1, ripples do
            local ripplePhase = (time * 2 * speedMult + ripple * 0.5) % (math.pi * 2)
            local rippleRadius = (ripplePhase / (math.pi * 2)) * radius * 1.2
            local rippleAlpha = (1 - ripplePhase / (math.pi * 2)) * 0.4 + audioBeat * 0.1
            local col = colors[(ripple % 4) + 1]
            local r, g, b = rainbowShift(col, colorShift + ripple * 0.3)
            gfx.set(r, g, b, math.min(0.5, rippleAlpha * audioMult))
            -- Draw ripple circle
            for angle = 0, math.pi * 2, 0.03 do
                local rx = cx + math.cos(angle) * rippleRadius * (1 + audioBass * 0.1)
                local ry = cy + math.sin(angle) * rippleRadius * (1 + audioBass * 0.1)
                gfx.circle(rx, ry, (2 + audioPeak) * sizeMult, 1, 1)
            end
        end

    -- === BASE PATTERN 35: Rotating Squares ===
    elseif basePattern == 35 then
        local squares = 10 + variation
        for sq = 1, squares do
            local sqSize = (sq / squares) * radius * 0.9 * (1 + audioBass * 0.2)
            local sqRot = time * (0.5 + sq * 0.1) * speedMult * (sq % 2 == 0 and 1 or -1) + rotation
            local col = colors[(sq % 4) + 1]
            local r, g, b = rainbowShift(col, colorShift + sq * 0.25)
            local alpha = (0.25 + audioBeat * 0.15) * audioMult
            gfx.set(r, g, b, math.min(0.6, alpha))
            -- Draw rotated square
            local corners = {}
            for corner = 0, 3 do
                local cornerAngle = sqRot + (corner / 4) * math.pi * 2 + math.pi / 4
                corners[corner + 1] = {
                    x = cx + math.cos(cornerAngle) * sqSize,
                    y = cy + math.sin(cornerAngle) * sqSize
                }
            end
            for i = 1, 4 do
                local next = (i % 4) + 1
                gfx.line(corners[i].x, corners[i].y, corners[next].x, corners[next].y)
            end
        end

    -- === CATEGORY: FRACTAL-LIKE (36-45) ===

    -- === BASE PATTERN 36: Sierpinski Triangle ===
    elseif basePattern == 36 then
        local depth = 4 + (variation % 3)
        local triangles = {{cx, cy - radius * 0.8, cx - radius * 0.7, cy + radius * 0.5, cx + radius * 0.7, cy + radius * 0.5}}
        for d = 1, depth do
            local newTriangles = {}
            for _, tri in ipairs(triangles) do
                local mx1 = (tri[1] + tri[3]) / 2
                local my1 = (tri[2] + tri[4]) / 2
                local mx2 = (tri[3] + tri[5]) / 2
                local my2 = (tri[4] + tri[6]) / 2
                local mx3 = (tri[5] + tri[1]) / 2
                local my3 = (tri[6] + tri[2]) / 2
                table.insert(newTriangles, {tri[1], tri[2], mx1, my1, mx3, my3})
                table.insert(newTriangles, {mx1, my1, tri[3], tri[4], mx2, my2})
                table.insert(newTriangles, {mx3, my3, mx2, my2, tri[5], tri[6]})
            end
            triangles = newTriangles
            if #triangles > 500 then break end
        end
        for i, tri in ipairs(triangles) do
            local col = colors[(i % 4) + 1]
            local r, g, b = rainbowShift(col, colorShift + i * 0.05)
            local alpha = (0.3 + audioBeat * 0.2) * audioMult
            gfx.set(r, g, b, math.min(0.6, alpha))
            gfx.line(tri[1], tri[2], tri[3], tri[4])
            gfx.line(tri[3], tri[4], tri[5], tri[6])
            gfx.line(tri[5], tri[6], tri[1], tri[2])
        end

    -- === BASE PATTERN 37: Koch Snowflake ===
    elseif basePattern == 37 then
        local iterations = 3 + (variation % 2)
        local scale = radius * 0.7 * (1 + audioBass * 0.2)
        -- Start with triangle
        local points = {}
        for i = 0, 2 do
            local angle = (i / 3) * math.pi * 2 - math.pi / 2 + time * 0.2 * speedMult + rotation
            table.insert(points, {cx + math.cos(angle) * scale, cy + math.sin(angle) * scale})
        end
        -- Koch iterations
        for iter = 1, iterations do
            local newPoints = {}
            for i = 1, #points do
                local p1 = points[i]
                local p2 = points[(i % #points) + 1]
                local dx, dy = p2[1] - p1[1], p2[2] - p1[2]
                local a = {p1[1], p1[2]}
                local b = {p1[1] + dx/3, p1[2] + dy/3}
                local d = {p1[1] + 2*dx/3, p1[2] + 2*dy/3}
                local angle = math.atan(dy, dx) - math.pi/3
                local c = {b[1] + math.cos(angle) * math.sqrt(dx*dx+dy*dy)/3, b[2] + math.sin(angle) * math.sqrt(dx*dx+dy*dy)/3}
                table.insert(newPoints, a)
                table.insert(newPoints, b)
                table.insert(newPoints, c)
                table.insert(newPoints, d)
            end
            points = newPoints
            if #points > 1000 then break end
        end
        for i = 1, #points do
            local p1 = points[i]
            local p2 = points[(i % #points) + 1]
            local col = colors[(i % 4) + 1]
            local r, g, b = rainbowShift(col, colorShift + i * 0.02)
            local alpha = (0.4 + audioBeat * 0.2) * audioMult
            gfx.set(r, g, b, math.min(0.7, alpha))
            gfx.line(p1[1], p1[2], p2[1], p2[2])
        end

    -- === BASE PATTERN 38: Julia Set Approximation ===
    elseif basePattern == 38 then
        local gridSize = 6 + variation
        local cReal = math.sin(time * 0.3 * speedMult) * 0.4
        local cImag = math.cos(time * 0.2 * speedMult) * 0.4 + audioBass * 0.1
        for gx = 0, w, gridSize do
            for gy = 0, h, gridSize do
                local zr = (gx - cx) / radius * 2
                local zi = (gy - cy) / radius * 2
                local iterations = 0
                for i = 1, 20 do
                    local zr2 = zr * zr - zi * zi + cReal
                    local zi2 = 2 * zr * zi + cImag
                    zr, zi = zr2, zi2
                    if zr * zr + zi * zi > 4 then break end
                    iterations = i
                end
                if iterations > 3 then
                    local col = colors[(iterations % 4) + 1]
                    local r, g, b = rainbowShift(col, colorShift + iterations * 0.2)
                    local alpha = (iterations / 20 * 0.5 + audioBeat * 0.1) * audioMult
                    gfx.set(r, g, b, math.min(0.6, alpha))
                    local dotSize = (2 + iterations * 0.2 + audioPeak) * sizeMult
                    gfx.circle(x + gx, y + gy, dotSize, 1, 1)
                end
            end
        end

    -- === BASE PATTERN 39: Barnsley Fern Points ===
    elseif basePattern == 39 then
        local px, py = 0, 0
        local fernPoints = {}
        for i = 1, 2000 do
            local r = seededRandom(seed + i, 1)
            local nx, ny
            if r < 0.01 then
                nx, ny = 0, 0.16 * py
            elseif r < 0.86 then
                nx = 0.85 * px + 0.04 * py
                ny = -0.04 * px + 0.85 * py + 1.6
            elseif r < 0.93 then
                nx = 0.2 * px - 0.26 * py
                ny = 0.23 * px + 0.22 * py + 1.6
            else
                nx = -0.15 * px + 0.28 * py
                ny = 0.26 * px + 0.24 * py + 0.44
            end
            px, py = nx, ny
            table.insert(fernPoints, {px, py})
        end
        local scale = radius * 0.08 * (1 + audioBass * 0.2)
        for i, pt in ipairs(fernPoints) do
            local fx = cx + pt[1] * scale
            local fy = cy + radius * 0.8 - pt[2] * scale
            local col = colors[(i % 4) + 1]
            local r, g, b = rainbowShift(col, colorShift + pt[2] * 0.3)
            local alpha = (0.3 + audioBeat * 0.1) * audioMult
            gfx.set(r, g, b, math.min(0.5, alpha))
            gfx.circle(fx, fy, sizeMult, 1, 1)
        end

    -- === BASE PATTERN 40: Recursive Circles ===
    elseif basePattern == 40 then
        local circles = {}
        local function addCircle(ccx, ccy, cr, depth)
            if depth > 5 + variation or cr < 5 or #circles > 200 then return end
            table.insert(circles, {ccx, ccy, cr, depth})
            local childR = cr * 0.45
            for i = 0, 3 do
                local angle = (i / 4) * math.pi * 2 + time * 0.3 * speedMult + rotation
                local childX = ccx + math.cos(angle) * (cr - childR) * (1 + audioBass * 0.1)
                local childY = ccy + math.sin(angle) * (cr - childR) * (1 + audioBass * 0.1)
                addCircle(childX, childY, childR, depth + 1)
            end
        end
        addCircle(cx, cy, radius * 0.8, 0)
        for _, c in ipairs(circles) do
            local col = colors[(c[4] % 4) + 1]
            local r, g, b = rainbowShift(col, colorShift + c[4] * 0.5)
            local alpha = (0.3 - c[4] * 0.04 + audioBeat * 0.1) * audioMult
            gfx.set(r, g, b, math.min(0.5, alpha))
            gfx.circle(c[1], c[2], c[3], 0, 1)
        end

    -- === BASE PATTERN 41: Dragon Curve ===
    elseif basePattern == 41 then
        local iterations = 10 + variation
        local sequence = {1}
        for i = 1, iterations do
            local newSeq = {1}
            for j = #sequence, 1, -1 do
                table.insert(newSeq, 1 - sequence[j])
            end
            for _, v in ipairs(sequence) do table.insert(newSeq, v) end
            sequence = newSeq
            if #sequence > 2000 then break end
        end
        local segLen = radius * 0.01 * (1 + audioBass * 0.2)
        local angle = time * 0.5 * speedMult + rotation
        local dx, dy = cx - radius * 0.3, cy
        for i, turn in ipairs(sequence) do
            local nx = dx + math.cos(angle) * segLen
            local ny = dy + math.sin(angle) * segLen
            local col = colors[(i % 4) + 1]
            local r, g, b = rainbowShift(col, colorShift + i * 0.01)
            local alpha = (0.4 + audioBeat * 0.15) * audioMult
            gfx.set(r, g, b, math.min(0.6, alpha))
            gfx.line(dx, dy, nx, ny)
            dx, dy = nx, ny
            angle = angle + (turn == 1 and math.pi/2 or -math.pi/2)
        end

    -- === BASE PATTERN 42: Penrose Tiling ===
    elseif basePattern == 42 then
        local tileSize = 20 + variation * 3
        local phi = (1 + math.sqrt(5)) / 2
        for tx = 0, w + tileSize, tileSize do
            for ty = 0, h + tileSize, tileSize * 0.866 do
                local offset = (math.floor(ty / (tileSize * 0.866)) % 2) * tileSize * 0.5
                local px = x + tx + offset + math.sin(time * speedMult + tx * 0.01) * 5 * audioBass
                local py = y + ty + math.cos(time * speedMult + ty * 0.01) * 5 * audioBass
                local tileType = math.floor(seededRandom(seed + tx + ty * 100, 1) * 2)
                local col = colors[(tileType + math.floor(tx / tileSize)) % 4 + 1]
                local r, g, b = rainbowShift(col, colorShift + tx * 0.01)
                local alpha = (0.25 + audioBeat * 0.15) * audioMult
                gfx.set(r, g, b, math.min(0.5, alpha))
                -- Draw rhombus
                local angles = tileType == 0 and {0, math.pi/5, math.pi, math.pi + math.pi/5} or {0, 2*math.pi/5, math.pi, math.pi + 2*math.pi/5}
                for i = 1, 4 do
                    local a1 = angles[i] + time * 0.1 + rotation
                    local a2 = angles[(i % 4) + 1] + time * 0.1 + rotation
                    gfx.line(px + math.cos(a1) * tileSize * 0.4, py + math.sin(a1) * tileSize * 0.4,
                             px + math.cos(a2) * tileSize * 0.4, py + math.sin(a2) * tileSize * 0.4)
                end
            end
        end

    -- === BASE PATTERN 43: Fibonacci Spiral ===
    elseif basePattern == 43 then
        local fib = {1, 1}
        for i = 3, 12 do fib[i] = fib[i-1] + fib[i-2] end
        local scale = radius * 0.015 * (1 + audioBass * 0.2)
        local spiralX, spiralY = cx, cy
        local angle = time * 0.3 * speedMult + rotation
        for i = 1, #fib do
            local boxSize = fib[i] * scale
            local col = colors[(i % 4) + 1]
            local r, g, b = rainbowShift(col, colorShift + i * 0.3)
            local alpha = (0.3 + audioBeat * 0.15) * audioMult
            gfx.set(r, g, b, math.min(0.5, alpha))
            -- Draw arc
            local startAngle = angle + (i - 1) * math.pi / 2
            for a = 0, math.pi / 2, 0.05 do
                local ax = spiralX + math.cos(startAngle + a) * boxSize
                local ay = spiralY + math.sin(startAngle + a) * boxSize
                gfx.circle(ax, ay, (1 + audioPeak) * sizeMult, 1, 1)
            end
            -- Move to next corner
            spiralX = spiralX + math.cos(angle) * boxSize
            spiralY = spiralY + math.sin(angle) * boxSize
            angle = angle + math.pi / 2
        end

    -- === BASE PATTERN 44: Cellular Automata ===
    elseif basePattern == 44 then
        local cellSize = 8 + variation
        local cols = math.ceil(w / cellSize)
        local rows = math.ceil(h / cellSize)
        local timeStep = math.floor(time * 5 * speedMult)
        for row = 0, rows do
            for col = 0, cols do
                -- Rule 110 inspired pattern
                local cellSeed = seed + col + row * cols + timeStep
                local alive = seededRandom(cellSeed, 1) > 0.5
                local neighbors = 0
                for dx = -1, 1 do
                    for dy = -1, 1 do
                        if dx ~= 0 or dy ~= 0 then
                            local ns = seededRandom(seed + (col+dx) + (row+dy) * cols + timeStep, 1)
                            if ns > 0.5 then neighbors = neighbors + 1 end
                        end
                    end
                end
                if (alive and (neighbors == 2 or neighbors == 3)) or (not alive and neighbors == 3) then
                    local cx = x + col * cellSize + cellSize / 2
                    local cy = y + row * cellSize + cellSize / 2
                    local colIdx = (col + row) % 4 + 1
                    local r, g, b = rainbowShift(colors[colIdx], colorShift + col * 0.1)
                    local alpha = (0.4 + audioBeat * 0.2) * audioMult
                    gfx.set(r, g, b, math.min(0.6, alpha))
                    gfx.rect(x + col * cellSize + 1, y + row * cellSize + 1, cellSize - 2, cellSize - 2, 1)
                end
            end
        end

    -- === BASE PATTERN 45: L-System Plant ===
    elseif basePattern == 45 then
        -- Simple L-system: F -> F[+F]F[-F]F
        local angle = -math.pi / 2 + rotation
        local len = radius * 0.15 * (1 + audioBass * 0.2)
        local stack = {}
        local px, py = cx, cy + radius * 0.5
        local depth = 3 + (variation % 2)
        local instructions = "F"
        for d = 1, depth do
            local newInst = ""
            for i = 1, #instructions do
                local c = instructions:sub(i, i)
                if c == "F" then newInst = newInst .. "F[+F]F[-F]F"
                else newInst = newInst .. c end
            end
            instructions = newInst
            if #instructions > 1000 then break end
        end
        local branchCount = 0
        for i = 1, math.min(#instructions, 500) do
            local c = instructions:sub(i, i)
            if c == "F" then
                local nx = px + math.cos(angle) * len
                local ny = py + math.sin(angle) * len
                local col = colors[(branchCount % 4) + 1]
                local r, g, b = rainbowShift(col, colorShift + branchCount * 0.1)
                local alpha = (0.4 + audioBeat * 0.15) * audioMult
                gfx.set(r, g, b, math.min(0.6, alpha))
                gfx.line(px, py, nx, ny)
                px, py = nx, ny
                branchCount = branchCount + 1
            elseif c == "+" then
                angle = angle + math.pi / 6 + audioHigh * 0.1
            elseif c == "-" then
                angle = angle - math.pi / 6 - audioHigh * 0.1
            elseif c == "[" then
                table.insert(stack, {px, py, angle, len})
                len = len * 0.7
            elseif c == "]" then
                local state = table.remove(stack)
                if state then px, py, angle, len = state[1], state[2], state[3], state[4] end
            end
        end

    -- === CATEGORY: PARTICLES & SPARKLE (46-55) ===

    -- === BASE PATTERN 46: Fireflies ===
    elseif basePattern == 46 then
        local fireflyCount = 50 + variation * 10
        for f = 1, fireflyCount do
            local fSeed = seed + f * 23
            local fx = cx + (seededRandom(fSeed, 1) - 0.5) * w * 0.9
            local fy = cy + (seededRandom(fSeed, 2) - 0.5) * h * 0.9
            fx = fx + math.sin(time * seededRandom(fSeed, 3) * 2 + f) * 30 * (1 + audioMid * 0.5)
            fy = fy + math.cos(time * seededRandom(fSeed, 4) * 1.5 + f) * 20 * (1 + audioMid * 0.5)
            local blink = (math.sin(time * 3 + seededRandom(fSeed, 5) * 10) + 1) / 2
            local col = colors[(f % 4) + 1]
            local r, g, b = rainbowShift(col, colorShift + f * 0.1)
            local alpha = blink * (0.6 + audioBeat * 0.3) * audioMult
            gfx.set(r, g, b, math.min(0.9, alpha))
            local fSize = (2 + blink * 4 + audioPeak * 3) * sizeMult
            gfx.circle(fx, fy, fSize, 1, 1)
            -- Glow
            gfx.set(r, g, b, alpha * 0.3)
            gfx.circle(fx, fy, fSize * 2, 1, 1)
        end

    -- === BASE PATTERN 47: Shooting Stars ===
    elseif basePattern == 47 then
        local starCount = 20 + variation * 5
        for s = 1, starCount do
            local sSeed = seed + s * 31
            local startX = x + seededRandom(sSeed, 1) * w
            local startY = y + seededRandom(sSeed, 2) * h * 0.3
            local angle = math.pi * 0.6 + (seededRandom(sSeed, 3) - 0.5) * 0.5
            local speed = 200 + seededRandom(sSeed, 4) * 300
            local startTime = seededRandom(sSeed, 5) * 5
            local t = (time * speedMult + startTime) % 3
            local sx = startX + math.cos(angle) * t * speed
            local sy = startY + math.sin(angle) * t * speed
            if sx > x and sx < x + w and sy > y and sy < y + h then
                local col = colors[(s % 4) + 1]
                local r, g, b = rainbowShift(col, colorShift + s * 0.2)
                local alpha = (1 - t / 3) * (0.7 + audioBeat * 0.2) * audioMult
                -- Trail
                local trailLen = 30 + audioPeak * 20
                for trail = 0, trailLen, 2 do
                    local tx = sx - math.cos(angle) * trail
                    local ty = sy - math.sin(angle) * trail
                    local tAlpha = alpha * (1 - trail / trailLen)
                    gfx.set(r, g, b, math.min(0.8, tAlpha))
                    gfx.circle(tx, ty, (2 - trail / trailLen) * sizeMult, 1, 1)
                end
            end
        end

    -- === BASE PATTERN 48: Confetti ===
    elseif basePattern == 48 then
        local confettiCount = 100 + variation * 20
        for c = 1, confettiCount do
            local cSeed = seed + c * 37
            local cx = x + seededRandom(cSeed, 1) * w
            local fallSpeed = 50 + seededRandom(cSeed, 2) * 100
            local cy = y + ((time * fallSpeed * speedMult + seededRandom(cSeed, 3) * h) % (h + 50)) - 25
            local wobble = math.sin(time * 3 + c) * 20 * (1 + audioHigh * 0.5)
            cx = cx + wobble
            local rot = time * 5 + seededRandom(cSeed, 4) * 10
            local col = colors[(c % 4) + 1]
            local r, g, b = rainbowShift(col, colorShift + c * 0.05)
            local alpha = (0.6 + audioBeat * 0.2) * audioMult
            gfx.set(r, g, b, math.min(0.8, alpha))
            local cSize = (4 + seededRandom(cSeed, 5) * 4 + audioPeak * 2) * sizeMult
            -- Rectangle confetti
            local cosR, sinR = math.cos(rot), math.sin(rot)
            for dx = -cSize/2, cSize/2, 1 do
                for dy = -cSize/4, cSize/4, 1 do
                    local rx = cx + dx * cosR - dy * sinR
                    local ry = cy + dx * sinR + dy * cosR
                    gfx.circle(rx, ry, 1, 1, 1)
                end
            end
        end

    -- === BASE PATTERN 49: Bubbles ===
    elseif basePattern == 49 then
        local bubbleCount = 30 + variation * 8
        for b = 1, bubbleCount do
            local bSeed = seed + b * 41
            local bx = x + seededRandom(bSeed, 1) * w
            local riseSpeed = 30 + seededRandom(bSeed, 2) * 60
            local by = y + h - ((time * riseSpeed * speedMult + seededRandom(bSeed, 3) * h) % (h + 100))
            local wobble = math.sin(time * 2 + b * 0.5) * 15 * (1 + audioMid * 0.3)
            bx = bx + wobble
            local bubbleSize = (10 + seededRandom(bSeed, 4) * 20 + audioBass * 10) * sizeMult
            local col = colors[(b % 4) + 1]
            local r, g, b = rainbowShift(col, colorShift + b * 0.1)
            -- Bubble outline
            local alpha = (0.4 + audioBeat * 0.15) * audioMult
            gfx.set(r, g, b, math.min(0.6, alpha))
            gfx.circle(bx, by, bubbleSize, 0, 1)
            -- Highlight
            gfx.set(1, 1, 1, alpha * 0.5)
            gfx.circle(bx - bubbleSize * 0.3, by - bubbleSize * 0.3, bubbleSize * 0.2, 1, 1)
        end

    -- === BASE PATTERN 50: Sparkle Dust ===
    elseif basePattern == 50 then
        local dustCount = 200 + variation * 50
        for d = 1, dustCount do
            local dSeed = seed + d * 43
            local dx = x + seededRandom(dSeed, 1) * w
            local dy = y + seededRandom(dSeed, 2) * h
            local drift = time * (10 + seededRandom(dSeed, 3) * 20) * speedMult
            dx = x + ((dx - x + drift + math.sin(time + d) * 10) % w)
            dy = y + ((dy - y + drift * 0.3 + math.cos(time * 0.7 + d) * 5) % h)
            local twinkle = (math.sin(time * 8 + seededRandom(dSeed, 4) * 20) + 1) / 2
            local col = colors[(d % 4) + 1]
            local r, g, b = rainbowShift(col, colorShift + d * 0.02)
            local alpha = twinkle * (0.5 + audioBeat * 0.3) * audioMult
            gfx.set(r, g, b, math.min(0.8, alpha))
            local dSize = (1 + twinkle * 2 + audioPeak * 2) * sizeMult
            gfx.circle(dx, dy, dSize, 1, 1)
        end

    -- === PATTERNS 51-100 CONTINUE... ===

    -- === BASE PATTERN 51: Smoke ===
    elseif basePattern == 51 then
        local puffCount = 30 + variation * 5
        for p = 1, puffCount do
            local pSeed = seed + p * 47
            local age = (time * speedMult + seededRandom(pSeed, 1) * 10) % 5
            local px = cx + (seededRandom(pSeed, 2) - 0.5) * 100 + math.sin(time + p) * age * 20
            local py = cy + radius * 0.3 - age * 50 * (1 + audioBass * 0.3)
            local pSize = (age * 20 + 5 + audioPeak * 10) * sizeMult
            local alpha = (1 - age / 5) * 0.3 * audioMult
            gfx.set(0.7, 0.7, 0.8, alpha)
            gfx.circle(px, py, pSize, 1, 1)
        end

    -- === BASE PATTERN 52: Rain ===
    elseif basePattern == 52 then
        local dropCount = 100 + variation * 30
        for d = 1, dropCount do
            local dSeed = seed + d * 53
            local dx = x + seededRandom(dSeed, 1) * w
            local fallSpeed = 300 + seededRandom(dSeed, 2) * 200
            local dy = y + ((time * fallSpeed * speedMult + seededRandom(dSeed, 3) * h) % h)
            local col = colors[(d % 4) + 1]
            local r, g, b = rainbowShift(col, colorShift)
            local alpha = (0.3 + audioBeat * 0.2) * audioMult
            gfx.set(r, g, b, alpha)
            local dropLen = (10 + audioPeak * 10) * sizeMult
            gfx.line(dx, dy, dx, dy + dropLen)
        end

    -- === BASE PATTERN 53: Snow ===
    elseif basePattern == 53 then
        local flakeCount = 80 + variation * 20
        for f = 1, flakeCount do
            local fSeed = seed + f * 59
            local fx = x + seededRandom(fSeed, 1) * w
            local fallSpeed = 20 + seededRandom(fSeed, 2) * 40
            local fy = y + ((time * fallSpeed * speedMult + seededRandom(fSeed, 3) * h) % h)
            local wobble = math.sin(time * 2 + f * 0.5) * 30
            fx = fx + wobble
            local flakeSize = (2 + seededRandom(fSeed, 4) * 4 + audioPeak * 2) * sizeMult
            local alpha = (0.5 + audioBeat * 0.2) * audioMult
            gfx.set(1, 1, 1, alpha)
            gfx.circle(fx, fy, flakeSize, 1, 1)
        end

    -- === BASE PATTERN 54: Embers ===
    elseif basePattern == 54 then
        local emberCount = 60 + variation * 15
        for e = 1, emberCount do
            local eSeed = seed + e * 61
            local age = (time * speedMult + seededRandom(eSeed, 1) * 8) % 4
            local ex = cx + (seededRandom(eSeed, 2) - 0.5) * 200 + math.sin(time * 2 + e) * age * 30
            local ey = cy + radius * 0.4 - age * 80 * (1 + audioBass * 0.2)
            local eSize = ((1 - age / 4) * 4 + 1 + audioPeak * 2) * sizeMult
            local heat = 1 - age / 4
            gfx.set(1, 0.3 + heat * 0.5, 0, heat * (0.7 + audioBeat * 0.2) * audioMult)
            gfx.circle(ex, ey, eSize, 1, 1)
        end

    -- === BASE PATTERN 55: Glitter ===
    elseif basePattern == 55 then
        local glitterCount = 150 + variation * 40
        for g = 1, glitterCount do
            local gSeed = seed + g * 67
            local gx = x + seededRandom(gSeed, 1) * w
            local gy = y + seededRandom(gSeed, 2) * h
            local sparkleBase = (math.sin(time * 10 + seededRandom(gSeed, 3) * 50) + 1) / 2
            local sparkle = sparkleBase * sparkleBase * sparkleBase  -- ^3
            if sparkle > 0.3 then
                local col = colors[(g % 4) + 1]
                local r, g, b = rainbowShift(col, colorShift + g * 0.03)
                local alpha = sparkle * (0.8 + audioBeat * 0.2) * audioMult
                gfx.set(r, g, b, alpha)
                local gSize = (sparkle * 3 + audioPeak * 2) * sizeMult
                gfx.circle(gx, gy, gSize, 1, 1)
            end
        end

    -- === CATEGORY: GEOMETRIC (56-65) ===

    -- === BASE PATTERN 56: Hexagon Grid ===
    elseif basePattern == 56 then
        local hexSize = 20 + variation * 3
        local hexH = hexSize * math.sqrt(3)
        for row = -1, math.ceil(h / hexH) + 1 do
            for col = -1, math.ceil(w / (hexSize * 1.5)) + 1 do
                local hx = x + col * hexSize * 1.5
                local hy = y + row * hexH + (col % 2) * hexH / 2
                local pulse = math.sin(time * 2 + col * 0.3 + row * 0.3 + audioBass * 2) * 0.3
                local colIdx = (col + row) % 4 + 1
                local r, g, b = rainbowShift(colors[colIdx], colorShift + col * 0.1)
                local alpha = (0.2 + pulse + audioBeat * 0.15) * audioMult
                gfx.set(r, g, b, math.min(0.5, alpha))
                for side = 0, 5 do
                    local a1 = (side / 6) * math.pi * 2 + rotation
                    local a2 = ((side + 1) / 6) * math.pi * 2 + rotation
                    gfx.line(hx + math.cos(a1) * hexSize, hy + math.sin(a1) * hexSize,
                             hx + math.cos(a2) * hexSize, hy + math.sin(a2) * hexSize)
                end
            end
        end

    -- === BASE PATTERN 57: Voronoi ===
    elseif basePattern == 57 then
        local pointCount = 15 + variation * 3
        local points = {}
        for p = 1, pointCount do
            local pSeed = seed + p * 71
            table.insert(points, {
                x = x + seededRandom(pSeed, 1) * w + math.sin(time + p) * 20,
                y = y + seededRandom(pSeed, 2) * h + math.cos(time * 0.7 + p) * 20,
                col = (p % 4) + 1
            })
        end
        local gridStep = 10 + variation
        for gx = 0, w, gridStep do
            for gy = 0, h, gridStep do
                local minDist = 999999
                local closestCol = 1
                local px, py = x + gx, y + gy
                for _, pt in ipairs(points) do
                    local dist = math.sqrt((px - pt.x)^2 + (py - pt.y)^2)
                    if dist < minDist then
                        minDist = dist
                        closestCol = pt.col
                    end
                end
                local r, g, b = rainbowShift(colors[closestCol], colorShift + minDist * 0.01)
                local alpha = (0.3 + audioBeat * 0.15) * audioMult
                gfx.set(r, g, b, alpha)
                gfx.rect(px, py, gridStep - 1, gridStep - 1, 1)
            end
        end

    -- === BASE PATTERN 58: Checkerboard Wave ===
    elseif basePattern == 58 then
        local tileSize = 15 + variation * 2
        for tx = 0, w, tileSize do
            for ty = 0, h, tileSize do
                local wave = math.sin(tx * 0.05 + ty * 0.05 + time * 3 * speedMult + audioBass * 2)
                local checker = ((math.floor(tx / tileSize) + math.floor(ty / tileSize)) % 2)
                if (wave > 0) == (checker == 1) then
                    local colIdx = (math.floor(tx / tileSize) % 4) + 1
                    local r, g, b = rainbowShift(colors[colIdx], colorShift + tx * 0.02)
                    local alpha = (0.4 + audioBeat * 0.2) * audioMult
                    gfx.set(r, g, b, alpha)
                    gfx.rect(x + tx, y + ty, tileSize - 1, tileSize - 1, 1)
                end
            end
        end

    -- === BASE PATTERN 59: Triangular Mesh ===
    elseif basePattern == 59 then
        local triSize = 25 + variation * 4
        local triH = triSize * math.sqrt(3) / 2
        for row = 0, math.ceil(h / triH) do
            for col = 0, math.ceil(w / triSize) do
                local tx = x + col * triSize + (row % 2) * triSize / 2
                local ty = y + row * triH
                local offset = math.sin(time * 2 + col * 0.3 + row * 0.3 + audioBass) * 5
                local colIdx = (col + row) % 4 + 1
                local r, g, b = rainbowShift(colors[colIdx], colorShift + col * 0.1)
                local alpha = (0.25 + audioBeat * 0.15) * audioMult
                gfx.set(r, g, b, alpha)
                gfx.line(tx + offset, ty, tx + triSize / 2 + offset, ty + triH)
                gfx.line(tx + triSize / 2 + offset, ty + triH, tx - triSize / 2 + offset, ty + triH)
                gfx.line(tx - triSize / 2 + offset, ty + triH, tx + offset, ty)
            end
        end

    -- === BASE PATTERN 60: Radial Burst ===
    elseif basePattern == 60 then
        local rays = 24 + variation * 4
        for ray = 0, rays - 1 do
            local rayAngle = (ray / rays) * math.pi * 2 + time * 0.3 * speedMult + rotation
            local rayLen = radius * (0.3 + seededRandom(seed + ray, 1) * 0.7) * (1 + audioBass * 0.3)
            local pulseLen = rayLen * (1 + math.sin(time * 4 + ray * 0.5) * 0.2 + audioPeak * 0.3)
            local col = colors[(ray % 4) + 1]
            local r, g, b = rainbowShift(col, colorShift + ray * 0.15)
            local alpha = (0.4 + audioBeat * 0.2) * audioMult
            gfx.set(r, g, b, alpha)
            gfx.line(cx, cy, cx + math.cos(rayAngle) * pulseLen, cy + math.sin(rayAngle) * pulseLen)
        end

    -- === PATTERNS 61-100: More variety ===

    elseif basePattern == 61 then -- Rotating Gears
        local gearCount = 3 + (variation % 4)
        for gear = 1, gearCount do
            local gearX = cx + (gear - (gearCount + 1) / 2) * radius * 0.5
            local gearRadius = radius * (0.2 + gear * 0.05) * (1 + audioBass * 0.2)
            local teeth = 8 + gear * 2
            local gearRot = time * (gear % 2 == 0 and 1 or -1) * speedMult + rotation
            local col = colors[(gear % 4) + 1]
            local r, g, b = rainbowShift(col, colorShift + gear)
            local alpha = (0.35 + audioBeat * 0.15) * audioMult
            gfx.set(r, g, b, alpha)
            for tooth = 0, teeth - 1 do
                local a1 = gearRot + (tooth / teeth) * math.pi * 2
                local a2 = gearRot + ((tooth + 0.3) / teeth) * math.pi * 2
                local a3 = gearRot + ((tooth + 0.7) / teeth) * math.pi * 2
                local a4 = gearRot + ((tooth + 1) / teeth) * math.pi * 2
                gfx.line(gearX + math.cos(a1) * gearRadius, cy + math.sin(a1) * gearRadius,
                         gearX + math.cos(a2) * gearRadius * 1.2, cy + math.sin(a2) * gearRadius * 1.2)
                gfx.line(gearX + math.cos(a2) * gearRadius * 1.2, cy + math.sin(a2) * gearRadius * 1.2,
                         gearX + math.cos(a3) * gearRadius * 1.2, cy + math.sin(a3) * gearRadius * 1.2)
                gfx.line(gearX + math.cos(a3) * gearRadius * 1.2, cy + math.sin(a3) * gearRadius * 1.2,
                         gearX + math.cos(a4) * gearRadius, cy + math.sin(a4) * gearRadius)
            end
        end

    elseif basePattern == 62 then -- Wave Grid
        local gridW, gridH = 20 + variation, 15 + variation
        for gx = 0, gridW do
            for gy = 0, gridH do
                local px = x + (gx / gridW) * w
                local py = y + (gy / gridH) * h
                local wave = math.sin(gx * 0.5 + time * 3 * speedMult) * 10 + math.sin(gy * 0.3 + time * 2) * 10
                py = py + wave * (1 + audioBass * 0.5)
                local col = colors[((gx + gy) % 4) + 1]
                local r, g, b = rainbowShift(col, colorShift + gx * 0.1)
                local alpha = (0.4 + audioBeat * 0.2) * audioMult
                gfx.set(r, g, b, alpha)
                gfx.circle(px, py, (2 + audioPeak * 2) * sizeMult, 1, 1)
            end
        end

    elseif basePattern == 63 then -- Orbital Paths
        local orbits = 5 + variation
        for orb = 1, orbits do
            local orbRadius = (orb / orbits) * radius * 0.9
            local col = colors[(orb % 4) + 1]
            local r, g, b = rainbowShift(col, colorShift + orb * 0.3)
            local alpha = (0.2 + audioBeat * 0.1) * audioMult
            gfx.set(r, g, b, alpha)
            -- Orbit path
            for angle = 0, math.pi * 2, 0.05 do
                local ox = cx + math.cos(angle + rotation) * orbRadius
                local oy = cy + math.sin(angle + rotation) * orbRadius * 0.5
                gfx.circle(ox, oy, sizeMult, 1, 1)
            end
            -- Planet
            local planetAngle = time * (1 + orb * 0.2) * speedMult + orb
            local planetX = cx + math.cos(planetAngle + rotation) * orbRadius
            local planetY = cy + math.sin(planetAngle + rotation) * orbRadius * 0.5
            gfx.set(r, g, b, (0.7 + audioBeat * 0.2) * audioMult)
            gfx.circle(planetX, planetY, (5 + orb + audioPeak * 3) * sizeMult, 1, 1)
        end

    elseif basePattern == 64 then -- Diamond Pattern
        local diamondSize = 20 + variation * 3
        for dx = -diamondSize, w + diamondSize, diamondSize do
            for dy = -diamondSize, h + diamondSize, diamondSize do
                local offset = (math.floor(dy / diamondSize) % 2) * diamondSize / 2
                local px = x + dx + offset + math.sin(time + dx * 0.01) * 5 * audioBass
                local py = y + dy + math.cos(time + dy * 0.01) * 5 * audioBass
                local col = colors[(math.floor(dx / diamondSize + dy / diamondSize) % 4) + 1]
                local r, g, b = rainbowShift(col, colorShift + dx * 0.02)
                local alpha = (0.3 + audioBeat * 0.15) * audioMult
                gfx.set(r, g, b, alpha)
                local ds = diamondSize * 0.4 * (1 + audioPeak * 0.2)
                gfx.line(px, py - ds, px + ds, py)
                gfx.line(px + ds, py, px, py + ds)
                gfx.line(px, py + ds, px - ds, py)
                gfx.line(px - ds, py, px, py - ds)
            end
        end

    elseif basePattern == 65 then -- Flower of Life
        local circleRadius = 25 + variation * 5
        local layers = 3 + (variation % 3)
        local drawn = {}
        local function drawFlowerCircle(fcx, fcy)
            local key = math.floor(fcx) .. "," .. math.floor(fcy)
            if drawn[key] then return end
            drawn[key] = true
            local col = colors[(#drawn % 4) + 1]
            local r, g, b = rainbowShift(col, colorShift + #drawn * 0.1)
            local alpha = (0.25 + audioBeat * 0.1) * audioMult
            gfx.set(r, g, b, alpha)
            for angle = 0, math.pi * 2, 0.05 do
                local ox = fcx + math.cos(angle) * circleRadius * (1 + audioBass * 0.1)
                local oy = fcy + math.sin(angle) * circleRadius * (1 + audioBass * 0.1)
                gfx.circle(ox, oy, sizeMult, 1, 1)
            end
        end
        drawFlowerCircle(cx, cy)
        for layer = 1, layers do
            for i = 0, 5 do
                local angle = (i / 6) * math.pi * 2 + time * 0.1 + rotation
                local dist = layer * circleRadius * (1 + audioBass * 0.1)
                drawFlowerCircle(cx + math.cos(angle) * dist, cy + math.sin(angle) * dist)
            end
        end

    -- === CATEGORY: WAVEFORMS & AUDIO (66-75) ===

    elseif basePattern == 66 then -- Spectrum Bars
        local bars = 32 + variation * 8
        local barW = w / bars
        for bar = 0, bars - 1 do
            local barPhase = time * 3 + bar * 0.2
            local barH = (math.sin(barPhase) * 0.5 + 0.5) * h * 0.8 * (1 + audioPeak * 0.5)
            if audioReactive.waveformHistory and #audioReactive.waveformHistory > 0 then
                local idx = math.floor(bar / bars * #audioReactive.waveformHistory) + 1
                barH = (audioReactive.waveformHistory[idx] or 0.5) * h * (1 + audioBass * 0.3)
            end
            local col = colors[(bar % 4) + 1]
            local r, g, b = rainbowShift(col, colorShift + bar * 0.1)
            local alpha = (0.5 + audioBeat * 0.2) * audioMult
            gfx.set(r, g, b, alpha)
            gfx.rect(x + bar * barW, y + h - barH, barW - 1, barH, 1)
        end

    elseif basePattern == 67 then -- Circular Spectrum
        local segments = 60 + variation * 10
        for seg = 0, segments - 1 do
            local segAngle = (seg / segments) * math.pi * 2 + rotation
            local segH = radius * 0.3 * (1 + math.sin(time * 3 + seg * 0.3) * 0.5 + audioPeak * 0.5)
            if audioReactive.waveformHistory and #audioReactive.waveformHistory > 0 then
                local idx = math.floor(seg / segments * #audioReactive.waveformHistory) + 1
                segH = radius * 0.2 + (audioReactive.waveformHistory[idx] or 0.3) * radius * 0.6
            end
            local innerR = radius * 0.3
            local outerR = innerR + segH
            local col = colors[(seg % 4) + 1]
            local r, g, b = rainbowShift(col, colorShift + seg * 0.05)
            local alpha = (0.5 + audioBeat * 0.2) * audioMult
            gfx.set(r, g, b, alpha)
            gfx.line(cx + math.cos(segAngle) * innerR, cy + math.sin(segAngle) * innerR,
                     cx + math.cos(segAngle) * outerR, cy + math.sin(segAngle) * outerR)
        end

    elseif basePattern == 68 then -- Oscilloscope
        local points = 200 + variation * 50
        local prevX, prevY
        for i = 0, points do
            local t = i / points
            local px = x + t * w
            local py = cy
            local wave1 = math.sin(t * 10 + time * 5 * speedMult) * h * 0.2
            local wave2 = math.sin(t * 15 - time * 3 * speedMult) * h * 0.1
            py = py + (wave1 + wave2) * (1 + audioPeak * 0.5)
            if audioReactive.waveformHistory and #audioReactive.waveformHistory > 0 then
                local idx = math.floor(t * #audioReactive.waveformHistory) + 1
                py = cy + (audioReactive.waveformHistory[idx] or 0) * h * 0.8 - h * 0.4
            end
            local col = colors[(math.floor(t * 4) % 4) + 1]
            local r, g, b = rainbowShift(col, colorShift + t * 2)
            local alpha = (0.6 + audioBeat * 0.2) * audioMult
            gfx.set(r, g, b, alpha)
            if prevX then gfx.line(prevX, prevY, px, py) end
            prevX, prevY = px, py
        end

    elseif basePattern == 69 then -- VU Meter
        local meterCount = 8 + variation
        local meterW = w / meterCount * 0.8
        local meterSpacing = w / meterCount
        for m = 0, meterCount - 1 do
            local meterX = x + m * meterSpacing + (meterSpacing - meterW) / 2
            local meterVal = math.sin(time * 2 + m * 0.5) * 0.5 + 0.5 + audioPeak * 0.3
            local segments = 10
            for seg = 0, segments - 1 do
                local segY = y + h - (seg + 1) * (h / segments)
                local lit = (seg / segments) < meterVal
                local col
                if seg < segments * 0.6 then col = {0.2, 0.8, 0.2}
                elseif seg < segments * 0.8 then col = {0.8, 0.8, 0.2}
                else col = {0.8, 0.2, 0.2} end
                local alpha = lit and (0.7 + audioBeat * 0.2) or 0.1
                gfx.set(col[1], col[2], col[3], alpha * audioMult)
                gfx.rect(meterX, segY, meterW, h / segments - 2, 1)
            end
        end

    elseif basePattern == 70 then -- Bass Kick
        local kickSize = radius * (0.5 + audioBass * 0.8)
        local kickAlpha = audioBass * 0.8 + 0.2
        for ring = 5, 1, -1 do
            local ringSize = kickSize * (1 + ring * 0.15)
            local col = colors[(ring % 4) + 1]
            local r, g, b = rainbowShift(col, colorShift + ring)
            gfx.set(r, g, b, kickAlpha / ring * audioMult)
            gfx.circle(cx, cy, ringSize, 1, 1)
        end

    -- === REMAINING PATTERNS (71-100) for variety ===

    elseif basePattern == 71 then -- Neon Signs
        local signCount = 4 + variation
        for sign = 1, signCount do
            local signX = x + (sign / (signCount + 1)) * w
            local signY = cy + math.sin(time + sign) * h * 0.2
            local col = colors[(sign % 4) + 1]
            local r, g, b = rainbowShift(col, colorShift + sign)
            local flicker = 0.7 + math.sin(time * 20 + sign * 100) * 0.3
            local alpha = flicker * (0.6 + audioBeat * 0.3) * audioMult
            -- Glow
            for glow = 3, 1, -1 do
                gfx.set(r, g, b, alpha / glow * 0.5)
                gfx.circle(signX, signY, (15 + glow * 5) * sizeMult, 1, 1)
            end
            gfx.set(r, g, b, alpha)
            gfx.circle(signX, signY, 10 * sizeMult, 1, 1)
        end

    elseif basePattern == 72 then -- Laser Show
        local laserCount = 8 + variation * 2
        for laser = 1, laserCount do
            local laserAngle = time * (1 + laser * 0.1) * speedMult + laser * 0.8
            local laserLen = radius * (0.8 + math.sin(time * 3 + laser) * 0.2) * (1 + audioBass * 0.3)
            local col = colors[(laser % 4) + 1]
            local r, g, b = rainbowShift(col, colorShift + laser * 0.2)
            local alpha = (0.5 + audioBeat * 0.3) * audioMult
            gfx.set(r, g, b, alpha)
            local ex = cx + math.cos(laserAngle + rotation) * laserLen
            local ey = cy + math.sin(laserAngle + rotation) * laserLen * 0.6
            gfx.line(cx, cy, ex, ey)
            -- Glow
            gfx.set(r, g, b, alpha * 0.3)
            gfx.line(cx + 1, cy + 1, ex + 1, ey + 1)
        end

    elseif basePattern == 73 then -- Disco Ball
        local facets = 20 + variation * 5
        for fx = 0, facets do
            for fy = 0, facets / 2 do
                local theta = (fx / facets) * math.pi * 2 + time * 0.5 + rotation
                local phi = (fy / (facets / 2)) * math.pi
                local bx = cx + math.sin(phi) * math.cos(theta) * radius * 0.6
                local by = cy + math.cos(phi) * radius * 0.4
                local bz = math.sin(phi) * math.sin(theta)
                if bz > -0.2 then
                    local brightness = (bz + 1) / 2
                    local sparkle = math.sin(time * 10 + fx * 3 + fy * 5) > 0.7 and 1 or 0.3
                    local col = colors[((fx + fy) % 4) + 1]
                    local r, g, b = rainbowShift(col, colorShift + fx * 0.1)
                    local alpha = brightness * sparkle * (0.7 + audioBeat * 0.3) * audioMult
                    gfx.set(r, g, b, alpha)
                    gfx.circle(bx, by, (3 + audioPeak * 2) * sizeMult, 1, 1)
                end
            end
        end

    elseif basePattern == 74 then -- Heartbeat
        local beatPhase = (time * 1.2 * speedMult) % 1
        local beatScale = 1 + (beatPhase < 0.1 and math.sin(beatPhase * 10 * math.pi) * 0.3 or 0)
        beatScale = beatScale + audioBeat * 0.3
        local heartSize = radius * 0.4 * beatScale
        local col = colors[1]  -- Red for heart
        local r, g, b = rainbowShift(col, colorShift)
        local alpha = (0.6 + audioBeat * 0.3) * audioMult
        gfx.set(r, g, b, alpha)
        -- Draw heart shape
        for t = 0, math.pi * 2, 0.02 do
            local sinT = math.sin(t)
            local hx = 16 * sinT * sinT * sinT  -- sin(t)^3
            local hy = -(13 * math.cos(t) - 5 * math.cos(2*t) - 2 * math.cos(3*t) - math.cos(4*t))
            local px = cx + hx * heartSize * 0.05
            local py = cy + hy * heartSize * 0.05
            gfx.circle(px, py, (2 + audioPeak) * sizeMult, 1, 1)
        end

    elseif basePattern == 75 then -- DNA Double Helix (alternative)
        local helixLen = h * 0.8
        local helixY = y + (h - helixLen) / 2
        local twists = 3 + variation
        for t = 0, 1, 0.01 do
            local ty = helixY + t * helixLen
            local phase = t * twists * math.pi * 2 + time * 2 * speedMult
            local x1 = cx + math.sin(phase) * radius * 0.3 * (1 + audioBass * 0.2)
            local x2 = cx + math.sin(phase + math.pi) * radius * 0.3 * (1 + audioBass * 0.2)
            -- Strand 1
            gfx.set(colors[1][1], colors[1][2], colors[1][3], (0.6 + audioBeat * 0.2) * audioMult)
            gfx.circle(x1, ty, (3 + audioPeak * 2) * sizeMult, 1, 1)
            -- Strand 2
            gfx.set(colors[3][1], colors[3][2], colors[3][3], (0.6 + audioBeat * 0.2) * audioMult)
            gfx.circle(x2, ty, (3 + audioPeak * 2) * sizeMult, 1, 1)
            -- Connecting rungs
            if math.floor(t * 50) % 3 == 0 then
                gfx.set(colors[2][1], colors[2][2], colors[2][3], (0.3 + audioBeat * 0.1) * audioMult)
                gfx.line(x1, ty, x2, ty)
            end
        end

    -- === PATTERNS 76-100: Final batch ===

    elseif basePattern >= 76 and basePattern <= 100 then
        -- Generate varied patterns using pattern number as modifier
        local patternType = (basePattern - 76) % 5
        local intensity = 0.5 + (basePattern - 76) / 50

        if patternType == 0 then -- Spinning webs
            local spokes = 12 + variation
            local rings = 8 + (basePattern % 5)
            for spoke = 0, spokes - 1 do
                local spokeAngle = (spoke / spokes) * math.pi * 2 + time * 0.3 * speedMult + rotation
                local col = colors[(spoke % 4) + 1]
                local r, g, b = rainbowShift(col, colorShift + spoke * 0.2)
                gfx.set(r, g, b, (0.3 + audioBeat * 0.15) * audioMult)
                gfx.line(cx, cy, cx + math.cos(spokeAngle) * radius, cy + math.sin(spokeAngle) * radius * 0.6)
            end
            for ring = 1, rings do
                local ringR = (ring / rings) * radius * (1 + audioBass * 0.2)
                for spoke = 0, spokes - 1 do
                    local a1 = (spoke / spokes) * math.pi * 2 + time * 0.3 + rotation
                    local a2 = ((spoke + 1) / spokes) * math.pi * 2 + time * 0.3 + rotation
                    gfx.line(cx + math.cos(a1) * ringR, cy + math.sin(a1) * ringR * 0.6,
                             cx + math.cos(a2) * ringR, cy + math.sin(a2) * ringR * 0.6)
                end
            end

        elseif patternType == 1 then -- Bouncing balls
            local ballCount = 10 + variation * 3
            for ball = 1, ballCount do
                local bSeed = seed + ball * (basePattern + 1)
                local bx = x + seededRandom(bSeed, 1) * w
                local bounceSpeed = 1 + seededRandom(bSeed, 2)
                local bouncePhase = (time * bounceSpeed * speedMult + seededRandom(bSeed, 3) * 10) % 2
                local by = y + h - math.abs(math.sin(bouncePhase * math.pi)) * h * 0.7 - 20
                local col = colors[(ball % 4) + 1]
                local r, g, b = rainbowShift(col, colorShift + ball * 0.2)
                gfx.set(r, g, b, (0.6 + audioBeat * 0.2) * audioMult)
                local ballSize = (10 + seededRandom(bSeed, 4) * 10 + audioPeak * 5) * sizeMult
                gfx.circle(bx, by, ballSize, 1, 1)
            end

        elseif patternType == 2 then -- Rotating star field
            local starCount = 50 + variation * 15
            for star = 1, starCount do
                local sSeed = seed + star * (basePattern + 1)
                local sAngle = seededRandom(sSeed, 1) * math.pi * 2
                local sDist = seededRandom(sSeed, 2) * radius
                local rotSpeed = (seededRandom(sSeed, 3) - 0.5) * 2
                local currentAngle = sAngle + time * rotSpeed * speedMult + rotation
                local sx = cx + math.cos(currentAngle) * sDist
                local sy = cy + math.sin(currentAngle) * sDist * 0.6
                local twinkle = (math.sin(time * 5 + star) + 1) / 2
                local col = colors[(star % 4) + 1]
                local r, g, b = rainbowShift(col, colorShift + star * 0.05)
                gfx.set(r, g, b, twinkle * (0.5 + audioBeat * 0.2) * audioMult)
                gfx.circle(sx, sy, (1 + twinkle * 2 + audioPeak) * sizeMult, 1, 1)
            end

        elseif patternType == 3 then -- Expanding rings
            local ringCount = 5 + variation
            for ring = 1, ringCount do
                local ringPhase = (time * speedMult * 0.5 + ring * 0.3) % 1
                local ringR = ringPhase * radius * 1.2
                local alpha = (1 - ringPhase) * 0.5 + audioBeat * 0.1
                local col = colors[(ring % 4) + 1]
                local r, g, b = rainbowShift(col, colorShift + ring * 0.3)
                gfx.set(r, g, b, alpha * audioMult)
                for angle = 0, math.pi * 2, 0.03 do
                    gfx.circle(cx + math.cos(angle) * ringR, cy + math.sin(angle) * ringR * 0.6, sizeMult, 1, 1)
                end
            end

        else -- Morphing blob
            local points = 60 + variation * 10
            local prevX, prevY
            for i = 0, points do
                local angle = (i / points) * math.pi * 2
                local noise = 0
                for harmonic = 1, 5 do
                    noise = noise + math.sin(angle * harmonic + time * (harmonic * 0.5) * speedMult) / harmonic
                end
                local blobR = radius * 0.5 * (1 + noise * 0.3 + audioBass * 0.2)
                local bx = cx + math.cos(angle + rotation) * blobR
                local by = cy + math.sin(angle + rotation) * blobR
                local col = colors[(i % 4) + 1]
                local r, g, b = rainbowShift(col, colorShift + angle)
                gfx.set(r, g, b, (0.5 + audioBeat * 0.2) * audioMult)
                if prevX then gfx.line(prevX, prevY, bx, by) end
                prevX, prevY = bx, by
            end
        end
    end

    -- Beat flash removed from Gallery - was causing visible grey square artifact
end

-- Wrapper function that handles crossfade transitions between patterns
local function drawProceduralArt(x, y, w, h, time, rotation, skipBackground)
    -- Check if visual FX are disabled
    if not SETTINGS.visualFX then
        -- Just draw a simple background when FX are off
        if not skipBackground then
            if SETTINGS.darkMode then
                gfx.set(0.08, 0.08, 0.1, 1)
            else
                gfx.set(0.95, 0.95, 0.97, 1)
            end
            gfx.rect(x, y, w, h, 1)
        end
        return
    end

    -- Update transition progress
    if proceduralArt.transitionProgress and proceduralArt.transitionProgress < 1 then
        proceduralArt.transitionProgress = proceduralArt.transitionProgress + (0.016 / (proceduralArt.transitionDuration or 1.5))

        if proceduralArt.transitionProgress < 1 then
            -- Smooth easing function (ease-in-out)
            local t = proceduralArt.transitionProgress
            local easeVal = -2 * t + 2
            local eased = t < 0.5 and (2 * t * t) or (1 - easeVal * easeVal / 2)

            -- Draw OLD pattern first (with zoom-out effect)
            if proceduralArt.oldSeed and proceduralArt.oldStyle then
                local zoomOut = 1 + eased * 0.2  -- Slight zoom out as it fades
                local oldW, oldH = w * zoomOut, h * zoomOut
                local oldX, oldY = x - (oldW - w) / 2, y - (oldH - h) / 2
                drawProceduralArtInternal(oldX, oldY, oldW, oldH, proceduralArt.oldTime or time, rotation, true, 1, proceduralArt.oldSeed, proceduralArt.oldStyle)

                -- Fade out overlay on old pattern (simulates alpha fade)
                if SETTINGS and SETTINGS.darkMode then
                    gfx.set(0, 0, 0, eased * 0.85)
                else
                    gfx.set(1, 1, 1, eased * 0.85)
                end
                gfx.rect(x, y, w, h, 1)
            end

            -- Draw NEW pattern (with zoom-in effect, starting slightly zoomed)
            local zoomIn = 1.15 - eased * 0.15  -- Start 15% zoomed in, settle to normal
            local newW, newH = w * zoomIn, h * zoomIn
            local newX, newY = x - (newW - w) / 2, y - (newH - h) / 2
            drawProceduralArtInternal(newX, newY, newW, newH, time, rotation, true, 1)

            -- Fade in overlay for new pattern (reverse - starts opaque, becomes transparent)
            if SETTINGS and SETTINGS.darkMode then
                gfx.set(0, 0, 0, (1 - eased) * 0.7)
            else
                gfx.set(1, 1, 1, (1 - eased) * 0.7)
            end
            gfx.rect(x, y, w, h, 1)
        else
            -- Transition complete
            proceduralArt.transitionProgress = nil
            proceduralArt.oldSeed = nil
            proceduralArt.oldStyle = nil
            proceduralArt.oldElements = nil
            proceduralArt.oldTime = nil
            drawProceduralArtInternal(x, y, w, h, time, rotation, skipBackground)
        end
    else
        -- No transition, just draw normally
        drawProceduralArtInternal(x, y, w, h, time, rotation, skipBackground)
    end
end

-- Initialize procedural art on first run
generateNewArt()

-- ============================================
-- END PROCEDURAL ART GENERATOR
-- ============================================

-- STEMperator Art Gallery - Spectacular animated visualizations
-- Each piece is a fully animated graphical artwork (20 masterpieces!)
local stemperatorArt = {
    {
        title = "The Prism of Sound",
        subtitle = "White light becomes a spectrum of music",
        description = "Audio enters as one, emerges as four distinct colors of sound",
    },
    {
        title = "Neural Separation",
        subtitle = "Deep learning dissects the mix",
        description = "Watch as AI neurons fire and separate the tangled waveforms",
    },
    {
        title = "The Four Elements",
        subtitle = "Voice, Rhythm, Bass, Harmony",
        description = "Like earth, water, fire and air - four essences of music",
    },
    {
        title = "Waveform Surgery",
        subtitle = "Precision extraction in real-time",
        description = "Surgical separation of intertwined frequencies",
    },
    {
        title = "The Sound Galaxy",
        subtitle = "Stars of audio in cosmic dance",
        description = "Each stem orbits the central mix like planets around a sun",
    },
    {
        title = "Frequency Waterfall",
        subtitle = "Cascading layers of sound",
        description = "High frequencies fall through mid and low, each finding its home",
    },
    {
        title = "The DNA Helix",
        subtitle = "Unraveling the genetic code of music",
        description = "Double helix of sound splits into its component strands",
    },
    {
        title = "Particle Storm",
        subtitle = "Audio atoms in motion",
        description = "Millions of sound particles sorting themselves by type",
    },
    {
        title = "The Mixing Desk",
        subtitle = "Faders of the universe",
        description = "Four channels rising from chaos into clarity",
    },
    {
        title = "Stem Constellation",
        subtitle = "Navigate by the stars of sound",
        description = "Connect the dots to reveal the hidden patterns in music",
    },
    -- NEW ART PIECES
    {
        title = "Harmonic Mandala",
        subtitle = "Sacred geometry of frequency",
        description = "The mathematical beauty underlying all music, visualized",
    },
    {
        title = "The Stem Lotus",
        subtitle = "Petals of pure audio",
        description = "Each stem unfolds like a lotus petal reaching for the light",
    },
    {
        title = "Aurora Borealis",
        subtitle = "Northern lights of sound",
        description = "Stems dance like the aurora across the audio sky",
    },
    {
        title = "Quantum Entanglement",
        subtitle = "Connected across the mix",
        description = "Four particles forever linked, yet beautifully separate",
    },
    {
        title = "The Spiral Tower",
        subtitle = "Ascending frequencies",
        description = "A tower of sound spiraling into the infinite",
    },
    {
        title = "Ocean of Waves",
        subtitle = "Tides of audio",
        description = "Each stem flows like waves in an endless ocean",
    },
    {
        title = "Crystalline Matrix",
        subtitle = "Frozen frequencies",
        description = "Sound crystalized into perfect geometric formations",
    },
    {
        title = "The Heartbeat",
        subtitle = "Pulse of the music",
        description = "Every song has a heartbeat - watch it pulse in four colors",
    },
    {
        title = "Stem Kaleidoscope",
        subtitle = "Infinite reflections",
        description = "Mirrors within mirrors, stems within stems",
    },
    {
        title = "Digital Rain",
        subtitle = "Cascading code of music",
        description = "The matrix of audio flows downward eternally",
    },
}

-- Forward declaration for showMessage
local showMessage

-- Draw Art Gallery window - SPECTACULAR GRAPHICAL ANIMATIONS
local function drawArtGallery()
    local w, h = gfx.w, gfx.h

    -- Calculate scale for large window (with text zoom for non-gallery tabs)
    -- Base scale is larger (1.5x) for better readability
    local baseScale = math.min(w / 600, h / 450) * 1.5
    baseScale = math.max(0.5, math.min(5.0, baseScale))

    -- Smooth text zoom interpolation
    helpState.textZoom = helpState.textZoom + (helpState.targetTextZoom - helpState.textZoom) * 0.15

    -- UI() = fixed scale for UI elements that should NOT zoom (tabs, buttons, theme toggle, etc.)
    local function UI(val) return math.floor(val * baseScale + 0.5) end

    -- Apply text zoom to scale for non-gallery/about tabs (content only)
    -- Tab 4 (Gallery) and Tab 5 (About) use art zoom instead
    local scale = baseScale
    if helpState.currentTab ~= 4 and helpState.currentTab ~= 5 then
        scale = baseScale * helpState.textZoom
    end
    -- PS() = zoomed scale for content that CAN zoom
    local function PS(val) return math.floor(val * scale + 0.5) end

    local mx, my = gfx.mouse_x, gfx.mouse_y
    local mouseDown = gfx.mouse_cap & 1 == 1
    local middleMouseDown = gfx.mouse_cap & 64 == 64  -- Middle mouse button
    local time = os.clock() - artGalleryState.startTime

    -- Tooltip tracking
    local tooltipText = nil
    local tooltipX, tooltipY = 0, 0

    -- === MOUSE WHEEL ZOOM ===
    local mouseWheel = gfx.mouse_wheel
    if mouseWheel ~= artGalleryState.lastMouseWheel then
        local delta = (mouseWheel - artGalleryState.lastMouseWheel) / 120

        if helpState.currentTab == 4 or helpState.currentTab == 5 then
            -- Gallery/About tab: zoom art (fly-through effect with huge zoom range)
            local zoomFactor = 1.15
            if delta > 0 then
                artGalleryState.targetZoom = math.min(50.0, artGalleryState.targetZoom * zoomFactor)  -- Much higher max for fly-through
            elseif delta < 0 then
                artGalleryState.targetZoom = math.max(0.1, artGalleryState.targetZoom / zoomFactor)  -- Lower min to zoom way out
            end
            -- Zoom towards mouse position
            local zoomCenterX = mx - w/2
            local zoomCenterY = my - h/2
            if delta > 0 then
                artGalleryState.targetPanX = artGalleryState.targetPanX - zoomCenterX * 0.15
                artGalleryState.targetPanY = artGalleryState.targetPanY - zoomCenterY * 0.15
            else
                artGalleryState.targetPanX = artGalleryState.targetPanX + zoomCenterX * 0.1
                artGalleryState.targetPanY = artGalleryState.targetPanY + zoomCenterY * 0.1
            end
        else
            -- Other tabs: zoom text (larger range now)
            local zoomFactor = 1.15
            if delta > 0 then
                helpState.targetTextZoom = math.min(4.0, helpState.targetTextZoom * zoomFactor)
            elseif delta < 0 then
                helpState.targetTextZoom = math.max(0.4, helpState.targetTextZoom / zoomFactor)
            end
        end
        artGalleryState.lastMouseWheel = mouseWheel
    end

    -- Mouse handling depends on tab
    local rightMouseDown = gfx.mouse_cap & 2 == 2

    if helpState.currentTab == 4 or helpState.currentTab == 5 then
        -- === GALLERY/ABOUT TAB MOUSE CONTROLS ===
        -- Left-click drag = pan
        -- Right-click drag = rotate
        -- Single left-click (no drag) = new art
        -- Double-click = reset

        -- Track click start for drag detection
        if mouseDown and not helpState.wasMouseDown then
            helpState.clickStartX = mx
            helpState.clickStartY = my
            helpState.wasDrag = false
        end

        -- Left-click drag = pan
        if mouseDown and not artGalleryState.isDragging then
            artGalleryState.isDragging = true
            artGalleryState.dragStartX = mx
            artGalleryState.dragStartY = my
            artGalleryState.dragStartPanX = artGalleryState.targetPanX
            artGalleryState.dragStartPanY = artGalleryState.targetPanY
        elseif mouseDown and artGalleryState.isDragging then
            local dx = mx - artGalleryState.dragStartX
            local dy = my - artGalleryState.dragStartY
            -- Mark as drag if moved more than 5 pixels
            if math.abs(dx) > 5 or math.abs(dy) > 5 then
                helpState.wasDrag = true
            end
            artGalleryState.targetPanX = artGalleryState.dragStartPanX + dx
            artGalleryState.targetPanY = artGalleryState.dragStartPanY + dy
        elseif not mouseDown then
            artGalleryState.isDragging = false
        end

        -- Right-click drag = rotate
        if rightMouseDown and not helpState.isRotating then
            helpState.isRotating = true
            helpState.rotateStartX = mx
            helpState.rotateStartY = my
            helpState.rotateStartAngle = helpState.targetRotation
        elseif rightMouseDown and helpState.isRotating then
            -- Rotation based on horizontal mouse movement
            local dx = mx - helpState.rotateStartX
            helpState.targetRotation = helpState.rotateStartAngle + dx * 0.01
        elseif not rightMouseDown then
            helpState.isRotating = false
        end

        -- Middle mouse drag = pan (alternative)
        if middleMouseDown then
            if not artGalleryState.isDragging then
                artGalleryState.isDragging = true
                artGalleryState.dragStartX = mx
                artGalleryState.dragStartY = my
                artGalleryState.dragStartPanX = artGalleryState.targetPanX
                artGalleryState.dragStartPanY = artGalleryState.targetPanY
            else
                artGalleryState.targetPanX = artGalleryState.dragStartPanX + (mx - artGalleryState.dragStartX)
                artGalleryState.targetPanY = artGalleryState.dragStartPanY + (my - artGalleryState.dragStartY)
            end
        end
    else
        -- === NON-GALLERY TABS: text panning ===
        -- Pan with right mouse button or middle mouse button
        if (rightMouseDown or middleMouseDown) and not artGalleryState.isDragging then
            artGalleryState.isDragging = true
            artGalleryState.dragStartX = mx
            artGalleryState.dragStartY = my
            artGalleryState.dragStartPanX = artGalleryState.targetPanX
            artGalleryState.dragStartPanY = artGalleryState.targetPanY
        elseif (rightMouseDown or middleMouseDown) and artGalleryState.isDragging then
            artGalleryState.targetPanX = artGalleryState.dragStartPanX + (mx - artGalleryState.dragStartX)
            artGalleryState.targetPanY = artGalleryState.dragStartPanY + (my - artGalleryState.dragStartY)
        elseif not rightMouseDown and not middleMouseDown then
            artGalleryState.isDragging = false
        end

        -- Left-click text dragging
        local inContentArea = my > PS(50) and my < (h - PS(60))  -- Not in tabs or buttons
        if mouseDown and inContentArea and not helpState.textDragging then
            helpState.textDragging = true
            helpState.textDragStartX = mx
            helpState.textDragStartY = my
            helpState.textDragStartPanX = helpState.targetTextPanX
            helpState.textDragStartPanY = helpState.targetTextPanY
        elseif mouseDown and helpState.textDragging then
            helpState.targetTextPanX = helpState.textDragStartPanX + (mx - helpState.textDragStartX)
            helpState.targetTextPanY = helpState.textDragStartPanY + (my - helpState.textDragStartY)
        elseif not mouseDown then
            helpState.textDragging = false
        end
    end

    -- Smooth interpolation for camera movement
    local smoothing = 0.15
    artGalleryState.zoom = artGalleryState.zoom + (artGalleryState.targetZoom - artGalleryState.zoom) * smoothing
    artGalleryState.panX = artGalleryState.panX + (artGalleryState.targetPanX - artGalleryState.panX) * smoothing
    artGalleryState.panY = artGalleryState.panY + (artGalleryState.targetPanY - artGalleryState.panY) * smoothing
    -- Rotation interpolation
    helpState.rotation = helpState.rotation + (helpState.targetRotation - helpState.rotation) * smoothing

    -- Smooth interpolation for text pan
    helpState.textPanX = helpState.textPanX + (helpState.targetTextPanX - helpState.textPanX) * smoothing
    helpState.textPanY = helpState.textPanY + (helpState.targetTextPanY - helpState.targetTextPanY) * smoothing

    -- Double-click to reset camera (including rotation) - only for Gallery/About tabs
    -- Skip if this was a drag operation (wasDrag flag set when moved > 5 pixels)
    if mouseDown and not artGalleryState.wasMouseDown then
        local now = os.clock()
        if artGalleryState.lastClickTime and now - artGalleryState.lastClickTime < 0.3 then
            -- Double click - reset camera and rotation ONLY if not dragging
            if not helpState.wasDrag and (helpState.currentTab == 4 or helpState.currentTab == 5) then
                artGalleryState.targetZoom = 1.0
                artGalleryState.targetPanX = 0
                artGalleryState.targetPanY = 0
                helpState.targetRotation = 0
            end
        end
        artGalleryState.lastClickTime = now
    end

    -- Apply zoom and pan to get effective center
    local zoom = artGalleryState.zoom
    local panX = artGalleryState.panX
    local panY = artGalleryState.panY

    -- Transform function: applies zoom and pan to coordinates relative to center
    local function transform(x, y)
        local cx, cy = w/2, h/2
        local tx = cx + (x - cx) * zoom + panX
        local ty = cy + (y - cy) * zoom + panY
        return tx, ty
    end

    -- Scaled size with zoom
    local function ZS(val)
        return PS(val) * zoom
    end

    -- STEM colors
    local stemColors = {
        {1.0, 0.4, 0.4},   -- S = Vocals (red)
        {0.4, 0.8, 1.0},   -- T = Drums (blue)
        {0.6, 0.4, 1.0},   -- E = Bass (purple)
        {0.4, 1.0, 0.6},   -- M = Other (green)
        {1.0, 0.7, 0.3},   -- About (orange/gold)
    }

    -- Background for all tabs - pure black/white
    if SETTINGS.darkMode then
        gfx.set(0, 0, 0, 1)  -- Pure black for dark mode
    else
        gfx.set(1, 1, 1, 1)  -- Pure white for light mode
    end
    gfx.rect(0, 0, w, h, 1)

    -- === TAB BAR (uses UI() - does NOT zoom) ===
    local tabY = UI(8)
    local tabH = UI(24)

    -- === GALLERY CONTROLS FADE LOGIC ===
    -- For Gallery tab (4), fade out controls when mouse is not near them
    local controlsOpacity = 1.0
    if helpState.currentTab == 4 then
        -- Define control areas: top bar (tabs + icons) and bottom (back button)
        local topControlArea = UI(45)  -- Height of top controls area
        local bottomControlArea = UI(50)  -- Height of bottom controls area
        local bottomY = h - bottomControlArea

        -- Check if mouse is in control areas
        local mouseInControls = (my < topControlArea) or (my > bottomY)

        -- Set target opacity based on mouse position
        helpState.targetControlsOpacity = mouseInControls and 1.0 or 0.0

        -- Smooth interpolation
        local fadeSpeed = mouseInControls and 0.25 or 0.08  -- Faster fade-in, slower fade-out
        helpState.controlsOpacity = helpState.controlsOpacity + (helpState.targetControlsOpacity - helpState.controlsOpacity) * fadeSpeed

        -- Clamp
        helpState.controlsOpacity = math.max(0, math.min(1, helpState.controlsOpacity))
        controlsOpacity = helpState.controlsOpacity
    end
    local tabs = {T("help_welcome"), T("help_quickstart"), T("help_stems"), T("help_gallery"), T("help_about")}
    local tabWidths = {}
    local totalTabW = 0
    gfx.setfont(1, "Arial", UI(11))
    for i, tab in ipairs(tabs) do
        tabWidths[i] = gfx.measurestr(tab) + UI(20)
        totalTabW = totalTabW + tabWidths[i]
    end
    local tabStartX = (w - totalTabW) / 2
    local tabX = tabStartX
    local tabHovers = {}
    local clickedTab = nil

    for i, tab in ipairs(tabs) do
        local isActive = helpState.currentTab == i
        local hover = mx >= tabX and mx <= tabX + tabWidths[i] and my >= tabY and my <= tabY + tabH
        tabHovers[i] = hover

        -- Tab background (with controlsOpacity for Gallery tab)
        local bgAlpha
        if isActive then
            bgAlpha = 0.8 * controlsOpacity
        elseif hover then
            bgAlpha = 0.4 * controlsOpacity
        else
            bgAlpha = 0.6 * controlsOpacity
        end
        if isActive then
            gfx.set(stemColors[i][1], stemColors[i][2], stemColors[i][3], bgAlpha)
        elseif hover then
            gfx.set(stemColors[i][1], stemColors[i][2], stemColors[i][3], bgAlpha)
        else
            gfx.set(0.3, 0.3, 0.35, bgAlpha)
        end
        gfx.rect(tabX, tabY, tabWidths[i], tabH, 1)

        -- Tab text
        local textAlpha = (isActive and 1 or 0.7) * controlsOpacity
        gfx.set(1, 1, 1, textAlpha)
        local textW = gfx.measurestr(tab)
        gfx.x = tabX + (tabWidths[i] - textW) / 2
        gfx.y = tabY + (tabH - UI(11)) / 2
        gfx.drawstr(tab)

        -- Check click (only if controls are visible enough)
        if hover and mouseDown and not helpState.wasMouseDown and controlsOpacity > 0.3 then
            clickedTab = i
        end

        tabX = tabX + tabWidths[i]
    end

    -- === THEME TOGGLE (top right) - uses UI(), does NOT zoom ===
    local themeSize = UI(24)
    local themeX = w - themeSize - UI(10)
    local themeY = UI(6)
    local themeHover = mx >= themeX and mx <= themeX + themeSize and my >= themeY and my <= themeY + themeSize

    if SETTINGS.darkMode then
        gfx.set(0.8, 0.8, 0.5, (themeHover and 1 or 0.7) * controlsOpacity)
        gfx.circle(themeX + themeSize/2, themeY + themeSize/2, themeSize/2 - 3, 1, 1)
        gfx.set(0.12, 0.12, 0.14, controlsOpacity)
        gfx.circle(themeX + themeSize/2 + 4, themeY + themeSize/2 - 3, themeSize/2 - 5, 1, 1)
    else
        gfx.set(1.0, 0.8, 0.2, (themeHover and 1 or 0.85) * controlsOpacity)
        gfx.circle(themeX + themeSize/2, themeY + themeSize/2, themeSize/3, 1, 1)
        for i = 0, 7 do
            local angle = i * math.pi / 4
            local x1 = themeX + themeSize/2 + math.cos(angle) * (themeSize/3 + 2)
            local y1 = themeY + themeSize/2 + math.sin(angle) * (themeSize/3 + 2)
            local x2 = themeX + themeSize/2 + math.cos(angle) * (themeSize/2 - 1)
            local y2 = themeY + themeSize/2 + math.sin(angle) * (themeSize/2 - 1)
            gfx.line(x1, y1, x2, y2)
        end
    end

    -- Theme click handling and tooltip
    if themeHover and controlsOpacity > 0.3 then
        tooltipText = SETTINGS.darkMode and T("switch_light") or T("switch_dark")
        tooltipX, tooltipY = mx + UI(10), my + UI(15)
        if mouseDown and not helpState.wasMouseDown then
            SETTINGS.darkMode = not SETTINGS.darkMode
            updateTheme()
            saveSettings()
        end
    end

    -- === LANGUAGE TOGGLE (next to theme) - uses UI(), does NOT zoom ===
    local langCode = string.upper(SETTINGS.language or "EN")
    gfx.setfont(1, "Arial", UI(12), string.byte('b'))
    local langW = gfx.measurestr(langCode)
    local langX = themeX - langW - UI(12)
    local langY = themeY + UI(5)
    local langHover = mx >= langX - UI(4) and mx <= langX + langW + UI(4) and my >= langY - UI(3) and my <= langY + UI(16)

    -- Draw language badge background
    if langHover and controlsOpacity > 0.3 then
        gfx.set(0.3, 0.4, 0.6, 0.5 * controlsOpacity)
        gfx.rect(langX - UI(4), langY - UI(2), langW + UI(8), UI(18), 1)
    end
    gfx.set(0.5, 0.7, 1.0, (langHover and 1 or 0.7) * controlsOpacity)
    gfx.x = langX
    gfx.y = langY
    gfx.drawstr(langCode)

    -- Language tooltip
    if langHover and controlsOpacity > 0.3 then
        tooltipText = T("tooltip_change_language")
        tooltipX, tooltipY = mx + UI(10), my + UI(15)
    end

    if langHover and mouseDown and not helpState.wasMouseDown and controlsOpacity > 0.3 then
        local langs = {"en", "nl", "de"}
        local currentIdx = 1
        for i, l in ipairs(langs) do
            if l == SETTINGS.language then currentIdx = i break end
        end
        local nextIdx = (currentIdx % #langs) + 1
        setLanguage(langs[nextIdx])
        saveSettings()
    end

    -- === FX TOGGLE (below theme icon) - uses UI(), does NOT zoom ===
    local fxSize = UI(20)
    local fxX = themeX + (themeSize - fxSize) / 2  -- Center under theme icon
    local fxY = themeY + themeSize + UI(4)
    local fxHover = mx >= fxX - UI(2) and mx <= fxX + fxSize + UI(2) and my >= fxY - UI(2) and my <= fxY + fxSize + UI(2)

    -- Draw FX icon (stylized "FX" text or sparkle icon)
    local fxAlpha = (fxHover and 1 or 0.7) * controlsOpacity
    if SETTINGS.visualFX then
        -- FX enabled: bright colored
        gfx.set(0.4, 0.9, 0.5, fxAlpha)  -- Green when on
    else
        -- FX disabled: dim/grey
        gfx.set(0.5, 0.5, 0.5, fxAlpha * 0.6)
    end

    -- Draw "FX" text
    gfx.setfont(1, "Arial", UI(11), string.byte('b'))
    local fxText = "FX"
    local fxTextW = gfx.measurestr(fxText)
    gfx.x = fxX + (fxSize - fxTextW) / 2
    gfx.y = fxY + UI(2)
    gfx.drawstr(fxText)

    -- Draw sparkle/star decorations when enabled
    if SETTINGS.visualFX then
        gfx.set(1, 1, 0.5, fxAlpha * 0.8)  -- Yellow sparkles
        -- Small stars around FX
        local starSize = UI(2)
        gfx.circle(fxX - UI(2), fxY + UI(3), starSize, 1, 1)
        gfx.circle(fxX + fxSize + UI(1), fxY + fxSize - UI(3), starSize, 1, 1)
    else
        -- Draw strikethrough when disabled
        gfx.set(0.8, 0.3, 0.3, fxAlpha)
        gfx.line(fxX - UI(2), fxY + fxSize / 2, fxX + fxSize + UI(2), fxY + fxSize / 2)
    end

    -- FX tooltip
    if fxHover and controlsOpacity > 0.3 then
        tooltipText = SETTINGS.visualFX and T("fx_disable") or T("fx_enable")
        tooltipX, tooltipY = mx + UI(10), my + UI(15)
    end

    -- FX click handling
    if fxHover and mouseDown and not helpState.wasMouseDown and controlsOpacity > 0.3 then
        SETTINGS.visualFX = not SETTINGS.visualFX
        saveSettings()
    end

    -- Content area starts below tabs
    local contentY = tabY + tabH + UI(10)
    local contentH = h - contentY - UI(40)

    -- Apply text pan offset for non-gallery tabs
    local textOffsetX = 0
    local textOffsetY = 0
    if helpState.currentTab ~= 4 then
        textOffsetX = helpState.textPanX
        textOffsetY = helpState.textPanY
        -- Apply Y offset directly to content area for text tabs
        contentY = contentY + textOffsetY
    end

    -- === TAB CONTENT ===
    if helpState.currentTab == 4 then
        -- ART GALLERY TAB - Fullscreen procedural art (below tabs)

        -- Tab area height to keep tabs visible
        local tabAreaH = UI(40)

        -- Define art display area (below tabs)
        local artX = 0
        local artY = tabAreaH
        local artW = w
        local artH = h - tabAreaH

        -- Apply zoom and pan to art area
        local zoomedW = artW * zoom
        local zoomedH = artH * zoom
        local zoomedX = artX - (zoomedW - artW) / 2 + panX
        local zoomedY = artY - (zoomedH - artH) / 2 + panY

        -- Draw the procedural art (fullscreen, no separate background) with rotation
        drawProceduralArt(zoomedX, zoomedY, zoomedW, zoomedH, time, helpState.rotation, true)

        -- Show "FX OFF" indicator when visual effects are disabled
        if not SETTINGS.visualFX then
            gfx.setfont(1, "Arial", UI(14))
            gfx.set(THEME.textDim[1], THEME.textDim[2], THEME.textDim[3], 0.3)
            local offText = "Visual FX Off - Click FX to enable"
            local offW = gfx.measurestr(offText)
            gfx.x = (w - offW) / 2
            gfx.y = h / 2
            gfx.drawstr(offText)
        end

        -- Single click (no drag) generates new art - detect on mouse RELEASE
        if not mouseDown and helpState.wasMouseDown and not helpState.wasDrag then
            -- Only if not clicking on tabs or close button
            local tabAreaBottom = UI(40)
            local closeBtnTop = h - UI(50)
            if helpState.clickStartY > tabAreaBottom and helpState.clickStartY < closeBtnTop then
                generateNewArt()
            end
        end

    -- END OF NEW PROCEDURAL ART CODE - skip old hardcoded art
    if false then
        -- Old hardcoded art code below (disabled)
        local prismX, prismY = w/2, h/2
        local prismSize = PS(80)

        -- Incoming white beam (animated)
        local beamPulse = 0.7 + math.sin(time * 3) * 0.3
        gfx.set(1, 1, 1, beamPulse)
        for i = -2, 2 do
            gfx.line(PS(50), prismY + i, prismX - prismSize/2, prismY + i)
        end

        -- Draw prism (triangle)
        gfx.set(0.3, 0.3, 0.4, 0.8)
        local p1x, p1y = prismX - prismSize/2, prismY + prismSize/2
        local p2x, p2y = prismX + prismSize/2, prismY + prismSize/2
        local p3x, p3y = prismX, prismY - prismSize/2
        -- Fill prism
        for y = p3y, p1y do
            local progress = (y - p3y) / (p1y - p3y)
            local halfWidth = progress * prismSize / 2
            gfx.line(prismX - halfWidth, y, prismX + halfWidth, y)
        end
        -- Prism outline
        gfx.set(0.5, 0.5, 0.6, 1)
        gfx.line(p1x, p1y, p2x, p2y)
        gfx.line(p2x, p2y, p3x, p3y)
        gfx.line(p3x, p3y, p1x, p1y)

        -- Outgoing colored beams (spreading)
        local beamStartX = prismX + prismSize/2
        local beamEndX = w - PS(50)
        for i, color in ipairs(stemColors) do
            local angle = (i - 2.5) * 0.15
            local waveOffset = math.sin(time * 4 + i) * PS(5)
            local alpha = 0.6 + math.sin(time * 3 + i * 0.5) * 0.4

            gfx.set(color[1], color[2], color[3], alpha)
            local endY = prismY + (beamEndX - beamStartX) * math.tan(angle) + waveOffset
            for j = -2, 2 do
                gfx.line(beamStartX, prismY + j, beamEndX, endY + j)
            end

            -- Stem label at end
            gfx.setfont(1, "Arial", PS(14), string.byte('b'))
            local labels = {"V", "D", "B", "O"}
            local lw = gfx.measurestr(labels[i])
            gfx.x = beamEndX + PS(10)
            gfx.y = endY - PS(7)
            gfx.drawstr(labels[i])
        end

    elseif artGalleryState.currentArt == 2 then
        -- === NEURAL SEPARATION ===
        -- Neural network nodes firing and processing

        local layers = {3, 6, 8, 6, 4}  -- neurons per layer
        local layerSpacing = (w - PS(150)) / (#layers - 1)
        local nodes = {}

        -- Create and draw nodes
        for l, count in ipairs(layers) do
            nodes[l] = {}
            local layerX = PS(75) + (l - 1) * layerSpacing
            local startY = centerY - (count - 1) * PS(25)

            for n = 1, count do
                local nodeY = startY + (n - 1) * PS(50)
                nodes[l][n] = {x = layerX, y = nodeY}

                -- Node pulse animation
                local pulsePhase = time * 3 + l * 0.5 + n * 0.3
                local pulse = 0.5 + math.sin(pulsePhase) * 0.5
                local radius = PS(12) + pulse * PS(5)

                -- Glow effect
                if l == #layers then
                    local color = stemColors[n] or stemColors[1]
                    gfx.set(color[1], color[2], color[3], 0.3 * pulse)
                    gfx.circle(layerX, nodeY, radius + PS(8), 1, 1)
                    gfx.set(color[1], color[2], color[3], 0.8)
                else
                    gfx.set(0.5, 0.6, 0.8, 0.3 * pulse)
                    gfx.circle(layerX, nodeY, radius + PS(5), 1, 1)
                    gfx.set(0.4, 0.5, 0.7, 0.8)
                end
                gfx.circle(layerX, nodeY, radius, 1, 1)

                -- Draw connections to previous layer
                if l > 1 then
                    for pn = 1, #nodes[l-1] do
                        local prevNode = nodes[l-1][pn]
                        local connPulse = math.sin(time * 5 + l + n + pn) * 0.5 + 0.5
                        gfx.set(0.3, 0.4, 0.6, 0.15 + connPulse * 0.2)
                        gfx.line(prevNode.x, prevNode.y, layerX, nodeY)
                    end
                end
            end
        end

        -- Draw labels for output
        local labels = {"Vocals", "Drums", "Bass", "Other"}
        gfx.setfont(1, "Arial", PS(11))
        for i = 1, 4 do
            gfx.set(stemColors[i][1], stemColors[i][2], stemColors[i][3], 1)
            local node = nodes[#layers][i]
            gfx.x = node.x + PS(20)
            gfx.y = node.y - PS(5)
            gfx.drawstr(labels[i])
        end

    elseif artGalleryState.currentArt == 3 then
        -- === THE FOUR ELEMENTS ===
        -- Four orbiting elemental spheres

        local orbitRadius = PS(120)
        local sphereRadius = PS(40)

        -- Central mix sphere
        local centralPulse = 0.8 + math.sin(time * 2) * 0.2
        gfx.set(0.9, 0.9, 0.9, centralPulse * 0.5)
        gfx.circle(centerX, centerY, PS(50), 1, 1)
        gfx.set(1, 1, 1, 0.8)
        gfx.circle(centerX, centerY, PS(45), 0, 1)
        gfx.setfont(1, "Arial", PS(12), string.byte('b'))
        gfx.set(0.3, 0.3, 0.3, 1)
        local mixW = gfx.measurestr("MIX")
        gfx.x = centerX - mixW/2
        gfx.y = centerY - PS(6)
        gfx.drawstr("MIX")

        -- Four orbiting elements
        local elements = {"Vocals", "Drums", "Bass", "Other"}
        local symbols = {"~", "#", "=", "*"}
        for i = 1, 4 do
            local angle = time * 0.5 + (i - 1) * math.pi / 2
            local wobble = math.sin(time * 3 + i) * PS(10)
            local ex = centerX + math.cos(angle) * (orbitRadius + wobble)
            local ey = centerY + math.sin(angle) * (orbitRadius + wobble)

            -- Element glow
            gfx.set(stemColors[i][1], stemColors[i][2], stemColors[i][3], 0.3)
            gfx.circle(ex, ey, sphereRadius + PS(15), 1, 1)

            -- Element sphere
            gfx.set(stemColors[i][1], stemColors[i][2], stemColors[i][3], 0.9)
            gfx.circle(ex, ey, sphereRadius, 1, 1)

            -- Element symbol
            gfx.set(1, 1, 1, 1)
            gfx.setfont(1, "Arial", PS(24), string.byte('b'))
            local symW = gfx.measurestr(symbols[i])
            gfx.x = ex - symW/2
            gfx.y = ey - PS(10)
            gfx.drawstr(symbols[i])

            -- Element name
            gfx.setfont(1, "Arial", PS(10))
            local nameW = gfx.measurestr(elements[i])
            gfx.x = ex - nameW/2
            gfx.y = ey + PS(12)
            gfx.drawstr(elements[i])

            -- Connection line to center
            gfx.set(stemColors[i][1], stemColors[i][2], stemColors[i][3], 0.3)
            gfx.line(centerX, centerY, ex, ey)
        end

    elseif artGalleryState.currentArt == 4 then
        -- === WAVEFORM SURGERY ===
        -- Scalpel cutting through waveform, separating colors

        local waveW = w - PS(100)
        local waveH = PS(150)
        local waveStartX = PS(50)
        local waveY = centerY

        -- Draw mixed waveform (before cut)
        local cutX = waveStartX + (time * 50) % waveW

        -- Before cut - mixed gray
        for x = waveStartX, math.min(cutX, waveStartX + waveW) do
            local t = (x - waveStartX) / waveW * math.pi * 8
            local amp = waveH/2 * (0.5 + math.sin(t * 0.5) * 0.3)
            local y = waveY + math.sin(t + time * 2) * amp
            gfx.set(0.5, 0.5, 0.5, 0.6)
            gfx.line(x, waveY, x, y)
        end

        -- After cut - separated colored stems
        if cutX > waveStartX then
            for i, color in ipairs(stemColors) do
                local offset = (i - 2.5) * PS(35)
                gfx.set(color[1], color[2], color[3], 0.7)
                for x = cutX, waveStartX + waveW do
                    local t = (x - waveStartX) / waveW * math.pi * 8
                    local amp = waveH/4 * (0.3 + math.sin(t * 0.3 + i) * 0.2)
                    local separation = math.min(1, (x - cutX) / PS(100))
                    local y = waveY + offset * separation + math.sin(t + time * 2 + i) * amp
                    gfx.line(x, waveY + offset * separation, x, y)
                end
            end
        end

        -- Draw scalpel
        local scalpelY = waveY - waveH/2 - PS(30) + math.sin(time * 8) * PS(5)
        gfx.set(0.8, 0.8, 0.9, 1)
        -- Blade
        gfx.line(cutX - PS(5), scalpelY, cutX, scalpelY + PS(60))
        gfx.line(cutX, scalpelY + PS(60), cutX + PS(5), scalpelY)
        -- Handle
        gfx.set(0.4, 0.3, 0.2, 1)
        gfx.rect(cutX - PS(8), scalpelY - PS(25), PS(16), PS(25), 1)

    elseif artGalleryState.currentArt == 5 then
        -- === THE SOUND GALAXY ===
        -- Stars orbiting a central sun, particles everywhere

        -- Draw background stars
        math.randomseed(42)  -- Fixed seed for consistent stars
        for i = 1, 100 do
            local sx = math.random() * w
            local sy = math.random() * h
            local twinkle = 0.3 + math.sin(time * 5 + i) * 0.3
            gfx.set(1, 1, 1, twinkle)
            gfx.circle(sx, sy, PS(1), 1, 1)
        end

        -- Central sun (the mix)
        local sunPulse = 1 + math.sin(time * 2) * 0.1
        -- Sun glow
        for r = PS(60), PS(30), -PS(5) do
            local alpha = (PS(60) - r) / PS(30) * 0.3
            gfx.set(1, 0.9, 0.5, alpha)
            gfx.circle(centerX, centerY, r * sunPulse, 1, 1)
        end
        gfx.set(1, 0.95, 0.7, 1)
        gfx.circle(centerX, centerY, PS(30) * sunPulse, 1, 1)

        -- Orbiting stem planets
        local orbits = {PS(100), PS(150), PS(200), PS(250)}
        local speeds = {0.8, 0.6, 0.4, 0.3}
        local labels = {"V", "D", "B", "O"}
        for i = 1, 4 do
            local angle = time * speeds[i] + (i - 1) * math.pi / 2
            local px = centerX + math.cos(angle) * orbits[i]
            local py = centerY + math.sin(angle) * orbits[i] * 0.6  -- Elliptical

            -- Orbit path
            gfx.set(stemColors[i][1], stemColors[i][2], stemColors[i][3], 0.15)
            for a = 0, math.pi * 2, 0.1 do
                local ox = centerX + math.cos(a) * orbits[i]
                local oy = centerY + math.sin(a) * orbits[i] * 0.6
                gfx.circle(ox, oy, PS(1), 1, 1)
            end

            -- Planet glow
            gfx.set(stemColors[i][1], stemColors[i][2], stemColors[i][3], 0.4)
            gfx.circle(px, py, PS(25), 1, 1)
            -- Planet
            gfx.set(stemColors[i][1], stemColors[i][2], stemColors[i][3], 1)
            gfx.circle(px, py, PS(18), 1, 1)
            -- Label
            gfx.set(1, 1, 1, 1)
            gfx.setfont(1, "Arial", PS(14), string.byte('b'))
            local lw = gfx.measurestr(labels[i])
            gfx.x = px - lw/2
            gfx.y = py - PS(6)
            gfx.drawstr(labels[i])
        end

    elseif artGalleryState.currentArt == 6 then
        -- === FREQUENCY WATERFALL ===
        -- Cascading frequency bands falling and separating

        local bandH = PS(30)
        local bandW = w - PS(100)
        local startX = PS(50)
        local labels = {"HIGH - Vocals", "MID-HIGH - Drums", "MID-LOW - Bass", "LOW - Other"}

        for i = 1, 4 do
            local baseY = PS(80) + (i - 1) * PS(100)
            local flowOffset = (time * 100 + i * 50) % bandW

            -- Draw flowing frequency band
            for x = 0, bandW do
                local xPos = startX + x
                local wavePhase = x / bandW * math.pi * 6 + time * 3
                local amp = bandH/2 * (0.5 + math.sin(wavePhase + i) * 0.3)
                local alpha = 0.3 + math.sin(wavePhase) * 0.2

                -- Waterfall effect - brighter at "current" position
                local distFromFlow = math.abs(x - flowOffset)
                if distFromFlow < PS(50) then
                    alpha = alpha + (1 - distFromFlow / PS(50)) * 0.5
                end

                gfx.set(stemColors[i][1], stemColors[i][2], stemColors[i][3], alpha)
                gfx.line(xPos, baseY - amp, xPos, baseY + amp)
            end

            -- Frequency label
            gfx.set(stemColors[i][1], stemColors[i][2], stemColors[i][3], 1)
            gfx.setfont(1, "Arial", PS(11), string.byte('b'))
            gfx.x = startX + bandW + PS(10)
            gfx.y = baseY - PS(5)
            gfx.drawstr(labels[i])

            -- Droplets falling
            for d = 1, 5 do
                local dropX = startX + ((time * 80 + d * 100 + i * 30) % bandW)
                local dropY = baseY + (time * 50 + d * 20) % PS(80)
                local dropAlpha = 1 - (dropY - baseY) / PS(80)
                gfx.set(stemColors[i][1], stemColors[i][2], stemColors[i][3], dropAlpha * 0.6)
                gfx.circle(dropX, dropY, PS(3), 1, 1)
            end
        end

    elseif artGalleryState.currentArt == 7 then
        -- === THE DNA HELIX ===
        -- Double helix unraveling into 4 strands

        local helixLength = w - PS(150)
        local helixStartX = PS(75)
        local helixRadius = PS(40)

        -- Draw the double helix splitting into 4
        for x = 0, helixLength do
            local progress = x / helixLength
            local phase = x / PS(30) + time * 2
            local splitFactor = math.min(1, progress * 2)  -- Start splitting at 50%

            if progress < 0.5 then
                -- Before split - double helix
                local y1 = centerY + math.sin(phase) * helixRadius
                local y2 = centerY - math.sin(phase) * helixRadius
                local alpha = 0.5 + math.cos(phase) * 0.3

                gfx.set(0.8, 0.8, 0.8, alpha)
                gfx.circle(helixStartX + x, y1, PS(4), 1, 1)
                gfx.circle(helixStartX + x, y2, PS(4), 1, 1)

                -- Connection bars
                if math.floor(phase) % 2 == 0 then
                    gfx.set(0.6, 0.6, 0.6, 0.4)
                    gfx.line(helixStartX + x, y1, helixStartX + x, y2)
                end
            else
                -- After split - 4 strands separating
                for i = 1, 4 do
                    local separation = (progress - 0.5) * 2  -- 0 to 1
                    local targetOffset = (i - 2.5) * PS(50)
                    local yOffset = targetOffset * separation
                    local y = centerY + yOffset + math.sin(phase + i * 0.5) * helixRadius * (1 - separation * 0.5)
                    local alpha = 0.5 + math.cos(phase + i) * 0.3

                    gfx.set(stemColors[i][1], stemColors[i][2], stemColors[i][3], alpha)
                    gfx.circle(helixStartX + x, y, PS(4), 1, 1)
                end
            end
        end

        -- Labels at the end
        local labels = {"Vocals", "Drums", "Bass", "Other"}
        gfx.setfont(1, "Arial", PS(12), string.byte('b'))
        for i = 1, 4 do
            local yOffset = (i - 2.5) * PS(50)
            gfx.set(stemColors[i][1], stemColors[i][2], stemColors[i][3], 1)
            gfx.x = helixStartX + helixLength + PS(15)
            gfx.y = centerY + yOffset - PS(6)
            gfx.drawstr(labels[i])
        end

    elseif artGalleryState.currentArt == 8 then
        -- === PARTICLE STORM ===
        -- Thousands of particles sorting by color

        -- Particle system with sorting animation
        math.randomseed(12345)
        local numParticles = 200

        for p = 1, numParticles do
            local colorIdx = ((p - 1) % 4) + 1
            local baseX = math.random() * w
            local baseY = math.random() * h

            -- Calculate target position (sorted by stem)
            local targetX = PS(100) + (colorIdx - 1) * (w - PS(200)) / 3
            local targetY = PS(100) + math.random() * (h - PS(250))

            -- Interpolate based on time (cycling)
            local sortPhase = (math.sin(time * 0.5) + 1) / 2  -- 0 to 1 cycling
            local px = baseX + (targetX - baseX) * sortPhase
            local py = baseY + (targetY - baseY) * sortPhase

            -- Add some turbulence
            px = px + math.sin(time * 3 + p) * PS(10) * (1 - sortPhase)
            py = py + math.cos(time * 3 + p * 0.7) * PS(10) * (1 - sortPhase)

            -- Draw particle
            local alpha = 0.4 + math.sin(time * 5 + p) * 0.2
            gfx.set(stemColors[colorIdx][1], stemColors[colorIdx][2], stemColors[colorIdx][3], alpha)
            gfx.circle(px, py, PS(3), 1, 1)
        end

        -- Labels when sorted
        local labels = {"Vocals", "Drums", "Bass", "Other"}
        gfx.setfont(1, "Arial", PS(14), string.byte('b'))
        for i = 1, 4 do
            local labelX = PS(100) + (i - 1) * (w - PS(200)) / 3
            gfx.set(stemColors[i][1], stemColors[i][2], stemColors[i][3], 1)
            local lw = gfx.measurestr(labels[i])
            gfx.x = labelX - lw/2
            gfx.y = h - PS(100)
            gfx.drawstr(labels[i])
        end

    elseif artGalleryState.currentArt == 9 then
        -- === THE MIXING DESK ===
        -- Four animated faders rising from darkness

        local faderW = PS(60)
        local faderH = PS(250)
        local faderSpacing = (w - PS(200) - faderW * 4) / 3
        local startX = PS(100)
        local baseY = h - PS(120)

        local labels = {"VOC", "DRM", "BAS", "OTH"}
        local fullLabels = {"Vocals", "Drums", "Bass", "Other"}

        for i = 1, 4 do
            local faderX = startX + (i - 1) * (faderW + faderSpacing)

            -- Fader channel strip background
            gfx.set(0.15, 0.15, 0.18, 1)
            gfx.rect(faderX - PS(10), baseY - faderH - PS(40), faderW + PS(20), faderH + PS(80), 1)

            -- Fader track
            gfx.set(0.1, 0.1, 0.12, 1)
            gfx.rect(faderX + faderW/2 - PS(4), baseY - faderH, PS(8), faderH, 1)

            -- Animated fader level
            local level = 0.3 + math.sin(time * 2 + i * 0.8) * 0.3 + math.sin(time * 5 + i * 1.5) * 0.15
            local faderY = baseY - level * faderH

            -- Level meter (behind fader)
            local meterLevel = level + math.sin(time * 8 + i) * 0.1
            for y = baseY, baseY - meterLevel * faderH, -PS(3) do
                local meterProgress = (baseY - y) / faderH
                local r = stemColors[i][1] * (0.3 + meterProgress * 0.7)
                local g = stemColors[i][2] * (0.3 + meterProgress * 0.7)
                local b = stemColors[i][3] * (0.3 + meterProgress * 0.7)
                gfx.set(r, g, b, 0.8)
                gfx.rect(faderX + PS(5), y, faderW - PS(10), PS(2), 1)
            end

            -- Fader knob
            gfx.set(stemColors[i][1], stemColors[i][2], stemColors[i][3], 1)
            gfx.rect(faderX, faderY - PS(10), faderW, PS(20), 1)
            gfx.set(1, 1, 1, 0.5)
            gfx.line(faderX + PS(5), faderY, faderX + faderW - PS(5), faderY)

            -- Channel label
            gfx.set(stemColors[i][1], stemColors[i][2], stemColors[i][3], 1)
            gfx.setfont(1, "Arial", PS(12), string.byte('b'))
            local labelW = gfx.measurestr(labels[i])
            gfx.x = faderX + faderW/2 - labelW/2
            gfx.y = baseY + PS(15)
            gfx.drawstr(labels[i])
        end

    elseif artGalleryState.currentArt == 10 then
        -- === STEM CONSTELLATION ===
        -- Stars connected forming STEM pattern

        -- Draw constellation background
        math.randomseed(999)
        for i = 1, 80 do
            local sx = math.random() * w
            local sy = math.random() * h
            local twinkle = 0.2 + math.sin(time * 4 + i * 0.5) * 0.2
            gfx.set(1, 1, 1, twinkle)
            gfx.circle(sx, sy, PS(1), 1, 1)
        end

        -- STEM constellation points
        local constellations = {
            -- S shape
            {points = {{0.15, 0.3}, {0.25, 0.25}, {0.15, 0.4}, {0.25, 0.55}, {0.15, 0.5}}, color = 1},
            -- T shape
            {points = {{0.35, 0.25}, {0.45, 0.25}, {0.55, 0.25}, {0.45, 0.35}, {0.45, 0.55}}, color = 2},
            -- E shape
            {points = {{0.65, 0.25}, {0.75, 0.25}, {0.65, 0.4}, {0.72, 0.4}, {0.65, 0.55}, {0.75, 0.55}}, color = 3},
            -- M shape
            {points = {{0.8, 0.55}, {0.8, 0.25}, {0.87, 0.4}, {0.94, 0.25}, {0.94, 0.55}}, color = 4},
        }

        for _, const in ipairs(constellations) do
            local color = stemColors[const.color]
            local points = const.points

            -- Draw connections
            gfx.set(color[1], color[2], color[3], 0.4)
            for i = 1, #points - 1 do
                local x1 = points[i][1] * w
                local y1 = points[i][2] * h
                local x2 = points[i+1][1] * w
                local y2 = points[i+1][2] * h
                gfx.line(x1, y1, x2, y2)
            end

            -- Draw stars with pulse
            for i, point in ipairs(points) do
                local px = point[1] * w
                local py = point[2] * h
                local pulse = 1 + math.sin(time * 3 + i + const.color) * 0.3

                -- Star glow
                gfx.set(color[1], color[2], color[3], 0.3 * pulse)
                gfx.circle(px, py, PS(12) * pulse, 1, 1)

                -- Star core
                gfx.set(color[1], color[2], color[3], 0.9)
                gfx.circle(px, py, PS(5) * pulse, 1, 1)

                -- Star center
                gfx.set(1, 1, 1, 1)
                gfx.circle(px, py, PS(2), 1, 1)
            end
        end

        -- Legend
        local labels = {"Vocals", "Drums", "Bass", "Other"}
        gfx.setfont(1, "Arial", PS(10))
        for i = 1, 4 do
            gfx.set(stemColors[i][1], stemColors[i][2], stemColors[i][3], 1)
            gfx.circle(PS(30), h - PS(90) + (i-1) * PS(18), PS(5), 1, 1)
            gfx.x = PS(45)
            gfx.y = h - PS(95) + (i-1) * PS(18)
            gfx.drawstr(labels[i])
        end

    elseif artGalleryState.currentArt == 11 then
        -- === HARMONIC MANDALA ===
        -- Rotating sacred geometry with stem colors
        local rings = 8
        local segments = 12
        for ring = 1, rings do
            local ringRadius = (ring / rings) * math.min(w, h) * 0.4
            local col = stemColors[(ring % 4) + 1]
            local rotDir = ring % 2 == 0 and 1 or -1
            for seg = 0, segments - 1 do
                local angle = (seg / segments) * math.pi * 2 + time * 0.5 * rotDir + ring * 0.2
                local px, py = transform(centerX + math.cos(angle) * ringRadius, centerY + math.sin(angle) * ringRadius)
                -- Draw petal shape
                local petalSize = PS(15 + ring * 3)
                gfx.set(col[1], col[2], col[3], 0.3 + ring * 0.05)
                for inner = 0, petalSize, PS(2) do
                    local innerAngle = angle + math.sin(time * 2 + ring) * 0.2
                    local ix = px + math.cos(innerAngle) * inner
                    local iy = py + math.sin(innerAngle) * inner
                    gfx.circle(ix, iy, PS(3), 1, 1)
                end
            end
        end
        -- Center jewel
        for r = PS(40), PS(5), -PS(5) do
            local pulse = 1 + math.sin(time * 3) * 0.2
            gfx.set(1, 0.9, 0.7, 0.3 * pulse)
            local cx, cy = transform(centerX, centerY)
            gfx.circle(cx, cy, r * pulse, 1, 1)
        end

    elseif artGalleryState.currentArt == 12 then
        -- === THE STEM LOTUS ===
        -- Petals unfolding from center
        local numPetals = 16
        for layer = 3, 1, -1 do
            for p = 0, numPetals - 1 do
                local baseAngle = (p / numPetals) * math.pi * 2
                local openAmount = 0.5 + math.sin(time * 0.8 + layer * 0.5) * 0.3
                local angle = baseAngle + time * 0.1 * (layer % 2 == 0 and 1 or -1)
                local dist = PS(50 + layer * 40) * openAmount
                local col = stemColors[(p % 4) + 1]

                local px, py = transform(centerX + math.cos(angle) * dist, centerY + math.sin(angle) * dist * 0.7)
                local petalW = PS(30 + layer * 10)
                local petalH = PS(50 + layer * 15)

                gfx.set(col[1], col[2], col[3], 0.2 + layer * 0.15)
                -- Draw petal as ellipse points
                for t = 0, math.pi, 0.1 do
                    local ew = math.sin(t) * petalW
                    local eh = math.cos(t) * petalH * openAmount
                    local rx = px + math.cos(angle) * eh - math.sin(angle) * ew
                    local ry = py + math.sin(angle) * eh + math.cos(angle) * ew * 0.7
                    gfx.circle(rx, ry, PS(2), 1, 1)
                end
            end
        end
        -- Glowing center
        local cx, cy = transform(centerX, centerY)
        for r = PS(25), PS(5), -PS(3) do
            gfx.set(1, 0.95, 0.8, 0.15)
            gfx.circle(cx, cy, r * (1 + math.sin(time * 4) * 0.1), 1, 1)
        end

    elseif artGalleryState.currentArt == 13 then
        -- === AURORA BOREALIS ===
        -- Wavy curtains of colored light
        for layer = 1, 4 do
            local col = stemColors[layer]
            local yOffset = (layer - 2.5) * PS(60)
            for x = 0, w, PS(3) do
                local wave1 = math.sin((x / w) * 4 + time * 1.5 + layer) * PS(80)
                local wave2 = math.sin((x / w) * 7 - time * 0.8 + layer * 2) * PS(40)
                local wave3 = math.sin((x / w) * 2 + time * 0.5) * PS(30)
                local baseY = centerY + yOffset + wave1 + wave2 + wave3

                -- Vertical curtain effect
                for dy = 0, PS(150), PS(3) do
                    local alpha = (1 - dy / PS(150)) * 0.4
                    local shimmer = math.sin(time * 8 + x * 0.1 + dy * 0.05) * 0.1
                    gfx.set(col[1], col[2], col[3], alpha + shimmer)
                    gfx.rect(x, baseY + dy, PS(2), PS(2), 1)
                end
            end
        end
        -- Stars in background
        math.randomseed(777)
        for i = 1, 50 do
            local sx, sy = math.random() * w, math.random() * h * 0.6
            local twinkle = 0.3 + math.sin(time * 5 + i) * 0.2
            gfx.set(1, 1, 1, twinkle)
            gfx.circle(sx, sy, PS(1), 1, 1)
        end

    elseif artGalleryState.currentArt == 14 then
        -- === QUANTUM ENTANGLEMENT ===
        -- Four connected particles that move together
        local particles = {}
        for i = 1, 4 do
            local angle = (i - 1) * math.pi / 2 + time * 0.3
            local dist = PS(100) + math.sin(time * 2 + i) * PS(30)
            particles[i] = {
                x = centerX + math.cos(angle) * dist,
                y = centerY + math.sin(angle) * dist,
                col = stemColors[i]
            }
        end
        -- Draw quantum connections (wavy lines between all particles)
        for i = 1, 4 do
            for j = i + 1, 4 do
                local p1, p2 = particles[i], particles[j]
                for t = 0, 1, 0.02 do
                    local wave = math.sin(t * math.pi * 6 + time * 10) * PS(10)
                    local px = p1.x + (p2.x - p1.x) * t
                    local py = p1.y + (p2.y - p1.y) * t + wave
                    local tx, ty = transform(px, py)
                    local blend = t
                    gfx.set(
                        p1.col[1] * (1-blend) + p2.col[1] * blend,
                        p1.col[2] * (1-blend) + p2.col[2] * blend,
                        p1.col[3] * (1-blend) + p2.col[3] * blend,
                        0.4
                    )
                    gfx.circle(tx, ty, PS(2), 1, 1)
                end
            end
        end
        -- Draw particles with glow
        for i, p in ipairs(particles) do
            local px, py = transform(p.x, p.y)
            local pulse = 1 + math.sin(time * 5 + i) * 0.3
            for r = PS(25), PS(8), -PS(3) do
                gfx.set(p.col[1], p.col[2], p.col[3], 0.1 * pulse)
                gfx.circle(px, py, r, 1, 1)
            end
            gfx.set(1, 1, 1, 1)
            gfx.circle(px, py, PS(5), 1, 1)
        end

    elseif artGalleryState.currentArt == 15 then
        -- === THE SPIRAL TOWER ===
        -- Ascending spiral of stem colors
        local spiralLevels = 50
        local rotations = 4
        for level = 0, spiralLevels do
            local t = level / spiralLevels
            local angle = t * rotations * math.pi * 2 + time * 0.5
            local radius = PS(150) * (1 - t * 0.5)
            local yPos = centerY + PS(200) - t * PS(400)
            local col = stemColors[(level % 4) + 1]

            local px, py = transform(centerX + math.cos(angle) * radius, yPos)
            local blockSize = PS(20) * (1 - t * 0.5)

            gfx.set(col[1], col[2], col[3], 0.7 - t * 0.3)
            gfx.rect(px - blockSize/2, py - blockSize/2, blockSize, blockSize, 1)

            -- Connecting line to next
            if level < spiralLevels then
                local nextT = (level + 1) / spiralLevels
                local nextAngle = nextT * rotations * math.pi * 2 + time * 0.5
                local nextRadius = PS(150) * (1 - nextT * 0.5)
                local nextY = centerY + PS(200) - nextT * PS(400)
                local nx, ny = transform(centerX + math.cos(nextAngle) * nextRadius, nextY)
                gfx.set(col[1], col[2], col[3], 0.3)
                gfx.line(px, py, nx, ny)
            end
        end

    elseif artGalleryState.currentArt == 16 then
        -- === OCEAN OF WAVES ===
        -- Layered waves in stem colors
        for layer = 4, 1, -1 do
            local col = stemColors[layer]
            local baseY = centerY + (layer - 2.5) * PS(50)
            local amplitude = PS(40 + layer * 10)
            local frequency = 3 + layer * 0.5
            local speed = 1.5 - layer * 0.2

            -- Draw wave as filled area
            for x = 0, w, PS(2) do
                local waveY = baseY + math.sin((x / w) * frequency * math.pi + time * speed) * amplitude
                waveY = waveY + math.sin((x / w) * frequency * 2 * math.pi - time * speed * 0.7) * amplitude * 0.3

                local depth = h - waveY
                for dy = 0, math.min(depth, PS(200)), PS(3) do
                    local alpha = (1 - dy / PS(200)) * 0.3
                    gfx.set(col[1], col[2], col[3], alpha)
                    gfx.rect(x, waveY + dy, PS(2), PS(2), 1)
                end

                -- Wave crest highlight
                gfx.set(1, 1, 1, 0.3)
                gfx.rect(x, waveY - PS(2), PS(2), PS(3), 1)
            end
        end

    elseif artGalleryState.currentArt == 17 then
        -- === CRYSTALLINE MATRIX ===
        -- Geometric crystal formations
        local crystals = 20
        math.randomseed(42)
        for i = 1, crystals do
            local cx = math.random() * w * 0.8 + w * 0.1
            local cy = math.random() * h * 0.6 + h * 0.2
            local size = PS(20 + math.random() * 40)
            local col = stemColors[(i % 4) + 1]
            local rotation = time * 0.3 + i * 0.5

            local tx, ty = transform(cx, cy)

            -- Draw hexagonal crystal
            local sides = 6
            gfx.set(col[1], col[2], col[3], 0.4)
            local points = {}
            for s = 0, sides - 1 do
                local angle = rotation + (s / sides) * math.pi * 2
                table.insert(points, tx + math.cos(angle) * size)
                table.insert(points, ty + math.sin(angle) * size * 0.7)
            end
            for s = 1, sides do
                local next = (s % sides) + 1
                gfx.line(points[s*2-1], points[s*2], points[next*2-1], points[next*2])
                -- Inner lines to center
                gfx.set(col[1], col[2], col[3], 0.2)
                gfx.line(tx, ty, points[s*2-1], points[s*2])
            end
            -- Crystal core glow
            gfx.set(col[1], col[2], col[3], 0.3 + math.sin(time * 3 + i) * 0.1)
            gfx.circle(tx, ty, size * 0.3, 1, 1)
        end

    elseif artGalleryState.currentArt == 18 then
        -- === THE HEARTBEAT ===
        -- Pulsing heart-shaped waveform
        local pulse = math.abs(math.sin(time * 2))
        local heartScale = PS(100) * (1 + pulse * 0.3)

        -- Draw heart shape for each stem
        for layer = 4, 1, -1 do
            local col = stemColors[layer]
            local layerScale = heartScale * (1 + (layer - 2.5) * 0.1)
            local layerOffset = (layer - 2.5) * PS(5)

            gfx.set(col[1], col[2], col[3], 0.15 + layer * 0.1)
            -- Parametric heart
            for t = 0, math.pi * 2, 0.05 do
                local hx = 16 * math.sin(t)^3
                local hy = -(13 * math.cos(t) - 5 * math.cos(2*t) - 2 * math.cos(3*t) - math.cos(4*t))
                local px, py = transform(centerX + hx * layerScale / 16 + layerOffset, centerY + hy * layerScale / 16)
                gfx.circle(px, py, PS(3 + layer), 1, 1)
            end
        end

        -- ECG-style line across
        gfx.set(1, 0.3, 0.3, 0.8)
        local ecgY = h - PS(100)
        local beatPos = (time * 200) % w
        for x = 0, w, PS(2) do
            local y = ecgY
            local relX = (x - beatPos + w) % w
            if relX < PS(20) then
                y = ecgY - PS(30) * math.sin(relX / PS(20) * math.pi)
            elseif relX < PS(40) then
                y = ecgY + PS(50) * math.sin((relX - PS(20)) / PS(20) * math.pi)
            elseif relX < PS(60) then
                y = ecgY - PS(20) * math.sin((relX - PS(40)) / PS(20) * math.pi)
            end
            gfx.rect(x, y, PS(2), PS(2), 1)
        end

    elseif artGalleryState.currentArt == 19 then
        -- === STEM KALEIDOSCOPE ===
        -- Mirrored, rotating patterns
        local mirrors = 8
        local elements = 15
        for m = 0, mirrors - 1 do
            local mirrorAngle = (m / mirrors) * math.pi * 2
            for e = 1, elements do
                local dist = PS(30 + e * 15)
                local angle = time * 0.5 + e * 0.3 + mirrorAngle
                local col = stemColors[(e % 4) + 1]

                local px = centerX + math.cos(angle) * dist
                local py = centerY + math.sin(angle) * dist
                local tx, ty = transform(px, py)

                local size = PS(5 + e * 2)
                local shape = e % 3

                gfx.set(col[1], col[2], col[3], 0.4)
                if shape == 0 then
                    gfx.circle(tx, ty, size, 1, 1)
                elseif shape == 1 then
                    gfx.rect(tx - size/2, ty - size/2, size, size, 1)
                else
                    -- Triangle
                    for i = 0, 2 do
                        local a1 = angle + (i / 3) * math.pi * 2
                        local a2 = angle + ((i + 1) / 3) * math.pi * 2
                        gfx.line(tx + math.cos(a1) * size, ty + math.sin(a1) * size,
                                 tx + math.cos(a2) * size, ty + math.sin(a2) * size)
                    end
                end
            end
        end
        -- Center gem
        local cx, cy = transform(centerX, centerY)
        for i = 1, 4 do
            gfx.set(stemColors[i][1], stemColors[i][2], stemColors[i][3], 0.5)
            local gemAngle = (i - 1) * math.pi / 2 + time
            gfx.circle(cx + math.cos(gemAngle) * PS(10), cy + math.sin(gemAngle) * PS(10), PS(8), 1, 1)
        end

    elseif artGalleryState.currentArt == 20 then
        -- === DIGITAL RAIN ===
        -- Matrix-style falling code in stem colors
        local columns = math.floor(w / PS(20))
        math.randomseed(123)
        for col = 0, columns do
            local colX = col * PS(20) + PS(10)
            local speed = 50 + math.random() * 100
            local offset = math.random() * 1000
            local stemCol = stemColors[(col % 4) + 1]

            local headY = ((time * speed + offset) % (h + PS(300))) - PS(100)

            -- Draw trail
            for i = 0, 20 do
                local charY = headY - i * PS(18)
                if charY > 0 and charY < h then
                    local alpha = 1 - (i / 20)
                    local char = string.char(48 + ((col * 7 + i * 3 + math.floor(time * 10)) % 74))

                    if i == 0 then
                        gfx.set(1, 1, 1, 1)  -- Bright head
                    else
                        gfx.set(stemCol[1], stemCol[2], stemCol[3], alpha * 0.8)
                    end

                    gfx.setfont(1, "Courier", PS(14))
                    gfx.x = colX
                    gfx.y = charY
                    gfx.drawstr(char)
                end
            end
        end
    end -- end of if false (disabled old art code)

        -- Gallery is now fullscreen with no overlays
        -- The art title is displayed by the procedural art generator itself
        -- Mouse controls: left-click=new art, scroll=zoom, drag=pan, double-click=reset

    elseif helpState.currentTab == 1 then
        -- === WELCOME TAB - FULL WINDOW EXPERIENCE + AUDIO REACTIVE ===

        -- Update audio reactivity
        updateAudioReactivity()
        local audioPeak = audioReactive.smoothPeakMono or 0
        local audioBass = audioReactive.smoothBass or 0
        local audioMid = audioReactive.smoothMid or 0
        local audioHigh = audioReactive.smoothHigh or 0
        local audioBeat = audioReactive.beatDecay or 0

        -- Draw animated background elements FIRST (behind text) - AUDIO REACTIVE
        local bgTime = os.clock() - helpState.startTime
        for i = 1, 4 do
            local angle = bgTime * 0.2 + (i - 1) * math.pi / 2 + audioPeak * 0.3
            local radius = math.min(w, h) * (0.4 + audioBass * 0.15)
            local cx = w / 2 + math.cos(angle) * radius * 0.4
            local cy = contentY + contentH / 2 + math.sin(angle) * radius * 0.3
            -- Larger, more visible background circles - pulse with audio
            local maxR = PS(120 + audioBass * 60)
            for r = maxR, PS(40), -PS(20) do
                local alpha = 0.03 + (maxR - r) / PS(400) + audioBeat * 0.05
                gfx.set(stemColors[i][1], stemColors[i][2], stemColors[i][3], math.min(0.3, alpha))
                gfx.circle(cx, cy, r, 1, 1)
            end
        end

        -- Floating particles in background - AUDIO REACTIVE
        local particleCount = 20 + math.floor(audioPeak * 15)
        for i = 1, particleCount do
            local px = (math.sin(bgTime * 0.5 + i * 1.3 + audioHigh * 0.5) * 0.5 + 0.5) * w
            local py = contentY + ((math.cos(bgTime * 0.3 + i * 0.7 + audioMid * 0.3) * 0.5 + 0.5) * contentH * 0.8)
            local col = stemColors[(i % 4) + 1]
            local particleAlpha = 0.15 + audioBeat * 0.2
            local particleSize = PS(3 + (i % 4) + audioPeak * 4)
            gfx.set(col[1], col[2], col[3], math.min(0.5, particleAlpha))
            gfx.circle(px, py, particleSize, 1, 1)
        end

        -- Audio waveform ring in center (MilkDrop-style!)
        if audioPeak > 0.05 then
            local waveRadius = PS(80 + audioBass * 40)
            local wcx, wcy = w / 2, contentY + contentH / 2
            for i = 0, 59 do
                local angle = (i / 60) * math.pi * 2
                local waveVal = audioReactive.waveformHistory[((audioReactive.waveformIndex + i) % audioReactive.waveformSize) + 1] or audioPeak
                local r = waveRadius * (1 + waveVal * 0.4)
                local wx = wcx + math.cos(angle + bgTime * 0.5) * r
                local wy = wcy + math.sin(angle + bgTime * 0.5) * r
                local col = stemColors[(math.floor(i / 15) % 4) + 1]
                gfx.set(col[1], col[2], col[3], 0.2 + waveVal * 0.3)
                gfx.circle(wx, wy, PS(2 + waveVal * 4), 1, 1)
            end
        end

        -- === TEXT CONTENT (drawn AFTER background) ===

        -- Large animated STEMperator title in STEM colors
        gfx.setfont(1, "Arial", PS(36), string.byte('b'))
        local titleText = "STEMperator"
        local titleChars = {"S", "T", "E", "M", "p", "e", "r", "a", "t", "o", "r"}
        local charColors = {1, 2, 3, 4, 0, 0, 0, 0, 0, 0, 0}  -- STEM colored, rest white

        -- Measure total width
        local totalTitleW = 0
        for _, ch in ipairs(titleChars) do
            totalTitleW = totalTitleW + gfx.measurestr(ch)
        end
        local titleX = (w - totalTitleW) / 2 + textOffsetX
        local titleY = contentY + PS(15)

        -- Draw each character with its color, pulse animation and flowing wave
        for i, ch in ipairs(titleChars) do
            local pulse = 1 + math.sin(time * 3 + i * 0.3) * 0.1
            local yOffset = math.sin(time * 3 + i * 0.5) * PS(4)
            if charColors[i] > 0 then
                local col = stemColors[charColors[i]]
                gfx.set(col[1] * pulse, col[2] * pulse, col[3] * pulse, 1)
            else
                gfx.set(THEME.text[1], THEME.text[2], THEME.text[3], 1)
            end
            gfx.x = titleX
            gfx.y = titleY + yOffset
            gfx.drawstr(ch)
            titleX = titleX + gfx.measurestr(ch)
        end

        -- Subtitle
        gfx.setfont(1, "Arial", PS(16))
        gfx.set(THEME.textDim[1], THEME.textDim[2], THEME.textDim[3], 1)
        local welcomeSub = T("help_welcome_sub")
        local wsW = gfx.measurestr(welcomeSub)
        gfx.x = (w - wsW) / 2 + textOffsetX
        gfx.y = contentY + PS(60)
        gfx.drawstr(welcomeSub)

        -- Divider line
        gfx.set(0.4, 0.4, 0.5, 0.5)
        gfx.line(w * 0.2 + textOffsetX, contentY + PS(85), w * 0.8 + textOffsetX, contentY + PS(85))

        -- Features list - LARGER and more descriptive
        local features = {
            {icon = "♪", color = stemColors[1], title = T("help_feature_vocals"), desc = "Lead vocals, backing vocals, speech"},
            {icon = "●", color = stemColors[2], title = T("help_feature_drums"), desc = "Kick, snare, hi-hats, percussion"},
            {icon = "≡", color = stemColors[3], title = T("help_feature_bass"), desc = "Bass guitar, synth bass, low frequencies"},
            {icon = "✦", color = stemColors[4], title = T("help_feature_other"), desc = "Guitar, keys, strings, synths, effects"},
        }
        local featureY = contentY + PS(100)
        local featureSpacing = PS(50)
        local leftCol = PS(40) + textOffsetX

        for i, feat in ipairs(features) do
            -- Colored icon/badge
            gfx.set(feat.color[1], feat.color[2], feat.color[3], 0.9)
            gfx.circle(leftCol + PS(15), featureY + PS(12), PS(18), 1, 1)

            -- Feature title (theme-aware)
            gfx.set(THEME.text[1], THEME.text[2], THEME.text[3], 1)
            gfx.setfont(1, "Arial", PS(16), string.byte('b'))
            gfx.x = leftCol + PS(45)
            gfx.y = featureY
            gfx.drawstr(feat.title)

            -- Feature description (theme-aware)
            gfx.set(THEME.textDim[1], THEME.textDim[2], THEME.textDim[3], 0.9)
            gfx.setfont(1, "Arial", PS(13))
            gfx.x = leftCol + PS(45)
            gfx.y = featureY + PS(22)
            gfx.drawstr(feat.desc)

            featureY = featureY + featureSpacing
        end

        -- Keyboard shortcuts section - FIXED position bottom-left, uses UI() (no zoom)
        local shortcutX = UI(15)
        local shortcutY = h - UI(90)

        gfx.setfont(1, "Arial", UI(12), string.byte('b'))
        gfx.set(THEME.text[1], THEME.text[2], THEME.text[3], 0.9)
        gfx.x = shortcutX
        gfx.y = shortcutY
        gfx.drawstr(T("keyboard_shortcuts"))

        local shortcuts = {
            {"F1", T("open_help")},
            {"ESC", T("close_cancel")},
            {"Enter", T("start_stemperator")},
        }
        gfx.setfont(1, "Arial", UI(10))
        local scY = shortcutY + UI(18)
        for _, sc in ipairs(shortcuts) do
            gfx.set(stemColors[2][1], stemColors[2][2], stemColors[2][3], 0.9)
            gfx.x = shortcutX
            gfx.y = scY
            gfx.drawstr(sc[1])
            gfx.set(THEME.textDim[1], THEME.textDim[2], THEME.textDim[3], 1)
            gfx.x = shortcutX + UI(50)
            gfx.y = scY
            gfx.drawstr(sc[2])
            scY = scY + UI(16)
        end

        -- Version info (bottom right with orange flarkAUDIO) - uses UI(), does NOT zoom
        gfx.setfont(1, "Arial", UI(10))
        local versionPart = "STEMperator v" .. APP_VERSION .. " - "
        local flarkPart = "flarkAUDIO"
        local vpW = gfx.measurestr(versionPart)
        local fpW = gfx.measurestr(flarkPart)
        local totalVW = vpW + fpW
        local vX = w - totalVW - UI(10)
        local vY = h - UI(18)  -- Bottom right corner
        -- Version text
        gfx.set(THEME.textHint[1], THEME.textHint[2], THEME.textHint[3], 0.8)
        gfx.x = vX
        gfx.y = vY
        gfx.drawstr(versionPart)
        -- flarkAUDIO in orange
        gfx.set(1.0, 0.6, 0.2, 1)
        gfx.x = vX + vpW
        gfx.y = vY
        gfx.drawstr(flarkPart)

    elseif helpState.currentTab == 2 then
        -- === QUICK START TAB + AUDIO REACTIVE ===

        -- Update audio reactivity
        updateAudioReactivity()
        local audioPeak = audioReactive.smoothPeakMono or 0
        local audioBass = audioReactive.smoothBass or 0
        local audioMid = audioReactive.smoothMid or 0
        local audioHigh = audioReactive.smoothHigh or 0
        local audioBeat = audioReactive.beatDecay or 0

        -- Flowing steps background animation
        local bgTime = os.clock() - helpState.startTime

        -- Flowing number particles (1, 2, 3) - AUDIO REACTIVE
        local stepNums = {"1", "2", "3"}
        local numCount = 25 + math.floor(audioPeak * 10)
        for i = 1, numCount do
            local numIdx = ((i - 1) % 3) + 1
            local num = stepNums[numIdx]

            -- Gentle floating motion - audio reactive
            local floatPhase = bgTime * (0.8 + audioMid * 0.4) + i * 0.7
            local fx = w * (i / (numCount + 1)) + math.sin(floatPhase * 0.6 + i) * PS(40 + audioBass * 30)
            local fy = contentY + (contentH * 0.5) + math.cos(floatPhase * 0.4 + i * 0.5) * PS(80 + audioHigh * 40)

            -- Size pulses with audio
            local fsize = PS(30 + math.sin(floatPhase) * 15 + audioPeak * 20)
            gfx.setfont(1, "Arial", fsize, string.byte('b'))

            -- Subtle color with audio-reactive alpha
            local falpha = 0.04 + math.sin(floatPhase * 2) * 0.02 + audioBeat * 0.08
            gfx.set(stemColors[numIdx][1], stemColors[numIdx][2], stemColors[numIdx][3], math.min(0.25, falpha))

            local fw = gfx.measurestr(num)
            gfx.x = fx - fw / 2
            gfx.y = fy - fsize / 2
            gfx.drawstr(num)
        end

        -- Connecting dotted paths - AUDIO REACTIVE
        for i = 1, 8 do
            local pathPhase = bgTime * (0.5 + audioMid * 0.3) + i * 0.9
            local dotCount = 12 + math.floor(audioPeak * 6)
            for dot = 1, dotCount do
                local dotPhase = pathPhase + dot * 0.2
                local dotX = w * 0.2 + (w * 0.6) * (dot / dotCount) + math.sin(dotPhase) * PS(20 + audioHigh * 15)
                local dotY = contentY + contentH * 0.3 + i * PS(30) + math.cos(dotPhase * 1.3) * PS(15 + audioBass * 20)

                local dotAlpha = 0.03 + math.sin(dotPhase * 3) * 0.015 + audioBeat * 0.04
                local colorIdx = ((dot - 1) % 3) + 1
                local dotSize = PS(2 + math.sin(dotPhase * 2) * 1 + audioPeak * 2)
                gfx.set(stemColors[colorIdx][1], stemColors[colorIdx][2], stemColors[colorIdx][3], math.min(0.15, dotAlpha))
                gfx.circle(dotX, dotY, dotSize, 1, 1)
            end
        end

        -- Audio waveform visualization (subtle, behind content)
        if audioPeak > 0.05 then
            local waveY = contentY + contentH * 0.85
            local waveW = w * 0.8
            local waveX = w * 0.1
            for i = 0, 59 do
                local histIdx = ((audioReactive.waveformIndex or 1) + i * 2) % (audioReactive.waveformSize or 60) + 1
                local waveVal = (audioReactive.waveformHistory and audioReactive.waveformHistory[histIdx]) or audioPeak * 0.3
                local wx = waveX + (i / 60) * waveW
                local wh = waveVal * PS(30)
                local colorIdx = (math.floor(i / 15) % 3) + 1
                gfx.set(stemColors[colorIdx][1], stemColors[colorIdx][2], stemColors[colorIdx][3], 0.1 + waveVal * 0.15)
                gfx.rect(wx, waveY - wh/2, PS(4), wh, 1)
            end
        end

        -- Title (theme-aware) - positioned like Welcome tab
        gfx.setfont(1, "Arial", PS(28), string.byte('b'))
        gfx.set(THEME.text[1], THEME.text[2], THEME.text[3], 1)
        local qsTitle = T("help_quickstart_title")
        local qtW = gfx.measurestr(qsTitle)
        gfx.x = (w - qtW) / 2 + textOffsetX
        gfx.y = contentY + PS(15)
        gfx.drawstr(qsTitle)

        -- Subtitle (theme-aware)
        gfx.setfont(1, "Arial", PS(14))
        gfx.set(THEME.textDim[1], THEME.textDim[2], THEME.textDim[3], 1)
        local subText = T("help_quickstart_sub")
        local subW = gfx.measurestr(subText)
        gfx.x = (w - subW) / 2 + textOffsetX
        gfx.y = contentY + PS(50)
        gfx.drawstr(subText)

        -- Steps - LARGER with more detail (all translated)
        local steps = {
            {num = "1", title = T("help_step1_title"), desc = T("help_step1_desc"),
             detail = T("help_step1_detail")},
            {num = "2", title = T("help_step2_title"), desc = T("help_step2_desc"),
             detail = T("help_step2_detail")},
            {num = "3", title = T("help_step3_title"), desc = T("help_step3_desc"),
             detail = T("help_step3_detail")},
        }
        local stepY = contentY + PS(85)
        local stepSpacing = PS(75)

        for i, step in ipairs(steps) do
            -- Step number circle - LARGER
            local circleX = PS(60) + textOffsetX
            local circleR = PS(25)

            -- Glow effect behind circle
            for r = circleR + PS(8), circleR, -PS(2) do
                gfx.set(stemColors[i][1], stemColors[i][2], stemColors[i][3], 0.1)
                gfx.circle(circleX, stepY + PS(18), r, 1, 1)
            end

            gfx.set(stemColors[i][1], stemColors[i][2], stemColors[i][3], 1)
            gfx.circle(circleX, stepY + PS(18), circleR, 1, 1)
            gfx.set(THEME.text[1], THEME.text[2], THEME.text[3], 1)
            gfx.setfont(1, "Arial", PS(20), string.byte('b'))
            local numW = gfx.measurestr(step.num)
            gfx.x = circleX - numW / 2
            gfx.y = stepY + PS(8)
            gfx.drawstr(step.num)

            -- Step title - LARGER (theme-aware)
            gfx.set(THEME.text[1], THEME.text[2], THEME.text[3], 1)
            gfx.setfont(1, "Arial", PS(18), string.byte('b'))
            gfx.x = PS(105) + textOffsetX
            gfx.y = stepY
            gfx.drawstr(step.title)

            -- Step description (theme-aware)
            gfx.set(THEME.textDim[1], THEME.textDim[2], THEME.textDim[3], 1)
            gfx.setfont(1, "Arial", PS(13))
            gfx.x = PS(105) + textOffsetX
            gfx.y = stepY + PS(24)
            gfx.drawstr(step.desc)

            -- Extra detail (if space) (theme-aware)
            if contentH > PS(300) then
                gfx.set(THEME.textHint[1], THEME.textHint[2], THEME.textHint[3], 0.9)
                gfx.setfont(1, "Arial", PS(11))
                gfx.x = PS(105) + textOffsetX
                gfx.y = stepY + PS(42)
                gfx.drawstr(step.detail)
            end

            -- Connecting line to next step
            if i < #steps then
                gfx.set(stemColors[i][1], stemColors[i][2], stemColors[i][3], 0.3)
                gfx.line(circleX, stepY + PS(18) + circleR, circleX, stepY + stepSpacing)
            end

            stepY = stepY + stepSpacing
        end

        -- Pro tip at bottom (blinking text, no bar)
        if contentH > PS(350) then
            local blink = 0.6 + math.sin(time * 4) * 0.4  -- Blinking effect
            local proTipText = T("help_pro_tip")
            gfx.setfont(1, "Arial", PS(13), string.byte('b'))
            gfx.set(stemColors[4][1], stemColors[4][2], stemColors[4][3], blink)
            local ptW = gfx.measurestr(proTipText)
            gfx.x = (w - ptW) / 2 + textOffsetX
            gfx.y = stepY + PS(20)
            gfx.drawstr(proTipText)
        end

    elseif helpState.currentTab == 3 then
        -- === STEMS TAB - COMPREHENSIVE STEM INFO ===

        -- Update audio reactivity for sound-driven animation
        updateAudioReactivity()

        -- SUPER FREAKY STEM letter morphing background (now audio-reactive!)
        local bgTime = os.clock() - helpState.startTime
        local stemLettersBg = {"S", "T", "E", "M"}

        -- Audio reactive values (use smoothed values for animation)
        local audioPeak = audioReactive.smoothPeakMono
        local audioBass = audioReactive.smoothBass
        local audioMid = audioReactive.smoothMid
        local audioHigh = audioReactive.smoothHigh
        local audioBeat = audioReactive.beatDecay

        -- === PSYCHEDELIC PLASMA WAVES ===
        local vortexCenterX = w / 2
        local vortexCenterY = contentY + contentH / 2

        -- Rainbow color cycling function
        local function rainbowColor(phase, baseColor)
            local hueShift = math.sin(phase) * 0.3
            local r = baseColor[1] + math.sin(phase) * 0.3
            local g = baseColor[2] + math.sin(phase + 2.1) * 0.3
            local b = baseColor[3] + math.sin(phase + 4.2) * 0.3
            return math.max(0, math.min(1, r)), math.max(0, math.min(1, g)), math.max(0, math.min(1, b))
        end

        -- === HYPNOTIC SPIRALING VORTEX (audio-reactive!) ===
        for ring = 1, 7 do
            for i = 1, 12 do
                local letterIdx = ((i - 1) % 4) + 1
                local letter = stemLettersBg[letterIdx]

                -- Warped spiral motion with breathing + AUDIO REACTIVE
                local breathe = 1 + math.sin(bgTime * 2) * 0.2 + audioBass * 0.4
                local angle = bgTime * (0.5 + ring * 0.15 + audioPeak * 0.3) + (i - 1) * (math.pi / 6) + ring * 0.7
                local warpAngle = angle + math.sin(bgTime * 3 + ring) * 0.5 + audioHigh * 0.3
                local radius = (PS(40 + ring * 35) + math.sin(bgTime * 2.5 + ring * 0.8) * PS(30) + audioBass * PS(40)) * breathe

                local lx = vortexCenterX + math.cos(warpAngle) * radius
                local ly = vortexCenterY + math.sin(warpAngle) * radius * 0.5

                -- Trippy size pulsation + AUDIO BOOST
                local sizePulse = math.sin(bgTime * 4 + i * 0.5 + ring) * 0.5 + 0.5
                local lsize = PS(25 + ring * 12 + sizePulse * 20 + audioPeak * 15)
                gfx.setfont(1, "Arial", lsize, string.byte('b'))

                -- Color cycling with phase shift + BEAT FLASH
                local colorPhase = bgTime * 2 + ring * 0.5 + i * 0.3 + audioPeak * 2
                local r, g, b = rainbowColor(colorPhase, stemColors[letterIdx])
                local lalpha = (0.15 - ring * 0.015) * (0.7 + math.sin(bgTime * 3 + i) * 0.3) + audioBeat * 0.15
                gfx.set(r, g, b, math.min(1, lalpha))

                local lw = gfx.measurestr(letter)
                gfx.x = lx - lw / 2
                gfx.y = ly - lsize / 2
                gfx.drawstr(letter)
            end
        end

        -- === MATRIX RAIN with color trails (audio-reactive!) ===
        for i = 1, 30 do
            local letterIdx = ((i - 1) % 4) + 1
            local letter = stemLettersBg[letterIdx]

            -- Cascading fall with wave distortion + AUDIO SPEED BOOST
            local fallSpeed = (0.4 + (i % 7) * 0.08) * (1 + audioMid * 0.5)
            local waveX = math.sin(bgTime * 2 + i * 0.3) * PS(50) * (1 + audioHigh * 0.5)
            local fallY = contentY + ((bgTime * fallSpeed * 120 + i * 40) % contentH)
            local driftX = w * (i / 31) + waveX

            local rainSize = PS(18 + (i % 4) * 10 + audioPeak * 8)
            gfx.setfont(1, "Arial", rainSize, string.byte('b'))

            -- Pulsing fade with color shift + BEAT BRIGHTNESS
            local fadeProgress = (fallY - contentY) / contentH
            local rainAlpha = (0.06 + audioBeat * 0.08) * math.sin(fadeProgress * math.pi) * (1 + math.sin(bgTime * 5 + i) * 0.3)

            local r, g, b = rainbowColor(bgTime * 3 + i * 0.5 + audioPeak * 2, stemColors[letterIdx])
            gfx.set(r, g, b, math.min(1, rainAlpha))
            gfx.x = driftX
            gfx.y = fallY
            gfx.drawstr(letter)
        end

        -- === ETHEREAL CORNER ORBS (audio-reactive!) ===
        local corners = {
            {x = PS(60), y = contentY + PS(40), idx = 1},
            {x = w - PS(60), y = contentY + PS(40), idx = 2},
            {x = PS(60), y = contentY + contentH - PS(50), idx = 3},
            {x = w - PS(60), y = contentY + contentH - PS(50), idx = 4},
        }
        for _, corner in ipairs(corners) do
            local cphase = bgTime * 1.5 + corner.idx * 1.5

            -- Soft pulsing rings + AUDIO EXPANSION
            for ring = 4, 1, -1 do
                local ringPhase = cphase + ring * 0.4
                local ringRadius = PS(15 + ring * 12 + math.sin(ringPhase) * 8) * (1 + audioBass * 0.4)
                local ringAlpha = (0.03 / ring * (0.8 + math.sin(ringPhase * 2) * 0.2)) + audioBeat * 0.02

                local r, g, b = rainbowColor(ringPhase + audioPeak, stemColors[corner.idx])
                gfx.set(r, g, b, math.min(0.3, ringAlpha))
                gfx.circle(corner.x, corner.y, ringRadius, 0, 1)
            end

            -- Glowing core + BEAT PULSE
            local coreAlpha = 0.06 + math.sin(cphase * 3) * 0.03 + audioBeat * 0.15
            local coreSize = PS(4 + math.sin(cphase * 2) * 2 + audioPeak * 6)
            local r, g, b = rainbowColor(cphase * 2 + audioPeak * 2, stemColors[corner.idx])
            gfx.set(r, g, b, math.min(0.5, coreAlpha))
            gfx.circle(corner.x, corner.y, coreSize, 1, 1)
        end

        -- === LASER BEAMS (audio-reactive!) ===
        for i = 1, 6 do
            local phase1 = bgTime * 0.8 + i * 1.05 + audioHigh * 0.5
            local phase2 = bgTime * 0.8 + ((i % 6) + 1) * 1.05 + audioHigh * 0.5

            local radius1 = PS(120 + math.sin(phase1 * 2) * 40 + audioBass * 60)
            local radius2 = PS(120 + math.sin(phase2 * 2) * 40 + audioBass * 60)
            local x1 = vortexCenterX + math.cos(phase1) * radius1
            local y1 = vortexCenterY + math.sin(phase1) * radius1 * 0.5
            local x2 = vortexCenterX + math.cos(phase2 + math.pi/3) * radius2
            local y2 = vortexCenterY + math.sin(phase2 + math.pi/3) * radius2 * 0.5

            local lineAlpha = 0.08 + math.sin(bgTime * 4 + i) * 0.04 + audioBeat * 0.15
            local colorIdx = ((i - 1) % 4) + 1
            local r, g, b = rainbowColor(bgTime * 2 + i + audioPeak * 3, stemColors[colorIdx])
            gfx.set(r, g, b, math.min(0.5, lineAlpha))
            gfx.line(x1, y1, x2, y2)
            -- Double line for glow effect
            gfx.set(r, g, b, math.min(0.25, lineAlpha * 0.5))
            gfx.line(x1 + 1, y1 + 1, x2 + 1, y2 + 1)
        end

        -- === FLOATING PARTICLES (audio-reactive!) ===
        for i = 1, 15 do
            local pphase = bgTime * 1.5 + i * 0.8
            local px = vortexCenterX + math.sin(pphase * 0.7 + i) * PS(150 + audioBass * 50)
            local py = vortexCenterY + math.cos(pphase * 0.5 + i * 0.5) * PS(80 + audioMid * 30)
            local psize = PS(8 + math.sin(pphase * 3) * 4 + audioPeak * 8)

            local colorIdx = ((i - 1) % 4) + 1
            local r, g, b = rainbowColor(pphase * 2 + audioPeak * 2, stemColors[colorIdx])
            local palpha = 0.15 + math.sin(pphase * 4) * 0.1 + audioBeat * 0.2
            gfx.set(r, g, b, math.min(0.6, palpha))
            gfx.circle(px, py, psize, 1, 1)
        end

        -- === MILKDROP FEEDBACK TUNNEL (zooming concentric shapes) ===
        local tunnelRings = 10
        for ring = tunnelRings, 1, -1 do
            local ringPhase = (bgTime * 0.8 + ring * 0.12) % 1
            local ringRadius = (1 - ringPhase) * math.min(w, contentH) * 0.6

            -- Warp distortion based on audio
            local warpAmt = 0.15 + audioMid * 0.25
            local sides = 4 + (ring % 3)  -- Varying polygon sides

            local col = stemColors[(ring % 4) + 1]
            local r, g, b = rainbowColor(bgTime * 2 + ring * 0.4 + audioPeak * 3, col)
            local alpha = ringPhase * 0.12 + audioBeat * 0.08
            gfx.set(r, g, b, math.min(0.4, alpha))

            -- Draw warped polygon
            for j = 0, sides do
                local angle1 = (j / sides) * math.pi * 2 + bgTime * 0.3
                local angle2 = ((j + 1) / sides) * math.pi * 2 + bgTime * 0.3
                local warp1 = 1 + math.sin(angle1 * 3 + bgTime * 2) * warpAmt * (1 + audioBass * 0.5)
                local warp2 = 1 + math.sin(angle2 * 3 + bgTime * 2) * warpAmt * (1 + audioBass * 0.5)

                local x1 = vortexCenterX + math.cos(angle1) * ringRadius * warp1
                local y1 = vortexCenterY + math.sin(angle1) * ringRadius * warp1 * 0.6
                local x2 = vortexCenterX + math.cos(angle2) * ringRadius * warp2
                local y2 = vortexCenterY + math.sin(angle2) * ringRadius * warp2 * 0.6

                gfx.line(x1, y1, x2, y2)
            end
        end

        -- === MILKDROP PLASMA WAVES (horizontal sine interference) ===
        local plasmaRows = 8
        for row = 1, plasmaRows do
            local rowY = contentY + (row / (plasmaRows + 1)) * contentH
            local rowPhase = bgTime * 1.5 + row * 0.4

            for i = 0, w, PS(8) do
                local t = i / w
                -- Multiple sine waves combined (plasma effect)
                local wave1 = math.sin(t * 8 + rowPhase + audioBass * 2) * PS(15)
                local wave2 = math.sin(t * 12 - rowPhase * 1.3 + audioMid) * PS(10)
                local wave3 = math.sin(t * 4 + rowPhase * 0.7 + audioHigh * 3) * PS(20)
                local combinedWave = (wave1 + wave2 + wave3) * (0.5 + audioPeak * 0.5)

                local px = i
                local py = rowY + combinedWave

                -- Color based on wave height
                local colorPhase = bgTime * 2 + t * 4 + combinedWave * 0.02
                local colorIdx = ((row - 1) % 4) + 1
                local r, g, b = rainbowColor(colorPhase, stemColors[colorIdx])
                local alpha = 0.06 + math.abs(combinedWave) * 0.002 + audioBeat * 0.04
                gfx.set(r, g, b, math.min(0.25, alpha))
                gfx.circle(px, py, PS(2 + audioPeak * 2), 1, 1)
            end
        end

        -- === MILKDROP AUDIO SCOPE (waveform display) ===
        if audioPeak > 0.03 then
            local scopeY = vortexCenterY
            local scopeW = w * 0.7
            local scopeX = (w - scopeW) / 2
            local scopeH = PS(60 + audioBass * 40)

            -- Draw waveform from history buffer
            local prevX, prevY
            local points = audioReactive.waveformSize or 60
            for i = 0, points - 1 do
                local histIdx = ((audioReactive.waveformIndex or 1) + i) % points + 1
                local waveVal = (audioReactive.waveformHistory and audioReactive.waveformHistory[histIdx]) or 0

                local sx = scopeX + (i / points) * scopeW
                local sy = scopeY + waveVal * scopeH * (0.5 + audioHigh * 0.5)

                local colorIdx = (math.floor(i / (points / 4)) % 4) + 1
                local r, g, b = rainbowColor(bgTime * 3 + i * 0.1, stemColors[colorIdx])
                local alpha = 0.15 + waveVal * 0.3 + audioBeat * 0.1
                gfx.set(r, g, b, math.min(0.5, alpha))

                if prevX then
                    gfx.line(prevX, prevY, sx, sy)
                end
                prevX, prevY = sx, sy

                -- Glow dots at peaks
                if waveVal > 0.3 then
                    gfx.set(r, g, b, alpha * 0.5)
                    gfx.circle(sx, sy, PS(3 + waveVal * 4), 1, 1)
                end
            end
        end

        -- === MILKDROP MOTION VECTORS (trailing lines) ===
        local mvCount = 12
        for i = 1, mvCount do
            local mvPhase = bgTime * 0.6 + i * 0.52
            local startAngle = (i / mvCount) * math.pi * 2 + bgTime * 0.2
            local mvLen = PS(40 + audioBass * 60 + math.sin(mvPhase * 2) * 20)

            local startR = PS(50 + audioMid * 30)
            local sx = vortexCenterX + math.cos(startAngle) * startR
            local sy = vortexCenterY + math.sin(startAngle) * startR * 0.5
            local ex = sx + math.cos(startAngle + math.sin(mvPhase) * 0.5) * mvLen
            local ey = sy + math.sin(startAngle + math.sin(mvPhase) * 0.5) * mvLen * 0.5

            local colorIdx = ((i - 1) % 4) + 1
            local r, g, b = rainbowColor(mvPhase * 2 + audioPeak * 2, stemColors[colorIdx])

            -- Draw motion trail with fade
            for trail = 0, 4 do
                local trailAlpha = (0.08 - trail * 0.015) * (1 + audioBeat * 0.5)
                local trailOffset = trail * PS(3)
                gfx.set(r, g, b, math.min(0.3, trailAlpha))
                gfx.line(sx - trailOffset, sy, ex - trailOffset, ey)
            end
        end

        -- === BEAT FLASH OVERLAY (on strong beats) ===
        if audioBeat > 0.3 then
            local flashAlpha = audioBeat * 0.08
            gfx.set(1, 1, 1, flashAlpha)
            gfx.rect(0, contentY, w, contentH, 1)
        end

        -- === BEAT COLOR INVERSION (MilkDrop hardcut style) ===
        if audioBeat > 0.6 then
            -- Brief inverted color flash on strong beats
            local invAlpha = (audioBeat - 0.6) * 0.15
            if SETTINGS.darkMode then
                gfx.set(1, 1, 1, invAlpha)
            else
                gfx.set(0, 0, 0, invAlpha)
            end
            gfx.rect(0, contentY, w, contentH, 1)
        end

        -- Title (theme-aware)
        gfx.setfont(1, "Arial", PS(28), string.byte('b'))
        gfx.set(THEME.text[1], THEME.text[2], THEME.text[3], 1)
        local stemTitle = T("help_stems_title")
        local stW = gfx.measurestr(stemTitle)
        gfx.x = (w - stW) / 2 + textOffsetX
        gfx.y = contentY + PS(10)
        gfx.drawstr(stemTitle)

        -- Subtitle (translated, theme-aware)
        gfx.setfont(1, "Arial", PS(13))
        gfx.set(THEME.textDim[1], THEME.textDim[2], THEME.textDim[3], 1)
        local subText = T("help_stems_sub")
        local subW = gfx.measurestr(subText)
        gfx.x = (w - subW) / 2 + textOffsetX
        gfx.y = contentY + PS(42)
        gfx.drawstr(subText)

        -- Stem explanations - All translated
        local stems = {
            {name = T("stem_vocals"), color = stemColors[1], desc = T("help_stem_vocals_desc"),
             uses = T("help_stem_vocals_uses")},
            {name = T("stem_drums"), color = stemColors[2], desc = T("help_stem_drums_desc"),
             uses = T("help_stem_drums_uses")},
            {name = T("stem_bass"), color = stemColors[3], desc = T("help_stem_bass_desc"),
             uses = T("help_stem_bass_uses")},
            {name = T("stem_other"), color = stemColors[4], desc = T("help_stem_other_desc"),
             uses = T("help_stem_other_uses")},
        }

        local stemY = contentY + PS(70)
        local cardH = PS(65)
        local cardGap = PS(10)

        for i, stem in ipairs(stems) do
            -- Color accent bar on left (no card background)
            gfx.set(stem.color[1], stem.color[2], stem.color[3], 1)
            gfx.rect(PS(25) + textOffsetX, stemY, PS(8), cardH, 1)

            -- Stem icon circle
            gfx.set(stem.color[1], stem.color[2], stem.color[3], 0.9)
            gfx.circle(PS(60) + textOffsetX, stemY + cardH/2, PS(20), 1, 1)

            -- Letter in circle (always white for contrast on colored circle)
            gfx.set(1, 1, 1, 1)
            gfx.setfont(1, "Arial", PS(16), string.byte('b'))
            local letter = stem.name:sub(1, 1)
            local lW = gfx.measurestr(letter)
            gfx.x = PS(60) + textOffsetX - lW/2
            gfx.y = stemY + cardH/2 - PS(9)
            gfx.drawstr(letter)

            -- Stem name - darker in light mode for readability
            if SETTINGS.darkMode then
                gfx.set(stem.color[1], stem.color[2], stem.color[3], 1)
            else
                gfx.set(stem.color[1] * 0.7, stem.color[2] * 0.7, stem.color[3] * 0.7, 1)
            end
            gfx.setfont(1, "Arial", PS(18), string.byte('b'))
            gfx.x = PS(95) + textOffsetX
            gfx.y = stemY + PS(8)
            gfx.drawstr(stem.name)

            -- Contains description (theme-aware)
            gfx.set(THEME.textDim[1], THEME.textDim[2], THEME.textDim[3], 1)
            gfx.setfont(1, "Arial", PS(12))
            gfx.x = PS(95) + textOffsetX
            gfx.y = stemY + PS(28)
            gfx.drawstr(stem.desc)

            -- Use cases (if space) (theme-aware)
            if contentH > PS(350) then
                gfx.set(THEME.textHint[1], THEME.textHint[2], THEME.textHint[3], 0.9)
                gfx.setfont(1, "Arial", PS(10))
                gfx.x = PS(95) + textOffsetX
                gfx.y = stemY + PS(45)
                gfx.drawstr(stem.uses)
            end

            stemY = stemY + cardH + cardGap
        end

        -- 6-stem model note (translated, better styled)
        if contentH > PS(400) then
            -- Blinking indicator
            local blink6 = 0.7 + math.sin(time * 3) * 0.3
            gfx.setfont(1, "Arial", PS(13), string.byte('b'))
            gfx.set(stemColors[4][1], stemColors[4][2], stemColors[4][3], blink6)
            local model6Title = T("help_6stem_title")
            local m6W = gfx.measurestr(model6Title)
            gfx.x = (w - m6W) / 2 + textOffsetX
            gfx.y = stemY + PS(10)
            gfx.drawstr(model6Title)

            gfx.setfont(1, "Arial", PS(11))
            gfx.set(THEME.textDim[1], THEME.textDim[2], THEME.textDim[3], 1)
            local model6Desc = T("help_6stem_desc")
            local m6dW = gfx.measurestr(model6Desc)
            gfx.x = (w - m6dW) / 2 + textOffsetX
            gfx.y = stemY + PS(28)
            gfx.drawstr(model6Desc)
        end

    elseif helpState.currentTab == 5 then
        -- === ABOUT TAB ===
        -- Fullscreen procedural art background with zoom/pan (like Gallery)
        local tabAreaH = UI(40)

        -- Define art display area (below tabs)
        local artX = 0
        local artY = tabAreaH
        local artW = w
        local artH = h - tabAreaH - UI(50)  -- Leave room for close button

        -- Apply zoom and pan to art area (fly-through effect!)
        local zoomedW = artW * zoom
        local zoomedH = artH * zoom
        local zoomedX = artX - (zoomedW - artW) / 2 + panX
        local zoomedY = artY - (zoomedH - artH) / 2 + panY

        -- Draw the procedural art with zoom and rotation
        drawProceduralArt(zoomedX, zoomedY, zoomedW, zoomedH, time, helpState.rotation, true)

        -- Semi-transparent overlay for readability - pure black/white (fixed position, doesn't zoom)
        if SETTINGS.darkMode then
            gfx.set(0, 0, 0, 0.6)
        else
            gfx.set(1, 1, 1, 0.6)
        end
        gfx.rect(0, artY, w, artH, 1)

        -- Content
        local centerX = w / 2
        local contentY = tabAreaH + PS(30)

        -- Title with colored STEM letters and flowing animation (no "About" prefix)
        gfx.setfont(1, "Arial", PS(24), string.byte('b'))
        local titleLetters = {"S", "T", "E", "M", "p", "e", "r", "a", "t", "o", "r"}
        local titleWidths = {}
        local totalTitleW = 0
        for i, letter in ipairs(titleLetters) do
            local lw = gfx.measurestr(letter)
            titleWidths[i] = lw
            totalTitleW = totalTitleW + lw
        end
        local titleX = centerX - totalTitleW / 2

        -- Draw each letter with flowing wave animation
        for i, letter in ipairs(titleLetters) do
            local yOffset = math.sin(time * 3 + i * 0.5) * PS(3)
            if i <= 4 then
                gfx.set(stemColors[i][1], stemColors[i][2], stemColors[i][3], 1)
            else
                gfx.set(THEME.text[1], THEME.text[2], THEME.text[3], 1)
            end
            gfx.x = titleX
            gfx.y = contentY + yOffset
            gfx.drawstr(letter)
            titleX = titleX + titleWidths[i]
        end

        contentY = contentY + PS(35)

        -- Subtitle
        gfx.setfont(1, "Arial", PS(12))
        gfx.set(THEME.textDim[1], THEME.textDim[2], THEME.textDim[3], 1)
        local subtitle = T("about_subtitle")
        local subW = gfx.measurestr(subtitle)
        gfx.x = centerX - subW / 2
        gfx.y = contentY
        gfx.drawstr(subtitle)

        contentY = contentY + PS(40)

        -- Version info
        gfx.setfont(1, "Arial", PS(11), string.byte('b'))
        gfx.set(stemColors[5][1], stemColors[5][2], stemColors[5][3], 1)
        local versionLabel = T("about_version") .. ": " .. APP_VERSION
        local vW = gfx.measurestr(versionLabel)
        gfx.x = centerX - vW / 2
        gfx.y = contentY
        gfx.drawstr(versionLabel)

        contentY = contentY + PS(30)

        -- Credits section (Conceived first, then Created with, then Powered by)
        gfx.setfont(1, "Arial", PS(10))

        -- Conceived by flarkAUDIO (first!)
        gfx.set(THEME.textDim[1], THEME.textDim[2], THEME.textDim[3], 1)
        local conceivedBy = T("about_conceived") .. " "
        gfx.x = centerX - PS(60)
        gfx.y = contentY
        gfx.drawstr(conceivedBy)
        gfx.set(1.0, 0.5, 0.3, 1)  -- flark orange
        gfx.drawstr("flarkAUDIO")

        contentY = contentY + PS(18)

        -- Created with Claude AI
        gfx.set(THEME.textDim[1], THEME.textDim[2], THEME.textDim[3], 1)
        local createdWith = T("about_author") .. " "
        gfx.x = centerX - PS(60)
        gfx.y = contentY
        gfx.drawstr(createdWith)
        gfx.set(0.6, 0.8, 1.0, 1)  -- Claude blue
        gfx.drawstr(T("about_claude"))

        contentY = contentY + PS(18)

        -- Powered by Meta's Demucs
        gfx.set(THEME.textDim[1], THEME.textDim[2], THEME.textDim[3], 1)
        local poweredBy = T("about_powered_by") .. " "
        gfx.x = centerX - PS(60)
        gfx.y = contentY
        gfx.drawstr(poweredBy)
        gfx.set(0.3, 0.7, 1.0, 1)  -- Meta blue
        gfx.drawstr(T("about_demucs"))

        contentY = contentY + PS(35)

        -- Features section
        gfx.setfont(1, "Arial", PS(12), string.byte('b'))
        gfx.set(THEME.text[1], THEME.text[2], THEME.text[3], 1)
        local featuresTitle = T("about_features_title")
        local ftW = gfx.measurestr(featuresTitle)
        gfx.x = centerX - ftW / 2
        gfx.y = contentY
        gfx.drawstr(featuresTitle)

        contentY = contentY + PS(20)

        -- Feature list
        gfx.setfont(1, "Arial", PS(10))
        local features = {
            {color = stemColors[1], text = T("about_feature_1")},
            {color = stemColors[2], text = T("about_feature_2")},
            {color = stemColors[3], text = T("about_feature_3")},
            {color = stemColors[4], text = T("about_feature_4")},
            {color = stemColors[5], text = T("about_feature_5")},
        }

        for i, feat in ipairs(features) do
            gfx.set(feat.color[1], feat.color[2], feat.color[3], 0.8)
            gfx.x = centerX - PS(140)
            gfx.y = contentY
            gfx.drawstr("●")
            gfx.set(THEME.textDim[1], THEME.textDim[2], THEME.textDim[3], 1)
            gfx.x = centerX - PS(130)
            gfx.drawstr(feat.text)
            contentY = contentY + PS(16)
        end

        contentY = contentY + PS(20)

        -- Tip
        gfx.setfont(1, "Arial", PS(9))
        local tipPulse = 0.5 + math.sin(time * 2) * 0.2
        gfx.set(stemColors[5][1], stemColors[5][2], stemColors[5][3], tipPulse)
        local tipText = T("about_tip")
        local tipW = gfx.measurestr(tipText)
        gfx.x = centerX - tipW / 2
        gfx.y = contentY
        gfx.drawstr(tipText)

        -- Click on art generates new art
        if not mouseDown and helpState.wasMouseDown and not helpState.wasDrag then
            local tabAreaBottom = UI(40)
            local closeBtnTop = h - UI(50)
            if helpState.clickStartY > tabAreaBottom and helpState.clickStartY < closeBtnTop then
                generateNewArt()
            end
        end
    end
    -- End of tab content

    -- === CLOSE BUTTON (uses UI() - does NOT zoom) ===
    local btnW = UI(70)
    local btnH = UI(24)
    local btnX = (w - btnW) / 2
    local btnY = h - UI(32)
    local closeHover = mx >= btnX and mx <= btnX + btnW and my >= btnY and my <= btnY + btnH

    if closeHover then
        gfx.set(0.9, 0.3, 0.3, 1 * controlsOpacity)
    else
        gfx.set(0.5, 0.2, 0.2, 0.9 * controlsOpacity)
    end
    -- Rounded button
    for i = 0, btnH - 1 do
        local radius = btnH / 2
        local inset = 0
        if i < radius then
            inset = radius - math.sqrt(math.max(0, radius * radius - (radius - i) * (radius - i)))
        elseif i > btnH - radius then
            inset = radius - math.sqrt(math.max(0, radius * radius - (i - (btnH - radius)) * (i - (btnH - radius))))
        end
        gfx.line(btnX + inset, btnY + i, btnX + btnW - inset, btnY + i)
    end
    gfx.set(1, 1, 1, 1 * controlsOpacity)
    gfx.setfont(1, "Arial", UI(11), string.byte('b'))
    local closeText = T("back")
    local closeTextW = gfx.measurestr(closeText)
    gfx.x = btnX + (btnW - closeTextW) / 2
    gfx.y = btnY + (btnH - UI(11)) / 2
    gfx.drawstr(closeText)

    -- Close button tooltip
    if closeHover and controlsOpacity > 0.3 then
        tooltipText = "Close Help (ESC) | Enter = Start"
        tooltipX, tooltipY = mx + UI(10), my - UI(25)
    end

    -- === DRAW TOOLTIP (always on top, with STEM colors) ===
    if tooltipText then
        gfx.setfont(1, "Arial", UI(11))
        local padding = UI(8)
        local tw = gfx.measurestr(tooltipText) + padding * 2
        local th = UI(18) + padding * 2
        local tx = tooltipX
        local ty = tooltipY

        -- Keep tooltip on screen
        if tx + tw > w then
            tx = w - tw - UI(5)
        end
        if ty + th > h then
            ty = tooltipY - th - UI(20)
        end
        if ty < 0 then ty = UI(5) end

        -- Background (theme-aware)
        gfx.set(THEME.inputBg[1], THEME.inputBg[2], THEME.inputBg[3], 0.98)
        gfx.rect(tx, ty, tw, th, 1)

        -- Colored top border (STEM colors gradient)
        for i = 0, tw - 1 do
            local colorIdx = math.floor(i / tw * 4) + 1
            colorIdx = math.min(4, math.max(1, colorIdx))
            local c = STEM_BORDER_COLORS[colorIdx]
            gfx.set(c[1]/255, c[2]/255, c[3]/255, 0.9)
            gfx.line(tx + i, ty, tx + i, ty + 2)
        end

        -- Border (theme-aware)
        gfx.set(THEME.border[1], THEME.border[2], THEME.border[3], 1)
        gfx.rect(tx, ty, tw, th, 0)

        -- Text (theme-aware)
        gfx.set(THEME.text[1], THEME.text[2], THEME.text[3], 1)
        gfx.x = tx + padding
        gfx.y = ty + padding + UI(2)
        gfx.drawstr(tooltipText)
    end

    gfx.update()

    -- Helper to reset camera when changing art
    local function resetCamera()
        helpState.targetZoom = 1.0
        helpState.targetPanX = 0
        helpState.targetPanY = 0
    end

    -- Helper to reset text zoom and pan
    local function resetTextZoom()
        helpState.targetTextZoom = 1.0
        helpState.targetTextPanX = 0
        helpState.targetTextPanY = 0
    end

    -- Handle clicks
    if mouseDown and not helpState.wasMouseDown then
        -- Double-click detection
        local now = os.clock()
        local isDoubleClick = helpState.lastClickTime and (now - helpState.lastClickTime) < 0.3
        helpState.lastClickTime = now

        if clickedTab then
            helpState.currentTab = clickedTab
            resetCamera()
            resetTextZoom()
            -- Stems tab needs slightly smaller zoom to fit all content
            if clickedTab == 3 then
                helpState.targetTextZoom = 0.85
            end
            -- Do NOT generate new art when switching tabs
        elseif closeHover and controlsOpacity > 0.3 then
            return "close"
        elseif isDoubleClick and not helpState.wasDrag then
            -- Double-click anywhere resets zoom/pan (only if not dragging)
            if helpState.currentTab == 4 or helpState.currentTab == 5 then
                resetCamera()
            else
                resetTextZoom()
            end
        end
    end
    helpState.wasMouseDown = mouseDown

    -- Keyboard navigation
    local char = gfx.getchar()
    if char == -1 or char == 27 then  -- Window closed or ESC
        return "close"
    elseif char == 13 then  -- Enter key = start STEMperator
        return "start"
    elseif helpState.currentTab == 4 or helpState.currentTab == 5 then
        -- Art gallery / About tab navigation
        if char == 114 or char == 82 then  -- R key to reset camera
            resetCamera()
        elseif char == 32 then  -- Space for new art
            generateNewArt()
            -- Note: Pan and zoom are preserved when switching art
        end
    end
    -- Tab switching with number keys
    if char >= 49 and char <= 53 then  -- 1-5 keys
        helpState.currentTab = char - 48
        resetCamera()
        resetTextZoom()
    end

    return nil
end

-- Forward declarations for functions defined later
local showStemSelectionDialog

-- Art Gallery window loop
local function artGalleryLoop()
    -- Update window title based on current tab
    local tabTitles = {
        "STEMperator - " .. T("help_welcome"),
        "STEMperator - " .. T("help_quickstart"),
        "STEMperator - " .. T("help_stems"),
        "STEMperator - " .. T("help_gallery"),
        "STEMperator - " .. T("help_about")
    }
    local currentTitle = tabTitles[helpState.currentTab] or "STEMperator Help"

    -- Save window position/size continuously and update title
    if reaper.JS_Window_Find then
        local hwnd = reaper.JS_Window_Find("STEMperator", false)  -- Partial match
        if hwnd then
            local retval, left, top, right, bottom = reaper.JS_Window_GetRect(hwnd)
            if retval then
                lastDialogX = left
                lastDialogY = top
                lastDialogW = right - left
                lastDialogH = bottom - top
            end
            -- Update window title dynamically
            if reaper.JS_Window_SetTitle then
                reaper.JS_Window_SetTitle(hwnd, currentTitle)
            end
        end
    end

    local result = drawArtGallery()
    if result == "close" then
        -- Save settings before closing
        saveSettings()
        gfx.quit()
        -- Save where we came from before resetting
        local cameFromDialog = (helpState.openedFrom == "dialog")
        -- Reset help state for next time
        helpState.currentTab = 1  -- Start at Welcome tab next time
        helpState.openedFrom = "start"
        -- Return to where help was opened from
        if cameFromDialog then
            -- Came from main dialog - go back to main dialog
            reaper.defer(function() showStemSelectionDialog() end)
        else
            -- Came from start screen - go back to main (which checks for selection)
            reaper.defer(function() main() end)
        end
        return
    elseif result == "start" then
        -- Enter key pressed - close help and start STEMperator
        saveSettings()
        gfx.quit()
        -- Reset help state for next time
        helpState.currentTab = 1  -- Start at Welcome tab next time
        helpState.openedFrom = "start"
        -- Go to main which will show dialog or start workflow
        reaper.defer(function() main() end)
        return
    end
    reaper.defer(artGalleryLoop)
end

-- Show Art Gallery
local function showArtGallery()
    loadSettings()
    updateTheme()

    artGalleryState.currentArt = 1
    artGalleryState.wasMouseDown = false
    artGalleryState.startTime = os.clock()
    -- Reset camera
    artGalleryState.zoom = 1.0
    artGalleryState.panX = 0
    artGalleryState.panY = 0
    artGalleryState.targetZoom = 1.0
    artGalleryState.targetPanX = 0
    artGalleryState.targetPanY = 0
    artGalleryState.isDragging = false
    artGalleryState.lastMouseWheel = 0

    -- Use same size and position as last dialog
    local winW = lastDialogW or 380
    local winH = lastDialogH or 340
    local winX, winY

    if lastDialogX and lastDialogY then
        winX = lastDialogX
        winY = lastDialogY
    else
        -- Fallback to mouse position
        local mouseX, mouseY = reaper.GetMousePosition()
        winX = mouseX - winW / 2
        winY = mouseY - winH / 2
    end

    gfx.init("STEMperator Art Gallery", winW, winH, 0, winX, winY)
    reaper.defer(artGalleryLoop)
end

-- Draw message window (replaces reaper.MB for proper positioning)
-- Styled to match main app window
local function drawMessageWindow()
    local w, h = gfx.w, gfx.h

    -- Calculate scale based on window size
    local scale = math.min(w / 380, h / 340)
    scale = math.max(0.5, math.min(4.0, scale))
    local function PS(val) return math.floor(val * scale + 0.5) end

    local mx, my = gfx.mouse_x, gfx.mouse_y
    local mouseDown = gfx.mouse_cap & 1 == 1
    local rightMouseDown = gfx.mouse_cap & 2 == 2
    local mouseWheel = gfx.mouse_wheel

    -- STEM colors
    local stemColors = {
        {255/255, 100/255, 100/255},  -- S = Vocals (red)
        {100/255, 200/255, 255/255},  -- T = Drums (blue)
        {150/255, 100/255, 255/255},  -- E = Bass (purple)
        {100/255, 255/255, 150/255},  -- M = Other (green)
    }

    -- Initialize procedural art if needed
    if proceduralArt.seed == 0 then
        generateNewArt()
    end

    -- Update animation time
    proceduralArt.time = proceduralArt.time + 0.016

    -- Initialize art state for mouse controls
    if not messageWindowState.artZoom then
        messageWindowState.artZoom = 1.0
        messageWindowState.artPanX = 0
        messageWindowState.artPanY = 0
        messageWindowState.artRotation = 0
        messageWindowState.lastMX = mx
        messageWindowState.lastMY = my
        messageWindowState.wasDragging = false
    end

    -- Mouse wheel zoom
    if mouseWheel ~= 0 then
        local zoomDelta = mouseWheel / 1200
        messageWindowState.artZoom = math.max(0.3, math.min(3.0, messageWindowState.artZoom + zoomDelta))
        gfx.mouse_wheel = 0
    end

    -- Right mouse drag = rotation
    if rightMouseDown then
        local dx = mx - (messageWindowState.lastMX or mx)
        messageWindowState.artRotation = (messageWindowState.artRotation or 0) + dx * 0.01
        messageWindowState.wasDragging = true
    end

    -- Left mouse drag = pan (only in lower area to not interfere with buttons)
    if mouseDown and my > h * 0.3 then
        local dx = mx - (messageWindowState.lastMX or mx)
        local dy = my - (messageWindowState.lastMY or my)
        if math.abs(dx) > 1 or math.abs(dy) > 1 then
            messageWindowState.artPanX = (messageWindowState.artPanX or 0) + dx
            messageWindowState.artPanY = (messageWindowState.artPanY or 0) + dy
            messageWindowState.wasDragging = true
        end
    end

    messageWindowState.lastMX = mx
    messageWindowState.lastMY = my

    -- Pure black/white background
    if SETTINGS.darkMode then
        gfx.set(0, 0, 0, 1)
    else
        gfx.set(1, 1, 1, 1)
    end
    gfx.rect(0, 0, w, h, 1)

    -- Draw procedural art background with zoom/pan/rotation
    local artX = messageWindowState.artPanX or 0
    local artY = messageWindowState.artPanY or 0
    local artZoom = messageWindowState.artZoom or 1.0
    local artRot = messageWindowState.artRotation or 0

    -- Apply zoom by adjusting draw area
    local zoomedW = w * artZoom
    local zoomedH = h * artZoom
    local drawX = (w - zoomedW) / 2 + artX
    local drawY = (h - zoomedH) / 2 + artY

    drawProceduralArt(drawX, drawY, zoomedW, zoomedH, proceduralArt.time, artRot, true)

    -- Semi-transparent overlay for UI readability
    if SETTINGS.darkMode then
        gfx.set(0, 0, 0, 0.6)
    else
        gfx.set(1, 1, 1, 0.6)
    end
    gfx.rect(0, 0, w, h, 1)

    -- Theme toggle button (sun/moon icon, top right)
    local themeSize = PS(20)
    local themeX = w - themeSize - PS(10)
    local themeY = PS(8)
    local themeHover = mx >= themeX and mx <= themeX + themeSize and my >= themeY and my <= themeY + themeSize

    if SETTINGS.darkMode then
        gfx.set(0.7, 0.7, 0.5, themeHover and 1 or 0.6)
        gfx.circle(themeX + themeSize/2, themeY + themeSize/2, themeSize/2 - 2, 1, 1)
        gfx.set(0, 0, 0, 1)  -- Pure black for moon overlay
        gfx.circle(themeX + themeSize/2 + 4, themeY + themeSize/2 - 3, themeSize/2 - 3, 1, 1)
    else
        gfx.set(0.9, 0.7, 0.2, themeHover and 1 or 0.8)
        gfx.circle(themeX + themeSize/2, themeY + themeSize/2, themeSize/3, 1, 1)
        for i = 0, 7 do
            local angle = i * math.pi / 4
            local x1 = themeX + themeSize/2 + math.cos(angle) * (themeSize/3 + 2)
            local y1 = themeY + themeSize/2 + math.sin(angle) * (themeSize/3 + 2)
            local x2 = themeX + themeSize/2 + math.cos(angle) * (themeSize/2 - 1)
            local y2 = themeY + themeSize/2 + math.sin(angle) * (themeSize/2 - 1)
            gfx.line(x1, y1, x2, y2)
        end
    end

    if themeHover and mouseDown and not messageWindowState.wasMouseDown then
        SETTINGS.darkMode = not SETTINGS.darkMode
        updateTheme()
        saveSettings()
    end

    -- Language toggle button (small text showing current language)
    local langW = PS(22)
    local langH = PS(14)
    local langX = themeX - langW - PS(6)
    local langY = themeY + (themeSize - langH) / 2
    local langHover = mx >= langX and mx <= langX + langW and my >= langY and my <= langY + langH

    -- Draw language indicator
    gfx.setfont(1, "Arial", PS(9), string.byte('b'))
    local langCode = string.upper(SETTINGS.language or "EN")
    local langTextW = gfx.measurestr(langCode)

    if langHover then
        gfx.set(0.4, 0.6, 0.9, 1)
    else
        gfx.set(THEME.textDim[1], THEME.textDim[2], THEME.textDim[3], 0.8)
    end
    gfx.x = langX + (langW - langTextW) / 2
    gfx.y = langY
    gfx.drawstr(langCode)

    -- Handle language toggle click
    if langHover and mouseDown and not messageWindowState.wasMouseDown then
        -- Cycle through languages: en -> nl -> de -> en
        local langs = {"en", "nl", "de"}
        local currentIdx = 1
        for i, l in ipairs(langs) do
            if l == SETTINGS.language then currentIdx = i break end
        end
        local nextIdx = (currentIdx % #langs) + 1
        setLanguage(langs[nextIdx])
        saveSettings()
    end

    -- === FX TOGGLE (below theme icon) ===
    local fxSize = PS(16)
    local fxX = themeX + (themeSize - fxSize) / 2
    local fxY = themeY + themeSize + PS(3)
    local fxHover = mx >= fxX - PS(2) and mx <= fxX + fxSize + PS(2) and my >= fxY - PS(2) and my <= fxY + fxSize + PS(2)

    local fxAlpha = fxHover and 1 or 0.7
    if SETTINGS.visualFX then
        gfx.set(0.4, 0.9, 0.5, fxAlpha)
    else
        gfx.set(0.5, 0.5, 0.5, fxAlpha * 0.6)
    end
    gfx.setfont(1, "Arial", PS(9), string.byte('b'))
    local fxText = "FX"
    local fxTextW = gfx.measurestr(fxText)
    gfx.x = fxX + (fxSize - fxTextW) / 2
    gfx.y = fxY + PS(1)
    gfx.drawstr(fxText)

    if SETTINGS.visualFX then
        gfx.set(1, 1, 0.5, fxAlpha * 0.8)
        gfx.circle(fxX - PS(1), fxY + PS(2), PS(1.5), 1, 1)
        gfx.circle(fxX + fxSize, fxY + fxSize - PS(2), PS(1.5), 1, 1)
    else
        gfx.set(0.8, 0.3, 0.3, fxAlpha)
        gfx.line(fxX - PS(1), fxY + fxSize / 2, fxX + fxSize + PS(1), fxY + fxSize / 2)
    end

    if fxHover and mouseDown and not messageWindowState.wasMouseDown then
        SETTINGS.visualFX = not SETTINGS.visualFX
        saveSettings()
    end

    -- Track tooltip
    local tooltipText = nil
    local tooltipX, tooltipY = 0, 0

    if themeHover then
        tooltipText = SETTINGS.darkMode and T("switch_light") or T("switch_dark")
        tooltipX = mx + PS(10)
        tooltipY = my + PS(15)
    elseif langHover then
        tooltipText = T("tooltip_change_language")
        tooltipX = mx + PS(10)
        tooltipY = my + PS(15)
    elseif fxHover then
        tooltipText = SETTINGS.visualFX and T("fx_disable") or T("fx_enable")
        tooltipX = mx + PS(10)
        tooltipY = my + PS(15)
    end

    local time = os.clock() - messageWindowState.startTime

    -- === STEMperator Logo (large, centered, ABOVE waveform) ===
    gfx.setfont(1, "Arial", PS(28), string.byte('b'))
    local logoY = PS(35)

    local logoLetters = {"S", "T", "E", "M", "p", "e", "r", "a", "t", "o", "r"}
    local logoWidths = {}
    local logoTotalWidth = 0
    for i, letter in ipairs(logoLetters) do
        local lw = gfx.measurestr(letter)
        logoWidths[i] = lw
        logoTotalWidth = logoTotalWidth + lw
    end
    local logoX = (w - logoTotalWidth) / 2

    -- Draw each letter with subtle animation
    for i, letter in ipairs(logoLetters) do
        local yOffset = math.sin(time * 3 + i * 0.5) * PS(2)
        if i <= 4 then
            gfx.set(stemColors[i][1], stemColors[i][2], stemColors[i][3], 1)
        else
            gfx.set(THEME.text[1], THEME.text[2], THEME.text[3], 0.9)
        end
        gfx.x = logoX
        gfx.y = logoY + yOffset
        gfx.drawstr(letter)
        logoX = logoX + logoWidths[i]
    end

    -- === Tagline (ABOVE waveform) ===
    gfx.setfont(1, "Arial", PS(11))
    gfx.set(THEME.textDim[1], THEME.textDim[2], THEME.textDim[3], 1)
    local tagline = "AI-Powered Stem Separation"
    local tagW = gfx.measurestr(tagline)
    gfx.x = (w - tagW) / 2
    gfx.y = PS(68)
    gfx.drawstr(tagline)

    -- === Animated waveform visualization (BELOW tagline) ===
    local waveY = PS(95)
    local waveH = PS(50)
    local waveW = w - PS(60)
    local waveX = PS(30)

    -- Draw 4 layered waveforms (one for each stem color)
    for stemIdx = 1, 4 do
        local color = stemColors[stemIdx]
        gfx.set(color[1], color[2], color[3], 0.4)

        local freq = 2 + stemIdx * 0.7
        local amp = waveH / 4 * (1 - (stemIdx - 1) * 0.15)
        local phase = time * 2 + stemIdx * 1.5

        local prevX, prevY
        for i = 0, waveW do
            local x = waveX + i
            local t = i / waveW * math.pi * freq + phase
            local y = waveY + waveH/2 + math.sin(t) * amp * math.sin(i / waveW * math.pi)

            if prevX then
                gfx.line(prevX, prevY, x, y)
            end
            prevX, prevY = x, y
        end
    end

    -- === Four stem icons ===
    local iconY = PS(170)
    local iconSpacing = PS(70)
    local iconStartX = (w - iconSpacing * 3) / 2
    local stemNames = {T("vocals"), T("drums"), T("bass"), T("other")}
    local stemSymbols = {"V", "D", "B", "O"}

    for i = 1, 4 do
        local ix = iconStartX + (i-1) * iconSpacing
        local pulseScale = 1 + math.sin(time * 4 + i) * 0.1

        -- Colored circle
        gfx.set(stemColors[i][1], stemColors[i][2], stemColors[i][3], 0.8)
        gfx.circle(ix, iconY, PS(16) * pulseScale, 1, 1)

        -- Letter
        gfx.set(1, 1, 1, 1)
        gfx.setfont(1, "Arial", PS(14), string.byte('b'))
        local symW = gfx.measurestr(stemSymbols[i])
        gfx.x = ix - symW/2
        gfx.y = iconY - PS(6)
        gfx.drawstr(stemSymbols[i])

        -- Label
        gfx.setfont(1, "Arial", PS(9))
        gfx.set(stemColors[i][1], stemColors[i][2], stemColors[i][3], 1)
        local nameW = gfx.measurestr(stemNames[i])
        gfx.x = ix - nameW/2
        gfx.y = iconY + PS(20)
        gfx.drawstr(stemNames[i])
    end

    -- === Message (animated, bold, pulsing) ===
    gfx.setfont(1, "Arial", PS(14), string.byte('b'))

    -- Pulsing effect: oscillate between dim and bright
    local pulseAlpha = 0.6 + math.sin(time * 3) * 0.4

    -- Gradient through STEM colors
    local colorPhase = (time * 0.5) % 4
    local colorIdx = math.floor(colorPhase) + 1
    local nextColorIdx = (colorIdx % 4) + 1
    local colorBlend = colorPhase % 1

    local r = stemColors[colorIdx][1] * (1 - colorBlend) + stemColors[nextColorIdx][1] * colorBlend
    local g = stemColors[colorIdx][2] * (1 - colorBlend) + stemColors[nextColorIdx][2] * colorBlend
    local b = stemColors[colorIdx][3] * (1 - colorBlend) + stemColors[nextColorIdx][3] * colorBlend

    gfx.set(r, g, b, pulseAlpha)

    local msg = T("select_audio")
    local msgW = gfx.measurestr(msg)
    local msgX = (w - msgW) / 2
    gfx.x = msgX
    gfx.y = PS(240)
    gfx.drawstr(msg)

    -- Tooltip for message area
    local msgHover = mx >= msgX and mx <= msgX + msgW and my >= PS(240) and my <= PS(240) + PS(16)
    if msgHover and not tooltipText then
        tooltipText = T("select_audio_tooltip")
        tooltipX = mx + PS(10)
        tooltipY = my + PS(15)
    end

    -- Subtle underline animation (growing/shrinking)
    local underlineW = msgW * (0.5 + math.sin(time * 2) * 0.3)
    local underlineX = (w - underlineW) / 2
    gfx.set(r, g, b, pulseAlpha * 0.5)
    gfx.line(underlineX, PS(258), underlineX + underlineW, PS(258))

    -- Shared button dimensions for consistency
    local btnW = PS(70)
    local btnH = PS(20)
    local btnSpacing = PS(10)
    local totalBtnsW = btnW * 2 + btnSpacing
    local btnY = h - PS(40)

    -- Help button (blue, left)
    local helpBtnX = (w - totalBtnsW) / 2
    local helpHover = mx >= helpBtnX and mx <= helpBtnX + btnW and my >= btnY and my <= btnY + btnH

    if helpHover then
        gfx.set(0.3, 0.5, 0.8, 1)  -- Brighter blue on hover
    else
        gfx.set(0.2, 0.4, 0.7, 0.9)  -- Blue
    end
    -- Draw rounded (pill-shaped) button
    for i = 0, btnH - 1 do
        local radius = btnH / 2
        local inset = 0
        if i < radius then
            inset = radius - math.sqrt(math.max(0, radius * radius - (radius - i) * (radius - i)))
        elseif i > btnH - radius then
            inset = radius - math.sqrt(math.max(0, radius * radius - (i - (btnH - radius)) * (i - (btnH - radius))))
        end
        gfx.line(helpBtnX + inset, btnY + i, helpBtnX + btnW - inset, btnY + i)
    end
    gfx.set(1, 1, 1, 1)
    gfx.setfont(1, "Arial", PS(13), string.byte('b'))
    local helpText = T("help")
    local helpTextW = gfx.measurestr(helpText)
    gfx.x = helpBtnX + (btnW - helpTextW) / 2
    gfx.y = btnY + (btnH - PS(13)) / 2
    gfx.drawstr(helpText)

    -- Help button tooltip
    if helpHover and not tooltipText then
        tooltipText = T("help_tooltip")
        tooltipX = mx + PS(10)
        tooltipY = my + PS(15)
    end

    -- Close button (red, right)
    local btnX = helpBtnX + btnW + btnSpacing
    local hover = mx >= btnX and mx <= btnX + btnW and my >= btnY and my <= btnY + btnH

    -- Red button color
    if hover then
        gfx.set(0.9, 0.3, 0.3, 1)
    else
        gfx.set(0.7, 0.2, 0.2, 1)
    end
    -- Draw rounded (pill-shaped) button
    for i = 0, btnH - 1 do
        local radius = btnH / 2
        local inset = 0
        if i < radius then
            inset = radius - math.sqrt(radius * radius - (radius - i) * (radius - i))
        elseif i > btnH - radius then
            inset = radius - math.sqrt(radius * radius - (i - (btnH - radius)) * (i - (btnH - radius)))
        end
        gfx.line(btnX + inset, btnY + i, btnX + btnW - inset, btnY + i)
    end

    gfx.set(1, 1, 1, 1)
    gfx.setfont(1, "Arial", PS(13), string.byte('b'))
    local closeText = T("close")
    local closeW = gfx.measurestr(closeText)
    gfx.x = btnX + (btnW - closeW) / 2
    gfx.y = btnY + (btnH - PS(13)) / 2
    gfx.drawstr(closeText)

    -- Close button tooltip
    if hover and not tooltipText then
        tooltipText = T("exit_tooltip")
        tooltipX = mx + PS(10)
        tooltipY = my + PS(15)
    end

    -- Hint at very bottom edge (different hint for monitoring mode)
    gfx.set(THEME.textHint[1], THEME.textHint[2], THEME.textHint[3], 1)
    gfx.setfont(1, "Arial", PS(9))
    local hint
    if messageWindowState.monitorSelection then
        hint = T("hint_monitor")
    else
        hint = T("hint_keys")
    end
    local hintW = gfx.measurestr(hint)
    gfx.x = (w - hintW) / 2
    gfx.y = h - PS(12)
    gfx.drawstr(hint)

    -- flarkAUDIO logo at top (translucent) - "flark" regular, "AUDIO" bold
    gfx.setfont(1, "Arial", PS(10))
    local flarkPart = "flark"
    local flarkPartW = gfx.measurestr(flarkPart)
    gfx.setfont(1, "Arial", PS(10), string.byte('b'))
    local audioPart = "AUDIO"
    local audioPartW = gfx.measurestr(audioPart)
    local totalLogoW = flarkPartW + audioPartW
    local logoStartX = (w - totalLogoW) / 2
    -- Orange text, 50% translucent
    gfx.set(1.0, 0.5, 0.1, 0.5)
    gfx.setfont(1, "Arial", PS(10))
    gfx.x = logoStartX
    gfx.y = PS(3)
    gfx.drawstr(flarkPart)
    gfx.setfont(1, "Arial", PS(10), string.byte('b'))
    gfx.x = logoStartX + flarkPartW
    gfx.y = PS(3)
    gfx.drawstr(audioPart)

    -- Draw tooltip if active (with STEM colors)
    if tooltipText then
        gfx.setfont(1, "Arial", PS(11))
        local padding = PS(8)
        local tw = gfx.measurestr(tooltipText) + padding * 2
        local th = PS(18) + padding * 2
        local tx = tooltipX
        local ty = tooltipY

        -- Keep tooltip on screen
        if tx + tw > w then
            tx = w - tw - PS(5)
        end
        if ty + th > h then
            ty = tooltipY - th - PS(20)
        end

        -- Background (theme-aware)
        gfx.set(THEME.inputBg[1], THEME.inputBg[2], THEME.inputBg[3], 0.98)
        gfx.rect(tx, ty, tw, th, 1)

        -- Colored top border (STEM colors gradient)
        for i = 0, tw - 1 do
            local colorIdx = math.floor(i / tw * 4) + 1
            colorIdx = math.min(4, math.max(1, colorIdx))
            local c = STEM_BORDER_COLORS[colorIdx]
            gfx.set(c[1]/255, c[2]/255, c[3]/255, 0.9)
            gfx.line(tx + i, ty, tx + i, ty + 2)
        end

        -- Border (theme-aware)
        gfx.set(THEME.border[1], THEME.border[2], THEME.border[3], 1)
        gfx.rect(tx, ty, tw, th, 0)

        -- Text (theme-aware)
        gfx.set(THEME.text[1], THEME.text[2], THEME.text[3], 1)
        gfx.x = tx + padding
        gfx.y = ty + padding + PS(2)
        gfx.drawstr(tooltipText)
    end

    gfx.update()

    -- Handle clicks
    if mouseDown and not messageWindowState.wasMouseDown then
        if helpHover then
            return "artgallery"
        elseif hover then
            return "close"
        end
    end

    messageWindowState.wasMouseDown = mouseDown

    local char = gfx.getchar()

    -- If window is closed (char == -1), exit
    if char == -1 then
        return "close"
    end

    -- ESC always closes
    if char == 27 then
        return "close"
    end

    -- F1 opens art gallery
    if char == 26161 then
        return "artgallery"
    end

    -- Space = generate new animation (like in Gallery)
    if char == 32 then
        generateNewArt()
        -- Reset art view
        messageWindowState.artZoom = 1.0
        messageWindowState.artPanX = 0
        messageWindowState.artPanY = 0
        messageWindowState.artRotation = 0
        return nil
    end

    -- Enter only closes if NOT in selection monitoring mode
    -- (In monitoring mode, user should select audio first, not just press Enter)
    if not messageWindowState.monitorSelection then
        if char == 13 then
            return "close"
        end
    end

    return nil
end

-- Check if there's any valid selection for processing
local function hasAnySelection()
    -- Check for time selection
    if hasTimeSelection() then return true end
    -- Check for selected items
    if reaper.CountSelectedMediaItems(0) > 0 then return true end
    -- Check for selected tracks with items
    local selTrackCount = reaper.CountSelectedTracks(0)
    if selTrackCount > 0 then
        for t = 0, selTrackCount - 1 do
            local track = reaper.GetSelectedTrack(0, t)
            if reaper.CountTrackMediaItems(track) > 0 then
                return true
            end
        end
    end
    return false
end

-- Message window loop
local function messageWindowLoop()
    -- Save window position for next time
    if reaper.JS_Window_Find then
        local hwnd = reaper.JS_Window_Find("Stemperator", true)
        if hwnd then
            local retval, left, top, right, bottom = reaper.JS_Window_GetRect(hwnd)
            if retval then
                lastDialogX = left
                lastDialogY = top
                lastDialogW = right - left
                lastDialogH = bottom - top
            end
        end
    end

    -- If monitoring for selection, check if user made a selection
    -- But DON'T transition while user is still dragging (mouse button held)
    -- This prevents stealing focus while user is making a time selection
    local hasSel = hasAnySelection()
    if messageWindowState.monitorSelection and hasSel then
        -- Check if mouse button is currently held down (user still dragging)
        local mouseState = reaper.JS_Mouse_GetState and reaper.JS_Mouse_GetState(1) or 0
        local mouseHeld = (mouseState & 1) == 1  -- Left mouse button

        if not mouseHeld then
            -- Mouse released, safe to transition
            -- Save window position/size before transitioning
            saveSettings()
            gfx.quit()
            messageWindowState.monitorSelection = false
            -- Re-run main to open the dialog with the new selection
            -- Then return focus to REAPER so user can continue working
            reaper.defer(function()
                main()
                -- Return focus to REAPER main window after opening dialog
                local mainHwnd = reaper.GetMainHwnd()
                if mainHwnd and reaper.JS_Window_SetFocus then
                    reaper.JS_Window_SetFocus(mainHwnd)
                end
            end)
            return
        end
        -- If mouse is held, don't transition yet - keep monitoring
    end

    local result = drawMessageWindow()
    if result == "close" then
        -- Save window position/size before closing
        saveSettings()
        gfx.quit()
        messageWindowState.monitorSelection = false
        -- Return focus to REAPER main window
        local mainHwnd = reaper.GetMainHwnd()
        if mainHwnd then
            reaper.JS_Window_SetFocus(mainHwnd)
        end
        return
    elseif result == "artgallery" then
        -- Save window position/size before switching to art gallery
        saveSettings()
        gfx.quit()
        messageWindowState.monitorSelection = false
        -- Open Art Gallery - track that it came from start screen
        helpState.openedFrom = "start"
        showArtGallery()
        return
    end
    reaper.defer(messageWindowLoop)
end

-- Show a styled message window (replacement for reaper.MB)
-- icon: "info", "warning", "error"
-- monitorSelection: if true, window will auto-close and open main dialog when user makes a selection
showMessage = function(title, message, icon, monitorSelection)
    -- Load settings to get current theme
    loadSettings()
    updateTheme()

    messageWindowState.title = title or "Stemperator"
    messageWindowState.message = message or ""
    messageWindowState.icon = icon or "info"
    messageWindowState.wasMouseDown = false
    messageWindowState.startTime = os.clock()
    messageWindowState.monitorSelection = monitorSelection or false

    -- Use same size as main dialog
    local winW = lastDialogW or 380
    local winH = lastDialogH or 340
    local winX, winY

    -- Use last dialog position if available (exact position, no clamping)
    if lastDialogX and lastDialogY then
        winX = lastDialogX
        winY = lastDialogY
    else
        -- Fallback to mouse position with clamping
        local mouseX, mouseY = reaper.GetMousePosition()
        winX = mouseX - winW / 2
        winY = mouseY - winH / 2
        winX, winY = clampToScreen(winX, winY, winW, winH, mouseX, mouseY)
    end

    gfx.init("Stemperator", winW, winH, 0, winX, winY)
    reaper.defer(messageWindowLoop)
end

-- Scaling helper: converts base coordinates to current scale
local function S(val)
    return math.floor(val * GUI.scale + 0.5)
end

-- Calculate current scale based on window size
local function updateScale()
    local scaleW = gfx.w / GUI.baseW
    local scaleH = gfx.h / GUI.baseH
    GUI.scale = math.min(scaleW, scaleH)
    -- Clamp scale (1.0 to 4.0)
    GUI.scale = math.max(1.0, math.min(4.0, GUI.scale))
end

-- Track if we've made window resizable
local windowResizableSet = false

-- Make window resizable using JS_ReaScriptAPI (if available)
local function makeWindowResizable()
    if windowResizableSet then return true end
    if not reaper.JS_Window_Find then return false end

    -- Find the gfx window
    local hwnd = reaper.JS_Window_Find(SCRIPT_NAME, true)
    if not hwnd then return false end

    -- On Linux/X11, use different approach - set window hints
    if OS == "Linux" then
        -- For Linux, we need to modify GDK window properties
        -- js_ReaScriptAPI doesn't directly support this, but we can try
        local style = reaper.JS_Window_GetLong(hwnd, "STYLE")
        if style then
            -- Try to add resize style bits
            reaper.JS_Window_SetLong(hwnd, "STYLE", style | 0x00040000 | 0x00010000)
        end
    else
        -- Windows: add WS_THICKFRAME and WS_MAXIMIZEBOX
        local style = reaper.JS_Window_GetLong(hwnd, "STYLE")
        local WS_THICKFRAME = 0x00040000
        local WS_MAXIMIZEBOX = 0x00010000
        reaper.JS_Window_SetLong(hwnd, "STYLE", style | WS_THICKFRAME | WS_MAXIMIZEBOX)
    end

    windowResizableSet = true
    return true
end

-- Tooltip helper: set tooltip if mouse is in area
local function setTooltip(x, y, w, h, text)
    local mx, my = gfx.mouse_x, gfx.mouse_y
    if mx >= x and mx <= x + w and my >= y and my <= y + h then
        GUI.tooltip = text
        GUI.tooltipX = mx + S(10)
        GUI.tooltipY = my + S(15)
    end
end

-- Set a rich tooltip for STEMperate button with colored output stems and target
local function setRichTooltip(x, y, w, h)
    local mx, my = gfx.mouse_x, gfx.mouse_y
    if mx >= x and mx <= x + w and my >= y and my <= y + h then
        GUI.richTooltip = true
        GUI.tooltipX = mx + S(10)
        GUI.tooltipY = my + S(15)
    end
end

-- Set a tooltip with keyboard shortcut highlighted in color
-- shortcut: the key (e.g. "K", "V", "1")
-- color: RGB table for the shortcut color (e.g. {255, 100, 100})
local function setTooltipWithShortcut(x, y, w, h, text, shortcut, color)
    local mx, my = gfx.mouse_x, gfx.mouse_y
    if mx >= x and mx <= x + w and my >= y and my <= y + h then
        GUI.shortcutTooltip = {
            text = text,
            shortcut = shortcut,
            color = color or {255, 200, 100}  -- Default orange/yellow
        }
        GUI.tooltipX = mx + S(10)
        GUI.tooltipY = my + S(15)
    end
end

-- Draw the current tooltip (call at end of frame)
local function drawTooltip()
    -- Rich tooltip for STEMperate button
    if GUI.richTooltip then
        gfx.setfont(1, "Arial", S(10))
        local padding = S(8)
        local lineH = S(14)

        -- Use global STEM border colors
        local titleColors = STEM_BORDER_COLORS

        -- Build selected stems list (use actual STEMS data)
        local selectedStems = {}
        for i, stem in ipairs(STEMS) do
            if stem.selected and (not stem.sixStemOnly or SETTINGS.model == "htdemucs_6s") then
                table.insert(selectedStems, {name = stem.name, color = stem.color})
            end
        end

        -- Get target info
        local targetText = "New tracks"
        if SETTINGS.deleteOriginal then targetText = "Delete original"
        elseif SETTINGS.deleteSelection then targetText = "Delete selection"
        elseif SETTINGS.muteOriginal then targetText = "Mute original"
        elseif SETTINGS.muteSelection then targetText = "Mute selection"
        end
        if SETTINGS.createFolder then targetText = targetText .. " + folder" end

        -- Count selection info
        local selTrackCount = reaper.CountSelectedTracks(0)
        local selItemCount = 0
        for i = 0, selTrackCount - 1 do
            local track = reaper.GetSelectedTrack(0, i)
            selItemCount = selItemCount + reaper.CountTrackMediaItems(track)
        end

        -- Calculate tooltip size (5 lines: header, stems, selection, takes, target)
        local th = padding * 2 + lineH * 5 + S(10)

        -- Fixed label column width
        local labelColW = S(65)

        -- Measure line widths (value column only)
        gfx.setfont(1, "Arial", S(10), string.byte('b'))
        local stemsValueW = 0
        for i, stem in ipairs(selectedStems) do
            stemsValueW = stemsValueW + gfx.measurestr(stem.name)
            if i < #selectedStems then stemsValueW = stemsValueW + gfx.measurestr(" ") end
        end

        gfx.setfont(1, "Arial", S(10))
        local selectionText = string.format("%d track%s, %d item%s",
            selTrackCount, selTrackCount == 1 and "" or "s",
            selItemCount, selItemCount == 1 and "" or "s")
        local selValueW = gfx.measurestr(selectionText)
        local takesText = SETTINGS.createTakes and "Yes" or "No"
        local takesValueW = gfx.measurestr(takesText)
        local targetValueW = gfx.measurestr(targetText)

        -- Measure header
        gfx.setfont(1, "Arial", S(11), string.byte('b'))
        local headerText = T("click_to_stemperate")
        local headerLineW = gfx.measurestr(headerText)

        -- Calculate max value width needed
        local maxValueW = math.max(stemsValueW, selValueW, takesValueW, targetValueW)
        -- Total width = padding + label column + value column + padding
        local tw = math.max(headerLineW + padding * 2, padding + labelColW + maxValueW + padding)

        local tx = GUI.tooltipX
        local ty = GUI.tooltipY

        -- Keep tooltip on screen
        if tx + tw > gfx.w then tx = gfx.w - tw - S(5) end
        if ty + th > gfx.h then ty = GUI.tooltipY - th - S(20) end

        -- Background (theme-aware)
        gfx.set(THEME.inputBg[1], THEME.inputBg[2], THEME.inputBg[3], 0.98)
        gfx.rect(tx, ty, tw, th, 1)

        -- Colored top border (stem colors gradient)
        for i = 0, tw - 1 do
            local colorIdx = math.floor(i / tw * 4) + 1
            colorIdx = math.min(4, math.max(1, colorIdx))
            local c = titleColors[colorIdx]
            gfx.set(c[1]/255, c[2]/255, c[3]/255, 0.9)
            gfx.line(tx + i, ty, tx + i, ty + 2)
        end

        -- Border (theme-aware)
        gfx.set(THEME.border[1], THEME.border[2], THEME.border[3], 1)
        gfx.rect(tx, ty, tw, th, 0)

        local labelX = tx + padding
        local valueX = tx + padding + labelColW
        local currentY = ty + padding + S(2)

        -- Header: Click to STEMperate (centered, colored letters)
        gfx.setfont(1, "Arial", S(11), string.byte('b'))
        local headerW = gfx.measurestr(headerText)
        local headerX = tx + (tw - headerW) / 2
        gfx.x = headerX
        gfx.y = currentY

        -- Draw "Click to " in theme text color
        gfx.set(THEME.text[1], THEME.text[2], THEME.text[3], 1)
        gfx.drawstr("Click to ")
        -- Draw "STEM" with colored letters
        local stemLetters = {"S", "T", "E", "M"}
        for i, letter in ipairs(stemLetters) do
            local c = titleColors[i]
            gfx.set(c[1]/255, c[2]/255, c[3]/255, 1)
            gfx.drawstr(letter)
        end
        -- Draw "perate" in theme text color
        gfx.set(THEME.text[1], THEME.text[2], THEME.text[3], 1)
        gfx.drawstr("perate")
        currentY = currentY + lineH + S(4)

        -- Line 1: Stems (colored)
        gfx.setfont(1, "Arial", S(10))
        gfx.set(THEME.textHint[1], THEME.textHint[2], THEME.textHint[3], 1)
        gfx.x = labelX
        gfx.y = currentY
        gfx.drawstr("Stems")

        gfx.setfont(1, "Arial", S(10), string.byte('b'))
        local stemX = valueX
        for i, stem in ipairs(selectedStems) do
            gfx.set(stem.color[1]/255, stem.color[2]/255, stem.color[3]/255, 1)
            gfx.x = stemX
            gfx.y = currentY
            gfx.drawstr(stem.name)
            stemX = stemX + gfx.measurestr(stem.name)
            if i < #selectedStems then
                gfx.set(THEME.textHint[1], THEME.textHint[2], THEME.textHint[3], 1)
                gfx.x = stemX
                gfx.drawstr(" ")
                stemX = stemX + gfx.measurestr(" ")
            end
        end
        currentY = currentY + lineH

        -- Line 2: Selection
        gfx.setfont(1, "Arial", S(10))
        gfx.set(THEME.textHint[1], THEME.textHint[2], THEME.textHint[3], 1)
        gfx.x = labelX
        gfx.y = currentY
        gfx.drawstr("Selection")
        gfx.set(THEME.text[1], THEME.text[2], THEME.text[3], 1)
        gfx.x = valueX
        gfx.drawstr(selectionText)
        currentY = currentY + lineH

        -- Line 3: Takes
        gfx.set(THEME.textHint[1], THEME.textHint[2], THEME.textHint[3], 1)
        gfx.x = labelX
        gfx.y = currentY
        gfx.drawstr("Takes")
        if SETTINGS.createTakes then
            gfx.set(0.4, 0.9, 0.5, 1)  -- Green for yes
        else
            gfx.set(THEME.textDim[1], THEME.textDim[2], THEME.textDim[3], 1)  -- Dim for no
        end
        gfx.x = valueX
        gfx.drawstr(takesText)
        currentY = currentY + lineH

        -- Line 4: Target
        gfx.set(THEME.textHint[1], THEME.textHint[2], THEME.textHint[3], 1)
        gfx.x = labelX
        gfx.y = currentY
        gfx.drawstr("Target")
        gfx.set(1.0, 0.6, 0.2, 1)  -- Orange for target (stays colored)
        gfx.x = valueX
        gfx.drawstr(targetText)

        GUI.richTooltip = nil
    elseif GUI.tooltip then
        -- Use global STEM border colors
        local tooltipColors = STEM_BORDER_COLORS

        gfx.setfont(1, "Arial", S(11))
        local padding = S(8)
        local tw = gfx.measurestr(GUI.tooltip) + padding * 2
        local th = S(18) + padding * 2
        local tx = GUI.tooltipX
        local ty = GUI.tooltipY

        -- Keep tooltip on screen
        if tx + tw > gfx.w then
            tx = gfx.w - tw - S(5)
        end
        if ty + th > gfx.h then
            ty = GUI.tooltipY - th - S(20)
        end

        -- Background (theme-aware)
        gfx.set(THEME.inputBg[1], THEME.inputBg[2], THEME.inputBg[3], 0.98)
        gfx.rect(tx, ty, tw, th, 1)

        -- Colored top border (stem colors gradient)
        for i = 0, tw - 1 do
            local colorIdx = math.floor(i / tw * 4) + 1
            colorIdx = math.min(4, math.max(1, colorIdx))
            local c = tooltipColors[colorIdx]
            gfx.set(c[1]/255, c[2]/255, c[3]/255, 0.9)
            gfx.line(tx + i, ty, tx + i, ty + 2)
        end

        -- Border (theme-aware)
        gfx.set(THEME.border[1], THEME.border[2], THEME.border[3], 1)
        gfx.rect(tx, ty, tw, th, 0)

        -- Text (theme-aware)
        gfx.set(THEME.text[1], THEME.text[2], THEME.text[3], 1)
        gfx.x = tx + padding
        gfx.y = ty + padding + S(2)
        gfx.drawstr(GUI.tooltip)

        -- Clear tooltip for next frame
        GUI.tooltip = nil
    elseif GUI.shortcutTooltip then
        -- Tooltip with colored keyboard shortcut
        local tooltipColors = STEM_BORDER_COLORS
        local st = GUI.shortcutTooltip

        gfx.setfont(1, "Arial", S(11))
        local padding = S(8)
        local textW = gfx.measurestr(st.text)
        local shortcutW = gfx.measurestr(" [" .. st.shortcut .. "]")
        local tw = textW + shortcutW + padding * 2
        local th = S(18) + padding * 2
        local tx = GUI.tooltipX
        local ty = GUI.tooltipY

        -- Keep tooltip on screen
        if tx + tw > gfx.w then
            tx = gfx.w - tw - S(5)
        end
        if ty + th > gfx.h then
            ty = GUI.tooltipY - th - S(20)
        end

        -- Background (theme-aware)
        gfx.set(THEME.inputBg[1], THEME.inputBg[2], THEME.inputBg[3], 0.98)
        gfx.rect(tx, ty, tw, th, 1)

        -- Colored top border (stem colors gradient)
        for i = 0, tw - 1 do
            local colorIdx = math.floor(i / tw * 4) + 1
            colorIdx = math.min(4, math.max(1, colorIdx))
            local c = tooltipColors[colorIdx]
            gfx.set(c[1]/255, c[2]/255, c[3]/255, 0.9)
            gfx.line(tx + i, ty, tx + i, ty + 2)
        end

        -- Border (theme-aware)
        gfx.set(THEME.border[1], THEME.border[2], THEME.border[3], 1)
        gfx.rect(tx, ty, tw, th, 0)

        -- Text (theme-aware)
        gfx.set(THEME.text[1], THEME.text[2], THEME.text[3], 1)
        gfx.x = tx + padding
        gfx.y = ty + padding + S(2)
        gfx.drawstr(st.text .. " ")

        -- Shortcut in color
        gfx.set(st.color[1]/255, st.color[2]/255, st.color[3]/255, 1)
        gfx.drawstr("[" .. st.shortcut .. "]")

        -- Clear tooltip for next frame
        GUI.shortcutTooltip = nil
    end
end

-- Draw a checkbox as a toggle box (like stems/presets) and return if it was clicked (scaled)
-- Optional fixedW parameter to set a fixed width for all boxes
local function drawCheckbox(x, y, checked, label, r, g, b, fixedW)
    local clicked = false
    local labelWidth = gfx.measurestr(label)
    local boxW = fixedW or (labelWidth + S(16))
    local boxH = S(20)
    local mx, my = gfx.mouse_x, gfx.mouse_y
    local mouseDown = gfx.mouse_cap & 1 == 1
    local hover = mx >= x and mx <= x + boxW and my >= y and my <= y + boxH

    if mouseDown and hover then
        if not GUI.wasMouseDown then clicked = true end
    end

    -- Background color based on checked state
    if checked then
        local mult = hover and 1.2 or 1.0
        gfx.set(r/255 * mult, g/255 * mult, b/255 * mult, 1)
    else
        local brightness = hover and 0.35 or 0.25
        gfx.set(brightness, brightness, brightness, 1)
    end
    gfx.rect(x, y, boxW, boxH, 1)

    -- Border
    gfx.set(THEME.border[1], THEME.border[2], THEME.border[3], 1)
    gfx.rect(x, y, boxW, boxH, 0)

    -- Text - white for contrast
    gfx.set(1, 1, 1, 1)
    local tw = gfx.measurestr(label)
    gfx.x = x + (boxW - tw) / 2
    gfx.y = y + (boxH - S(14)) / 2
    gfx.drawstr(label)

    return clicked, boxW
end

-- Draw a radio button as a toggle box (like stems/presets) and return if it was clicked (scaled)
-- Optional fixedW parameter to set a fixed width for all boxes
local function drawRadio(x, y, selected, label, color, fixedW)
    local clicked = false
    local labelWidth = gfx.measurestr(label)
    local boxW = fixedW or (labelWidth + S(16))
    local boxH = S(20)
    local mx, my = gfx.mouse_x, gfx.mouse_y
    local mouseDown = gfx.mouse_cap & 1 == 1
    local hover = mx >= x and mx <= x + boxW and my >= y and my <= y + boxH

    if mouseDown and hover then
        if not GUI.wasMouseDown then clicked = true end
    end

    -- Use provided color or default accent color
    local r, g, b = THEME.accent[1] * 255, THEME.accent[2] * 255, THEME.accent[3] * 255
    if color then
        r, g, b = color[1], color[2], color[3]
    end

    -- Background color based on selected state
    if selected then
        local mult = hover and 1.2 or 1.0
        gfx.set(r/255 * mult, g/255 * mult, b/255 * mult, 1)
    else
        local brightness = hover and 0.35 or 0.25
        gfx.set(brightness, brightness, brightness, 1)
    end
    gfx.rect(x, y, boxW, boxH, 1)

    -- Border
    gfx.set(THEME.border[1], THEME.border[2], THEME.border[3], 1)
    gfx.rect(x, y, boxW, boxH, 0)

    -- Text - white for contrast
    gfx.set(1, 1, 1, 1)
    local tw = gfx.measurestr(label)
    gfx.x = x + (boxW - tw) / 2
    gfx.y = y + (boxH - S(14)) / 2
    gfx.drawstr(label)

    return clicked, boxW
end

-- Draw a toggle button (like stems) with selected state
local function drawToggleButton(x, y, w, h, label, selected, color)
    local clicked = false
    local mx, my = gfx.mouse_x, gfx.mouse_y
    local mouseDown = gfx.mouse_cap & 1 == 1
    local hover = mx >= x and mx <= x + w and my >= y and my <= y + h

    -- Track that mouse is over a UI element (prevents background art click)
    if hover then GUI.uiClickedThisFrame = true end

    if mouseDown and hover then
        if not GUI.wasMouseDown then clicked = true end
    end

    -- Background color based on selected state
    if selected then
        -- Selected: use the stem color
        local mult = hover and 1.2 or 1.0
        gfx.set(color[1]/255 * mult, color[2]/255 * mult, color[3]/255 * mult, 1)
    else
        -- Not selected: dim gray
        local brightness = hover and 0.35 or 0.25
        gfx.set(brightness, brightness, brightness, 1)
    end
    gfx.rect(x, y, w, h, 1)

    -- Border - brighter when selected
    if selected then
        gfx.set(1, 1, 1, 0.5)
    else
        gfx.set(THEME.border[1], THEME.border[2], THEME.border[3], 1)
    end
    gfx.rect(x, y, w, h, 0)

    -- Button text
    if selected then
        gfx.set(1, 1, 1, 1)
    else
        gfx.set(0.6, 0.6, 0.6, 1)
    end
    local tw = gfx.measurestr(label)
    gfx.x = x + (w - tw) / 2
    gfx.y = y + (h - S(14)) / 2
    gfx.drawstr(label)

    return clicked
end

-- Draw a small button and return if it was clicked (scaled)
local function drawButton(x, y, w, h, label, isDefault, color)
    local clicked = false
    local mx, my = gfx.mouse_x, gfx.mouse_y
    local mouseDown = gfx.mouse_cap & 1 == 1
    local hover = mx >= x and mx <= x + w and my >= y and my <= y + h

    -- Track that mouse is over a UI element (prevents background art click)
    if hover then GUI.uiClickedThisFrame = true end

    if mouseDown and hover then
        if not GUI.wasMouseDown then clicked = true end
    end

    if color then
        -- Custom color provided (e.g., preset buttons)
        local mult = hover and 1.2 or 1.0
        gfx.set(color[1]/255 * mult, color[2]/255 * mult, color[3]/255 * mult, 1)
    else
        -- Use theme colors
        if isDefault then
            if hover then
                gfx.set(THEME.buttonPrimaryHover[1], THEME.buttonPrimaryHover[2], THEME.buttonPrimaryHover[3], 1)
            else
                gfx.set(THEME.buttonPrimary[1], THEME.buttonPrimary[2], THEME.buttonPrimary[3], 1)
            end
        else
            if hover then
                gfx.set(THEME.buttonHover[1], THEME.buttonHover[2], THEME.buttonHover[3], 1)
            else
                gfx.set(THEME.button[1], THEME.button[2], THEME.button[3], 1)
            end
        end
    end

    -- Draw rounded (pill-shaped) button background
    for i = 0, h - 1 do
        local radius = h / 2
        local inset = 0
        if i < radius then
            inset = radius - math.sqrt(radius * radius - (radius - i) * (radius - i))
        elseif i > h - radius then
            inset = radius - math.sqrt(radius * radius - (i - (h - radius)) * (i - (h - radius)))
        end
        gfx.line(x + inset, y + i, x + w - inset, y + i)
    end

    -- Button text - always white for good contrast on colored buttons
    gfx.set(1, 1, 1, 1)
    local tw = gfx.measurestr(label)
    gfx.x = x + (w - tw) / 2
    gfx.y = y + (h - S(14)) / 2
    gfx.drawstr(label)

    return clicked
end

-- Main dialog loop
local function dialogLoop()
    -- Try to make window resizable (needs to be called after window is visible)
    makeWindowResizable()

    -- Save window position continuously (for when window loses focus)
    if reaper.JS_Window_GetRect then
        local hwnd = reaper.JS_Window_Find(SCRIPT_NAME, true)
        if hwnd then
            local retval, left, top, right, bottom = reaper.JS_Window_GetRect(hwnd)
            if retval then
                lastDialogX = left
                lastDialogY = top
                lastDialogW = right - left
                lastDialogH = bottom - top
            end
        end
    end

    -- Check if settings changed and save periodically (throttled to avoid excessive writes)
    if not GUI.lastSaveTime then GUI.lastSaveTime = 0 end
    local now = os.clock()
    if now - GUI.lastSaveTime > 0.5 then  -- Save at most every 0.5 seconds
        saveSettings()
        GUI.lastSaveTime = now
    end

    -- Update scale based on current window size
    updateScale()

    -- Check if selection was lost - switch to "Start" message
    -- Use a counter to require sustained deselection (prevents race conditions)
    -- IMPORTANT: If we're in timeSelectionMode, don't auto-close (time selection was stored at start)
    local hasSel = hasAnySelection() or timeSelectionMode
    if not hasSel then
        GUI.noSelectionFrames = (GUI.noSelectionFrames or 0) + 1
        -- Require 10+ frames (~0.3 sec) of no selection before closing
        if GUI.noSelectionFrames > 10 then
            gfx.quit()
            -- Clear auto-selection tracking (user already deselected everything)
            autoSelectedItems = {}
            autoSelectionTracks = {}
            GUI.noSelectionFrames = 0
            -- Show "Start" with monitoring enabled
            reaper.defer(function() main() end)
            return
        end
    else
        -- Selection exists, reset counter
        GUI.noSelectionFrames = 0
    end

    -- === PROCEDURAL ART BACKGROUND WITH CAMERA CONTROLS ===

    -- Reset UI click tracking for this frame
    GUI.uiClickedThisFrame = false

    -- Initialize art if not yet done
    if proceduralArt.seed == 0 then
        generateNewArt()
    end

    -- Update animation time
    proceduralArt.time = proceduralArt.time + 0.016  -- ~60fps

    -- Smooth camera interpolation
    local smoothing = 0.15
    mainDialogArt.zoom = mainDialogArt.zoom + (mainDialogArt.targetZoom - mainDialogArt.zoom) * smoothing
    mainDialogArt.panX = mainDialogArt.panX + (mainDialogArt.targetPanX - mainDialogArt.panX) * smoothing
    mainDialogArt.panY = mainDialogArt.panY + (mainDialogArt.targetPanY - mainDialogArt.panY) * smoothing
    mainDialogArt.rotation = mainDialogArt.rotation + (mainDialogArt.targetRotation - mainDialogArt.rotation) * smoothing

    -- Get mouse state early for background interaction
    local mx, my = gfx.mouse_x, gfx.mouse_y
    local mouseDown = gfx.mouse_cap & 1 == 1
    local rightMouseDown = gfx.mouse_cap & 2 == 2
    local mouseWheel = gfx.mouse_wheel

    -- === MOUSE INTERACTION FOR BACKGROUND ART ===

    -- Mousewheel zoom
    if mouseWheel ~= 0 then
        local zoomDelta = mouseWheel > 0 and 0.15 or -0.15
        mainDialogArt.targetZoom = math.max(0.3, math.min(5.0, mainDialogArt.targetZoom + zoomDelta))
        gfx.mouse_wheel = 0  -- Consume the wheel event
    end

    -- Right-click drag for rotation
    if rightMouseDown then
        if not mainDialogArt.wasRightMouseDown then
            -- Start rotation
            mainDialogArt.isRotating = true
            mainDialogArt.rotateStartX = mx
            mainDialogArt.rotateStartAngle = mainDialogArt.targetRotation
        elseif mainDialogArt.isRotating then
            -- Continue rotation
            local deltaX = mx - mainDialogArt.rotateStartX
            mainDialogArt.targetRotation = mainDialogArt.rotateStartAngle + deltaX * 0.01
        end
    else
        mainDialogArt.isRotating = false
    end

    -- Left-click: drag for panning OR click+release for next animation
    if mouseDown then
        if not mainDialogArt.wasMouseDown then
            -- Mouse just pressed - record start position for drag/click detection
            mainDialogArt.clickStartX = mx
            mainDialogArt.clickStartY = my
            mainDialogArt.clickStartTime = os.clock()
            mainDialogArt.wasDrag = false
            mainDialogArt.dragStartPanX = mainDialogArt.targetPanX
            mainDialogArt.dragStartPanY = mainDialogArt.targetPanY
        else
            -- Mouse held - check if dragging
            local dragDist = math.sqrt((mx - mainDialogArt.clickStartX)^2 + (my - mainDialogArt.clickStartY)^2)
            if dragDist > 5 then
                -- This is a drag, not a click
                mainDialogArt.wasDrag = true
                mainDialogArt.isDragging = true
                mainDialogArt.targetPanX = mainDialogArt.dragStartPanX + (mx - mainDialogArt.clickStartX)
                mainDialogArt.targetPanY = mainDialogArt.dragStartPanY + (my - mainDialogArt.clickStartY)
            end
        end
    else
        -- Mouse released
        if mainDialogArt.wasMouseDown and not mainDialogArt.wasDrag then
            -- This was a click (not a drag) - but only trigger new art if clicking on background
            -- Check if not clicking on any UI element (we'll check this after UI is drawn)
            local clickDuration = os.clock() - (mainDialogArt.clickStartTime or 0)
            if clickDuration < 0.3 then
                -- Quick click - mark for potential new art (will be processed at end of frame)
                mainDialogArt.pendingNewArt = true
                mainDialogArt.pendingNewArtX = mainDialogArt.clickStartX
                mainDialogArt.pendingNewArtY = mainDialogArt.clickStartY
            end
        end
        mainDialogArt.isDragging = false
    end

    -- Draw full-window background first - pure black/white
    local w, h = gfx.w, gfx.h
    if SETTINGS.darkMode then
        gfx.set(0, 0, 0, 1)
    else
        gfx.set(1, 1, 1, 1)
    end
    gfx.rect(0, 0, w, h, 1)

    -- Draw procedural art spanning entire window (no box)
    -- Zoom/pan/rotation affect internal art rendering via modified parameters
    local artCenterX = w / 2 + mainDialogArt.panX
    local artCenterY = h / 2 + mainDialogArt.panY
    local artRadius = math.max(w, h) * mainDialogArt.zoom

    -- Draw art at full window, skipBackground=true (we already drew pure bg)
    drawProceduralArt(0, 0, w, h, proceduralArt.time, mainDialogArt.rotation, true)

    -- Semi-transparent overlay for UI readability - pure black/white
    if SETTINGS.darkMode then
        gfx.set(0, 0, 0, 0.5)
    else
        gfx.set(1, 1, 1, 0.5)
    end
    gfx.rect(0, 0, w, h, 1)

    -- Track mouse state for next frame
    mainDialogArt.wasMouseDown = mouseDown
    mainDialogArt.wasRightMouseDown = rightMouseDown

    -- Theme toggle button (sun/moon icon, aligned with column 4)
    local themeSize = S(20)
    local themeX = S(260) + S(70) - themeSize  -- col4X + outBoxW - themeSize (right-aligned)
    local themeY = S(8)
    local themeHover = mx >= themeX and mx <= themeX + themeSize and my >= themeY and my <= themeY + themeSize

    -- Draw theme toggle (circle with rays for sun, crescent for moon)
    if SETTINGS.darkMode then
        -- Moon icon (crescent)
        gfx.set(0.7, 0.7, 0.5, themeHover and 1 or 0.6)
        gfx.circle(themeX + themeSize/2, themeY + themeSize/2, themeSize/2 - 2, 1, 1)
        gfx.set(0, 0, 0, 1)  -- Pure black for moon overlay
        gfx.circle(themeX + themeSize/2 + 4, themeY + themeSize/2 - 3, themeSize/2 - 3, 1, 1)
    else
        -- Sun icon
        gfx.set(0.9, 0.7, 0.2, themeHover and 1 or 0.8)
        gfx.circle(themeX + themeSize/2, themeY + themeSize/2, themeSize/3, 1, 1)
        -- Rays
        for i = 0, 7 do
            local angle = i * math.pi / 4
            local x1 = themeX + themeSize/2 + math.cos(angle) * (themeSize/3 + 2)
            local y1 = themeY + themeSize/2 + math.sin(angle) * (themeSize/3 + 2)
            local x2 = themeX + themeSize/2 + math.cos(angle) * (themeSize/2 - 1)
            local y2 = themeY + themeSize/2 + math.sin(angle) * (themeSize/2 - 1)
            gfx.line(x1, y1, x2, y2)
        end
    end

    -- Handle theme toggle click and tooltip
    if themeHover then
        local themeTip = SETTINGS.darkMode and T("switch_light") or T("switch_dark")
        setTooltip(themeX, themeY, themeSize, themeSize, themeTip)
        if mouseDown and not GUI.wasMouseDown then
            SETTINGS.darkMode = not SETTINGS.darkMode
            updateTheme()
            saveSettings()  -- Persist theme change
        end
    end

    -- Language toggle button (small text showing current language)
    local langW = S(22)
    local langH = S(14)
    local langX = themeX - langW - S(6)
    local langY = themeY + (themeSize - langH) / 2
    local langHover = mx >= langX and mx <= langX + langW and my >= langY and my <= langY + langH

    -- Draw language indicator
    gfx.setfont(1, "Arial", S(9), string.byte('b'))
    local langCode = string.upper(SETTINGS.language or "EN")
    local langTextW = gfx.measurestr(langCode)

    if langHover then
        gfx.set(0.4, 0.6, 0.9, 1)
    else
        gfx.set(THEME.textDim[1], THEME.textDim[2], THEME.textDim[3], 0.8)
    end
    gfx.x = langX + (langW - langTextW) / 2
    gfx.y = langY
    gfx.drawstr(langCode)

    -- Handle language toggle click
    if langHover then
        setTooltip(langX, langY, langW, langH, T("tooltip_change_language"))
        if mouseDown and not GUI.wasMouseDown then
            -- Cycle through languages: en -> nl -> de -> en
            local langs = {"en", "nl", "de"}
            local currentIdx = 1
            for i, l in ipairs(langs) do
                if l == SETTINGS.language then currentIdx = i break end
            end
            local nextIdx = (currentIdx % #langs) + 1
            setLanguage(langs[nextIdx])
            saveSettings()
        end
    end

    -- === FX TOGGLE (below theme icon) ===
    local fxSize = S(16)
    local fxX = themeX + (themeSize - fxSize) / 2
    local fxY = themeY + themeSize + S(3)
    local fxHover = mx >= fxX - S(2) and mx <= fxX + fxSize + S(2) and my >= fxY - S(2) and my <= fxY + fxSize + S(2)

    local fxAlpha = fxHover and 1 or 0.7
    if SETTINGS.visualFX then
        gfx.set(0.4, 0.9, 0.5, fxAlpha)
    else
        gfx.set(0.5, 0.5, 0.5, fxAlpha * 0.6)
    end
    gfx.setfont(1, "Arial", S(9), string.byte('b'))
    local fxText = "FX"
    local fxTextW = gfx.measurestr(fxText)
    gfx.x = fxX + (fxSize - fxTextW) / 2
    gfx.y = fxY + S(1)
    gfx.drawstr(fxText)

    if SETTINGS.visualFX then
        gfx.set(1, 1, 0.5, fxAlpha * 0.8)
        gfx.circle(fxX - S(1), fxY + S(2), S(1.5), 1, 1)
        gfx.circle(fxX + fxSize, fxY + fxSize - S(2), S(1.5), 1, 1)
    else
        gfx.set(0.8, 0.3, 0.3, fxAlpha)
        gfx.line(fxX - S(1), fxY + fxSize / 2, fxX + fxSize + S(1), fxY + fxSize / 2)
    end

    if fxHover then
        setTooltip(fxX - S(2), fxY - S(2), fxSize + S(4), fxSize + S(4), SETTINGS.visualFX and T("fx_disable") or T("fx_enable"))
        if mouseDown and not GUI.wasMouseDown then
            SETTINGS.visualFX = not SETTINGS.visualFX
            saveSettings()
        end
    end

    -- === LOGO: Centered "STEMperator" at top ===
    gfx.setfont(1, "Arial", S(24), string.byte('b'))  -- Bold, large font
    local logoY = S(12)

    -- Calculate total width of logo text to center it
    local logoLetters = {"S", "T", "E", "M", "p", "e", "r", "a", "t", "o", "r"}
    local logoWidths = {}
    local logoTotalWidth = 0
    for i, letter in ipairs(logoLetters) do
        local w, _ = gfx.measurestr(letter)
        logoWidths[i] = w
        logoTotalWidth = logoTotalWidth + w
    end
    local logoX = (gfx.w - logoTotalWidth) / 2

    -- STEM colors (Vocals red, Drums blue, Bass purple, Other green)
    local logoColors = {
        {255/255, 100/255, 100/255},  -- S = Vocals (red)
        {100/255, 200/255, 255/255},  -- T = Drums (blue)
        {150/255, 100/255, 255/255},  -- E = Bass (purple)
        {100/255, 255/255, 150/255},  -- M = Other (green)
    }

    -- Store logo start position for click detection
    local logoStartX = logoX

    -- Draw each letter with subtle wave animation (like start screen)
    local time = os.clock()
    for i, letter in ipairs(logoLetters) do
        local yOffset = math.sin(time * 3 + i * 0.5) * S(2)
        if i <= 4 then
            -- Colored STEM letters
            gfx.set(logoColors[i][1], logoColors[i][2], logoColors[i][3], 1)
        else
            -- White/gray "perator"
            gfx.set(THEME.text[1], THEME.text[2], THEME.text[3], 0.9)
        end
        gfx.x = logoX
        gfx.y = logoY + yOffset
        gfx.drawstr(letter)
        logoX = logoX + logoWidths[i]
    end

    -- Logo click detection and tooltip
    local logoH = S(28)
    local mx, my = gfx.mouse_x, gfx.mouse_y
    local logoHover = mx >= logoStartX and mx <= logoStartX + logoTotalWidth and my >= logoY and my <= logoY + logoH
    if logoHover then
        setTooltip(logoStartX, logoY, logoTotalWidth, logoH, T("tooltip_logo_help"))
        -- Check for click
        if gfx.mouse_cap & 1 == 1 and not GUI.logoWasClicked then
            GUI.logoWasClicked = true
        elseif gfx.mouse_cap & 1 == 0 and GUI.logoWasClicked then
            GUI.logoWasClicked = false
            -- Set flag to show help (handled after dialog loop exits)
            GUI.result = "help"
        end
    end

    -- Content starts below logo
    local contentTop = S(45)

    gfx.setfont(1, "Arial", S(13))

    -- Determine 6-stem mode early (needed for stem display)
    local is6Stem = (SETTINGS.model == "htdemucs_6s")

    -- Column positions (4 columns)
    local col1X = S(10)   -- Presets
    local col2X = S(90)   -- Stems
    local col3X = S(175)  -- Model
    local col4X = S(260)  -- Output
    local colW = S(70)
    local btnH = S(20)

    -- === COLUMN 1: Presets ===
    gfx.set(THEME.textDim[1], THEME.textDim[2], THEME.textDim[3], 1)
    gfx.x = col1X
    gfx.y = contentTop
    gfx.drawstr(T("presets"))

    local presetY = contentTop + S(20)

    -- Combo presets first (most common use cases)
    if drawButton(col1X, presetY, colW, btnH, "Karaoke (K)", false, {80, 80, 90}) then applyPresetKaraoke() end
    setTooltipWithShortcut(col1X, presetY, colW, btnH, T("tooltip_preset_karaoke"), "K", {255, 200, 100})
    presetY = presetY + S(22)
    if drawButton(col1X, presetY, colW, btnH, "All (A)", false, {80, 80, 90}) then applyPresetAll() end
    setTooltipWithShortcut(col1X, presetY, colW, btnH, T("tooltip_preset_all"), "A", {255, 200, 100})

    -- Separator
    presetY = presetY + S(28)

    -- Stem presets (colored by stem)
    if drawButton(col1X, presetY, colW, btnH, "Vocals (V)", false, {255, 100, 100}) then applyPresetVocalsOnly() end
    setTooltipWithShortcut(col1X, presetY, colW, btnH, T("tooltip_preset_vocals"), "V", {255, 100, 100})
    presetY = presetY + S(22)
    if drawButton(col1X, presetY, colW, btnH, "Drums (D)", false, {100, 200, 255}) then applyPresetDrumsOnly() end
    setTooltipWithShortcut(col1X, presetY, colW, btnH, T("tooltip_preset_drums"), "D", {100, 200, 255})
    presetY = presetY + S(22)
    if drawButton(col1X, presetY, colW, btnH, "Bass (B)", false, {150, 100, 255}) then applyPresetBassOnly() end
    setTooltipWithShortcut(col1X, presetY, colW, btnH, T("tooltip_preset_bass"), "B", {150, 100, 255})
    presetY = presetY + S(22)
    if drawButton(col1X, presetY, colW, btnH, "Other (O)", false, {100, 255, 150}) then applyPresetOtherOnly() end
    setTooltipWithShortcut(col1X, presetY, colW, btnH, T("tooltip_preset_other"), "O", {100, 255, 150})
    presetY = presetY + S(22)

    -- Piano and Guitar only show for 6-stem model
    if is6Stem then
        if drawButton(col1X, presetY, colW, btnH, "Piano (P)", false, {255, 120, 200}) then applyPresetPianoOnly() end
        setTooltipWithShortcut(col1X, presetY, colW, btnH, T("tooltip_preset_piano"), "P", {255, 120, 200})
        presetY = presetY + S(22)
        if drawButton(col1X, presetY, colW, btnH, "Guitar (G)", false, {255, 180, 100}) then applyPresetGuitarOnly() end
        setTooltipWithShortcut(col1X, presetY, colW, btnH, T("tooltip_preset_guitar"), "G", {255, 180, 100})
        presetY = presetY + S(22)
    end

    -- === COLUMN 2: Stems ===
    gfx.set(THEME.textDim[1], THEME.textDim[2], THEME.textDim[3], 1)
    gfx.x = col2X
    gfx.y = contentTop
    gfx.drawstr(is6Stem and T("stems_6") or T("stems"))

    local stemY = contentTop + S(20)
    -- Map stem names to translation keys
    local stemTooltipKeys = {
        Vocals = "tooltip_stem_vocals",
        Drums = "tooltip_stem_drums",
        Bass = "tooltip_stem_bass",
        Other = "tooltip_stem_other",
        Guitar = "tooltip_stem_guitar",
        Piano = "tooltip_stem_piano"
    }
    for i, stem in ipairs(STEMS) do
        if not stem.sixStemOnly or is6Stem then
            local label = stem.name .. " (" .. stem.key .. ")"
            if drawToggleButton(col2X, stemY, colW, btnH, label, stem.selected, stem.color) then
                STEMS[i].selected = not STEMS[i].selected
            end
            local tooltipKey = stemTooltipKeys[stem.name] or "tooltip_stem_other"
            setTooltipWithShortcut(col2X, stemY, colW, btnH, T(tooltipKey), stem.key, stem.color)
            stemY = stemY + S(22)
        end
    end

    -- === COLUMN 3: Model ===
    gfx.set(THEME.textDim[1], THEME.textDim[2], THEME.textDim[3], 1)
    gfx.x = col3X
    gfx.y = contentTop
    gfx.drawstr(T("model"))

    -- Fixed width for all Model column boxes
    local modelBoxW = S(70)

    local modelY = contentTop + S(20)
    -- Map model id to translation key
    local modelDescKeys = {
        htdemucs = "model_fast_desc",
        htdemucs_ft = "model_quality_desc",
        htdemucs_6s = "model_6stem_desc",
    }
    for _, model in ipairs(MODELS) do
        if drawRadio(col3X, modelY, SETTINGS.model == model.id, model.name, nil, modelBoxW) then
            SETTINGS.model = model.id
        end
        local descKey = modelDescKeys[model.id] or "model_fast_desc"
        setTooltip(col3X, modelY, modelBoxW, btnH, T(descKey))
        modelY = modelY + S(22)
    end

    -- Processing mode
    modelY = modelY + S(8)
    local parallelColor = SETTINGS.parallelProcessing and {100, 180, 255} or {160, 160, 160}
    local parallelLabel = SETTINGS.parallelProcessing and T("parallel") or T("sequential")
    if drawCheckbox(col3X, modelY, SETTINGS.parallelProcessing, parallelLabel, parallelColor[1], parallelColor[2], parallelColor[3], modelBoxW) then
        SETTINGS.parallelProcessing = not SETTINGS.parallelProcessing
    end
    local parallelTip = SETTINGS.parallelProcessing
        and T("tooltip_parallel")
        or T("tooltip_sequential")
    setTooltip(col3X, modelY, modelBoxW, btnH, parallelTip)

    -- === COLUMN 4: Output ===
    gfx.set(THEME.textDim[1], THEME.textDim[2], THEME.textDim[3], 1)
    gfx.x = col4X
    gfx.y = contentTop
    gfx.drawstr(T("output"))

    -- Fixed width for all Output column boxes
    local outBoxW = S(70)

    -- Count selected stems for plural labels
    local stemCount = 0
    for _, stem in ipairs(STEMS) do
        if stem.selected and (not stem.sixStemOnly or is6Stem) then
            stemCount = stemCount + 1
        end
    end
    local stemPlural = stemCount ~= 1
    local newTracksLabel = stemPlural and T("new_tracks") or T("new_track")
    local inPlaceLabel = T("in_place")

    local outY = contentTop + S(20)
    if drawRadio(col4X, outY, SETTINGS.createNewTracks, newTracksLabel, nil, outBoxW) then
        SETTINGS.createNewTracks = true
    end
    setTooltip(col4X, outY, outBoxW, btnH, T("tooltip_new_tracks"))
    outY = outY + S(22)
    if drawRadio(col4X, outY, not SETTINGS.createNewTracks, inPlaceLabel, nil, outBoxW) then
        SETTINGS.createNewTracks = false
    end
    setTooltip(col4X, outY, outBoxW, btnH, T("tooltip_in_place"))

    -- Options (only when creating new tracks)
    if SETTINGS.createNewTracks then
        outY = outY + S(28)
        gfx.set(THEME.textDim[1], THEME.textDim[2], THEME.textDim[3], 1)
        gfx.x = col4X
        gfx.y = outY
        gfx.drawstr(T("after"))

        outY = outY + S(20)
        if drawCheckbox(col4X, outY, SETTINGS.createFolder, T("create_folder"), 160, 160, 160, outBoxW) then
            SETTINGS.createFolder = not SETTINGS.createFolder
        end
        setTooltip(col4X, outY, outBoxW, btnH, T("tooltip_create_folder"))

        outY = outY + S(22)
        if drawCheckbox(col4X, outY, SETTINGS.muteOriginal, T("mute_original"), 160, 160, 160, outBoxW) then
            SETTINGS.muteOriginal = not SETTINGS.muteOriginal
            if SETTINGS.muteOriginal then
                SETTINGS.deleteOriginal = false; SETTINGS.deleteOriginalTrack = false
                SETTINGS.muteSelection = false; SETTINGS.deleteSelection = false
            end
        end
        setTooltip(col4X, outY, outBoxW, btnH, T("tooltip_mute_original"))

        outY = outY + S(22)
        local delItemColor = SETTINGS.deleteOriginal and {255, 120, 120} or {160, 160, 160}
        if drawCheckbox(col4X, outY, SETTINGS.deleteOriginal, T("delete_original"), delItemColor[1], delItemColor[2], delItemColor[3], outBoxW) then
            SETTINGS.deleteOriginal = not SETTINGS.deleteOriginal
            if SETTINGS.deleteOriginal then
                SETTINGS.muteOriginal = false
                SETTINGS.muteSelection = false; SETTINGS.deleteSelection = false
            end
        end
        setTooltip(col4X, outY, outBoxW, btnH, T("tooltip_delete_original"))

        outY = outY + S(22)
        local delTrackColor = SETTINGS.deleteOriginalTrack and {255, 120, 120} or {160, 160, 160}
        if drawCheckbox(col4X, outY, SETTINGS.deleteOriginalTrack, T("delete_track"), delTrackColor[1], delTrackColor[2], delTrackColor[3], outBoxW) then
            SETTINGS.deleteOriginalTrack = not SETTINGS.deleteOriginalTrack
            if SETTINGS.deleteOriginalTrack then
                SETTINGS.deleteOriginal = true; SETTINGS.muteOriginal = false
                SETTINGS.muteSelection = false; SETTINGS.deleteSelection = false
            end
        end
        setTooltip(col4X, outY, outBoxW, btnH, T("tooltip_delete_track"))

        -- Selection-level options (only if time selection exists)
        local hasTimeSel = hasTimeSelection()
        if hasTimeSel then
            outY = outY + S(22)
            if drawCheckbox(col4X, outY, SETTINGS.muteSelection, T("mute_selection"), 160, 160, 160, outBoxW) then
                SETTINGS.muteSelection = not SETTINGS.muteSelection
                if SETTINGS.muteSelection then
                    SETTINGS.muteOriginal = false; SETTINGS.deleteOriginal = false; SETTINGS.deleteOriginalTrack = false
                    SETTINGS.deleteSelection = false
                end
            end
            setTooltip(col4X, outY, outBoxW, btnH, T("tooltip_mute_selection"))

            outY = outY + S(22)
            local delSelColor = SETTINGS.deleteSelection and {255, 120, 120} or {160, 160, 160}
            if drawCheckbox(col4X, outY, SETTINGS.deleteSelection, T("delete_selection"), delSelColor[1], delSelColor[2], delSelColor[3], outBoxW) then
                SETTINGS.deleteSelection = not SETTINGS.deleteSelection
                if SETTINGS.deleteSelection then
                    SETTINGS.muteOriginal = false; SETTINGS.deleteOriginal = false; SETTINGS.deleteOriginalTrack = false
                    SETTINGS.muteSelection = false
                end
            end
            setTooltip(col4X, outY, outBoxW, btnH, T("tooltip_delete_selection"))
        end
    end


    -- Buttons
    gfx.setfont(1, "Arial", S(13))
    local btnY = gfx.h - S(32)
    local btnW = S(80)
    local btnH = S(20)
    local stemBtnW = S(70)  -- Same width as Cancel button

    -- Footer layout: 3 info rows + button row
    -- Row 1: Selected info
    -- Row 2: Output info
    -- Row 3: Target info (+ time selection)
    -- Row 4: STEMperate button + Cancel button
    local footerRow1Y = btnY - S(48)  -- Selected
    local footerRow2Y = btnY - S(32)  -- Output
    local footerRow3Y = btnY - S(16)  -- Target
    local footerRow4Y = btnY          -- Buttons

    local selTrackCount = reaper.CountSelectedTracks(0)
    local selItemCount = reaper.CountSelectedMediaItems(0)

    -- For time selection mode: count items that overlap with time selection
    -- This gives a better estimate of output when items aren't explicitly selected
    local currentTimeStart, currentTimeEnd = reaper.GetSet_LoopTimeRange(false, false, 0, 0, false)
    local hasTimeSel = currentTimeEnd > currentTimeStart

    -- Count items overlapping time selection on selected tracks
    -- This works even when items aren't explicitly selected
    local timeSelItemCount = 0
    if hasTimeSel and selTrackCount > 0 then
        for t = 0, selTrackCount - 1 do
            local track = reaper.GetSelectedTrack(0, t)
            if track then
                local numItems = reaper.CountTrackMediaItems(track)
                for i = 0, numItems - 1 do
                    local item = reaper.GetTrackMediaItem(track, i)
                    local iPos = reaper.GetMediaItemInfo_Value(item, "D_POSITION")
                    local iLen = reaper.GetMediaItemInfo_Value(item, "D_LENGTH")
                    local iEnd = iPos + iLen
                    if iPos < currentTimeEnd and iEnd > currentTimeStart then
                        timeSelItemCount = timeSelItemCount + 1
                    end
                end
            end
        end
    end

    -- Use the larger of explicit selection or time selection overlap count
    if hasTimeSel and timeSelItemCount > selItemCount then
        selItemCount = timeSelItemCount
    end

    local trackLabel = selTrackCount == 1 and "track" or "tracks"
    local itemLabel = selItemCount == 1 and "item" or "items"

    -- Format time selection duration
    local timeSelText = nil
    if hasTimeSel then
        -- Update stored values for processing
        timeSelectionStart = currentTimeStart
        timeSelectionEnd = currentTimeEnd
        timeSelectionMode = true
        local duration = currentTimeEnd - currentTimeStart
        local mins = math.floor(duration / 60)
        local secs = duration - (mins * 60)
        if mins > 0 then
            timeSelText = string.format("%d:%04.1f", mins, secs)
        else
            timeSelText = string.format("%.1fs", secs)
        end
    else
        -- No time selection currently
        timeSelectionMode = false
    end

    -- Count selected stems for output calculation
    local selectedStemCount = 0
    for _, stem in ipairs(STEMS) do
        if stem.selected and (not stem.sixStemOnly or is6Stem) then
            selectedStemCount = selectedStemCount + 1
        end
    end

    -- Calculate expected output
    local outTrackCount = SETTINGS.createNewTracks and (selTrackCount * selectedStemCount) or 0
    local outItemCount = selItemCount * selectedStemCount
    local outTrackLabel = outTrackCount == 1 and "track" or "tracks"
    local outItemLabel = outItemCount == 1 and "item" or "items"

    gfx.set(THEME.textDim[1], THEME.textDim[2], THEME.textDim[3], 1)
    gfx.setfont(1, "Arial", S(11))

    -- Row 1: Selected (include time selection if applicable)
    gfx.x = col1X
    gfx.y = footerRow1Y
    gfx.drawstr("Selected:")
    local selInfoText
    if timeSelText then
        selInfoText = string.format("%d %s, %d %s, %s time selection", selTrackCount, trackLabel, selItemCount, itemLabel, timeSelText)
    else
        selInfoText = string.format("%d %s, %d %s", selTrackCount, trackLabel, selItemCount, itemLabel)
    end
    gfx.x = col2X
    gfx.y = footerRow1Y
    gfx.drawstr(selInfoText)

    -- Row 2: Output
    gfx.x = col1X
    gfx.y = footerRow2Y
    gfx.drawstr("Output:")
    local outInfoText
    if SETTINGS.createNewTracks then
        outInfoText = string.format("%d %s, %d %s", outTrackCount, outTrackLabel, outItemCount, outItemLabel)
    else
        outInfoText = string.format("%d takes", outItemCount)
    end
    gfx.x = col2X
    gfx.y = footerRow2Y
    gfx.drawstr(outInfoText)

    -- Row 3: Target
    gfx.x = col1X
    gfx.y = footerRow3Y
    gfx.drawstr("Target:")

    -- Determine target description based on output mode
    local targetText
    if SETTINGS.createNewTracks then
        if SETTINGS.createFolder then
            targetText = "New folder with stem tracks"
        else
            targetText = "New tracks below source"
        end
    else
        -- Show number of takes per source item
        targetText = string.format("In-place (as %d takes on source tracks)", selectedStemCount)
    end
    gfx.x = col2X
    gfx.y = footerRow3Y
    gfx.drawstr(targetText)

    -- Row 4: STEMperate button
    local stemBtnX = col3X
    local mx, my = gfx.mouse_x, gfx.mouse_y
    local stemBtnHover = mx >= stemBtnX and mx <= stemBtnX + stemBtnW and my >= footerRow4Y and my <= footerRow4Y + btnH
    local stemBtnColor = stemBtnHover and THEME.buttonPrimaryHover or THEME.buttonPrimary

    -- Draw button background
    gfx.set(stemBtnColor[1], stemBtnColor[2], stemBtnColor[3], 1)
    for i = 0, btnH - 1 do
        local radius = btnH / 2
        local inset = 0
        if i < radius then
            inset = radius - math.sqrt(radius * radius - (radius - i) * (radius - i))
        elseif i > btnH - radius then
            inset = radius - math.sqrt(radius * radius - (i - (btnH - radius)) * (i - (btnH - radius)))
        end
        gfx.line(stemBtnX + inset, footerRow4Y + i, stemBtnX + stemBtnW - inset, footerRow4Y + i)
    end

    -- Draw "STEMperate" with colored STEM letters
    gfx.setfont(1, "Arial", S(13), string.byte('b'))
    local textY = footerRow4Y + (btnH - gfx.texth) / 2

    -- Calculate total width to center
    local letters = {"S", "T", "E", "M", "p", "e", "r", "a", "t", "e"}
    local letterWidths = {}
    local totalWidth = 0
    for i, letter in ipairs(letters) do
        local w, _ = gfx.measurestr(letter)
        letterWidths[i] = w
        totalWidth = totalWidth + w
    end
    local textX = stemBtnX + (stemBtnW - totalWidth) / 2

    -- STEM colors (Vocals, Drums, Bass, Other)
    local stemColors = {
        {255/255, 100/255, 100/255},  -- S = Vocals (red)
        {100/255, 200/255, 255/255},  -- T = Drums (blue)
        {150/255, 100/255, 255/255},  -- E = Bass (purple)
        {100/255, 255/255, 150/255},  -- M = Other (green)
    }

    for i, letter in ipairs(letters) do
        if i <= 4 then
            -- Colored STEM letters
            gfx.set(stemColors[i][1], stemColors[i][2], stemColors[i][3], 1)
        else
            -- White "perate"
            gfx.set(1, 1, 1, 1)
        end
        gfx.x = textX
        gfx.y = textY
        gfx.drawstr(letter)
        textX = textX + letterWidths[i]
    end

    -- Rich tooltip for STEMperate button (shows output stems + target with colors)
    setRichTooltip(stemBtnX, footerRow4Y, stemBtnW, btnH)

    -- Handle STEMperate click
    if stemBtnHover and GUI.wasMouseDown and (gfx.mouse_cap & 1 == 0) then
        local anySelected = false
        for _, stem in ipairs(STEMS) do
            if stem.selected then anySelected = true; break end
        end
        if anySelected then
            saveSettings()
            GUI.result = true
        else
            showMessage("No Stems Selected", "Please select at least one stem.", "warning")
        end
    end

    -- Row 3, Col 4: Close button (red, like Start window)
    local closeBtnX = col4X
    local closeBtnW = outBoxW
    local closeBtnHover = mx >= closeBtnX and mx <= closeBtnX + closeBtnW and my >= footerRow4Y and my <= footerRow4Y + btnH

    -- Red button color
    if closeBtnHover then
        gfx.set(0.9, 0.3, 0.3, 1)
    else
        gfx.set(0.7, 0.2, 0.2, 1)
    end
    -- Draw rounded (pill-shaped) button
    for i = 0, btnH - 1 do
        local radius = btnH / 2
        local inset = 0
        if i < radius then
            inset = radius - math.sqrt(radius * radius - (radius - i) * (radius - i))
        elseif i > btnH - radius then
            inset = radius - math.sqrt(radius * radius - (i - (btnH - radius)) * (i - (btnH - radius)))
        end
        gfx.line(closeBtnX + inset, footerRow4Y + i, closeBtnX + closeBtnW - inset, footerRow4Y + i)
    end

    gfx.set(1, 1, 1, 1)
    gfx.setfont(1, "Arial", S(13), string.byte('b'))
    local closeText = "Close"
    local closeTextW = gfx.measurestr(closeText)
    gfx.x = closeBtnX + (closeBtnW - closeTextW) / 2
    gfx.y = footerRow4Y + (btnH - S(13)) / 2
    gfx.drawstr(closeText)

    -- Handle Close button click
    if closeBtnHover and GUI.wasMouseDown and (gfx.mouse_cap & 1 == 0) then
        GUI.result = false
    end
    setTooltip(closeBtnX, footerRow4Y, closeBtnW, btnH, T("tooltip_close"))

    GUI.wasMouseDown = (gfx.mouse_cap & 1 == 1)

    -- Handle keyboard
    local char = gfx.getchar()
    if char == 27 then  -- ESC
        GUI.result = false
    elseif char == 26161 then  -- F1 key - open help
        GUI.result = "help"
    elseif char == 13 or char == 32 then  -- Enter or Space
        local anySelected = false
        for _, stem in ipairs(STEMS) do
            if stem.selected then anySelected = true; break end
        end
        if anySelected then
            GUI.result = true
        end
    elseif char == 49 then STEMS[1].selected = not STEMS[1].selected  -- 1: Vocals
    elseif char == 50 then STEMS[2].selected = not STEMS[2].selected  -- 2: Drums
    elseif char == 51 then STEMS[3].selected = not STEMS[3].selected  -- 3: Bass
    elseif char == 52 then STEMS[4].selected = not STEMS[4].selected  -- 4: Other
    elseif char == 53 and SETTINGS.model == "htdemucs_6s" then STEMS[5].selected = not STEMS[5].selected  -- 5: Guitar (6-stem only)
    elseif char == 54 and SETTINGS.model == "htdemucs_6s" then STEMS[6].selected = not STEMS[6].selected  -- 6: Piano (6-stem only)
    -- Preset shortcuts: first letter of preset name
    elseif char == 118 or char == 86 then applyPresetVocalsOnly()  -- V: Vocals
    elseif char == 100 or char == 68 then applyPresetDrumsOnly()  -- D: Drums
    elseif char == 98 or char == 66 then applyPresetBassOnly()  -- B: Bass
    elseif char == 111 or char == 79 then applyPresetOtherOnly()  -- O: Other
    elseif char == 112 or char == 80 then applyPresetPianoOnly()  -- P: Piano (6-stem only)
    elseif char == 103 or char == 71 then applyPresetGuitarOnly()  -- G: Guitar (6-stem only)
    elseif char == 107 or char == 75 then applyPresetKaraoke()  -- K: Karaoke
    elseif char == 105 or char == 73 then applyPresetKaraoke()  -- I: Instrumental (alias for Karaoke)
    elseif char == 97 or char == 65 then applyPresetAll()  -- A: All
    -- Model shortcuts: F=Fast, Q=Quality, S=6-stem
    elseif char == 102 or char == 70 then SETTINGS.model = "htdemucs"  -- F: Fast
    elseif char == 113 or char == 81 then SETTINGS.model = "htdemucs_ft"  -- Q: Quality
    elseif char == 115 or char == 83 then SETTINGS.model = "htdemucs_6s"  -- S: 6-stem
    elseif char == 43 or char == 61 then  -- + or = to grow window
        local newW = math.min(GUI.maxW, gfx.w + 76)
        local newH = math.min(GUI.maxH, gfx.h + 68)
        gfx.init(SCRIPT_NAME, newW, newH)
    elseif char == 45 then  -- - to shrink window
        local newW = math.max(GUI.minW, gfx.w - 76)
        local newH = math.max(GUI.minH, gfx.h - 68)
        gfx.init(SCRIPT_NAME, newW, newH)
    end

    -- flarkAUDIO logo at top (translucent) - "flark" regular, "AUDIO" bold
    gfx.setfont(1, "Arial", S(10))
    local flarkPart = "flark"
    local flarkPartW = gfx.measurestr(flarkPart)
    gfx.setfont(1, "Arial", S(10), string.byte('b'))
    local audioPart = "AUDIO"
    local audioPartW = gfx.measurestr(audioPart)
    local totalLogoW = flarkPartW + audioPartW
    local logoStartX = (gfx.w - totalLogoW) / 2
    -- Orange text, 50% translucent
    gfx.set(1.0, 0.5, 0.1, 0.5)
    gfx.setfont(1, "Arial", S(10))
    gfx.x = logoStartX
    gfx.y = S(3)
    gfx.drawstr(flarkPart)
    gfx.setfont(1, "Arial", S(10), string.byte('b'))
    gfx.x = logoStartX + flarkPartW
    gfx.y = S(3)
    gfx.drawstr(audioPart)

    -- === PROCESS PENDING NEW ART CLICK ===
    -- Only trigger new art if click was on background (not on any UI element)
    if mainDialogArt.pendingNewArt then
        mainDialogArt.pendingNewArt = false
        -- Only generate new art if mouse was NOT over any UI element
        if not GUI.uiClickedThisFrame then
            generateNewArt()
            -- Note: Pan and zoom are preserved when switching art
        end
    end

    -- Draw tooltip on top of everything
    drawTooltip()

    gfx.update()

    if GUI.result == nil and char ~= -1 then
        reaper.defer(dialogLoop)
    else
        -- Save dialog position before closing for progress window positioning
        if reaper.JS_Window_GetRect then
            local hwnd = reaper.JS_Window_Find(SCRIPT_NAME, true)
            if hwnd then
                local retval, left, top, right, bottom = reaper.JS_Window_GetRect(hwnd)
                if retval then
                    lastDialogX = left
                    lastDialogY = top
                    lastDialogW = right - left
                    lastDialogH = bottom - top
                end
            end
        end
        -- Fallback: keep existing lastDialogX/Y, just update size
        if not lastDialogX then
            -- Use initial position that was set in showStemSelectionDialog
            lastDialogW = gfx.w
            lastDialogH = gfx.h
        end
        -- Always save settings (including position) when dialog closes
        saveSettings()
        gfx.quit()
        if GUI.result == "help" then
            -- Show art gallery (help window) - track that it came from dialog
            helpState.openedFrom = "dialog"
            reaper.defer(function() showArtGallery() end)
        elseif GUI.result then
            reaper.defer(runSeparationWorkflow)
        else
            -- User cancelled: restore original selection state if items were auto-selected
            if #autoSelectedItems > 0 then
                for _, item in ipairs(autoSelectedItems) do
                    if reaper.ValidatePtr(item, "MediaItem*") then
                        reaper.SetMediaItemSelected(item, false)
                    end
                end
                autoSelectedItems = {}
            end
            -- Also deselect the tracks that triggered auto-selection
            if #autoSelectionTracks > 0 then
                for _, track in ipairs(autoSelectionTracks) do
                    if reaper.ValidatePtr(track, "MediaTrack*") then
                        reaper.SetTrackSelected(track, false)
                    end
                end
                autoSelectionTracks = {}
            end
            reaper.UpdateArrange()
        end
    end
end

-- Show stem selection dialog
showStemSelectionDialog = function()
    loadSettings()
    GUI.result = nil
    GUI.wasMouseDown = false
    GUI.hadSelectionOnOpen = true  -- Dialog was opened with valid selection, don't auto-close

    -- Use saved size if available, otherwise use default
    local dialogW = GUI.savedW or GUI.baseW
    local dialogH = GUI.savedH or GUI.baseH
    -- Clamp to min/max
    dialogW = math.max(GUI.minW, math.min(GUI.maxW, dialogW))
    dialogH = math.max(GUI.minH, math.min(GUI.maxH, dialogH))

    local posX, posY

    -- Use saved position if available, otherwise center on mouse
    if GUI.savedX and GUI.savedY then
        -- Use exact saved position (user placed it there intentionally)
        posX = GUI.savedX
        posY = GUI.savedY
    else
        -- No saved position - center on mouse and clamp to screen
        local mouseX, mouseY = reaper.GetMousePosition()
        posX = mouseX - dialogW / 2
        posY = mouseY - dialogH / 2
        posX, posY = clampToScreen(posX, posY, dialogW, dialogH, mouseX, mouseY)
    end

    -- Save initial position for progress window
    lastDialogX = posX
    lastDialogY = posY
    lastDialogW = dialogW
    lastDialogH = dialogH

    gfx.init(SCRIPT_NAME, dialogW, dialogH, 0, posX, posY)

    -- Make window resizable (requires js_ReaScriptAPI extension)
    makeWindowResizable()

    gfx.setfont(1, "Arial", S(13))
    dialogLoop()
end

-- Get temp directory (cross-platform)
local function getTempDir()
    if OS == "Windows" then
        return os.getenv("TEMP") or os.getenv("TMP") or "C:\\Temp"
    else
        return os.getenv("TMPDIR") or "/tmp"
    end
end

-- Create directory (cross-platform)
local function makeDir(path)
    if OS == "Windows" then
        os.execute('mkdir "' .. path .. '" 2>nul')
    else
        os.execute('mkdir -p "' .. path .. '"')
    end
end

-- Suppress stderr (cross-platform)
local function suppressStderr()
    return OS == "Windows" and " 2>nul" or " 2>/dev/null"
end

-- Execute command without showing a window (Windows-specific)
-- On Windows, os.execute() shows a brief CMD flash. This avoids that.
local function execHidden(cmd)
    debugLog("execHidden called")
    debugLog("  Command: " .. cmd:sub(1, 200) .. (cmd:len() > 200 and "..." or ""))
    if OS == "Windows" then
        -- Use a temporary VBS file to run the command hidden
        local tempDir = os.getenv("TEMP") or os.getenv("TMP") or "."
        local vbsPath = tempDir .. "\\stemperator_exec_" .. os.time() .. ".vbs"
        debugLog("  VBS path: " .. vbsPath)
        local vbsFile = io.open(vbsPath, "w")
        if vbsFile then
            -- Window style 0 = hidden, True = wait for completion
            local vbsContent = 'CreateObject("WScript.Shell").Run "cmd /c ' .. cmd:gsub('"', '""') .. '", 0, True\n'
            vbsFile:write(vbsContent)
            vbsFile:close()
            debugLog("  VBS file created")

            if reaper.ExecProcess then
                debugLog("  Using reaper.ExecProcess")
                reaper.ExecProcess('wscript "' .. vbsPath .. '"', 0)  -- 0 = wait for completion
            else
                debugLog("  Using os.execute")
                os.execute('wscript "' .. vbsPath .. '"')
            end
            debugLog("  Command completed")

            -- Clean up VBS file
            os.remove(vbsPath)
            debugLog("  VBS file cleaned up")
        else
            -- Fallback to os.execute if VBS creation fails
            debugLog("  VBS creation failed, falling back to os.execute")
            os.execute(cmd)
        end
    else
        debugLog("  Non-Windows, using os.execute")
        os.execute(cmd)
    end
    debugLog("execHidden done")
end

-- Render selected item to a temporary WAV file
-- If time selection exists and overlaps item, only render that portion
local function renderItemToWav(item, outputPath)
    local take = reaper.GetActiveTake(item)
    if not take then return nil, "No active take" end

    local source = reaper.GetMediaItemTake_Source(take)
    if not source then return nil, "No source" end

    local sourceFile = reaper.GetMediaSourceFileName(source, "")
    if not sourceFile or sourceFile == "" then return nil, "No source file" end

    local itemPos = reaper.GetMediaItemInfo_Value(item, "D_POSITION")
    local itemLen = reaper.GetMediaItemInfo_Value(item, "D_LENGTH")
    local itemEnd = itemPos + itemLen
    local takeOffset = reaper.GetMediaItemTakeInfo_Value(take, "D_STARTOFFS")
    local playrate = reaper.GetMediaItemTakeInfo_Value(take, "D_PLAYRATE")

    -- Check for time selection that overlaps the item
    local timeSelStart, timeSelEnd = reaper.GetSet_LoopTimeRange(false, false, 0, 0, false)
    local hasTimeSel = timeSelEnd > timeSelStart

    local renderStart = itemPos
    local renderEnd = itemEnd

    if hasTimeSel then
        -- Clamp time selection to item bounds
        if timeSelStart > itemPos and timeSelStart < itemEnd then
            renderStart = timeSelStart
        end
        if timeSelEnd > itemPos and timeSelEnd < itemEnd then
            renderEnd = timeSelEnd
        end
        -- Only use time selection if it actually overlaps
        if timeSelStart >= itemEnd or timeSelEnd <= itemPos then
            -- No overlap, render whole item
            renderStart = itemPos
            renderEnd = itemEnd
        end
    end

    -- Calculate source file offset and duration
    local renderOffset = takeOffset + (renderStart - itemPos) * playrate
    local renderDuration = (renderEnd - renderStart) * playrate

    local ffmpegCmd = string.format(
        'ffmpeg -y -i "%s" -ss %.6f -t %.6f -ar 44100 -ac 2 "%s"' .. suppressStderr(),
        sourceFile, renderOffset, renderDuration, outputPath
    )

    execHidden(ffmpegCmd)

    local f = io.open(outputPath, "r")
    if f then f:close(); return outputPath, nil, renderStart, renderEnd - renderStart
    else return nil, "Failed to extract audio" end
end

-- Render time selection to a temporary WAV file
local function renderTimeSelectionToWav(outputPath)
    local startTime, endTime = reaper.GetSet_LoopTimeRange(false, false, 0, 0, false)
    if startTime >= endTime then return nil, "No time selection" end

    -- Find all selected items overlapping the time selection
    local numTracks = reaper.CountTracks(0)
    if numTracks == 0 then return nil, "No tracks in project" end

    local selectedItems = {}
    local foundItem = nil  -- First found item for return value

    for t = 0, numTracks - 1 do
        local track = reaper.GetTrack(0, t)
        local numItems = reaper.CountTrackMediaItems(track)
        for i = 0, numItems - 1 do
            local item = reaper.GetTrackMediaItem(track, i)
            local iPos = reaper.GetMediaItemInfo_Value(item, "D_POSITION")
            local iLen = reaper.GetMediaItemInfo_Value(item, "D_LENGTH")
            local iEnd = iPos + iLen
            -- Check if item overlaps time selection AND is selected
            if iPos < endTime and iEnd > startTime then
                if reaper.IsMediaItemSelected(item) then
                    table.insert(selectedItems, {item = item, track = track})
                    if not foundItem then foundItem = item end
                end
            end
        end
    end

    -- If no items selected but tracks are selected and In-place mode is on,
    -- find items on those tracks that overlap the time selection
    if #selectedItems == 0 then
        local selTrackCount = reaper.CountSelectedTracks(0)
        local selItemCount = reaper.CountSelectedMediaItems(0)

        -- In-place mode with track selected: auto-find overlapping items on selected tracks
        if selTrackCount > 0 and selItemCount == 0 and not SETTINGS.createNewTracks then
            debugLog("In-place mode: finding items on selected tracks overlapping time selection")
            for t = 0, selTrackCount - 1 do
                local track = reaper.GetSelectedTrack(0, t)
                local numItems = reaper.CountTrackMediaItems(track)
                for i = 0, numItems - 1 do
                    local item = reaper.GetTrackMediaItem(track, i)
                    local iPos = reaper.GetMediaItemInfo_Value(item, "D_POSITION")
                    local iLen = reaper.GetMediaItemInfo_Value(item, "D_LENGTH")
                    local iEnd = iPos + iLen
                    -- Check if item overlaps time selection
                    if iPos < endTime and iEnd > startTime then
                        table.insert(selectedItems, {item = item, track = track})
                        if not foundItem then foundItem = item end
                        debugLog("Found overlapping item on selected track at pos " .. iPos)
                    end
                end
            end
        end

        -- No items/tracks selected - find ALL items that overlap the time selection
        if #selectedItems == 0 and selTrackCount == 0 and selItemCount == 0 then
            debugLog("No selection - finding all items overlapping time selection")
            for t = 0, numTracks - 1 do
                local track = reaper.GetTrack(0, t)
                local numItems = reaper.CountTrackMediaItems(track)
                for i = 0, numItems - 1 do
                    local item = reaper.GetTrackMediaItem(track, i)
                    local iPos = reaper.GetMediaItemInfo_Value(item, "D_POSITION")
                    local iLen = reaper.GetMediaItemInfo_Value(item, "D_LENGTH")
                    local iEnd = iPos + iLen
                    -- Check if item overlaps time selection
                    if iPos < endTime and iEnd > startTime then
                        table.insert(selectedItems, {item = item, track = track})
                        if not foundItem then foundItem = item end
                        debugLog("Found overlapping item at pos " .. iPos)
                    end
                end
            end
        end

        -- Still no items found - show appropriate error
        if #selectedItems == 0 then
            if selTrackCount == 0 and selItemCount == 0 then
                return nil, "No items overlap the time selection"
            elseif selTrackCount == 0 then
                return nil, "No tracks selected (select tracks with items)"
            elseif selItemCount == 0 and not SETTINGS.createNewTracks then
                return nil, "No items on selected tracks overlap time selection"
            elseif selItemCount == 0 then
                return nil, "No items selected on tracks"
            else
                return nil, "No selected items overlap the time selection"
            end
        end
    end

    -- If only one item, use simple ffmpeg extraction (faster)
    if #selectedItems == 1 then
        local take = reaper.GetActiveTake(selectedItems[1].item)
        if not take then return nil, "No active take" end

        local source = reaper.GetMediaItemTake_Source(take)
        if not source then return nil, "No source" end

        local sourceFile = reaper.GetMediaSourceFileName(source, "")
        if not sourceFile or sourceFile == "" then return nil, "No source file" end

        local itemPos = reaper.GetMediaItemInfo_Value(selectedItems[1].item, "D_POSITION")
        local takeOffset = reaper.GetMediaItemTakeInfo_Value(take, "D_STARTOFFS")
        local playrate = reaper.GetMediaItemTakeInfo_Value(take, "D_PLAYRATE")

        local selStartInItem = math.max(0, startTime - itemPos)
        local selEndInItem = math.min(endTime - itemPos, reaper.GetMediaItemInfo_Value(selectedItems[1].item, "D_LENGTH"))
        local duration = (selEndInItem - selStartInItem) * playrate
        local sourceOffset = takeOffset + (selStartInItem * playrate)

        local ffmpegCmd = string.format(
            'ffmpeg -y -i "%s" -ss %.6f -t %.6f -ar 44100 -ac 2 "%s"' .. suppressStderr(),
            sourceFile, sourceOffset, duration, outputPath
        )

        execHidden(ffmpegCmd)

        local f = io.open(outputPath, "r")
        if f then f:close(); return outputPath, nil, foundItem
        else return nil, "Failed to extract audio from time selection", nil end
    end

    -- Multiple items selected - group by track
    local trackItems = {}  -- track -> list of items
    for _, itemData in ipairs(selectedItems) do
        if not trackItems[itemData.track] then
            trackItems[itemData.track] = {}
        end
        table.insert(trackItems[itemData.track], itemData.item)
    end

    -- Count tracks
    local trackCount = 0
    local trackList = {}
    for track in pairs(trackItems) do
        trackCount = trackCount + 1
        table.insert(trackList, track)
    end

    if trackCount > 1 then
        -- Multiple tracks - return special marker to indicate multi-track mode
        return nil, "MULTI_TRACK", nil, trackList, trackItems
    end

    -- All items are on the same track - use the first one
    local take = reaper.GetActiveTake(foundItem)
    if not take then return nil, "No active take" end

    local source = reaper.GetMediaItemTake_Source(take)
    if not source then return nil, "No source" end

    local sourceFile = reaper.GetMediaSourceFileName(source, "")
    if not sourceFile or sourceFile == "" then return nil, "No source file" end

    local itemPos = reaper.GetMediaItemInfo_Value(foundItem, "D_POSITION")
    local takeOffset = reaper.GetMediaItemTakeInfo_Value(take, "D_STARTOFFS")
    local playrate = reaper.GetMediaItemTakeInfo_Value(take, "D_PLAYRATE")

    local selStartInItem = math.max(0, startTime - itemPos)
    local selEndInItem = math.min(endTime - itemPos, reaper.GetMediaItemInfo_Value(foundItem, "D_LENGTH"))
    local duration = (selEndInItem - selStartInItem) * playrate
    local sourceOffset = takeOffset + (selStartInItem * playrate)

    local ffmpegCmd = string.format(
        'ffmpeg -y -i "%s" -ss %.6f -t %.6f -ar 44100 -ac 2 "%s"' .. suppressStderr(),
        sourceFile, sourceOffset, duration, outputPath
    )

    execHidden(ffmpegCmd)

    local f = io.open(outputPath, "r")
    if f then f:close(); return outputPath, nil, foundItem
    else return nil, "Failed to extract audio from time selection", nil end
end

-- Extract audio for a specific track within time selection
local function renderTrackTimeSelectionToWav(track, outputPath)
    local startTime, endTime = reaper.GetSet_LoopTimeRange(false, false, 0, 0, false)
    if startTime >= endTime then return nil, "No time selection" end

    -- Find ALL items on this track overlapping time selection
    -- (prefer selected items, but include all overlapping if none selected)
    local numItems = reaper.CountTrackMediaItems(track)
    local foundItem = nil
    local allFoundItems = {}
    local hasSelectedItems = false

    -- First pass: look for selected items
    for i = 0, numItems - 1 do
        local item = reaper.GetTrackMediaItem(track, i)
        local iPos = reaper.GetMediaItemInfo_Value(item, "D_POSITION")
        local iLen = reaper.GetMediaItemInfo_Value(item, "D_LENGTH")
        local iEnd = iPos + iLen
        if iPos < endTime and iEnd > startTime and reaper.IsMediaItemSelected(item) then
            hasSelectedItems = true
            if not foundItem then
                foundItem = item
            end
            table.insert(allFoundItems, item)
        end
    end

    -- Second pass: if no selected items, find ANY overlapping items
    if not foundItem then
        for i = 0, numItems - 1 do
            local item = reaper.GetTrackMediaItem(track, i)
            local iPos = reaper.GetMediaItemInfo_Value(item, "D_POSITION")
            local iLen = reaper.GetMediaItemInfo_Value(item, "D_LENGTH")
            local iEnd = iPos + iLen
            if iPos < endTime and iEnd > startTime then
                if not foundItem then
                    foundItem = item
                end
                table.insert(allFoundItems, item)
            end
        end
    end

    if not foundItem then return nil, "No items on track overlap time selection" end

    local take = reaper.GetActiveTake(foundItem)
    if not take then return nil, "No active take" end

    local source = reaper.GetMediaItemTake_Source(take)
    if not source then return nil, "No source" end

    local sourceFile = reaper.GetMediaSourceFileName(source, "")
    if not sourceFile or sourceFile == "" then return nil, "No source file" end

    local itemPos = reaper.GetMediaItemInfo_Value(foundItem, "D_POSITION")
    local itemLen = reaper.GetMediaItemInfo_Value(foundItem, "D_LENGTH")
    local takeOffset = reaper.GetMediaItemTakeInfo_Value(take, "D_STARTOFFS")
    local playrate = reaper.GetMediaItemTakeInfo_Value(take, "D_PLAYRATE")

    local selStartInItem = math.max(0, startTime - itemPos)
    local selEndInItem = math.min(endTime - itemPos, itemLen)
    local duration = (selEndInItem - selStartInItem) * playrate
    local sourceOffset = takeOffset + (selStartInItem * playrate)

    -- Debug logging for audio extraction
    debugLog("=== renderTrackTimeSelectionToWav DEBUG ===")
    debugLog("Time selection: " .. startTime .. " to " .. endTime)
    debugLog("Item position: " .. itemPos .. ", length: " .. itemLen)
    debugLog("takeOffset: " .. takeOffset .. ", playrate: " .. playrate)
    debugLog("selStartInItem: " .. selStartInItem .. ", selEndInItem: " .. selEndInItem)
    debugLog("sourceOffset: " .. sourceOffset .. ", duration: " .. duration)
    debugLog("Source file: " .. sourceFile)

    local ffmpegCmd = string.format(
        'ffmpeg -y -i "%s" -ss %.6f -t %.6f -ar 44100 -ac 2 "%s"' .. suppressStderr(),
        sourceFile, sourceOffset, duration, outputPath
    )
    debugLog("ffmpeg cmd: ffmpeg -ss " .. sourceOffset .. " -t " .. duration)

    execHidden(ffmpegCmd)

    local f = io.open(outputPath, "r")
    if f then f:close(); return outputPath, nil, foundItem, allFoundItems
    else return nil, "Failed to extract audio", nil, nil end
end

-- Render selected items on a track to WAV (no time selection needed)
-- Used when items are selected but no time selection exists
local function renderTrackSelectedItemsToWav(track, outputPath)
    -- Find ALL selected items on this track
    local numItems = reaper.CountTrackMediaItems(track)
    local foundItem = nil
    local allFoundItems = {}
    local minPos = math.huge
    local maxEnd = 0

    for i = 0, numItems - 1 do
        local item = reaper.GetTrackMediaItem(track, i)
        if reaper.IsMediaItemSelected(item) then
            local iPos = reaper.GetMediaItemInfo_Value(item, "D_POSITION")
            local iLen = reaper.GetMediaItemInfo_Value(item, "D_LENGTH")
            local iEnd = iPos + iLen
            if not foundItem then
                foundItem = item  -- Keep first for audio extraction
            end
            table.insert(allFoundItems, item)
            minPos = math.min(minPos, iPos)
            maxEnd = math.max(maxEnd, iEnd)
        end
    end

    if not foundItem then return nil, "No selected items on track" end

    local take = reaper.GetActiveTake(foundItem)
    if not take then return nil, "No active take" end

    local source = reaper.GetMediaItemTake_Source(take)
    if not source then return nil, "No source" end

    local sourceFile = reaper.GetMediaSourceFileName(source, "")
    if not sourceFile or sourceFile == "" then return nil, "No source file" end

    local itemPos = reaper.GetMediaItemInfo_Value(foundItem, "D_POSITION")
    local itemLen = reaper.GetMediaItemInfo_Value(foundItem, "D_LENGTH")
    local takeOffset = reaper.GetMediaItemTakeInfo_Value(take, "D_STARTOFFS")
    local playrate = reaper.GetMediaItemTakeInfo_Value(take, "D_PLAYRATE")

    -- Extract the full item (not a sub-selection)
    local duration = itemLen * playrate
    local sourceOffset = takeOffset

    local ffmpegCmd = string.format(
        'ffmpeg -y -i "%s" -ss %.6f -t %.6f -ar 44100 -ac 2 "%s"' .. suppressStderr(),
        sourceFile, sourceOffset, duration, outputPath
    )

    execHidden(ffmpegCmd)

    local f = io.open(outputPath, "r")
    if f then f:close(); return outputPath, nil, foundItem, allFoundItems
    else return nil, "Failed to extract audio", nil, nil end
end

-- Render a single item to WAV (for in-place multi-item processing)
local function renderSingleItemToWav(item, outputPath)
    if not item or not reaper.ValidatePtr(item, "MediaItem*") then
        return nil, "Invalid item"
    end

    local take = reaper.GetActiveTake(item)
    if not take then return nil, "No active take" end

    local source = reaper.GetMediaItemTake_Source(take)
    if not source then return nil, "No source" end

    local sourceFile = reaper.GetMediaSourceFileName(source, "")
    if not sourceFile or sourceFile == "" then return nil, "No source file" end

    local itemPos = reaper.GetMediaItemInfo_Value(item, "D_POSITION")
    local itemLen = reaper.GetMediaItemInfo_Value(item, "D_LENGTH")
    local takeOffset = reaper.GetMediaItemTakeInfo_Value(take, "D_STARTOFFS")
    local playrate = reaper.GetMediaItemTakeInfo_Value(take, "D_PLAYRATE")

    local duration = itemLen * playrate
    local sourceOffset = takeOffset

    local ffmpegCmd = string.format(
        'ffmpeg -y -i "%s" -ss %.6f -t %.6f -ar 44100 -ac 2 "%s"' .. suppressStderr(),
        sourceFile, sourceOffset, duration, outputPath
    )

    execHidden(ffmpegCmd)

    local f = io.open(outputPath, "r")
    if f then f:close(); return outputPath, nil
    else return nil, "Failed to extract audio" end
end

-- Progress window state
local progressState = {
    running = false,
    outputDir = nil,
    stdoutFile = nil,
    logFile = nil,
    percent = 0,
    stage = "Starting...",
    startTime = 0,
    wasMouseDown = false,  -- Track mouse state for click detection
    -- Nerd terminal state
    showTerminal = false,
    terminalLines = {},
    terminalScrollPos = 0,
    lastTerminalUpdate = 0,
}

-- Multi-track queue state (declared early for access in drawProgressWindow)
local multiTrackQueue = {
    tracks = {},           -- List of tracks to process
    currentIndex = 0,      -- Current track being processed
    totalTracks = 0,       -- Total number of tracks
    active = false,        -- Is multi-track mode active
    currentTrackName = "", -- Name of current track being processed
    currentSourceTrack = nil, -- Track to place stems under
}

-- Forward declarations for multi-track processing
local runSingleTrackSeparation
local startSeparationProcessForJob
local updateAllJobsProgress
local allJobsDone
local getOverallProgress
local showMultiTrackProgressWindow
local processAllStemsResult

-- Progress window base dimensions for scaling (taller for art)
local PROGRESS_BASE_W = 480
local PROGRESS_BASE_H = 420

-- Progress window resizable flag
local progressWindowResizableSet = false

-- Make progress window resizable
local function makeProgressWindowResizable()
    if progressWindowResizableSet then return true end
    if not reaper.JS_Window_Find then return false end

    local hwnd = reaper.JS_Window_Find("AI STEMperator - Processing...", true)
    if not hwnd then return false end

    local style = reaper.JS_Window_GetLong(hwnd, "STYLE")
    if style then
        local WS_THICKFRAME = 0x00040000
        local WS_MAXIMIZEBOX = 0x00010000
        reaper.JS_Window_SetLong(hwnd, "STYLE", style | WS_THICKFRAME | WS_MAXIMIZEBOX)
    end

    progressWindowResizableSet = true
    return true
end

-- Animated waveform data for eye candy
local waveformState = {
    bars = {},
    particles = {},
    lastUpdate = 0,
    pulsePhase = 0,
}

-- Initialize waveform bars
local function initWaveformBars(count)
    waveformState.bars = {}
    for i = 1, count do
        waveformState.bars[i] = {
            height = math.random() * 0.5 + 0.2,
            targetHeight = math.random() * 0.8 + 0.2,
            velocity = 0,
            phase = math.random() * math.pi * 2,
        }
    end
end

-- Draw progress window with stem colors and eye candy (scalable)
local function drawProgressWindow()
    local w, h = gfx.w, gfx.h

    -- Calculate scale based on window size
    local scaleW = w / PROGRESS_BASE_W
    local scaleH = h / PROGRESS_BASE_H
    local scale = math.min(scaleW, scaleH)
    scale = math.max(0.5, math.min(4.0, scale))  -- Clamp scale

    -- Scaling helper
    local function PS(val) return math.floor(val * scale + 0.5) end

    -- Try to make window resizable
    makeProgressWindowResizable()

    -- === PROCEDURAL ART AS FULL BACKGROUND LAYER ===
    -- Pure black/white background first
    if SETTINGS.darkMode then
        gfx.set(0, 0, 0, 1)
    else
        gfx.set(1, 1, 1, 1)
    end
    gfx.rect(0, 0, w, h, 1)

    -- Update art animation time
    proceduralArt.time = proceduralArt.time + 0.016  -- ~60fps

    -- Draw procedural art covering entire window (background layer)
    drawProceduralArt(0, 0, w, h, proceduralArt.time, 0, true)

    -- Semi-transparent overlay for readability - pure black/white
    if SETTINGS.darkMode then
        gfx.set(0, 0, 0, 0.5)
    else
        gfx.set(1, 1, 1, 0.5)
    end
    gfx.rect(0, 0, w, h, 1)

    -- Mouse position for UI interactions
    local mx, my = gfx.mouse_x, gfx.mouse_y
    local mouseDown = gfx.mouse_cap & 1 == 1

    -- Tooltip tracking
    local tooltipText = nil
    local tooltipX, tooltipY = 0, 0

    -- === THEME TOGGLE (top right) ===
    local themeSize = PS(18)
    local themeX = w - themeSize - PS(8)
    local themeY = PS(6)
    local themeHover = mx >= themeX and mx <= themeX + themeSize and my >= themeY and my <= themeY + themeSize

    if SETTINGS.darkMode then
        gfx.set(0.7, 0.7, 0.5, themeHover and 1 or 0.5)
        gfx.circle(themeX + themeSize/2, themeY + themeSize/2, themeSize/2 - 2, 1, 1)
        gfx.set(0, 0, 0, 1)  -- Pure black for moon overlay
        gfx.circle(themeX + themeSize/2 + 3, themeY + themeSize/2 - 2, themeSize/2 - 3, 1, 1)
    else
        gfx.set(0.9, 0.7, 0.2, themeHover and 1 or 0.7)
        gfx.circle(themeX + themeSize/2, themeY + themeSize/2, themeSize/3, 1, 1)
        for i = 0, 7 do
            local angle = i * math.pi / 4
            local x1 = themeX + themeSize/2 + math.cos(angle) * (themeSize/3 + 1)
            local y1 = themeY + themeSize/2 + math.sin(angle) * (themeSize/3 + 1)
            local x2 = themeX + themeSize/2 + math.cos(angle) * (themeSize/2 - 1)
            local y2 = themeY + themeSize/2 + math.sin(angle) * (themeSize/2 - 1)
            gfx.line(x1, y1, x2, y2)
        end
    end

    -- Theme click and tooltip
    if themeHover then
        tooltipText = SETTINGS.darkMode and T("switch_light") or T("switch_dark")
        tooltipX, tooltipY = mx + PS(10), my + PS(15)
        if mouseDown and not progressState.wasMouseDown then
            SETTINGS.darkMode = not SETTINGS.darkMode
            updateTheme()
            saveSettings()
        end
    end

    -- === LANGUAGE TOGGLE (next to theme) ===
    local langCode = string.upper(SETTINGS.language or "EN")
    gfx.setfont(1, "Arial", PS(8))
    local langW = gfx.measurestr(langCode)
    local langX = themeX - langW - PS(10)
    local langY = themeY + PS(3)
    local langHover = mx >= langX - PS(3) and mx <= langX + langW + PS(3) and my >= langY - PS(2) and my <= langY + PS(10)
    gfx.set(0.5, 0.6, 0.8, langHover and 1 or 0.4)
    gfx.x = langX
    gfx.y = langY
    gfx.drawstr(langCode)

    -- Language tooltip and click
    if langHover then
        tooltipText = T("tooltip_change_language")
        tooltipX, tooltipY = mx + PS(10), my + PS(15)
    end
    if langHover and mouseDown and not progressState.wasMouseDown then
        local langs = {"en", "nl", "de"}
        local currentIdx = 1
        for i, l in ipairs(langs) do
            if l == SETTINGS.language then currentIdx = i break end
        end
        local nextIdx = (currentIdx % #langs) + 1
        setLanguage(langs[nextIdx])
        saveSettings()
    end

    -- === FX TOGGLE (below theme icon) ===
    local fxSize = PS(16)
    local fxX = themeX + (themeSize - fxSize) / 2
    local fxY = themeY + themeSize + PS(3)
    local fxHover = mx >= fxX - PS(2) and mx <= fxX + fxSize + PS(2) and my >= fxY - PS(2) and my <= fxY + fxSize + PS(2)

    local fxAlpha = fxHover and 1 or 0.7
    if SETTINGS.visualFX then
        gfx.set(0.4, 0.9, 0.5, fxAlpha)
    else
        gfx.set(0.5, 0.5, 0.5, fxAlpha * 0.6)
    end
    gfx.setfont(1, "Arial", PS(9), string.byte('b'))
    local fxText = "FX"
    local fxTextW = gfx.measurestr(fxText)
    gfx.x = fxX + (fxSize - fxTextW) / 2
    gfx.y = fxY + PS(1)
    gfx.drawstr(fxText)

    if SETTINGS.visualFX then
        gfx.set(1, 1, 0.5, fxAlpha * 0.8)
        gfx.circle(fxX - PS(1), fxY + PS(2), PS(1.5), 1, 1)
        gfx.circle(fxX + fxSize, fxY + fxSize - PS(2), PS(1.5), 1, 1)
    else
        gfx.set(0.8, 0.3, 0.3, fxAlpha)
        gfx.line(fxX - PS(1), fxY + fxSize / 2, fxX + fxSize + PS(1), fxY + fxSize / 2)
    end

    if fxHover then
        tooltipText = SETTINGS.visualFX and T("fx_disable") or T("fx_enable")
        tooltipX, tooltipY = mx + PS(10), my + PS(15)
    end
    if fxHover and mouseDown and not progressState.wasMouseDown then
        SETTINGS.visualFX = not SETTINGS.visualFX
        saveSettings()
    end

    -- NOTE: wasMouseDown is set at END of function to allow art click detection

    -- Get selected stems for colors
    local selectedStems = {}
    for _, stem in ipairs(STEMS) do
        if stem.selected and (not stem.sixStemOnly or SETTINGS.model == "htdemucs_6s") then
            table.insert(selectedStems, stem)
        end
    end

    -- Model badge (aligned with stems row at right side)
    local modelText = SETTINGS.model or "htdemucs"
    gfx.setfont(1, "Arial", PS(11))
    local modelW = gfx.measurestr(modelText) + PS(16)
    local badgeX = w - modelW - PS(20)
    local badgeY = PS(61)  -- Aligned with stems row
    local badgeH = PS(18)
    gfx.set(THEME.inputBg[1], THEME.inputBg[2], THEME.inputBg[3], 1)
    gfx.rect(badgeX, badgeY, modelW, badgeH, 1)
    gfx.set(THEME.border[1], THEME.border[2], THEME.border[3], 1)
    gfx.rect(badgeX, badgeY, modelW, badgeH, 0)
    gfx.set(THEME.accent[1], THEME.accent[2], THEME.accent[3], 1)
    gfx.x = badgeX + PS(8)
    gfx.y = badgeY + PS(2)
    gfx.drawstr(modelText)

    -- Title with colored STEM
    gfx.setfont(1, "Arial", PS(18), string.byte('b'))
    local titleX = PS(25)
    local titleY = PS(28)

    -- In multi-track mode, show which track
    if multiTrackQueue.active then
        gfx.set(THEME.text[1], THEME.text[2], THEME.text[3], 1)
        gfx.x = titleX
        gfx.y = titleY
        gfx.drawstr("Track " .. multiTrackQueue.currentIndex .. "/" .. multiTrackQueue.totalTracks .. ": " .. (multiTrackQueue.currentTrackName or ""))
    else
        -- Draw "AI " in theme color
        gfx.set(THEME.text[1], THEME.text[2], THEME.text[3], 1)
        gfx.x = titleX
        gfx.y = titleY
        gfx.drawstr("AI ")
        titleX = titleX + gfx.measurestr("AI ")

        -- Draw "STEM" with each letter in stem color
        local stemLetterColors = {
            {229/255, 115/255, 115/255},  -- S = Vocals (red)
            {100/255, 181/255, 246/255},  -- T = Drums (blue)
            {186/255, 104/255, 200/255},  -- E = Bass (purple)
            {129/255, 199/255, 132/255},  -- M = Other (green)
        }
        local stemLetters = {"S", "T", "E", "M"}
        for i, letter in ipairs(stemLetters) do
            gfx.set(stemLetterColors[i][1], stemLetterColors[i][2], stemLetterColors[i][3], 1)
            gfx.x = titleX
            gfx.y = titleY
            gfx.drawstr(letter)
            titleX = titleX + gfx.measurestr(letter)
        end

        -- Draw "perator" in theme color
        gfx.set(THEME.text[1], THEME.text[2], THEME.text[3], 1)
        gfx.x = titleX
        gfx.y = titleY
        gfx.drawstr("perator")
    end

    -- Stem indicators (simple colored boxes)
    local stemX = PS(25)
    local stemY = PS(63)
    local stemBoxSize = PS(14)
    gfx.setfont(1, "Arial", PS(11))
    for _, stem in ipairs(STEMS) do
        if stem.selected and (not stem.sixStemOnly or SETTINGS.model == "htdemucs_6s") then
            -- Stem color box
            gfx.set(stem.color[1]/255, stem.color[2]/255, stem.color[3]/255, 1)
            gfx.rect(stemX, stemY, stemBoxSize, stemBoxSize, 1)
            -- Stem name
            gfx.set(THEME.textDim[1], THEME.textDim[2], THEME.textDim[3], 1)
            gfx.x = stemX + stemBoxSize + PS(6)
            gfx.y = stemY + PS(1)
            gfx.drawstr(stem.name)
            stemX = stemX + stemBoxSize + gfx.measurestr(stem.name) + PS(20)
        end
    end

    -- Progress bar
    local barX = PS(25)
    local barY = PS(98)
    local barW = w - PS(50)
    local barH = PS(28)

    -- Progress bar background
    gfx.set(THEME.inputBg[1], THEME.inputBg[2], THEME.inputBg[3], 1)
    gfx.rect(barX, barY, barW, barH, 1)
    gfx.set(THEME.border[1], THEME.border[2], THEME.border[3], 1)
    gfx.rect(barX, barY, barW, barH, 0)

    -- Progress bar fill with stem color gradient
    local fillWidth = math.floor(barW * progressState.percent / 100)
    if fillWidth > 0 and #selectedStems > 0 then
        for x = 0, fillWidth - 1 do
            local pos = x / math.max(1, fillWidth - 1)
            local idx = math.floor(pos * (#selectedStems - 1)) + 1
            local nextIdx = math.min(idx + 1, #selectedStems)
            local blend = (pos * (#selectedStems - 1)) % 1

            idx = math.max(1, math.min(idx, #selectedStems))
            nextIdx = math.max(1, math.min(nextIdx, #selectedStems))

            local r = (selectedStems[idx].color[1] * (1 - blend) + selectedStems[nextIdx].color[1] * blend) / 255
            local g = (selectedStems[idx].color[2] * (1 - blend) + selectedStems[nextIdx].color[2] * blend) / 255
            local b = (selectedStems[idx].color[3] * (1 - blend) + selectedStems[nextIdx].color[3] * blend) / 255

            gfx.set(r, g, b, 1)
            gfx.rect(barX + x, barY + 1, 1, barH - 2, 1)
        end
    end

    -- Progress percentage in center of bar
    gfx.setfont(1, "Arial", PS(14), string.byte('b'))
    local percentText = string.format("%d%%", progressState.percent)
    local tw = gfx.measurestr(percentText)
    gfx.set(1, 1, 1, 1)
    gfx.x = barX + (barW - tw) / 2
    gfx.y = barY + (barH - PS(14)) / 2
    gfx.drawstr(percentText)

    -- Stage text
    gfx.setfont(1, "Arial", PS(11))
    gfx.set(THEME.textDim[1], THEME.textDim[2], THEME.textDim[3], 1)
    gfx.x = PS(25)
    gfx.y = PS(130)
    local stageDisplay = progressState.stage or "Starting..."
    local maxStageLen = math.floor(70 * scale)
    if #stageDisplay > maxStageLen then stageDisplay = stageDisplay:sub(1, maxStageLen - 3) .. "..." end
    gfx.drawstr(stageDisplay)

    -- Info boxes row
    local infoY = PS(155)
    local infoH = PS(22)
    local infoGap = PS(8)

    -- Time info box
    local elapsed = os.time() - progressState.startTime
    local mins = math.floor(elapsed / 60)
    local secs = elapsed % 60

    gfx.set(THEME.inputBg[1], THEME.inputBg[2], THEME.inputBg[3], 1)
    gfx.rect(PS(25), infoY, PS(95), infoH, 1)
    gfx.set(THEME.border[1], THEME.border[2], THEME.border[3], 1)
    gfx.rect(PS(25), infoY, PS(95), infoH, 0)
    gfx.set(THEME.text[1], THEME.text[2], THEME.text[3], 1)
    gfx.x = PS(32)
    gfx.y = infoY + PS(4)
    gfx.drawstr(string.format("Elapsed: %d:%02d", mins, secs))

    -- ETA box (if available)
    local stageStr = progressState.stage or ""
    local eta = stageStr:match("ETA ([%d:]+)")
    if eta then
        gfx.set(THEME.inputBg[1], THEME.inputBg[2], THEME.inputBg[3], 1)
        gfx.rect(PS(128), infoY, PS(75), infoH, 1)
        gfx.set(THEME.border[1], THEME.border[2], THEME.border[3], 1)
        gfx.rect(PS(128), infoY, PS(75), infoH, 0)
        gfx.set(0.3, 0.75, 0.45, 1)
        gfx.x = PS(135)
        gfx.y = infoY + PS(4)
        gfx.drawstr("ETA: " .. eta)
    end

    -- Segment size indicator
    gfx.set(THEME.inputBg[1], THEME.inputBg[2], THEME.inputBg[3], 1)
    gfx.rect(w - PS(190), infoY, PS(60), infoH, 1)
    gfx.set(THEME.border[1], THEME.border[2], THEME.border[3], 1)
    gfx.rect(w - PS(190), infoY, PS(60), infoH, 0)
    gfx.set(THEME.textDim[1], THEME.textDim[2], THEME.textDim[3], 1)
    gfx.x = w - PS(183)
    gfx.y = infoY + PS(4)
    gfx.drawstr("Seg: 30")

    -- GPU indicator
    gfx.set(THEME.inputBg[1], THEME.inputBg[2], THEME.inputBg[3], 1)
    gfx.rect(w - PS(122), infoY, PS(97), infoH, 1)
    gfx.set(THEME.border[1], THEME.border[2], THEME.border[3], 1)
    gfx.rect(w - PS(122), infoY, PS(97), infoH, 0)
    gfx.set(0.3, 0.75, 0.45, 1)
    gfx.x = w - PS(115)
    gfx.y = infoY + PS(4)
    gfx.drawstr("GPU: DirectML")

    -- === NERD TERMINAL TOGGLE BUTTON ===
    local nerdBtnW = PS(22)
    local nerdBtnH = PS(18)
    local nerdBtnX = PS(25)
    local nerdBtnY = infoY
    local nerdHover = mx >= nerdBtnX and mx <= nerdBtnX + nerdBtnW and my >= nerdBtnY and my <= nerdBtnY + nerdBtnH

    -- Draw nerd button (terminal icon: >_)
    if progressState.showTerminal then
        gfx.set(0.3, 0.8, 0.3, 1)  -- Green when active
    else
        gfx.set(0.4, 0.4, 0.4, nerdHover and 1 or 0.6)
    end
    gfx.rect(nerdBtnX, nerdBtnY, nerdBtnW, nerdBtnH, 1)
    gfx.set(0, 0, 0, 1)
    gfx.setfont(1, "Courier", PS(10), string.byte('b'))
    gfx.x = nerdBtnX + PS(3)
    gfx.y = nerdBtnY + PS(3)
    gfx.drawstr(">_")

    -- Handle nerd button click and tooltip
    if nerdHover then
        if progressState.showTerminal then
            tooltipText = "Switch to Art View"
        else
            tooltipText = "Nerd Mode: Show terminal output"
        end
        tooltipX, tooltipY = mx + PS(10), my + PS(15)
        if mouseDown and not progressState.wasMouseDown then
            progressState.showTerminal = not progressState.showTerminal
        end
    end

    -- === DISPLAY AREA (ART or TERMINAL) ===
    local displayY = PS(190)
    local displayH = h - displayY - PS(55)
    local displayX = PS(15)
    local displayW = w - PS(30)

    if displayH > PS(100) then
        if progressState.showTerminal then
            -- === NERD TERMINAL VIEW ===
            -- Dark terminal background
            gfx.set(0.02, 0.02, 0.03, 0.98)
            gfx.rect(displayX, displayY, displayW, displayH, 1)

            -- Terminal border (green)
            gfx.set(0.2, 0.8, 0.2, 0.5)
            gfx.rect(displayX, displayY, displayW, displayH, 0)

            -- Terminal header
            gfx.set(0.2, 0.6, 0.2, 1)
            gfx.rect(displayX, displayY, displayW, PS(18), 1)
            gfx.set(0, 0, 0, 1)
            gfx.setfont(1, "Courier", PS(10), string.byte('b'))
            gfx.x = displayX + PS(5)
            gfx.y = displayY + PS(3)
            gfx.drawstr("DEMUCS OUTPUT")

            -- Read latest terminal output from stdout file
            local now = os.clock()
            if now - progressState.lastTerminalUpdate > 0.5 then  -- Update every 0.5 sec
                progressState.lastTerminalUpdate = now
                progressState.terminalLines = {}
                if progressState.stdoutFile then
                    local f = io.open(progressState.stdoutFile, "r")
                    if f then
                        for line in f:lines() do
                            table.insert(progressState.terminalLines, line)
                        end
                        f:close()
                    end
                end
            end

            -- Draw terminal lines (monospace, green on black)
            local termContentY = displayY + PS(22)
            local termContentH = displayH - PS(26)
            local lineHeight = PS(12)
            local maxLines = math.floor(termContentH / lineHeight)
            local startLine = math.max(1, #progressState.terminalLines - maxLines + 1)

            gfx.setfont(1, "Courier", PS(9))
            local lineY = termContentY
            for i = startLine, #progressState.terminalLines do
                if lineY < displayY + displayH - PS(5) then
                    local line = progressState.terminalLines[i] or ""
                    -- Truncate long lines
                    if #line > 80 then line = line:sub(1, 77) .. "..." end

                    -- Color based on content
                    if line:match("error") or line:match("Error") or line:match("ERROR") then
                        gfx.set(1, 0.3, 0.3, 1)  -- Red for errors
                    elseif line:match("warning") or line:match("Warning") then
                        gfx.set(1, 0.8, 0.3, 1)  -- Yellow for warnings
                    elseif line:match("PROGRESS") then
                        gfx.set(0.3, 0.8, 1, 1)  -- Cyan for progress
                    elseif line:match("Separating") or line:match("100%%") then
                        gfx.set(0.5, 1, 0.5, 1)  -- Bright green for success
                    else
                        gfx.set(0.3, 0.9, 0.3, 0.9)  -- Normal green
                    end

                    gfx.x = displayX + PS(5)
                    gfx.y = lineY
                    gfx.drawstr(line)
                    lineY = lineY + lineHeight
                end
            end

            -- Blinking cursor at bottom
            if math.floor(now * 2) % 2 == 0 then
                gfx.set(0.3, 1, 0.3, 1)
                gfx.x = displayX + PS(5)
                gfx.y = math.min(lineY, displayY + displayH - lineHeight - PS(5))
                gfx.drawstr("_")
            end

            -- Terminal hint
            gfx.set(0.3, 0.5, 0.3, 0.7)
            gfx.setfont(1, "Courier", PS(8))
            local termHint = "Click >_ to return to art"
            local termHintW = gfx.measurestr(termHint)
            gfx.x = displayX + (displayW - termHintW) / 2
            gfx.y = displayY + displayH - PS(12)
            gfx.drawstr(termHint)

        else
            -- === ART INFO VIEW ===
            -- Art is already drawn as full background layer
            -- Just show title/subtitle info in the display area

            -- Art title overlay (bottom of display area)
            gfx.setfont(1, "Arial", PS(11), string.byte('b'))
            gfx.set(1, 1, 1, 0.9)
            local artTitle = proceduralArt.title or "Generative Art"
            local titleW = gfx.measurestr(artTitle)
            gfx.x = displayX + (displayW - titleW) / 2
            gfx.y = displayY + displayH - PS(35)
            gfx.drawstr(artTitle)

            -- Art subtitle
            gfx.setfont(1, "Arial", PS(9))
            gfx.set(0.7, 0.7, 0.7, 0.8)
            local artSub = proceduralArt.subtitle or ""
            local subW = gfx.measurestr(artSub)
            gfx.x = displayX + (displayW - subW) / 2
            gfx.y = displayY + displayH - PS(20)
            gfx.drawstr(artSub)

            -- Click hint at bottom
            gfx.setfont(1, "Arial", PS(8))
            gfx.set(0.5, 0.5, 0.5, 0.6)
            local clickHint = T("click_new_art")
            local clickW = gfx.measurestr(clickHint)
            gfx.x = displayX + (displayW - clickW) / 2
            gfx.y = displayY + displayH - PS(8)
            gfx.drawstr(clickHint)

            -- Click anywhere in display area to regenerate art
            local artHover = mx >= displayX and mx <= displayX + displayW and my >= displayY and my <= displayY + displayH
            if artHover then
                tooltipText = T("click_new_art")
                tooltipX, tooltipY = mx + PS(10), my + PS(15)
                if mouseDown and not progressState.wasMouseDown then
                    generateNewArt()
                end
            end
        end
    end

    -- Update mouse state AFTER all click handling
    progressState.wasMouseDown = mouseDown

    -- Cancel hint (below art/terminal)
    gfx.set(THEME.textHint[1], THEME.textHint[2], THEME.textHint[3], 1)
    gfx.setfont(1, "Arial", PS(9))
    local hintText = T("hint_cancel")
    local hintW = gfx.measurestr(hintText)
    gfx.x = (w - hintW) / 2
    gfx.y = h - PS(20)
    gfx.drawstr(hintText)

    -- flarkAUDIO logo at top (translucent) - "flark" regular, "AUDIO" bold
    gfx.setfont(1, "Arial", PS(10))
    local flarkPart = "flark"
    local flarkPartW = gfx.measurestr(flarkPart)
    gfx.setfont(1, "Arial", PS(10), string.byte('b'))
    local audioPart = "AUDIO"
    local audioPartW = gfx.measurestr(audioPart)
    local totalLogoW = flarkPartW + audioPartW
    local logoStartX = (w - totalLogoW) / 2
    -- Orange text, 50% translucent
    gfx.set(1.0, 0.5, 0.1, 0.5)
    gfx.setfont(1, "Arial", PS(10))
    gfx.x = logoStartX
    gfx.y = PS(3)
    gfx.drawstr(flarkPart)
    gfx.setfont(1, "Arial", PS(10), string.byte('b'))
    gfx.x = logoStartX + flarkPartW
    gfx.y = PS(3)
    gfx.drawstr(audioPart)

    -- === DRAW TOOLTIP (always on top, with STEM colors) ===
    if tooltipText then
        gfx.setfont(1, "Arial", PS(11))
        local padding = PS(8)
        local tw = gfx.measurestr(tooltipText) + padding * 2
        local th = PS(18) + padding * 2
        local tx = tooltipX
        local ty = tooltipY

        -- Keep tooltip on screen
        if tx + tw > w then
            tx = w - tw - PS(5)
        end
        if ty + th > h then
            ty = tooltipY - th - PS(20)
        end

        -- Background (theme-aware)
        gfx.set(THEME.inputBg[1], THEME.inputBg[2], THEME.inputBg[3], 0.98)
        gfx.rect(tx, ty, tw, th, 1)

        -- Colored top border (STEM colors gradient)
        for i = 0, tw - 1 do
            local colorIdx = math.floor(i / tw * 4) + 1
            colorIdx = math.min(4, math.max(1, colorIdx))
            local c = STEM_BORDER_COLORS[colorIdx]
            gfx.set(c[1]/255, c[2]/255, c[3]/255, 0.9)
            gfx.line(tx + i, ty, tx + i, ty + 2)
        end

        -- Border (theme-aware)
        gfx.set(THEME.border[1], THEME.border[2], THEME.border[3], 1)
        gfx.rect(tx, ty, tw, th, 0)

        -- Text (theme-aware)
        gfx.set(THEME.text[1], THEME.text[2], THEME.text[3], 1)
        gfx.x = tx + padding
        gfx.y = ty + padding + PS(2)
        gfx.drawstr(tooltipText)
    end

    -- === F1 KEY HANDLING ===
    local char = gfx.getchar()
    if char == 26161 then  -- F1 key code
        -- Close progress window and show help
        -- Note: Help will be shown after processing completes
    end

    gfx.update()
end

-- Read latest progress from stdout file
local function updateProgressFromFile()
    local f = io.open(progressState.stdoutFile, "r")
    if not f then return end

    local lastProgress = nil
    for line in f:lines() do
        local percent, stage = line:match("PROGRESS:(%d+):(.+)")
        if percent then
            lastProgress = { percent = tonumber(percent), stage = stage }
        end
    end
    f:close()

    if lastProgress then
        progressState.percent = lastProgress.percent
        progressState.stage = lastProgress.stage
    end
end

-- Check if separation process is done (check for done.txt marker file)
local function checkSeparationDone()
    -- Check for done marker file
    local doneFile = io.open(progressState.outputDir .. PATH_SEP .. "done.txt", "r")
    if doneFile then
        doneFile:close()
        return true
    end
    -- Also check if progress hit 100%
    return progressState.percent >= 100
end

-- Background process handle
local bgProcess = nil

-- Start separation process in background (Windows)
local function startSeparationProcess(inputFile, outputDir, model)
    local logFile = outputDir .. PATH_SEP .. "separation_log.txt"
    local stdoutFile = outputDir .. PATH_SEP .. "stdout.txt"
    local doneFile = outputDir .. PATH_SEP .. "done.txt"

    -- Store for progress tracking
    progressState.outputDir = outputDir
    progressState.stdoutFile = stdoutFile
    progressState.logFile = logFile
    progressState.percent = 0
    progressState.stage = "Starting..."
    progressState.startTime = os.time()

    if OS == "Windows" then
        -- Create batch file to run Python with output redirection
        -- Single-track mode uses larger segment size (40) for better GPU utilization
        local batPath = outputDir .. PATH_SEP .. "run_separation.bat"
        local batFile = io.open(batPath, "w")
        if batFile then
            batFile:write('@echo off\n')
            batFile:write('"' .. PYTHON_PATH .. '" -u "' .. SEPARATOR_SCRIPT .. '" ')
            batFile:write('"' .. inputFile .. '" "' .. outputDir .. '" --model ' .. model .. ' --segment-size 30 ')
            batFile:write('>"' .. stdoutFile .. '" 2>"' .. logFile .. '"\n')
            batFile:write('echo DONE >"' .. doneFile .. '"\n')
            batFile:close()
        end

        -- Create VBS to run batch file hidden (window style 0)
        local vbsPath = outputDir .. PATH_SEP .. "run_hidden.vbs"
        local vbsFile = io.open(vbsPath, "w")
        if vbsFile then
            vbsFile:write('CreateObject("WScript.Shell").Run """' .. batPath .. '""", 0, False\n')
            vbsFile:close()
        end

        -- Try reaper.ExecProcess first (no CMD window), fallback to os.execute
        if reaper.ExecProcess then
            reaper.ExecProcess('wscript "' .. vbsPath .. '"', -1)
        else
            -- Use io.popen instead of os.execute to avoid CMD flash
            local handle = io.popen('wscript "' .. vbsPath .. '"')
            if handle then handle:close() end
        end
    else
        -- Unix: run in background
        -- Single-track mode uses larger segment size (40) for better GPU utilization
        local cmd = string.format(
            '"%s" -u "%s" "%s" "%s" --model %s --segment-size 30 >"%s" 2>"%s" && echo DONE > "%s/done.txt" &',
            PYTHON_PATH, SEPARATOR_SCRIPT, inputFile, outputDir, model, stdoutFile, logFile, outputDir
        )
        os.execute(cmd)
    end
end

-- Progress loop with UI
local function progressLoop()
    updateProgressFromFile()
    drawProgressWindow()

    local char = gfx.getchar()
    if char == -1 or char == 27 then  -- Window closed or ESC pressed
        -- Window closed by user
        progressState.running = false
        isProcessingActive = false  -- Reset guard so workflow can be restarted
        gfx.quit()
        -- If there's still a selection (or time selection mode), go back to dialog
        -- Otherwise show start screen with monitoring
        if hasAnySelection() or timeSelectionMode then
            reaper.defer(function() showStemSelectionDialog() end)
        else
            showMessage("Cancelled", T("separation_cancelled"), "info", true)
        end
        return
    end

    if checkSeparationDone() then
        -- Done!
        progressState.running = false
        gfx.quit()
        finishSeparation()
        return
    end

    -- Check timeout (10 minutes max)
    if os.time() - progressState.startTime > 600 then
        progressState.running = false
        isProcessingActive = false  -- Reset guard so workflow can be restarted
        gfx.quit()
        showMessage("Timeout", "Separation timed out after 10 minutes.", "error", true)
        return
    end

    reaper.defer(progressLoop)
end

-- Finish separation after progress completes
local function finishSeparationCallback()
    -- Small delay to ensure files are written
    local checkCount = 0
    local function checkFiles()
        checkCount = checkCount + 1
        local stems = {}
        for _, stem in ipairs(STEMS) do
            if stem.selected then
                local stemPath = progressState.outputDir .. PATH_SEP .. stem.file
                local f = io.open(stemPath, "r")
                if f then f:close(); stems[stem.name:lower()] = stemPath end
            end
        end

        if next(stems) then
            -- Success - process stems
            isProcessingActive = false  -- Reset guard so workflow can be restarted after result
            processStemsResult(stems)
        elseif checkCount < 10 then
            -- Retry
            reaper.defer(checkFiles)
        else
            -- Failed
            isProcessingActive = false  -- Reset guard so workflow can be restarted
            local errLog = io.open(progressState.logFile, "r")
            local errMsg = "No stems created"
            if errLog then
                local content = errLog:read("*a")
                errLog:close()
                if content and content ~= "" then
                    errMsg = errMsg .. "\n\nLog:\n" .. content:sub(1, 500)
                end
            end
            showMessage("Separation Failed", errMsg, "error", true)
        end
    end
    checkFiles()
end

-- Store callback reference
finishSeparation = finishSeparationCallback

-- Run AI separation with progress UI
local function runSeparationWithProgress(inputFile, outputDir, model)
    -- Load settings to get current theme
    loadSettings()
    updateTheme()

    -- Start the process
    startSeparationProcess(inputFile, outputDir, model)

    -- Use same size as main dialog (scaled proportionally for progress content)
    local winW = lastDialogW or 380
    local winH = lastDialogH or 340
    local winX, winY

    -- Use last dialog position if available, otherwise use mouse position
    local refX, refY  -- reference point for screen detection
    if lastDialogX and lastDialogY then
        winX = lastDialogX
        winY = lastDialogY
        refX = lastDialogX + winW / 2
        refY = lastDialogY + winH / 2
    else
        -- Fallback to mouse position
        local mouseX, mouseY = reaper.GetMousePosition()
        winX = mouseX - winW / 2
        winY = mouseY - winH / 2
        refX, refY = mouseX, mouseY
    end

    -- Clamp to current monitor
    winX, winY = clampToScreen(winX, winY, winW, winH, refX, refY)

    -- Open progress window
    gfx.init("AI STEMperator - Processing...", winW, winH, 0, winX, winY)
    progressWindowResizableSet = false  -- Reset so we try to make it resizable
    progressState.running = true

    -- Start progress loop
    reaper.defer(progressLoop)
end

-- Legacy synchronous separation (fallback)
local function runSeparation(inputFile, outputDir, model)
    local logFile = outputDir .. PATH_SEP .. "separation_log.txt"
    local stdoutFile = outputDir .. PATH_SEP .. "stdout.txt"

    local cmd
    if OS == "Windows" then
        local vbsPath = outputDir .. PATH_SEP .. "run_hidden.vbs"
        local vbsFile = io.open(vbsPath, "w")
        if vbsFile then
            local pythonCmd = string.format(
                '"%s" -u "%s" "%s" "%s" --model %s',
                PYTHON_PATH, SEPARATOR_SCRIPT, inputFile, outputDir, model
            )
            pythonCmd = pythonCmd:gsub('"', '""')
            vbsFile:write('Set WshShell = CreateObject("WScript.Shell")\n')
            vbsFile:write('WshShell.Run "cmd /c ' .. pythonCmd .. ' >""' .. stdoutFile .. '"" 2>""' .. logFile .. '""", 0, True\n')
            vbsFile:close()
            cmd = 'cscript //nologo "' .. vbsPath .. '"'
        end
    else
        cmd = string.format(
            '"%s" -u "%s" "%s" "%s" --model %s >"%s" 2>"%s"',
            PYTHON_PATH, SEPARATOR_SCRIPT, inputFile, outputDir, model, stdoutFile, logFile
        )
    end

    os.execute(cmd)

    local stems = {}
    for _, stem in ipairs(STEMS) do
        if stem.selected then
            local stemPath = outputDir .. PATH_SEP .. stem.file
            local f = io.open(stemPath, "r")
            if f then f:close(); stems[stem.name:lower()] = stemPath end
        end
    end

    if next(stems) == nil then
        local errLog = io.open(logFile, "r")
        local errMsg = "No stems created"
        if errLog then
            local content = errLog:read("*a")
            errLog:close()
            if content and content ~= "" then
                errMsg = errMsg .. "\n\nLog:\n" .. content:sub(1, 500)
            end
        end
        return nil, errMsg
    end
    return stems
end

-- Replace only a portion of an item with stems (for time selection mode)
-- Splits the item at selection boundaries and replaces only the selected portion
local function replaceInPlacePartial(item, stemPaths, selStart, selEnd)
    local track = reaper.GetMediaItem_Track(item)
    local origItemPos = reaper.GetMediaItemInfo_Value(item, "D_POSITION")
    local origItemEnd = origItemPos + reaper.GetMediaItemInfo_Value(item, "D_LENGTH")

    reaper.Undo_BeginBlock()

    -- We need to split the item at selection boundaries
    -- First, deselect all items and select only our target item
    reaper.SelectAllMediaItems(0, false)
    reaper.SetMediaItemSelected(item, true)

    local leftItem = nil   -- Part before selection (if any)
    local middleItem = item -- Part to replace
    local rightItem = nil  -- Part after selection (if any)

    -- Split at selection start if it's inside the item
    if selStart > origItemPos and selStart < origItemEnd then
        middleItem = reaper.SplitMediaItem(item, selStart)
        leftItem = item
        if middleItem then
            reaper.SetMediaItemSelected(leftItem, false)
            reaper.SetMediaItemSelected(middleItem, true)
        else
            -- Split failed, middle is still the original item
            middleItem = item
            leftItem = nil
        end
    end

    -- Split at selection end if it's inside what remains
    if middleItem then
        local midPos = reaper.GetMediaItemInfo_Value(middleItem, "D_POSITION")
        local midEnd = midPos + reaper.GetMediaItemInfo_Value(middleItem, "D_LENGTH")

        if selEnd > midPos and selEnd < midEnd then
            rightItem = reaper.SplitMediaItem(middleItem, selEnd)
            if rightItem then
                reaper.SetMediaItemSelected(rightItem, false)
            end
        end
    end

    -- Now delete the middle item and insert stems in its place
    local selLen = selEnd - selStart
    if middleItem then
        reaper.DeleteTrackMediaItem(track, middleItem)
    end

    -- Create stem items at the selection position
    local items = {}
    local stemColors = {}  -- Store colors for later take coloring
    for _, stem in ipairs(STEMS) do
        if stem.selected then
            local stemPath = stemPaths[stem.name:lower()]
            if stemPath then
                local newItem = reaper.AddMediaItemToTrack(track)
                reaper.SetMediaItemInfo_Value(newItem, "D_POSITION", selStart)
                reaper.SetMediaItemInfo_Value(newItem, "D_LENGTH", selLen)

                local take = reaper.AddTakeToMediaItem(newItem)
                local source = reaper.PCM_Source_CreateFromFile(stemPath)
                reaper.SetMediaItemTake_Source(take, source)
                reaper.GetSetMediaItemTakeInfo_String(take, "P_NAME", stem.name, true)
                -- Ensure take volume is at unity (1.0 = 0dB)
                reaper.SetMediaItemTakeInfo_Value(take, "D_VOL", 1.0)

                local stemColor = rgbToReaperColor(stem.color[1], stem.color[2], stem.color[3])
                reaper.SetMediaItemInfo_Value(newItem, "I_CUSTOMCOLOR", stemColor)

                items[#items + 1] = { item = newItem, take = take, color = stemColor, name = stem.name }
            end
        end
    end

    -- Merge into takes on the first item
    if #items > 1 then
        local mainItem = items[1].item
        -- Set main item color to first stem color
        reaper.SetMediaItemInfo_Value(mainItem, "I_CUSTOMCOLOR", items[1].color)

        for i = 2, #items do
            local srcTake = reaper.GetActiveTake(items[i].item)
            if srcTake then
                local newTake = reaper.AddTakeToMediaItem(mainItem)
                reaper.SetMediaItemTake_Source(newTake, reaper.GetMediaItemTake_Source(srcTake))
                reaper.GetSetMediaItemTakeInfo_String(newTake, "P_NAME", items[i].name, true)
                -- Ensure take volume is at unity (1.0 = 0dB)
                reaper.SetMediaItemTakeInfo_Value(newTake, "D_VOL", 1.0)
            end
            reaper.DeleteTrackMediaItem(track, items[i].item)
        end

        -- Now set the color for each take based on its stem
        -- Iterate through all takes and set their colors
        local numTakes = reaper.CountTakes(mainItem)
        for t = 0, numTakes - 1 do
            local take = reaper.GetTake(mainItem, t)
            if take then
                local _, takeName = reaper.GetSetMediaItemTakeInfo_String(take, "P_NAME", "", false)
                -- Find the matching stem color
                for _, stemData in ipairs(items) do
                    if stemData.name == takeName then
                        -- Set take color (I_CUSTOMCOLOR on the take)
                        reaper.SetMediaItemTakeInfo_Value(take, "I_CUSTOMCOLOR", stemData.color)
                        break
                    end
                end
            end
        end
    end

    reaper.Undo_EndBlock("Stemperator: Replace selection in-place", -1)
    return #items
end

-- Replace item in-place with stems as takes
local function replaceInPlace(item, stemPaths, itemPos, itemLen)
    local track = reaper.GetMediaItem_Track(item)
    reaper.Undo_BeginBlock()
    reaper.DeleteTrackMediaItem(track, item)

    local items = {}
    for _, stem in ipairs(STEMS) do
        if stem.selected then
            local stemPath = stemPaths[stem.name:lower()]
            if stemPath then
                local newItem = reaper.AddMediaItemToTrack(track)
                reaper.SetMediaItemInfo_Value(newItem, "D_POSITION", itemPos)
                reaper.SetMediaItemInfo_Value(newItem, "D_LENGTH", itemLen)

                local take = reaper.AddTakeToMediaItem(newItem)
                local source = reaper.PCM_Source_CreateFromFile(stemPath)
                reaper.SetMediaItemTake_Source(take, source)
                reaper.GetSetMediaItemTakeInfo_String(take, "P_NAME", stem.name, true)
                -- Ensure take volume is at unity (1.0 = 0dB)
                reaper.SetMediaItemTakeInfo_Value(take, "D_VOL", 1.0)

                local stemColor = rgbToReaperColor(stem.color[1], stem.color[2], stem.color[3])
                reaper.SetMediaItemInfo_Value(newItem, "I_CUSTOMCOLOR", stemColor)

                items[#items + 1] = { item = newItem, take = take, color = stemColor, name = stem.name }
            end
        end
    end

    -- Merge into takes
    if #items > 1 then
        local mainItem = items[1].item
        -- Set main item color to first stem color
        reaper.SetMediaItemInfo_Value(mainItem, "I_CUSTOMCOLOR", items[1].color)

        for i = 2, #items do
            local srcTake = reaper.GetActiveTake(items[i].item)
            if srcTake then
                local newTake = reaper.AddTakeToMediaItem(mainItem)
                reaper.SetMediaItemTake_Source(newTake, reaper.GetMediaItemTake_Source(srcTake))
                reaper.GetSetMediaItemTakeInfo_String(newTake, "P_NAME", items[i].name, true)
                -- Ensure take volume is at unity (1.0 = 0dB)
                reaper.SetMediaItemTakeInfo_Value(newTake, "D_VOL", 1.0)
            end
            reaper.DeleteTrackMediaItem(track, items[i].item)
        end

        -- Now set the color for each take based on its stem
        local numTakes = reaper.CountTakes(mainItem)
        for t = 0, numTakes - 1 do
            local take = reaper.GetTake(mainItem, t)
            if take then
                local _, takeName = reaper.GetSetMediaItemTakeInfo_String(take, "P_NAME", "", false)
                -- Find the matching stem color
                for _, stemData in ipairs(items) do
                    if stemData.name == takeName then
                        reaper.SetMediaItemTakeInfo_Value(take, "I_CUSTOMCOLOR", stemData.color)
                        break
                    end
                end
            end
        end
    end

    reaper.Undo_EndBlock("Stemperator: Replace in-place", -1)
    return #items
end

-- Create new tracks for each selected stem
local function createStemTracks(item, stemPaths, itemPos, itemLen)
    local track = reaper.GetMediaItem_Track(item)
    local trackIdx = math.floor(reaper.GetMediaTrackInfo_Value(track, "IP_TRACKNUMBER"))
    local _, trackName = reaper.GetSetMediaTrackInfo_String(track, "P_NAME", "", false)
    if trackName == "" then trackName = "Item" end

    local take = reaper.GetActiveTake(item)
    local sourceName = trackName
    if take then
        local _, takeName = reaper.GetSetMediaItemTakeInfo_String(take, "P_NAME", "", false)
        if takeName and takeName ~= "" then
            sourceName = takeName:match("([^/\\]+)%.[^.]*$") or takeName
        end
    end

    reaper.Undo_BeginBlock()

    local selectedCount = 0
    for _, stem in ipairs(STEMS) do
        if stem.selected and stemPaths[stem.name:lower()] then selectedCount = selectedCount + 1 end
    end

    local folderTrack = nil
    if SETTINGS.createFolder then
        reaper.InsertTrackAtIndex(trackIdx, true)
        folderTrack = reaper.GetTrack(0, trackIdx)
        reaper.GetSetMediaTrackInfo_String(folderTrack, "P_NAME", sourceName .. " - Stems", true)
        reaper.SetMediaTrackInfo_Value(folderTrack, "I_FOLDERDEPTH", 1)
        reaper.SetMediaTrackInfo_Value(folderTrack, "I_CUSTOMCOLOR", rgbToReaperColor(180, 140, 200))
        trackIdx = trackIdx + 1
    end

    local importedCount = 0
    for _, stem in ipairs(STEMS) do
        if stem.selected then
            local stemPath = stemPaths[stem.name:lower()]
            if stemPath then
                reaper.InsertTrackAtIndex(trackIdx + importedCount, true)
                local newTrack = reaper.GetTrack(0, trackIdx + importedCount)

                local newTrackName = selectedCount == 1 and (stem.name .. " - " .. sourceName) or (sourceName .. " - " .. stem.name)
                reaper.GetSetMediaTrackInfo_String(newTrack, "P_NAME", newTrackName, true)

                local color = rgbToReaperColor(stem.color[1], stem.color[2], stem.color[3])
                reaper.SetMediaTrackInfo_Value(newTrack, "I_CUSTOMCOLOR", color)

                local newItem = reaper.AddMediaItemToTrack(newTrack)
                reaper.SetMediaItemInfo_Value(newItem, "D_POSITION", itemPos)
                reaper.SetMediaItemInfo_Value(newItem, "D_LENGTH", itemLen)

                local newTake = reaper.AddTakeToMediaItem(newItem)
                reaper.SetMediaItemTake_Source(newTake, reaper.PCM_Source_CreateFromFile(stemPath))
                reaper.GetSetMediaItemTakeInfo_String(newTake, "P_NAME", stem.name, true)
                reaper.SetMediaItemInfo_Value(newItem, "I_CUSTOMCOLOR", color)

                importedCount = importedCount + 1
            end
        end
    end

    if folderTrack and importedCount > 0 then
        reaper.SetMediaTrackInfo_Value(reaper.GetTrack(0, trackIdx + importedCount - 1), "I_FOLDERDEPTH", -1)
    end

    if SETTINGS.deleteOriginalTrack then
        reaper.DeleteTrack(track)
    elseif SETTINGS.deleteOriginal then
        reaper.DeleteTrackMediaItem(track, item)
    elseif SETTINGS.muteOriginal then
        reaper.SetMediaItemInfo_Value(item, "B_MUTE", 1)
    elseif SETTINGS.muteSelection then
        -- Mute only the selection portion by splitting and muting that part
        -- Use the ORIGINAL time selection (stored when separation started), not current selection
        local selStart, selEnd = timeSelectionStart, timeSelectionEnd
        -- Fallback to current selection if no stored selection (shouldn't happen, but safety)
        if selEnd <= selStart then
            selStart, selEnd = reaper.GetSet_LoopTimeRange(false, false, 0, 0, false)
        end
        local origItemPos = reaper.GetMediaItemInfo_Value(item, "D_POSITION")
        local origItemEnd = origItemPos + reaper.GetMediaItemInfo_Value(item, "D_LENGTH")

        -- Check if there's a valid time selection overlapping the item
        if selEnd > selStart and selStart < origItemEnd and selEnd > origItemPos then
            -- Clamp selection to item bounds
            local muteStart = math.max(selStart, origItemPos)
            local muteEnd = math.min(selEnd, origItemEnd)

            -- Split at selection start (if inside item)
            local middleItem = item
            if muteStart > origItemPos then
                middleItem = reaper.SplitMediaItem(item, muteStart)
            end

            -- Split at selection end (if inside remaining item)
            if middleItem then
                local midPos = reaper.GetMediaItemInfo_Value(middleItem, "D_POSITION")
                local midEnd = midPos + reaper.GetMediaItemInfo_Value(middleItem, "D_LENGTH")
                if muteEnd < midEnd then
                    reaper.SplitMediaItem(middleItem, muteEnd)
                end
                -- Mute the middle section
                reaper.SetMediaItemInfo_Value(middleItem, "B_MUTE", 1)
            end
        else
            -- No valid selection, mute entire item
            reaper.SetMediaItemInfo_Value(item, "B_MUTE", 1)
        end
    elseif SETTINGS.deleteSelection then
        -- Delete only the selection portion by splitting and deleting that part
        -- Use the ORIGINAL time selection (stored when separation started), not current selection
        local selStart, selEnd = timeSelectionStart, timeSelectionEnd
        -- Fallback to current selection if no stored selection (shouldn't happen, but safety)
        if selEnd <= selStart then
            selStart, selEnd = reaper.GetSet_LoopTimeRange(false, false, 0, 0, false)
        end
        local origItemPos = reaper.GetMediaItemInfo_Value(item, "D_POSITION")
        local origItemEnd = origItemPos + reaper.GetMediaItemInfo_Value(item, "D_LENGTH")

        -- Check if there's a valid time selection overlapping the item
        if selEnd > selStart and selStart < origItemEnd and selEnd > origItemPos then
            -- Clamp selection to item bounds
            local delStart = math.max(selStart, origItemPos)
            local delEnd = math.min(selEnd, origItemEnd)

            -- Split at selection start (if inside item)
            local middleItem = item
            if delStart > origItemPos then
                middleItem = reaper.SplitMediaItem(item, delStart)
            end

            -- Split at selection end (if inside remaining item)
            if middleItem then
                local midPos = reaper.GetMediaItemInfo_Value(middleItem, "D_POSITION")
                local midEnd = midPos + reaper.GetMediaItemInfo_Value(middleItem, "D_LENGTH")
                if delEnd < midEnd then
                    reaper.SplitMediaItem(middleItem, delEnd)
                end
                -- Delete the middle section
                reaper.DeleteTrackMediaItem(track, middleItem)
            end
        else
            -- No valid selection, delete entire item
            reaper.DeleteTrackMediaItem(track, item)
        end
    end
    -- If none of the above, leave item as-is

    reaper.Undo_EndBlock("Stemperator: Create stem tracks", -1)
    return importedCount
end

-- Store item reference for async workflow
local selectedItem = nil
local itemPos = 0
local itemLen = 0
-- timeSelectionMode, timeSelectionStart, timeSelectionEnd declared at top of file
local timeSelectionSourceItem = nil  -- The item found in time selection (for in-place replacement)
local itemSubSelection = false  -- true when we rendered only a portion of the selected item
local itemSubSelStart = 0
local itemSubSelEnd = 0

-- Get all items that overlap with a time range
-- If selectedOnly is true, only returns items that are also selected
local function getItemsInTimeRange(startTime, endTime, selectedOnly)
    local items = {}
    local numTracks = reaper.CountTracks(0)
    for t = 0, numTracks - 1 do
        local track = reaper.GetTrack(0, t)
        local numItems = reaper.CountTrackMediaItems(track)
        for i = 0, numItems - 1 do
            local item = reaper.GetTrackMediaItem(track, i)
            local itemStart = reaper.GetMediaItemInfo_Value(item, "D_POSITION")
            local itemEnd = itemStart + reaper.GetMediaItemInfo_Value(item, "D_LENGTH")
            -- Check if item overlaps with time range
            if itemStart < endTime and itemEnd > startTime then
                -- If selectedOnly, check if item is selected
                if selectedOnly then
                    if reaper.IsMediaItemSelected(item) then
                        table.insert(items, item)
                    end
                else
                    table.insert(items, item)
                end
            end
        end
    end
    return items
end

-- Mute the selection portion of selected items within a time range
local function muteSelectionInItems(startTime, endTime)
    local items = getItemsInTimeRange(startTime, endTime, true)  -- selectedOnly = true
    for _, item in ipairs(items) do
        local track = reaper.GetMediaItem_Track(item)
        local origItemPos = reaper.GetMediaItemInfo_Value(item, "D_POSITION")
        local origItemEnd = origItemPos + reaper.GetMediaItemInfo_Value(item, "D_LENGTH")
        local muteStart = math.max(startTime, origItemPos)
        local muteEnd = math.min(endTime, origItemEnd)

        local middleItem = item
        if muteStart > origItemPos then
            middleItem = reaper.SplitMediaItem(item, muteStart)
        end
        if middleItem then
            local midEnd = reaper.GetMediaItemInfo_Value(middleItem, "D_POSITION") + reaper.GetMediaItemInfo_Value(middleItem, "D_LENGTH")
            if muteEnd < midEnd then
                reaper.SplitMediaItem(middleItem, muteEnd)
            end
            reaper.SetMediaItemInfo_Value(middleItem, "B_MUTE", 1)
        end
    end
    return #items
end

-- Delete the selection portion of selected items within a time range
local function deleteSelectionInItems(startTime, endTime)
    local items = getItemsInTimeRange(startTime, endTime, true)  -- selectedOnly = true
    -- Process in reverse order to avoid index shifting issues
    for i = #items, 1, -1 do
        local item = items[i]
        local track = reaper.GetMediaItem_Track(item)
        local origItemPos = reaper.GetMediaItemInfo_Value(item, "D_POSITION")
        local origItemEnd = origItemPos + reaper.GetMediaItemInfo_Value(item, "D_LENGTH")
        local delStart = math.max(startTime, origItemPos)
        local delEnd = math.min(endTime, origItemEnd)

        local middleItem = item
        if delStart > origItemPos then
            middleItem = reaper.SplitMediaItem(item, delStart)
        end
        if middleItem then
            local midEnd = reaper.GetMediaItemInfo_Value(middleItem, "D_POSITION") + reaper.GetMediaItemInfo_Value(middleItem, "D_LENGTH")
            if delEnd < midEnd then
                reaper.SplitMediaItem(middleItem, delEnd)
            end
            reaper.DeleteTrackMediaItem(track, middleItem)
        end
    end
    return #items
end

-- Create new tracks for stems from time selection (no original item)
local function createStemTracksForSelection(stemPaths, selPos, selLen, sourceTrack)
    reaper.Undo_BeginBlock()

    -- Get reference track: use provided sourceTrack, or first selected track, or track 0
    local refTrack = sourceTrack or reaper.GetSelectedTrack(0, 0) or reaper.GetTrack(0, 0)
    local trackIdx = 0
    if refTrack then
        trackIdx = math.floor(reaper.GetMediaTrackInfo_Value(refTrack, "IP_TRACKNUMBER"))
    end

    local selectedCount = 0
    for _, stem in ipairs(STEMS) do
        if stem.selected and stemPaths[stem.name:lower()] then selectedCount = selectedCount + 1 end
    end

    -- Get source track name for stem naming
    local folderTrack = nil
    local sourceName = "Selection"
    if refTrack then
        local _, trackName = reaper.GetTrackName(refTrack)
        if trackName and trackName ~= "" then
            sourceName = trackName
        end
    end
    if SETTINGS.createFolder then
        reaper.InsertTrackAtIndex(trackIdx, true)
        folderTrack = reaper.GetTrack(0, trackIdx)
        reaper.GetSetMediaTrackInfo_String(folderTrack, "P_NAME", sourceName .. " - Stems", true)
        reaper.SetMediaTrackInfo_Value(folderTrack, "I_FOLDERDEPTH", 1)
        reaper.SetMediaTrackInfo_Value(folderTrack, "I_CUSTOMCOLOR", rgbToReaperColor(180, 140, 200))
        trackIdx = trackIdx + 1
    end

    local importedCount = 0
    for _, stem in ipairs(STEMS) do
        if stem.selected then
            local stemPath = stemPaths[stem.name:lower()]
            if stemPath then
                reaper.InsertTrackAtIndex(trackIdx + importedCount, true)
                local newTrack = reaper.GetTrack(0, trackIdx + importedCount)

                local newTrackName = selectedCount == 1 and (stem.name .. " - " .. sourceName) or (sourceName .. " - " .. stem.name)
                reaper.GetSetMediaTrackInfo_String(newTrack, "P_NAME", newTrackName, true)

                local color = rgbToReaperColor(stem.color[1], stem.color[2], stem.color[3])
                reaper.SetMediaTrackInfo_Value(newTrack, "I_CUSTOMCOLOR", color)

                local newItem = reaper.AddMediaItemToTrack(newTrack)
                reaper.SetMediaItemInfo_Value(newItem, "D_POSITION", selPos)
                reaper.SetMediaItemInfo_Value(newItem, "D_LENGTH", selLen)

                local newTake = reaper.AddTakeToMediaItem(newItem)
                reaper.SetMediaItemTake_Source(newTake, reaper.PCM_Source_CreateFromFile(stemPath))
                reaper.GetSetMediaItemTakeInfo_String(newTake, "P_NAME", stem.name, true)
                reaper.SetMediaItemInfo_Value(newItem, "I_CUSTOMCOLOR", color)

                importedCount = importedCount + 1
            end
        end
    end

    if folderTrack and importedCount > 0 then
        reaper.SetMediaTrackInfo_Value(reaper.GetTrack(0, trackIdx + importedCount - 1), "I_FOLDERDEPTH", -1)
    end

    reaper.Undo_EndBlock("Stemperator: Create stem tracks from selection", -1)
    return importedCount
end

-- Store temp directory for async workflow
local workflowTempDir = nil
local workflowTempInput = nil

-- Process stems after separation completes (called from progress UI)
function processStemsResult(stems)
    local count
    local resultMsg

    if timeSelectionMode then
        -- Time selection mode: respect user's setting
        if SETTINGS.createNewTracks then
            -- Handle mute/delete options BEFORE creating stems (so new stems aren't affected)
            local actionMsg = ""
            if SETTINGS.muteOriginal then
                -- Mute only SELECTED items that overlap with time selection
                local items = getItemsInTimeRange(timeSelectionStart, timeSelectionEnd, true)
                for _, item in ipairs(items) do
                    reaper.SetMediaItemInfo_Value(item, "B_MUTE", 1)
                end
                local itemWord = #items == 1 and "item" or "items"
                actionMsg = "\n" .. #items .. " " .. itemWord .. " muted."
            elseif SETTINGS.muteSelection then
                -- Mute selection portion of SELECTED items
                local itemCount = muteSelectionInItems(timeSelectionStart, timeSelectionEnd)
                local itemWord = itemCount == 1 and "item" or "items"
                actionMsg = "\nSelection muted in " .. itemCount .. " " .. itemWord .. "."
            elseif SETTINGS.deleteOriginal then
                -- Delete only SELECTED items that overlap with time selection
                local items = getItemsInTimeRange(timeSelectionStart, timeSelectionEnd, true)
                for i = #items, 1, -1 do
                    local item = items[i]
                    reaper.DeleteTrackMediaItem(reaper.GetMediaItem_Track(item), item)
                end
                local itemWord = #items == 1 and "item" or "items"
                actionMsg = "\n" .. #items .. " " .. itemWord .. " deleted."
            elseif SETTINGS.deleteSelection then
                -- Delete selection portion of SELECTED items
                local itemCount = deleteSelectionInItems(timeSelectionStart, timeSelectionEnd)
                local itemWord = itemCount == 1 and "item" or "items"
                actionMsg = "\nSelection deleted from " .. itemCount .. " " .. itemWord .. "."
            end
            -- Now create stems (after mute/delete so they're not affected)
            -- In multi-track mode, use the source track from the queue
            local sourceTrack = multiTrackQueue.active and multiTrackQueue.currentSourceTrack or nil
            count = createStemTracksForSelection(stems, itemPos, itemLen, sourceTrack)
            local trackWord = count == 1 and "track" or "tracks"
            -- In multi-track mode, show which track we're on
            local trackInfo = ""
            if multiTrackQueue.active then
                trackInfo = " [Track " .. multiTrackQueue.currentIndex .. "/" .. multiTrackQueue.totalTracks .. ": " .. (multiTrackQueue.currentTrackName or "?") .. "]"
            end
            resultMsg = count .. " stem " .. trackWord .. " created from time selection." .. actionMsg .. trackInfo
        else
            -- In-place mode: replace only the selected portion of the item
            if timeSelectionSourceItem then
                -- Use partial replacement - splits the item and replaces only the selected part
                count = replaceInPlacePartial(timeSelectionSourceItem, stems, timeSelectionStart, timeSelectionEnd)
                resultMsg = count == 1 and "Selection replaced with stem." or "Selection replaced with stems as takes (press T to switch)."
            else
                -- Fallback: create new tracks if no source item
                local sourceTrack = multiTrackQueue.active and multiTrackQueue.currentSourceTrack or nil
                count = createStemTracksForSelection(stems, itemPos, itemLen, sourceTrack)
                local trackWord = count == 1 and "track" or "tracks"
                resultMsg = count .. " stem " .. trackWord .. " created from time selection."
            end
        end
    elseif SETTINGS.createNewTracks then
        count = createStemTracks(selectedItem, stems, itemPos, itemLen)
        local action = SETTINGS.deleteOriginalTrack and "Track deleted." or
                       (SETTINGS.deleteOriginal and "Item deleted." or
                       (SETTINGS.deleteSelection and "Selection deleted." or
                       (SETTINGS.muteOriginal and "Item muted." or
                       (SETTINGS.muteSelection and "Selection muted." or ""))))
        local trackWord = count == 1 and "track" or "tracks"
        resultMsg = count .. " stem " .. trackWord .. " created."
        if action ~= "" then resultMsg = resultMsg .. "\n" .. action end
    else
        -- Check if we processed a sub-selection of the item
        if itemSubSelection then
            -- Use partial replacement - splits the item and replaces only the selected part
            count = replaceInPlacePartial(selectedItem, stems, itemSubSelStart, itemSubSelEnd)
            resultMsg = count == 1 and "Selection replaced with stem." or "Selection replaced with stems as takes (press T to switch)."
        else
            count = replaceInPlace(selectedItem, stems, itemPos, itemLen)
            resultMsg = count == 1 and "Stem replaced." or "Stems added as takes (press T to switch)."
        end
    end

    local selectedNames = {}
    local selectedStemData = {}
    local is6Stem = (SETTINGS.model == "htdemucs_6s")
    for _, stem in ipairs(STEMS) do
        -- Only include stems that were actually processed (respect sixStemOnly flag)
        if stem.selected and (not stem.sixStemOnly or is6Stem) then
            selectedNames[#selectedNames + 1] = stem.name
            selectedStemData[#selectedStemData + 1] = stem
        end
    end

    -- Calculate and add timing info
    local totalTime = os.time() - (progressState.startTime or os.time())
    local totalMins = math.floor(totalTime / 60)
    local totalSecs = totalTime % 60
    local timeStr = string.format("%d:%02d", totalMins, totalSecs)
    resultMsg = resultMsg .. "\nTime: " .. timeStr

    reaper.UpdateArrange()

    -- Show custom result window
    showResultWindow(selectedStemData, resultMsg)
end

-- Result window state
local resultWindowState = {
    selectedStems = {},
    message = "",
    running = false,
    startTime = 0,
    confetti = {},
    rings = {},
}

-- Initialize celebration effects
local function initCelebration()
    resultWindowState.startTime = os.clock()
    resultWindowState.confetti = {}
    resultWindowState.rings = {}

    -- Create confetti particles
    for i = 1, 50 do
        table.insert(resultWindowState.confetti, {
            x = math.random() * 400 + 100,
            y = -math.random() * 100,
            vx = (math.random() - 0.5) * 4,
            vy = math.random() * 2 + 1,
            rotation = math.random() * math.pi * 2,
            rotSpeed = (math.random() - 0.5) * 0.3,
            size = math.random() * 8 + 4,
            colorIdx = math.random(1, 6),
            delay = math.random() * 0.5,
        })
    end

    -- Create expanding rings
    for i = 1, 3 do
        table.insert(resultWindowState.rings, {
            radius = 0,
            alpha = 1,
            delay = i * 0.15,
        })
    end
end

-- Draw result window (clean style matching main app)
local function drawResultWindow()
    local w, h = gfx.w, gfx.h

    -- Calculate scale
    local scale = math.min(w / 380, h / 340)
    scale = math.max(0.5, math.min(4.0, scale))
    local function PS(val) return math.floor(val * scale + 0.5) end

    -- === PROCEDURAL ART AS FULL BACKGROUND LAYER ===
    -- Pure black/white background first
    if SETTINGS.darkMode then
        gfx.set(0, 0, 0, 1)
    else
        gfx.set(1, 1, 1, 1)
    end
    gfx.rect(0, 0, w, h, 1)

    proceduralArt.time = proceduralArt.time + 0.016  -- ~60fps
    drawProceduralArt(0, 0, w, h, proceduralArt.time, 0, true)

    -- Semi-transparent overlay for readability - pure black/white
    if SETTINGS.darkMode then
        gfx.set(0, 0, 0, 0.5)
    else
        gfx.set(1, 1, 1, 0.5)
    end
    gfx.rect(0, 0, w, h, 1)

    -- Theme toggle button (sun/moon icon, top right)
    local themeSize = PS(20)
    local themeX = w - themeSize - PS(10)
    local themeY = PS(8)
    local mx, my = gfx.mouse_x, gfx.mouse_y
    local themeHover = mx >= themeX and mx <= themeX + themeSize and my >= themeY and my <= themeY + themeSize
    local mouseDown = gfx.mouse_cap & 1 == 1

    -- Draw theme toggle (circle with rays for sun, crescent for moon)
    if SETTINGS.darkMode then
        -- Moon icon (crescent)
        gfx.set(0.7, 0.7, 0.5, themeHover and 1 or 0.6)
        gfx.circle(themeX + themeSize/2, themeY + themeSize/2, themeSize/2 - 2, 1, 1)
        gfx.set(0, 0, 0, 1)  -- Pure black for moon overlay
        gfx.circle(themeX + themeSize/2 + 4, themeY + themeSize/2 - 3, themeSize/2 - 3, 1, 1)
    else
        -- Sun icon
        gfx.set(0.9, 0.7, 0.2, themeHover and 1 or 0.8)
        gfx.circle(themeX + themeSize/2, themeY + themeSize/2, themeSize/3, 1, 1)
        -- Rays
        for i = 0, 7 do
            local angle = i * math.pi / 4
            local x1 = themeX + themeSize/2 + math.cos(angle) * (themeSize/3 + 2)
            local y1 = themeY + themeSize/2 + math.sin(angle) * (themeSize/3 + 2)
            local x2 = themeX + themeSize/2 + math.cos(angle) * (themeSize/2 - 1)
            local y2 = themeY + themeSize/2 + math.sin(angle) * (themeSize/2 - 1)
            gfx.line(x1, y1, x2, y2)
        end
    end

    -- Handle theme toggle click
    if themeHover and mouseDown and not resultWindowState.wasMouseDown then
        SETTINGS.darkMode = not SETTINGS.darkMode
        updateTheme()
        saveSettings()  -- Persist theme change
    end

    -- Language toggle (next to theme)
    local langW = PS(22)
    local langH = PS(14)
    local langX = themeX - langW - PS(6)
    local langY = themeY + (themeSize - langH) / 2
    local langHover = mx >= langX and mx <= langX + langW and my >= langY and my <= langY + langH

    gfx.setfont(1, "Arial", PS(9), string.byte('b'))
    local langCode = string.upper(SETTINGS.language or "EN")
    local langTextW = gfx.measurestr(langCode)

    if langHover then
        gfx.set(0.4, 0.6, 0.9, 1)
        if mouseDown and not resultWindowState.wasMouseDown then
            local langs = {"en", "nl", "de"}
            local currentIdx = 1
            for i, l in ipairs(langs) do
                if l == SETTINGS.language then currentIdx = i; break end
            end
            local nextIdx = (currentIdx % #langs) + 1
            setLanguage(langs[nextIdx])
            saveSettings()
        end
    else
        gfx.set(THEME.textDim[1], THEME.textDim[2], THEME.textDim[3], 0.8)
    end
    gfx.x = langX + (langW - langTextW) / 2
    gfx.y = langY
    gfx.drawstr(langCode)

    -- Success icon (simple green circle with checkmark)
    local iconX = w / 2
    local iconY = PS(60)
    local iconR = PS(28)

    -- Green circle
    gfx.set(0.2, 0.65, 0.35, 1)
    gfx.circle(iconX, iconY, iconR, 1, 1)

    -- White checkmark
    gfx.set(1, 1, 1, 1)
    local cx, cy = iconX, iconY
    -- First part of checkmark
    local x1, y1 = cx - PS(10), cy
    local x2, y2 = cx - PS(3), cy + PS(8)
    gfx.line(x1, y1, x2, y2)
    gfx.line(x1, y1+1, x2, y2+1)
    -- Second part of checkmark
    local x3, y3 = cx + PS(10), cy - PS(7)
    gfx.line(x2, y2, x3, y3)
    gfx.line(x2, y2+1, x3, y3+1)

    -- Title with colored STEM letters: "STEMperation Complete!"
    gfx.setfont(1, "Arial", PS(18), string.byte('b'))

    -- STEM colors (same as STEMperate button)
    local stemLetterColors = {
        {255, 100, 100},  -- S = Vocals (red)
        {100, 200, 255},  -- T = Drums (blue)
        {150, 100, 255},  -- E = Bass (purple)
        {100, 255, 150},  -- M = Other (green)
    }

    local stemPart = "STEM"
    local restPart = "peration Complete!"
    local stemW = gfx.measurestr(stemPart)
    local restW = gfx.measurestr(restPart)
    local totalW = stemW + restW
    local titleX = (w - totalW) / 2
    local titleY = PS(100)

    -- Draw STEM with individual colored letters
    local charX = titleX
    for i = 1, 4 do
        local char = stemPart:sub(i, i)
        local color = stemLetterColors[i]
        gfx.set(color[1]/255, color[2]/255, color[3]/255, 1)
        gfx.x = charX
        gfx.y = titleY
        gfx.drawstr(char)
        charX = charX + gfx.measurestr(char)
    end

    -- Draw rest of title in normal text color
    gfx.set(THEME.text[1], THEME.text[2], THEME.text[3], 1)
    gfx.x = charX
    gfx.y = titleY
    gfx.drawstr(restPart)

    -- Stem indicators (simple colored boxes)
    local stemY = PS(125)
    local stemBoxSize = PS(14)
    gfx.setfont(1, "Arial", PS(11))

    -- Calculate total width to center
    local totalStemWidth = 0
    for _, stem in ipairs(resultWindowState.selectedStems) do
        totalStemWidth = totalStemWidth + stemBoxSize + gfx.measurestr(stem.name) + PS(16)
    end
    local stemX = (w - totalStemWidth) / 2

    for _, stem in ipairs(resultWindowState.selectedStems) do
        -- Stem color box
        gfx.set(stem.color[1]/255, stem.color[2]/255, stem.color[3]/255, 1)
        gfx.rect(stemX, stemY, stemBoxSize, stemBoxSize, 1)

        -- Stem name
        gfx.set(THEME.textDim[1], THEME.textDim[2], THEME.textDim[3], 1)
        gfx.x = stemX + stemBoxSize + PS(5)
        gfx.y = stemY + PS(1)
        gfx.drawstr(stem.name)
        stemX = stemX + stemBoxSize + gfx.measurestr(stem.name) + PS(16)
    end

    -- Target info (output mode)
    local targetY = PS(150)
    gfx.setfont(1, "Arial", PS(10))
    gfx.set(THEME.textDim[1], THEME.textDim[2], THEME.textDim[3], 1)
    local targetText = "Target: "
    if SETTINGS.createNewTracks then
        targetText = targetText .. "New tracks"
        if SETTINGS.createFolder then targetText = targetText .. " (folder)" end
    else
        targetText = targetText .. "In-place (as takes)"
    end
    -- Add action info
    if SETTINGS.muteOriginal then
        targetText = targetText .. " | Mute original"
    elseif SETTINGS.muteSelection then
        targetText = targetText .. " | Mute selection"
    elseif SETTINGS.deleteOriginal then
        targetText = targetText .. " | Delete original"
    elseif SETTINGS.deleteSelection then
        targetText = targetText .. " | Delete selection"
    elseif SETTINGS.deleteOriginalTrack then
        targetText = targetText .. " | Delete track"
    end
    local targetW = gfx.measurestr(targetText)
    gfx.x = (w - targetW) / 2
    gfx.y = targetY
    gfx.drawstr(targetText)

    -- Result message box
    local msgBoxY = PS(170)
    local msgBoxH = PS(70)
    gfx.set(THEME.inputBg[1], THEME.inputBg[2], THEME.inputBg[3], 1)
    gfx.rect(PS(20), msgBoxY, w - PS(40), msgBoxH, 1)
    gfx.set(THEME.border[1], THEME.border[2], THEME.border[3], 1)
    gfx.rect(PS(20), msgBoxY, w - PS(40), msgBoxH, 0)

    -- Result message text
    gfx.set(THEME.text[1], THEME.text[2], THEME.text[3], 1)
    gfx.setfont(1, "Arial", PS(11))
    local msgLines = {}
    for line in (resultWindowState.message .. "\n"):gmatch("([^\n]*)\n") do
        table.insert(msgLines, line)
    end
    local msgY = msgBoxY + PS(8)
    for _, line in ipairs(msgLines) do
        local lineW = gfx.measurestr(line)
        gfx.x = (w - lineW) / 2
        gfx.y = msgY
        gfx.drawstr(line)
        msgY = msgY + PS(13)
    end

    -- OK button (rounded pill style like main app)
    local btnW = PS(70)
    local btnH = PS(20)
    local btnX = (w - btnW) / 2
    local btnY = h - PS(40)

    local hover = mx >= btnX and mx <= btnX + btnW and my >= btnY and my <= btnY + btnH

    -- Button background
    if hover then
        gfx.set(THEME.buttonPrimaryHover[1], THEME.buttonPrimaryHover[2], THEME.buttonPrimaryHover[3], 1)
    else
        gfx.set(THEME.buttonPrimary[1], THEME.buttonPrimary[2], THEME.buttonPrimary[3], 1)
    end
    -- Draw rounded (pill-shaped) button
    for i = 0, btnH - 1 do
        local radius = btnH / 2
        local inset = 0
        if i < radius then
            inset = radius - math.sqrt(radius * radius - (radius - i) * (radius - i))
        elseif i > btnH - radius then
            inset = radius - math.sqrt(radius * radius - (i - (btnH - radius)) * (i - (btnH - radius)))
        end
        gfx.line(btnX + inset, btnY + i, btnX + btnW - inset, btnY + i)
    end

    -- Button text
    gfx.set(1, 1, 1, 1)
    gfx.setfont(1, "Arial", PS(13), string.byte('b'))
    local okText = "OK"
    local okW = gfx.measurestr(okText)
    gfx.x = btnX + (btnW - okW) / 2
    gfx.y = btnY + (btnH - PS(13)) / 2
    gfx.drawstr(okText)

    -- Hint at very bottom edge
    gfx.set(THEME.textHint[1], THEME.textHint[2], THEME.textHint[3], 1)
    gfx.setfont(1, "Arial", PS(9))
    local hint = "Enter / Space / ESC"
    local hintW = gfx.measurestr(hint)
    gfx.x = (w - hintW) / 2
    gfx.y = h - PS(12)
    gfx.drawstr(hint)

    -- flarkAUDIO logo at top (translucent) - "flark" regular, "AUDIO" bold
    gfx.setfont(1, "Arial", PS(10))
    local flarkPart = "flark"
    local flarkPartW = gfx.measurestr(flarkPart)
    gfx.setfont(1, "Arial", PS(10), string.byte('b'))
    local audioPart = "AUDIO"
    local audioPartW = gfx.measurestr(audioPart)
    local totalLogoW = flarkPartW + audioPartW
    local logoStartX = (w - totalLogoW) / 2
    -- Orange text, 50% translucent
    gfx.set(1.0, 0.5, 0.1, 0.5)
    gfx.setfont(1, "Arial", PS(10))
    gfx.x = logoStartX
    gfx.y = PS(3)
    gfx.drawstr(flarkPart)
    gfx.setfont(1, "Arial", PS(10), string.byte('b'))
    gfx.x = logoStartX + flarkPartW
    gfx.y = PS(3)
    gfx.drawstr(audioPart)

    gfx.update()

    -- Check for click on OK button
    if hover and mouseDown and not resultWindowState.wasMouseDown then
        return true  -- Close
    end

    resultWindowState.wasMouseDown = mouseDown

    local char = gfx.getchar()
    if char == -1 or char == 27 or char == 13 or char == 32 then  -- Window closed, ESC, Enter, or Space
        return true  -- Close
    end

    return false  -- Keep open
end

-- Result window loop
local function resultWindowLoop()
    -- Save window position for next time
    if reaper.JS_Window_GetRect then
        local hwnd = reaper.JS_Window_Find("Stemperator - Complete", true)
        if hwnd then
            local retval, left, top, right, bottom = reaper.JS_Window_GetRect(hwnd)
            if retval then
                lastDialogX = left
                lastDialogY = top
                lastDialogW = right - left
                lastDialogH = bottom - top
            end

            -- NOTE: Focus check removed - was causing double execution on multi-track processing
            -- The result window should stay open until user explicitly closes it
        end
    end

    if drawResultWindow() then
        gfx.quit()
        -- Geef focus terug aan REAPER main window
        local mainHwnd = reaper.GetMainHwnd()
        if mainHwnd and reaper.JS_Window_SetFocus then
            reaper.JS_Window_SetFocus(mainHwnd)
        end
        -- Reopen main dialog (if there's still a selection)
        reaper.defer(function() main() end)
        return
    end
    reaper.defer(resultWindowLoop)
end

-- Show result window
function showResultWindow(selectedStems, message)
    -- Load settings to get current theme
    loadSettings()
    updateTheme()

    resultWindowState.selectedStems = selectedStems
    resultWindowState.message = message
    resultWindowState.wasMouseDown = false

    -- Initialize celebration effects
    initCelebration()

    -- Restore playback state if it was playing before processing
    if savedPlaybackState == 1 then
        -- Was playing, resume playback
        reaper.OnPlayButton()
    elseif savedPlaybackState == 2 then
        -- Was paused, start and pause (to restore paused state)
        reaper.OnPlayButton()
        reaper.OnPauseButton()
    end

    -- Return focus to REAPER main window so user can interact
    local mainHwnd = reaper.GetMainHwnd()
    if mainHwnd and reaper.JS_Window_SetFocus then
        reaper.JS_Window_SetFocus(mainHwnd)
    end

    -- Use same size as main dialog
    local winW = lastDialogW or 380
    local winH = lastDialogH or 340
    local winX, winY

    -- Use last dialog position if available (exact position, no clamping)
    if lastDialogX and lastDialogY then
        winX = lastDialogX
        winY = lastDialogY
    else
        -- Fallback to mouse position with clamping
        local mouseX, mouseY = reaper.GetMousePosition()
        winX = mouseX - winW / 2
        winY = mouseY - winH / 2
        winX, winY = clampToScreen(winX, winY, winW, winH, mouseX, mouseY)
    end

    gfx.init("Stemperator - Complete", winW, winH, 0, winX, winY)
    reaper.defer(resultWindowLoop)
end

-- Run multi-track separation (parallel or sequential based on setting)
runSingleTrackSeparation = function(trackList)
    local baseTempDir = getTempDir() .. PATH_SEP .. "stemperator_" .. os.time()
    makeDir(baseTempDir)

    -- Check if we have a time selection
    local hasTimeSel = hasTimeSelection()

    -- In-place mode with no time selection: process each item separately
    -- This ensures each item gets its own stems as takes
    local inPlaceMultiItem = not SETTINGS.createNewTracks and not hasTimeSel

    -- Prepare all tracks: extract audio
    local trackJobs = {}
    local jobIndex = 0

    for i, track in ipairs(trackList) do
        local _, trackName = reaper.GetTrackName(track)
        if trackName == "" then trackName = "Track " .. math.floor(reaper.GetMediaTrackInfo_Value(track, "IP_TRACKNUMBER")) end

        if inPlaceMultiItem then
            -- In-place mode: create a separate job for EACH selected item on the track
            local numItems = reaper.CountTrackMediaItems(track)
            local selectedItems = {}
            for j = 0, numItems - 1 do
                local item = reaper.GetTrackMediaItem(track, j)
                if reaper.IsMediaItemSelected(item) then
                    table.insert(selectedItems, item)
                end
            end

            for itemIdx, item in ipairs(selectedItems) do
                jobIndex = jobIndex + 1
                local itemDir = baseTempDir .. PATH_SEP .. "item_" .. jobIndex
                makeDir(itemDir)
                local inputFile = itemDir .. PATH_SEP .. "input.wav"

                local extracted, err = renderSingleItemToWav(item, inputFile)
                if extracted then
                    -- Get item name for display
                    local itemName = "Unknown"
                    local take = reaper.GetActiveTake(item)
                    if take then
                        local _, takeName = reaper.GetSetMediaItemTakeInfo_String(take, "P_NAME", "", false)
                        if takeName and takeName ~= "" then
                            itemName = takeName
                        else
                            local source = reaper.GetMediaItemTake_Source(take)
                            if source then
                                local sourcePath = reaper.GetMediaSourceFileName(source, "")
                                if sourcePath and sourcePath ~= "" then
                                    itemName = sourcePath:match("([^/\\]+)$") or sourcePath
                                end
                            end
                        end
                    end

                    -- Get audio duration
                    local audioDuration = 0
                    local f = io.popen('ffprobe -v error -show_entries format=duration -of default=noprint_wrappers=1:nokey=1 "' .. inputFile .. '" 2>nul')
                    if f then
                        local dur = f:read("*a")
                        f:close()
                        audioDuration = tonumber(dur) or 0
                    end

                    table.insert(trackJobs, {
                        track = track,
                        trackName = trackName .. " [" .. itemIdx .. "/" .. #selectedItems .. "]",
                        trackDir = itemDir,
                        inputFile = inputFile,
                        sourceItem = item,
                        sourceItems = {item},  -- Only this one item
                        itemNames = itemName,
                        itemCount = 1,
                        index = jobIndex,
                        audioDuration = audioDuration,
                    })
                end
            end
        else
            -- Original behavior: one job per track (combines items or uses time selection)
            jobIndex = jobIndex + 1
            local trackDir = baseTempDir .. PATH_SEP .. "track_" .. jobIndex
            makeDir(trackDir)
            local inputFile = trackDir .. PATH_SEP .. "input.wav"

            -- Use appropriate render function based on whether time selection exists
            local extracted, err, sourceItem, allSourceItems
            if hasTimeSel then
                extracted, err, sourceItem, allSourceItems = renderTrackTimeSelectionToWav(track, inputFile)
            else
                extracted, err, sourceItem, allSourceItems = renderTrackSelectedItemsToWav(track, inputFile)
            end
            if extracted then
                -- Get media item name(s) for display
                local itemNames = {}
                local items = allSourceItems or {sourceItem}
                for _, item in ipairs(items) do
                    if item and reaper.ValidatePtr(item, "MediaItem*") then
                        local take = reaper.GetActiveTake(item)
                        if take then
                            local _, takeName = reaper.GetSetMediaItemTakeInfo_String(take, "P_NAME", "", false)
                            if takeName and takeName ~= "" then
                                table.insert(itemNames, takeName)
                            else
                                -- Try to get source filename
                                local source = reaper.GetMediaItemTake_Source(take)
                                if source then
                                    local sourcePath = reaper.GetMediaSourceFileName(source, "")
                                    if sourcePath and sourcePath ~= "" then
                                        local fileName = sourcePath:match("([^/\\]+)$") or sourcePath
                                        table.insert(itemNames, fileName)
                                    end
                                end
                            end
                        end
                    end
                end
                local itemNamesStr = #itemNames > 0 and table.concat(itemNames, ", ") or "Unknown"

                -- Get audio duration from the input file
                local audioDuration = 0
                local f = io.popen('ffprobe -v error -show_entries format=duration -of default=noprint_wrappers=1:nokey=1 "' .. inputFile .. '" 2>nul')
                if f then
                    local dur = f:read("*a")
                    f:close()
                    audioDuration = tonumber(dur) or 0
                end

                table.insert(trackJobs, {
                    track = track,
                    trackName = trackName,
                    trackDir = trackDir,
                    inputFile = inputFile,
                    sourceItem = sourceItem,
                    sourceItems = allSourceItems or {sourceItem},  -- All items for mute/delete
                    itemNames = itemNamesStr,
                    itemCount = #items,
                    index = jobIndex,
                    audioDuration = audioDuration,  -- Duration in seconds
                })
            end
        end
    end

    if #trackJobs == 0 then
        showMessage("Error", "Failed to extract audio from any tracks.", "error")
        return
    end

    -- Store jobs in queue for progress tracking
    multiTrackQueue.jobs = trackJobs
    multiTrackQueue.totalTracks = #trackJobs
    multiTrackQueue.completedCount = 0
    multiTrackQueue.baseTempDir = baseTempDir
    multiTrackQueue.active = true
    multiTrackQueue.sequentialMode = not SETTINGS.parallelProcessing
    multiTrackQueue.currentJobIndex = 0
    multiTrackQueue.globalStartTime = os.time()  -- Track total elapsed time
    multiTrackQueue.totalAudioDuration = 0  -- Will be updated when jobs start

    if SETTINGS.parallelProcessing then
        -- Start all separation processes in parallel (uses more VRAM)
        for _, job in ipairs(trackJobs) do
            startSeparationProcessForJob(job, 25)  -- Smaller segments for parallel
        end
    else
        -- Sequential mode: start only the first job (uses less VRAM)
        startSeparationProcessForJob(trackJobs[1], 40)  -- Larger segments for sequential
        multiTrackQueue.currentJobIndex = 1
    end

    -- Show progress window that monitors all jobs
    showMultiTrackProgressWindow()
end

-- Start a separation process for one job (no window, just background process)
-- segmentSize: optional, defaults to 25 for parallel, 40 for sequential
startSeparationProcessForJob = function(job, segmentSize)
    segmentSize = segmentSize or 25
    local logFile = job.trackDir .. PATH_SEP .. "separation_log.txt"
    local stdoutFile = job.trackDir .. PATH_SEP .. "stdout.txt"
    local doneFile = job.trackDir .. PATH_SEP .. "done.txt"

    job.stdoutFile = stdoutFile
    job.doneFile = doneFile
    job.logFile = logFile
    job.percent = 0
    job.stage = "Starting..."
    job.startTime = os.time()

    if OS == "Windows" then
        -- Create batch file to run Python with output redirection
        local batPath = job.trackDir .. PATH_SEP .. "run_separation.bat"
        local batFile = io.open(batPath, "w")
        if batFile then
            batFile:write('@echo off\n')
            batFile:write('"' .. PYTHON_PATH .. '" -u "' .. SEPARATOR_SCRIPT .. '" ')
            batFile:write('"' .. job.inputFile .. '" "' .. job.trackDir .. '" --model ' .. SETTINGS.model .. ' --segment-size ' .. segmentSize .. ' ')
            batFile:write('>"' .. stdoutFile .. '" 2>"' .. logFile .. '"\n')
            batFile:write('echo DONE >"' .. doneFile .. '"\n')
            batFile:close()
        end

        -- Create VBS to run batch file hidden
        local vbsPath = job.trackDir .. PATH_SEP .. "run_hidden.vbs"
        local vbsFile = io.open(vbsPath, "w")
        if vbsFile then
            vbsFile:write('CreateObject("WScript.Shell").Run """' .. batPath .. '""", 0, False\n')
            vbsFile:close()
        end

        -- Start the process
        if reaper.ExecProcess then
            reaper.ExecProcess('wscript "' .. vbsPath .. '"', -1)
        else
            local handle = io.popen('wscript "' .. vbsPath .. '"')
            if handle then handle:close() end
        end
    else
        -- macOS/Linux
        local cmd = '"' .. PYTHON_PATH .. '" -u "' .. SEPARATOR_SCRIPT .. '" '
        cmd = cmd .. '"' .. job.inputFile .. '" "' .. job.trackDir .. '" --model ' .. SETTINGS.model .. ' --segment-size ' .. segmentSize
        cmd = cmd .. ' >"' .. stdoutFile .. '" 2>"' .. logFile .. '" && echo DONE >"' .. doneFile .. '" &'
        os.execute(cmd)
    end
end

-- Update progress for all jobs from their stdout files
updateAllJobsProgress = function()
    for _, job in ipairs(multiTrackQueue.jobs) do
        -- Only check progress for jobs that have been started
        if job.startTime then
            local f = io.open(job.stdoutFile, "r")
            if f then
                local lastProgress = nil
                for line in f:lines() do
                    local percent, stage = line:match("PROGRESS:(%d+):(.+)")
                    if percent then
                        lastProgress = { percent = tonumber(percent), stage = stage }
                    end
                end
                f:close()
                if lastProgress then
                    job.percent = lastProgress.percent
                    job.stage = lastProgress.stage
                end
            end

            -- Check if done
            local doneFile = io.open(job.doneFile, "r")
            if doneFile then
                doneFile:close()
                if not job.done then
                    job.done = true
                    -- In sequential mode, start the next job when this one completes
                    if multiTrackQueue.sequentialMode then
                        local nextIndex = multiTrackQueue.currentJobIndex + 1
                        if nextIndex <= #multiTrackQueue.jobs then
                            local nextJob = multiTrackQueue.jobs[nextIndex]
                            startSeparationProcessForJob(nextJob, 40)  -- Larger segments for sequential
                            multiTrackQueue.currentJobIndex = nextIndex
                        end
                    end
                end
            end
        else
            -- Job not yet started (sequential mode)
            job.percent = 0
            job.stage = "Waiting..."
        end
    end
end

-- Check if all jobs are done
allJobsDone = function()
    for _, job in ipairs(multiTrackQueue.jobs) do
        if not job.done then return false end
    end
    return true
end

-- Calculate overall progress
getOverallProgress = function()
    local total = 0
    for _, job in ipairs(multiTrackQueue.jobs) do
        total = total + (job.percent or 0)
    end
    return math.floor(total / #multiTrackQueue.jobs)
end

-- Draw multi-track progress window
local function drawMultiTrackProgressWindow()
    local w, h = gfx.w, gfx.h

    -- Scale
    local scale = math.min(w / 480, h / 280)
    scale = math.max(0.5, math.min(4.0, scale))
    local function PS(val) return math.floor(val * scale + 0.5) end

    -- Mouse position for UI interactions
    local mx, my = gfx.mouse_x, gfx.mouse_y
    local mouseDown = gfx.mouse_cap & 1 == 1

    -- Tooltip tracking
    local tooltipText = nil
    local tooltipX, tooltipY = 0, 0

    -- === PROCEDURAL ART AS FULL BACKGROUND LAYER ===
    -- Pure black/white background first
    if SETTINGS.darkMode then
        gfx.set(0, 0, 0, 1)
    else
        gfx.set(1, 1, 1, 1)
    end
    gfx.rect(0, 0, w, h, 1)

    proceduralArt.time = proceduralArt.time + 0.016  -- ~60fps
    drawProceduralArt(0, 0, w, h, proceduralArt.time, 0, true)

    -- Semi-transparent overlay for readability - pure black/white
    if SETTINGS.darkMode then
        gfx.set(0, 0, 0, 0.5)
    else
        gfx.set(1, 1, 1, 0.5)
    end
    gfx.rect(0, 0, w, h, 1)

    -- === THEME TOGGLE (top right) ===
    local themeSize = PS(18)
    local themeX = w - themeSize - PS(8)
    local themeY = PS(6)
    local themeHover = mx >= themeX and mx <= themeX + themeSize and my >= themeY and my <= themeY + themeSize

    if SETTINGS.darkMode then
        gfx.set(0.7, 0.7, 0.5, themeHover and 1 or 0.5)
        gfx.circle(themeX + themeSize/2, themeY + themeSize/2, themeSize/2 - 2, 1, 1)
        gfx.set(0, 0, 0, 1)  -- Pure black for moon overlay
        gfx.circle(themeX + themeSize/2 + 3, themeY + themeSize/2 - 2, themeSize/2 - 3, 1, 1)
    else
        gfx.set(0.9, 0.7, 0.2, themeHover and 1 or 0.7)
        gfx.circle(themeX + themeSize/2, themeY + themeSize/2, themeSize/3, 1, 1)
        for i = 0, 7 do
            local angle = i * math.pi / 4
            local x1 = themeX + themeSize/2 + math.cos(angle) * (themeSize/3 + 1)
            local y1 = themeY + themeSize/2 + math.sin(angle) * (themeSize/3 + 1)
            local x2 = themeX + themeSize/2 + math.cos(angle) * (themeSize/2 - 1)
            local y2 = themeY + themeSize/2 + math.sin(angle) * (themeSize/2 - 1)
            gfx.line(x1, y1, x2, y2)
        end
    end

    -- Theme click and tooltip
    if themeHover then
        tooltipText = SETTINGS.darkMode and T("switch_light") or T("switch_dark")
        tooltipX, tooltipY = mx + PS(10), my + PS(15)
        if mouseDown and not multiTrackQueue.wasMouseDown then
            SETTINGS.darkMode = not SETTINGS.darkMode
            updateTheme()
            saveSettings()
        end
    end

    -- === FX TOGGLE (below theme icon) ===
    local fxSize = PS(16)
    local fxX = themeX + (themeSize - fxSize) / 2
    local fxY = themeY + themeSize + PS(3)
    local fxHover = mx >= fxX - PS(2) and mx <= fxX + fxSize + PS(2) and my >= fxY - PS(2) and my <= fxY + fxSize + PS(2)

    local fxAlpha = fxHover and 1 or 0.7
    if SETTINGS.visualFX then
        gfx.set(0.4, 0.9, 0.5, fxAlpha)
    else
        gfx.set(0.5, 0.5, 0.5, fxAlpha * 0.6)
    end
    gfx.setfont(1, "Arial", PS(9), string.byte('b'))
    local fxText = "FX"
    local fxTextW = gfx.measurestr(fxText)
    gfx.x = fxX + (fxSize - fxTextW) / 2
    gfx.y = fxY + PS(1)
    gfx.drawstr(fxText)

    if SETTINGS.visualFX then
        gfx.set(1, 1, 0.5, fxAlpha * 0.8)
        gfx.circle(fxX - PS(1), fxY + PS(2), PS(1.5), 1, 1)
        gfx.circle(fxX + fxSize, fxY + fxSize - PS(2), PS(1.5), 1, 1)
    else
        gfx.set(0.8, 0.3, 0.3, fxAlpha)
        gfx.line(fxX - PS(1), fxY + fxSize / 2, fxX + fxSize + PS(1), fxY + fxSize / 2)
    end

    if fxHover then
        tooltipText = SETTINGS.visualFX and T("fx_disable") or T("fx_enable")
        tooltipX, tooltipY = mx + PS(10), my + PS(15)
    end
    if fxHover and mouseDown and not multiTrackQueue.wasMouseDown then
        SETTINGS.visualFX = not SETTINGS.visualFX
        saveSettings()
    end

    -- Title with colored STEM
    gfx.setfont(1, "Arial", PS(16), string.byte('b'))
    local modeStr = multiTrackQueue.sequentialMode and "Sequential" or "Parallel"
    local titleX = PS(20)
    local titleY = PS(25)

    -- Draw "Multi-Track " in theme color
    gfx.set(THEME.text[1], THEME.text[2], THEME.text[3], 1)
    gfx.x = titleX
    gfx.y = titleY
    gfx.drawstr("Multi-Track ")
    titleX = titleX + gfx.measurestr("Multi-Track ")

    -- Draw "STEM" with each letter in stem color
    local stemLetterColors = {
        {229/255, 115/255, 115/255},  -- S = Vocals (red)
        {100/255, 181/255, 246/255},  -- T = Drums (blue)
        {186/255, 104/255, 200/255},  -- E = Bass (purple)
        {129/255, 199/255, 132/255},  -- M = Other (green)
    }
    local stemLetters = {"S", "T", "E", "M"}
    for i, letter in ipairs(stemLetters) do
        gfx.set(stemLetterColors[i][1], stemLetterColors[i][2], stemLetterColors[i][3], 1)
        gfx.x = titleX
        gfx.y = titleY
        gfx.drawstr(letter)
        titleX = titleX + gfx.measurestr(letter)
    end

    -- Draw "Peration - mode (tracks)" in theme color
    gfx.set(THEME.text[1], THEME.text[2], THEME.text[3], 1)
    gfx.x = titleX
    gfx.y = titleY
    gfx.drawstr(string.format("Peration - %s (%d tracks)", modeStr, #multiTrackQueue.jobs))

    -- Language toggle (left of theme toggle)
    local langW = PS(20)
    local langH = PS(14)
    local langX = themeX - langW - PS(8)
    local langY = themeY + (themeSize - langH) / 2
    local langHover = mx >= langX and mx <= langX + langW and my >= langY and my <= langY + langH

    gfx.setfont(1, "Arial", PS(9), string.byte('b'))
    local langCode = string.upper(SETTINGS.language or "EN")
    local langTextW = gfx.measurestr(langCode)

    if langHover then
        gfx.set(0.4, 0.6, 0.9, 1)
        tooltipText = T("tooltip_change_language")
        tooltipX, tooltipY = mx + PS(10), my + PS(15)
        if mouseDown and not multiTrackQueue.wasMouseDown then
            -- Cycle through languages
            local langs = {"en", "nl", "de"}
            local currentIdx = 1
            for i, l in ipairs(langs) do
                if l == SETTINGS.language then currentIdx = i; break end
            end
            local nextIdx = (currentIdx % #langs) + 1
            setLanguage(langs[nextIdx])
            saveSettings()
        end
    else
        gfx.set(THEME.textDim[1], THEME.textDim[2], THEME.textDim[3], 0.8)
    end
    gfx.x = langX + (langW - langTextW) / 2
    gfx.y = langY
    gfx.drawstr(langCode)

    -- Overall progress bar
    local barX = PS(20)
    local barY = PS(55)
    local barW = w - PS(40)
    local barH = PS(20)
    local overallProgress = getOverallProgress()
    local animTime = proceduralArt.time or 0

    -- Progress bar background with subtle gradient
    for i = 0, barH - 1 do
        local shade = 0.1 + (i / barH) * 0.05
        if not SETTINGS.darkMode then shade = 0.85 - (i / barH) * 0.05 end
        gfx.set(shade, shade, shade + 0.02, 1)
        gfx.line(barX, barY + i, barX + barW, barY + i)
    end
    gfx.set(THEME.border[1], THEME.border[2], THEME.border[3], 1)
    gfx.rect(barX, barY, barW, barH, 0)

    -- Animated progress fill with gradient (dark → white based on progress)
    local fillW = math.floor(barW * overallProgress / 100)
    if fillW > 0 then
        for i = 0, fillW - 1 do
            local progress = i / barW  -- 0 to 1 based on position
            local pulse = 0.9 + math.sin(animTime * 3 + i * 0.05) * 0.1
            -- Gradient: dark gray → teal → white
            local r, g, b
            if progress < 0.5 then
                -- Dark to teal
                local t = progress * 2
                r = 0.1 + t * 0.2
                g = 0.1 + t * 0.5
                b = 0.15 + t * 0.4
            else
                -- Teal to white
                local t = (progress - 0.5) * 2
                r = 0.3 + t * 0.7
                g = 0.6 + t * 0.4
                b = 0.55 + t * 0.45
            end
            gfx.set(r * pulse, g * pulse, b * pulse, 1)
            gfx.line(barX + 1 + i, barY + 1, barX + 1 + i, barY + barH - 2)
        end
        -- Animated glow at the edge
        if fillW > 3 then
            local glowPulse = 0.5 + math.sin(animTime * 5) * 0.5
            gfx.set(1, 1, 1, glowPulse * 0.6)
            gfx.line(barX + fillW - 2, barY + 2, barX + fillW - 2, barY + barH - 3)
            gfx.set(1, 1, 1, glowPulse * 0.3)
            gfx.line(barX + fillW - 1, barY + 3, barX + fillW - 1, barY + barH - 4)
        end
    end

    -- Progress text
    gfx.setfont(1, "Arial", PS(11))
    gfx.set(1, 1, 1, 1)
    local progText = string.format("%d%%", overallProgress)
    local progW = gfx.measurestr(progText)
    gfx.x = barX + (barW - progW) / 2
    gfx.y = barY + PS(3)
    gfx.drawstr(progText)

    -- Individual track progress
    local trackY = PS(80)
    local trackSpacing = PS(30)

    gfx.setfont(1, "Arial", PS(10))
    for i, job in ipairs(multiTrackQueue.jobs) do
        local yPos = trackY + (i - 1) * trackSpacing

        -- Track name
        gfx.set(THEME.textDim[1], THEME.textDim[2], THEME.textDim[3], 1)
        gfx.x = barX
        gfx.y = yPos
        local displayName = job.trackName
        if #displayName > 20 then displayName = displayName:sub(1, 17) .. "..." end
        gfx.drawstr(displayName)

        -- Track progress bar
        local tBarX = barX + PS(120)
        local tBarW = barW - PS(150)
        local tBarH = PS(18)

        -- Progress bar background
        gfx.set(THEME.inputBg[1], THEME.inputBg[2], THEME.inputBg[3], 1)
        gfx.rect(tBarX, yPos, tBarW, tBarH, 1)
        gfx.set(THEME.border[1], THEME.border[2], THEME.border[3], 1)
        gfx.rect(tBarX, yPos, tBarW, tBarH, 0)

        -- Fill
        local tFillW = math.floor(tBarW * (job.percent or 0) / 100)
        if tFillW > 0 then
            -- Color based on stem being processed
            local stemIdx = (i - 1) % #STEMS + 1
            local stemColor = STEMS[stemIdx].color
            gfx.set(stemColor[1]/255, stemColor[2]/255, stemColor[3]/255, 0.85)
            gfx.rect(tBarX + 1, yPos + 1, tFillW - 2, tBarH - 2, 1)
        end

        -- Stage text inside progress bar
        if not job.done and job.stage and job.stage ~= "" then
            gfx.setfont(1, "Arial", PS(9))
            gfx.set(1, 1, 1, 0.95)
            local stageText = job.stage
            if #stageText > 35 then stageText = stageText:sub(1, 32) .. "..." end
            gfx.x = tBarX + PS(5)
            gfx.y = yPos + PS(3)
            gfx.drawstr(stageText)
        end

        -- Done checkmark or percentage
        gfx.setfont(1, "Arial", PS(10))
        if job.done then
            gfx.set(0.3, 0.75, 0.4, 1)
            gfx.x = tBarX + tBarW + PS(8)
            gfx.y = yPos + PS(2)
            gfx.drawstr("Done")
        else
            gfx.set(THEME.textDim[1], THEME.textDim[2], THEME.textDim[3], 1)
            gfx.x = tBarX + tBarW + PS(8)
            gfx.y = yPos + PS(2)
            gfx.drawstr(string.format("%d%%", job.percent or 0))
        end
    end

    -- Current processing info (positioned below progress bars)
    local numJobs = #multiTrackQueue.jobs
    local infoY = trackY + numJobs * trackSpacing + PS(8)  -- Below last progress bar

    -- Calculate stats
    local globalElapsed = os.time() - (multiTrackQueue.globalStartTime or os.time())
    local completedJobs = 0
    local activeJobs = 0
    local totalAudioDur = 0
    local completedAudioDur = 0
    local activeJob = nil

    for _, job in ipairs(multiTrackQueue.jobs) do
        totalAudioDur = totalAudioDur + (job.audioDuration or 0)
        if job.done then
            completedJobs = completedJobs + 1
            completedAudioDur = completedAudioDur + (job.audioDuration or 0)
        elseif job.startTime then
            activeJobs = activeJobs + 1
            if not activeJob then activeJob = job end
            -- Estimate completed audio based on progress %
            completedAudioDur = completedAudioDur + (job.audioDuration or 0) * (job.percent or 0) / 100
        end
    end

    -- Calculate processing speed (realtime factor)
    local realtimeFactor = 0
    if globalElapsed > 5 and completedAudioDur > 0 then
        realtimeFactor = completedAudioDur / globalElapsed
    end

    -- Estimate ETA
    local eta = 0
    local remainingAudio = totalAudioDur - completedAudioDur
    if realtimeFactor > 0 then
        eta = remainingAudio / realtimeFactor
    elseif globalElapsed > 0 and overallProgress > 5 then
        -- Fallback: estimate from progress %
        local totalEstimate = globalElapsed * 100 / overallProgress
        eta = totalEstimate - globalElapsed
    end

    gfx.setfont(1, "Arial", PS(11))
    gfx.set(THEME.textDim[1], THEME.textDim[2], THEME.textDim[3], 1)

    -- Count expected stems
    local stemsPerTrack = SETTINGS.model == "htdemucs_6s" and 6 or 4
    local selectedStemCount = 0
    for _, stem in ipairs(STEMS) do
        if stem.selected then selectedStemCount = selectedStemCount + 1 end
    end
    local expectedStems = numJobs * selectedStemCount

    -- Line 1: Status overview
    local statusText = string.format("Tracks: %d/%d | Audio: %.1fs/%.1fs | Stems: %d expected",
        completedJobs, numJobs, completedAudioDur, totalAudioDur, expectedStems)
    gfx.x = barX
    gfx.y = infoY
    gfx.drawstr(statusText)

    -- Line 2: Speed and ETA
    local speedText = ""
    if realtimeFactor > 0 then
        speedText = string.format("Speed: %.2fx realtime", realtimeFactor)
    else
        speedText = "Speed: calculating..."
    end
    local etaText = ""
    if eta > 0 then
        local etaMins = math.floor(eta / 60)
        local etaSecs = math.floor(eta % 60)
        etaText = string.format(" | ETA: %d:%02d remaining", etaMins, etaSecs)
    end
    gfx.x = barX
    gfx.y = infoY + PS(16)
    gfx.drawstr(speedText .. etaText)

    -- Line 3: Current job info (if active)
    if activeJob then
        local jobElapsed = os.time() - (activeJob.startTime or os.time())
        local jobMins = math.floor(jobElapsed / 60)
        local jobSecs = jobElapsed % 60
        local audioDurStr = activeJob.audioDuration and string.format("%.1fs", activeJob.audioDuration) or "?"
        local infoText = string.format("Current: %s (%s) | %d:%02d elapsed",
            activeJob.trackName or "?",
            audioDurStr,
            jobMins, jobSecs)
        gfx.x = barX
        gfx.y = infoY + PS(48)
        gfx.drawstr(infoText)

        -- Line 5: Media item info
        local itemInfo = activeJob.itemNames or "Unknown"
        if #itemInfo > 55 then itemInfo = itemInfo:sub(1, 52) .. "..." end
        gfx.set(THEME.textHint[1], THEME.textHint[2], THEME.textHint[3], 1)
        gfx.x = barX
        gfx.y = infoY + PS(64)
        gfx.drawstr("Media: " .. itemInfo)
    end

    -- Bottom line: Total elapsed, model, segment and cancel hint
    local totalMins = math.floor(globalElapsed / 60)
    local totalSecs = globalElapsed % 60
    gfx.set(THEME.textHint[1], THEME.textHint[2], THEME.textHint[3], 1)
    gfx.setfont(1, "Arial", PS(10))
    gfx.x = PS(20)
    gfx.y = h - PS(20)
    local segSize = multiTrackQueue.sequentialMode and "40" or "25"
    local modeStr = multiTrackQueue.sequentialMode and "Seq" or "Par"
    gfx.drawstr(string.format("Time: %d:%02d | %s | Seg:%s | %s | ESC=cancel",
        totalMins, totalSecs, SETTINGS.model or "?", segSize, modeStr))

    -- flarkAUDIO logo at top (translucent) - "flark" regular, "AUDIO" bold
    gfx.setfont(1, "Arial", PS(10))
    local flarkPart = "flark"
    local flarkPartW = gfx.measurestr(flarkPart)
    gfx.setfont(1, "Arial", PS(10), string.byte('b'))
    local audioPart = "AUDIO"
    local audioPartW = gfx.measurestr(audioPart)
    local totalLogoW = flarkPartW + audioPartW
    local logoStartX = (w - totalLogoW) / 2
    -- Orange text, 50% translucent
    gfx.set(1.0, 0.5, 0.1, 0.5)
    gfx.setfont(1, "Arial", PS(10))
    gfx.x = logoStartX
    gfx.y = PS(3)
    gfx.drawstr(flarkPart)
    gfx.setfont(1, "Arial", PS(10), string.byte('b'))
    gfx.x = logoStartX + flarkPartW
    gfx.y = PS(3)
    gfx.drawstr(audioPart)

    -- === DRAW TOOLTIP (on top of everything, with STEM colors) ===
    if tooltipText then
        gfx.setfont(1, "Arial", PS(11))
        local padding = PS(8)
        local ttW = gfx.measurestr(tooltipText) + padding * 2
        local ttH = PS(18) + padding * 2
        local ttX = math.min(tooltipX, w - ttW - PS(5))
        local ttY = math.min(tooltipY, h - ttH - PS(5))

        -- Background (theme-aware)
        gfx.set(THEME.inputBg[1], THEME.inputBg[2], THEME.inputBg[3], 0.98)
        gfx.rect(ttX, ttY, ttW, ttH, 1)

        -- Colored top border (STEM colors gradient)
        for i = 0, ttW - 1 do
            local colorIdx = math.floor(i / ttW * 4) + 1
            colorIdx = math.min(4, math.max(1, colorIdx))
            local c = STEM_BORDER_COLORS[colorIdx]
            gfx.set(c[1]/255, c[2]/255, c[3]/255, 0.9)
            gfx.line(ttX + i, ttY, ttX + i, ttY + 2)
        end

        -- Border (theme-aware)
        gfx.set(THEME.border[1], THEME.border[2], THEME.border[3], 1)
        gfx.rect(ttX, ttY, ttW, ttH, 0)

        -- Text (theme-aware)
        gfx.set(THEME.text[1], THEME.text[2], THEME.text[3], 1)
        gfx.x = ttX + padding
        gfx.y = ttY + padding + PS(2)
        gfx.drawstr(tooltipText)
    end

    -- Track mouse state for next frame
    multiTrackQueue.wasMouseDown = mouseDown

    gfx.update()

    -- Check for cancel
    local char = gfx.getchar()
    if char == -1 or char == 27 then
        return "cancel"
    end

    return nil
end

-- Multi-track progress window loop
local function multiTrackProgressLoop()
    -- Update all job progress
    updateAllJobsProgress()

    local result = drawMultiTrackProgressWindow()

    if result == "cancel" then
        gfx.quit()
        multiTrackQueue.active = false
        isProcessingActive = false  -- Reset guard so workflow can be restarted
        local mainHwnd = reaper.GetMainHwnd()
        if mainHwnd then reaper.JS_Window_SetFocus(mainHwnd) end
        showMessage("Cancelled", "Multi-track separation was cancelled.", "info", true)
        return
    end

    if allJobsDone() then
        gfx.quit()
        -- Process all results
        processAllStemsResult()
        return
    end

    reaper.defer(multiTrackProgressLoop)
end

-- Show multi-track progress window
showMultiTrackProgressWindow = function()
    -- Load settings to get current theme
    loadSettings()
    updateTheme()

    -- Use saved dialog size/position like other windows
    -- Increased height for stats display (5 lines of info + track bars)
    local winW = lastDialogW or 480
    local winH = lastDialogH or 460

    local winX, winY
    if lastDialogX and lastDialogY then
        winX = lastDialogX
        winY = lastDialogY
    else
        local mouseX, mouseY = reaper.GetMousePosition()
        winX = mouseX - winW / 2
        winY = mouseY - winH / 2
        winX, winY = clampToScreen(winX, winY, winW, winH, mouseX, mouseY)
    end

    gfx.init("Stemperator - Multi-Track Progress", winW, winH, 0, winX, winY)
    reaper.defer(multiTrackProgressLoop)
end

-- Guard against multiple concurrent runs
local isProcessingActive = false

-- Process all stems after parallel jobs complete
processAllStemsResult = function()
    reaper.Undo_BeginBlock()

    -- Handle mute/delete options FIRST (before creating stems)
    local actionMsg = ""
    local actionCount = 0

    -- Collect all source items from all jobs
    local allItems = {}
    for _, job in ipairs(multiTrackQueue.jobs) do
        if job.sourceItems then
            for _, item in ipairs(job.sourceItems) do
                table.insert(allItems, item)
            end
        elseif job.sourceItem then
            table.insert(allItems, job.sourceItem)
        end
    end

    -- Skip item-level processing if deleteOriginalTrack is set (tracks will be deleted after stems created)
    -- Also skip muteSelection/deleteSelection for in-place + time selection mode
    -- (the selection portion will be replaced by stems, splitting is done there)
    local skipSelectionProcessing = timeSelectionMode and not SETTINGS.createNewTracks

    if SETTINGS.deleteOriginalTrack then
        -- Do nothing here - track deletion happens after stems are created
    elseif SETTINGS.muteOriginal and not skipSelectionProcessing then
        -- Mute all source items from all jobs
        for _, item in ipairs(allItems) do
            if reaper.ValidatePtr(item, "MediaItem*") then
                reaper.SetMediaItemInfo_Value(item, "B_MUTE", 1)
                actionCount = actionCount + 1
            end
        end
        local itemWord = actionCount == 1 and "item" or "items"
        actionMsg = "\n" .. actionCount .. " " .. itemWord .. " muted."
    elseif SETTINGS.muteSelection and not skipSelectionProcessing then
        -- Mute selection portion of all source items
        -- Process in reverse order to avoid item index shifting issues
        for i = #allItems, 1, -1 do
            local item = allItems[i]
            if reaper.ValidatePtr(item, "MediaItem*") then
                local itemTrack = reaper.GetMediaItem_Track(item)
                if itemTrack then
                    local itemPos = reaper.GetMediaItemInfo_Value(item, "D_POSITION")
                    local itemLen = reaper.GetMediaItemInfo_Value(item, "D_LENGTH")
                    local itemEnd = itemPos + itemLen

                    -- Only process if item overlaps time selection
                    if itemPos < timeSelectionEnd and itemEnd > timeSelectionStart then
                        -- Split at selection boundaries if needed
                        local splitStart = math.max(itemPos, timeSelectionStart)
                        local splitEnd = math.min(itemEnd, timeSelectionEnd)

                        -- Split at start of selection (if not at item start)
                        local middleItem = item
                        if splitStart > itemPos + 0.001 then
                            middleItem = reaper.SplitMediaItem(item, splitStart)
                        end

                        -- Split at end of selection (if not at item end)
                        if middleItem then
                            -- Get middleItem's actual end position after first split
                            local middlePos = reaper.GetMediaItemInfo_Value(middleItem, "D_POSITION")
                            local middleLen = reaper.GetMediaItemInfo_Value(middleItem, "D_LENGTH")
                            local middleEnd = middlePos + middleLen

                            if splitEnd < middleEnd - 0.001 then
                                reaper.SplitMediaItem(middleItem, splitEnd)
                            end
                        end

                        -- Mute the middle part (now 'middleItem' is the selection portion)
                        if middleItem then
                            reaper.SetMediaItemInfo_Value(middleItem, "B_MUTE", 1)
                            actionCount = actionCount + 1
                        end
                    end
                end
            end
        end
        local itemWord = actionCount == 1 and "item" or "items"
        actionMsg = "\nSelection muted in " .. actionCount .. " " .. itemWord .. "."
    elseif SETTINGS.deleteOriginal then
        -- Delete all source items from all jobs
        -- Process in reverse order to avoid index shifting issues
        for i = #allItems, 1, -1 do
            local item = allItems[i]
            if reaper.ValidatePtr(item, "MediaItem*") then
                local itemTrack = reaper.GetMediaItem_Track(item)
                if itemTrack then
                    reaper.DeleteTrackMediaItem(itemTrack, item)
                    actionCount = actionCount + 1
                end
            end
        end
        local itemWord = actionCount == 1 and "item" or "items"
        actionMsg = "\n" .. actionCount .. " " .. itemWord .. " deleted."
    elseif SETTINGS.deleteSelection and not skipSelectionProcessing then
        -- Delete selection portion of all source items
        -- Process in reverse order to avoid item index shifting issues
        for i = #allItems, 1, -1 do
            local item = allItems[i]
            if reaper.ValidatePtr(item, "MediaItem*") then
                local itemTrack = reaper.GetMediaItem_Track(item)
                if itemTrack then
                    local itemPos = reaper.GetMediaItemInfo_Value(item, "D_POSITION")
                    local itemLen = reaper.GetMediaItemInfo_Value(item, "D_LENGTH")
                    local itemEnd = itemPos + itemLen

                    -- Only process if item overlaps time selection
                    if itemPos < timeSelectionEnd and itemEnd > timeSelectionStart then
                        local splitStart = math.max(itemPos, timeSelectionStart)
                        local splitEnd = math.min(itemEnd, timeSelectionEnd)

                        -- Split at start of selection (if not at item start)
                        local middleItem = item
                        if splitStart > itemPos + 0.001 then
                            middleItem = reaper.SplitMediaItem(item, splitStart)
                        end

                        -- Split at end of selection (if not at item end)
                        if middleItem then
                            -- Get middleItem's actual end position after first split
                            local middlePos = reaper.GetMediaItemInfo_Value(middleItem, "D_POSITION")
                            local middleLen = reaper.GetMediaItemInfo_Value(middleItem, "D_LENGTH")
                            local middleEnd = middlePos + middleLen

                            if splitEnd < middleEnd - 0.001 then
                                reaper.SplitMediaItem(middleItem, splitEnd)
                            end
                        end

                        -- Delete the middle part
                        if middleItem then
                            local middleTrack = reaper.GetMediaItem_Track(middleItem)
                            if middleTrack then
                                reaper.DeleteTrackMediaItem(middleTrack, middleItem)
                                actionCount = actionCount + 1
                            end
                        end
                    end
                end
            end
        end
        local itemWord = actionCount == 1 and "item" or "items"
        actionMsg = "\nSelection deleted from " .. actionCount .. " " .. itemWord .. "."
    end

    -- Now create stems for each job
    local totalStemsCreated = 0
    local trackNames = {}

    debugLog("=== processAllStemsResult: Creating stem tracks ===")
    debugLog("Number of jobs: " .. #multiTrackQueue.jobs)
    debugLog("itemPos: " .. tostring(itemPos) .. ", itemLen: " .. tostring(itemLen))
    debugLog("createNewTracks: " .. tostring(SETTINGS.createNewTracks))

    local is6Stem = (SETTINGS.model == "htdemucs_6s")

    for jobIdx, job in ipairs(multiTrackQueue.jobs) do
        debugLog("Job " .. jobIdx .. ": trackDir=" .. tostring(job.trackDir))
        -- Find stem files in job directory
        local stems = {}
        local selectedCount = 0
        local foundCount = 0
        for _, stem in ipairs(STEMS) do
            -- Skip 6-stem-only stems if not using 6-stem model
            local stemApplies = stem.selected and (not stem.sixStemOnly or is6Stem)
            if stemApplies then
                selectedCount = selectedCount + 1
                local stemPath = job.trackDir .. PATH_SEP .. stem.name:lower() .. ".wav"
                local f = io.open(stemPath, "r")
                if f then
                    f:close()
                    stems[stem.name:lower()] = stemPath
                    foundCount = foundCount + 1
                    debugLog("  Found stem: " .. stem.name:lower() .. " at " .. stemPath)
                else
                    debugLog("  MISSING stem: " .. stem.name:lower() .. " at " .. stemPath)
                end
            end
        end
        debugLog("  Selected stems: " .. selectedCount .. ", Found: " .. foundCount)

        -- Create stems based on output mode
        if next(stems) then
            if SETTINGS.createNewTracks then
                -- New tracks mode: create separate tracks for each stem
                debugLog("  Calling createStemTracksForSelection...")
                local count = createStemTracksForSelection(stems, itemPos, itemLen, job.track)
                debugLog("  Created " .. count .. " stem tracks")
                totalStemsCreated = totalStemsCreated + count
            else
                -- In-place mode: replace source item with stems as takes
                debugLog("  In-place mode: processing source item...")
                local sourceItem = job.sourceItem
                if sourceItem and reaper.ValidatePtr(sourceItem, "MediaItem*") then
                    -- Bij time selection: split het item eerst bij de selectie grenzen
                    -- zodat we alleen het selectie-deel vervangen, niet het hele item
                    if timeSelectionMode and timeSelectionStart and timeSelectionEnd then
                        local srcItemPos = reaper.GetMediaItemInfo_Value(sourceItem, "D_POSITION")
                        local srcItemLen = reaper.GetMediaItemInfo_Value(sourceItem, "D_LENGTH")
                        local srcItemEnd = srcItemPos + srcItemLen

                        debugLog("  Time selection mode: splitting item at selection boundaries")
                        debugLog("  Item: " .. srcItemPos .. " to " .. srcItemEnd)
                        debugLog("  Selection: " .. timeSelectionStart .. " to " .. timeSelectionEnd)

                        -- Split bij start van selectie (als selectie niet aan begin item is)
                        local selectionItem = sourceItem
                        if timeSelectionStart > srcItemPos + 0.001 then
                            selectionItem = reaper.SplitMediaItem(sourceItem, timeSelectionStart)
                            debugLog("  Split at start: " .. timeSelectionStart)
                        end

                        -- Split bij einde van selectie (als selectie niet aan einde item is)
                        if selectionItem and timeSelectionEnd < srcItemEnd - 0.001 then
                            reaper.SplitMediaItem(selectionItem, timeSelectionEnd)
                            debugLog("  Split at end: " .. timeSelectionEnd)
                        end

                        -- Gebruik het selectie-item voor replacement
                        if selectionItem then
                            sourceItem = selectionItem
                        end
                    end

                    local srcItemPos = reaper.GetMediaItemInfo_Value(sourceItem, "D_POSITION")
                    local srcItemLen = reaper.GetMediaItemInfo_Value(sourceItem, "D_LENGTH")
                    debugLog("  Replacing item at pos=" .. srcItemPos .. ", len=" .. srcItemLen)
                    local count = replaceInPlace(sourceItem, stems, srcItemPos, srcItemLen)
                    debugLog("  Replaced with " .. count .. " stems as takes")
                    totalStemsCreated = totalStemsCreated + count
                else
                    debugLog("  ERROR: No valid source item for in-place replacement")
                end
            end
            table.insert(trackNames, job.trackName)
        else
            debugLog("  No stems found, skipping")
        end
    end
    debugLog("Total stems created: " .. totalStemsCreated)

    -- Handle deleteOriginalTrack AFTER stems are created (deletes entire source tracks)
    if SETTINGS.deleteOriginalTrack then
        -- Collect unique tracks from jobs (delete in reverse order to avoid index issues)
        local tracksToDelete = {}
        for _, job in ipairs(multiTrackQueue.jobs) do
            if job.track and reaper.ValidatePtr(job.track, "MediaTrack*") then
                -- Check if track is not already in list
                local found = false
                for _, t in ipairs(tracksToDelete) do
                    if t == job.track then found = true; break end
                end
                if not found then
                    table.insert(tracksToDelete, job.track)
                end
            end
        end
        -- Delete tracks in reverse order (higher indices first)
        for i = #tracksToDelete, 1, -1 do
            local track = tracksToDelete[i]
            if reaper.ValidatePtr(track, "MediaTrack*") then
                reaper.DeleteTrack(track)
                actionCount = actionCount + 1
            end
        end
        local trackWord = actionCount == 1 and "track" or "tracks"
        actionMsg = "\n" .. actionCount .. " source " .. trackWord .. " deleted."
    end

    reaper.Undo_EndBlock("Stemperator: Multi-track stem separation", -1)
    reaper.UpdateArrange()

    -- Calculate total processing time
    local totalTime = os.time() - (multiTrackQueue.globalStartTime or os.time())
    local totalMins = math.floor(totalTime / 60)
    local totalSecs = totalTime % 60

    -- Calculate total audio duration processed
    local totalAudioDur = 0
    for _, job in ipairs(multiTrackQueue.jobs) do
        totalAudioDur = totalAudioDur + (job.audioDuration or 0)
    end

    -- Calculate realtime factor
    local realtimeFactor = totalAudioDur > 0 and (totalAudioDur / totalTime) or 0

    -- Log benchmark result
    local modeStr = multiTrackQueue.sequentialMode and "Sequential" or "Parallel"
    local segSize = multiTrackQueue.sequentialMode and "40" or "25"
    local benchmarkLog = os.getenv("TEMP") .. "\\stemperator_benchmark.txt"
    local bf = io.open(benchmarkLog, "a")
    if bf then
        bf:write(string.format("\n=== Benchmark Result ===\n"))
        bf:write(string.format("Date: %s\n", os.date("%Y-%m-%d %H:%M:%S")))
        bf:write(string.format("Mode: %s (segment size: %s)\n", modeStr, segSize))
        bf:write(string.format("Model: %s\n", SETTINGS.model or "?"))
        bf:write(string.format("Tracks: %d\n", #multiTrackQueue.jobs))
        bf:write(string.format("Audio duration: %.1fs\n", totalAudioDur))
        bf:write(string.format("Processing time: %d:%02d (%ds)\n", totalMins, totalSecs, totalTime))
        bf:write(string.format("Speed: %.2fx realtime\n", realtimeFactor))
        bf:write(string.format("Stems created: %d\n", totalStemsCreated))
        bf:write("========================\n")
        bf:close()
    end

    multiTrackQueue.active = false

    -- Show result
    local selectedStemData = {}
    local is6Stem = (SETTINGS.model == "htdemucs_6s")
    for _, stem in ipairs(STEMS) do
        if stem.selected and (not stem.sixStemOnly or is6Stem) then
            table.insert(selectedStemData, stem)
        end
    end

    local timeStr = string.format("%d:%02d", totalMins, totalSecs)
    local speedStr = string.format("%.2fx", realtimeFactor)
    local resultMsg
    if SETTINGS.createNewTracks then
        local trackWord = totalStemsCreated == 1 and "track" or "tracks"
        resultMsg = string.format("%d stem %s created from %d source tracks.\nTime: %s | Speed: %s realtime | Mode: %s%s",
            totalStemsCreated, trackWord, #multiTrackQueue.jobs, timeStr, speedStr, modeStr, actionMsg)
    else
        local itemWord = #multiTrackQueue.jobs == 1 and "item" or "items"
        resultMsg = string.format("%d %s replaced with stems as takes.\nTime: %s | Speed: %s realtime | Mode: %s%s",
            #multiTrackQueue.jobs, itemWord, timeStr, speedStr, modeStr, actionMsg)
    end

    -- Clear time selection na processing om dubbele runs te voorkomen
    -- (main() wordt opnieuw aangeroepen na result window, zou anders opnieuw starten)
    if timeSelectionMode then
        reaper.GetSet_LoopTimeRange(true, false, 0, 0, false)
        timeSelectionMode = false
        debugLog("Cleared time selection after multi-track processing")
    end

    -- Reset processing guard
    isProcessingActive = false

    showResultWindow(selectedStemData, resultMsg)
end

-- Separation workflow
function runSeparationWorkflow()
    -- Prevent multiple concurrent runs
    if isProcessingActive then
        debugLog("=== runSeparationWorkflow BLOCKED - already processing ===")
        return
    end
    isProcessingActive = true
    debugLog("=== runSeparationWorkflow started ===")

    -- Save playback state to restore after processing
    savedPlaybackState = reaper.GetPlayState()
    debugLog("Saved playback state: " .. savedPlaybackState)

    -- Re-fetch the current selection at processing time (user may have changed it)
    selectedItem = reaper.GetSelectedMediaItem(0, 0)
    timeSelectionMode = false
    debugLog("Selected item: " .. tostring(selectedItem))

    -- If no items selected but tracks are selected (and no time selection),
    -- auto-select all items on those tracks
    if not selectedItem and not hasTimeSelection() and reaper.CountSelectedTracks(0) > 0 then
        debugLog("No items/time selection, but tracks selected - auto-selecting items on tracks")
        for t = 0, reaper.CountSelectedTracks(0) - 1 do
            local track = reaper.GetSelectedTrack(0, t)
            local numItems = reaper.CountTrackMediaItems(track)
            for i = 0, numItems - 1 do
                local item = reaper.GetTrackMediaItem(track, i)
                reaper.SetMediaItemSelected(item, true)
            end
        end
        reaper.UpdateArrange()
        selectedItem = reaper.GetSelectedMediaItem(0, 0)
        debugLog("After auto-select, selected item: " .. tostring(selectedItem))
    end

    -- Time selection takes priority over item selection
    -- This allows processing a specific region regardless of which item is selected
    if hasTimeSelection() then
        timeSelectionMode = true
        timeSelectionStart, timeSelectionEnd = reaper.GetSet_LoopTimeRange(false, false, 0, 0, false)
        itemPos = timeSelectionStart
        itemLen = timeSelectionEnd - timeSelectionStart
        debugLog("Time selection mode: " .. timeSelectionStart .. " to " .. timeSelectionEnd)
    elseif selectedItem then
        -- No time selection, use selected item
        itemPos = reaper.GetMediaItemInfo_Value(selectedItem, "D_POSITION")
        itemLen = reaper.GetMediaItemInfo_Value(selectedItem, "D_LENGTH")
    else
        -- No time selection and no item selected (and no track with items)
        showMessage("Start", "Please select a media item, track, or make a time selection to separate.", "info", true)
        return
    end

    workflowTempDir = getTempDir() .. PATH_SEP .. "stemperator_" .. os.time()
    makeDir(workflowTempDir)
    workflowTempInput = workflowTempDir .. PATH_SEP .. "input.wav"
    debugLog("Temp dir: " .. workflowTempDir)
    debugLog("Temp input: " .. workflowTempInput)

    local extracted, err, sourceItem, trackList, trackItems
    if timeSelectionMode then
        debugLog("Rendering time selection to WAV...")
        extracted, err, sourceItem, trackList, trackItems = renderTimeSelectionToWav(workflowTempInput)
        debugLog("Render result: extracted=" .. tostring(extracted) .. ", err=" .. tostring(err))

        -- Check for multi-track mode
        if err == "MULTI_TRACK" and trackList and #trackList > 1 then
            -- Multi-track mode: process all tracks in parallel
            debugLog("Multi-track mode: " .. #trackList .. " tracks")
            runSingleTrackSeparation(trackList)
            return
        end

        timeSelectionSourceItem = sourceItem  -- Store for later use
    else
        -- No time selection - check if we have multiple items selected (multi-track mode)
        local selItemCount = reaper.CountSelectedMediaItems(0)
        debugLog("No time selection, selected items: " .. selItemCount)

        if selItemCount > 1 then
            -- Multiple items selected - group by track and use multi-track mode
            local trackItems = {}  -- track -> list of items
            for i = 0, selItemCount - 1 do
                local item = reaper.GetSelectedMediaItem(0, i)
                local track = reaper.GetMediaItem_Track(item)
                if not trackItems[track] then
                    trackItems[track] = {}
                end
                table.insert(trackItems[track], item)
            end

            -- Build track list
            local trackList = {}
            for track in pairs(trackItems) do
                table.insert(trackList, track)
            end

            debugLog("Multi-item mode: " .. #trackList .. " tracks with items")
            runSingleTrackSeparation(trackList)
            return
        end

        -- Single item mode
        local origItemPos = reaper.GetMediaItemInfo_Value(selectedItem, "D_POSITION")
        local origItemLen = reaper.GetMediaItemInfo_Value(selectedItem, "D_LENGTH")

        extracted, err = renderItemToWav(selectedItem, workflowTempInput)
        -- Check if we rendered a sub-selection (not the whole item)
        local renderPos, renderLen = nil, nil  -- These would come from renderItemToWav if supported
        if renderPos and renderLen then
            itemPos = renderPos
            itemLen = renderLen
            -- Detect if this is a sub-selection
            if math.abs(renderPos - origItemPos) > 0.001 or math.abs(renderLen - origItemLen) > 0.001 then
                itemSubSelection = true
                itemSubSelStart = renderPos
                itemSubSelEnd = renderPos + renderLen
            else
                itemSubSelection = false
            end
        end
    end

    if not extracted then
        debugLog("Extraction FAILED: " .. (err or "Unknown"))
        -- Show error, then return to dialog if there's still a selection
        reaper.ShowMessageBox("Failed to extract audio:\n\n" .. (err or "Unknown") .. "\n\nMake sure you have items/tracks selected that overlap your time selection.", "Extraction Failed", 0)
        -- Go back to dialog
        if hasAnySelection() or timeSelectionMode then
            reaper.defer(function() showStemSelectionDialog() end)
        else
            showMessage("Start", "Select audio in REAPER", "info", true)
        end
        return
    end

    debugLog("Extraction successful, starting separation...")
    debugLog("Model: " .. SETTINGS.model)
    -- Start separation with progress UI (async)
    runSeparationWithProgress(workflowTempInput, workflowTempDir, SETTINGS.model)
    debugLog("runSeparationWithProgress called")
end

-- Check for quick preset mode (called from toolbar scripts)
local function checkQuickPreset()
    local quickRun = reaper.GetExtState(EXT_SECTION, "quick_run")
    if quickRun == "1" then
        -- Clear the flag
        reaper.DeleteExtState(EXT_SECTION, "quick_run", false)

        -- Apply preset based on quick_preset
        local preset = reaper.GetExtState(EXT_SECTION, "quick_preset")
        reaper.DeleteExtState(EXT_SECTION, "quick_preset", false)

        if preset == "karaoke" or preset == "instrumental" then
            applyPresetKaraoke()
        elseif preset == "vocals" then
            applyPresetVocalsOnly()
        elseif preset == "drums" then
            applyPresetDrumsOnly()
        elseif preset == "bass" then
            STEMS[1].selected = false
            STEMS[2].selected = false
            STEMS[3].selected = true
            STEMS[4].selected = false
        elseif preset == "all" then
            applyPresetAll()
        end

        return true  -- Quick mode, skip dialog
    end
    return false
end

-- Main
main = function()
    debugLog("=== main() called ===")

    -- Check if STEMperator window is already open - if so, just bring it to focus
    if reaper.JS_Window_Find then
        local existingHwnd = reaper.JS_Window_Find("Stemperator", true)
        if existingHwnd then
            debugLog("  Existing Stemperator window found, bringing to focus")
            reaper.JS_Window_SetFocus(existingHwnd)
            return  -- Don't start a new instance
        end
    end

    -- Load settings first (needed for window position in error messages)
    loadSettings()

    selectedItem = reaper.GetSelectedMediaItem(0, 0)
    timeSelectionMode = false
    autoSelectedItems = {}  -- Reset auto-selected items tracking
    autoSelectionTracks = {}  -- Reset auto-selection tracks tracking

    -- If no items selected but tracks are selected (and no time selection),
    -- auto-select all items on those tracks
    if not selectedItem and not hasTimeSelection() and reaper.CountSelectedTracks(0) > 0 then
        for t = 0, reaper.CountSelectedTracks(0) - 1 do
            local track = reaper.GetSelectedTrack(0, t)
            table.insert(autoSelectionTracks, track)  -- Track this track for potential restore
            local numItems = reaper.CountTrackMediaItems(track)
            for i = 0, numItems - 1 do
                local item = reaper.GetTrackMediaItem(track, i)
                reaper.SetMediaItemSelected(item, true)
                table.insert(autoSelectedItems, item)  -- Track this item for potential restore
            end
        end
        reaper.UpdateArrange()
        selectedItem = reaper.GetSelectedMediaItem(0, 0)
    end

    -- Time selection takes priority over item selection
    -- This allows processing a specific region regardless of which item is selected
    if hasTimeSelection() then
        timeSelectionMode = true
        timeSelectionStart, timeSelectionEnd = reaper.GetSet_LoopTimeRange(false, false, 0, 0, false)
        itemPos = timeSelectionStart
        itemLen = timeSelectionEnd - timeSelectionStart
    elseif selectedItem then
        -- No time selection, use selected item
        itemPos = reaper.GetMediaItemInfo_Value(selectedItem, "D_POSITION")
        itemLen = reaper.GetMediaItemInfo_Value(selectedItem, "D_LENGTH")
    else
        -- No time selection, no item selected, no track with items
        -- Show start screen with selection monitoring
        showMessage("Start", "Select audio in REAPER", "info", true)
        return
    end

    -- Check for quick preset mode (from toolbar scripts)
    if checkQuickPreset() then
        -- Quick mode: run immediately without dialog
        saveSettings()
        reaper.defer(runSeparationWorkflow)
    else
        -- Normal mode: show dialog
        showStemSelectionDialog()
    end
end

main()
