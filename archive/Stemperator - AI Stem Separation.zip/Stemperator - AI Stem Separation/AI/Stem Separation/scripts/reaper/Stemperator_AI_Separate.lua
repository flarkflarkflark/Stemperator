-- @description Stemperator - AI Stem Separation
-- @author flarkAUDIO
-- @version 1.5.0
-- @changelog
--   v1.5.0: Improved cross-platform support
--   - Better Python detection (Homebrew, Windows venvs, user paths)
--   - Added ~/.stemperator/.venv support for global installation
--   - macOS: Added /opt/homebrew paths for Apple Silicon
--   - Windows: Better AppData Python detection
--   - Run "Stemperator: Setup AI Backend" to verify installation
--   v1.4.0: Time selection support
--   - Can now separate time selections (not just media items)
--   - If no item selected, uses time selection instead
--   - Stems are placed at the time selection position
--   v1.3.0: 6-stem model support with Guitar/Piano
--   - Guitar and Piano checkboxes appear when 6-stem model selected
--   - Keys 5/6 toggle Guitar/Piano stems
--   v1.2.0: Scalable/resizable GUI
--   - Window is now resizable (drag edges/corners)
--   - All elements scale proportionally with window size
--   v1.1.0: Major update
--   - Persist settings between sessions (REAPER ExtState)
--   - Keyboard shortcuts: 1-4 toggle stems, K=Karaoke, I=Instrumental
--   v1.0.0: Initial release
-- @provides
--   [main] .
--   [nomain] audio_separator_process.py
-- @link Repository https://github.com/flarkflarkflark/Stemperator
-- @about
--   # Stemperator - AI Stem Separation
--
--   High-quality AI-powered stem separation using Demucs/audio-separator.
--   Separates the selected media item (or time selection) into stems:
--   Vocals, Drums, Bass, Other (and optionally Guitar, Piano with 6-stem model).
--
--   ## Features
--   - Processes ONLY the selected item portion (respects splits!)
--   - Choose which stems to extract via checkboxes or presets
--   - Quick presets: Karaoke, Instrumental, Drums Only
--   - Keyboard shortcuts for fast workflow
--   - Settings persist between sessions
--   - Option to create new tracks or replace in-place (as takes)
--   - GPU acceleration support (NVIDIA CUDA, AMD ROCm)
--
--   ## Keyboard Shortcuts (in dialog)
--   - 1-4: Toggle Vocals/Drums/Bass/Other
--   - K: Karaoke preset (instrumental only)
--   - I: Instrumental preset (no vocals)
--   - D: Drums Only preset
--   - Enter: Start separation
--   - Escape: Cancel
--
--   ## Requirements
--   - Python 3.9+ with audio-separator:
--     `pip install audio-separator[gpu]`
--   - ffmpeg installed and in PATH
--
--   ## License
--   MIT License - https://opensource.org/licenses/MIT

local SCRIPT_NAME = "Stemperator: AI Stem Separation"
local EXT_SECTION = "Stemperator"  -- For ExtState persistence

-- Get script path for finding audio_separator_process.py
local info = debug.getinfo(1, "S")
local script_path = info.source:match("@?(.*/)")
if not script_path then script_path = "" end

-- Detect OS
local function getOS()
    local sep = package.config:sub(1,1)
    if sep == "\\" then return "Windows"
    elseif reaper.GetOS():match("OSX") or reaper.GetOS():match("macOS") then return "macOS"
    else return "Linux"
    end
end

local OS = getOS()
local PATH_SEP = OS == "Windows" and "\\" or "/"

-- Get home directory (cross-platform)
local function getHome()
    if OS == "Windows" then
        return os.getenv("USERPROFILE") or "C:\\Users\\Default"
    else
        return os.getenv("HOME") or "/tmp"
    end
end

-- Configuration - Auto-detect paths (cross-platform)
local function findPython()
    local paths = {}
    local home = getHome()

    if OS == "Windows" then
        -- Windows paths - check venvs first
        table.insert(paths, script_path .. ".venv\\Scripts\\python.exe")
        table.insert(paths, home .. "\\.stemperator\\.venv\\Scripts\\python.exe")
        table.insert(paths, script_path .. "..\\..\\..\\venv\\Scripts\\python.exe")
        -- Standard Python locations
        local localAppData = os.getenv("LOCALAPPDATA") or ""
        table.insert(paths, localAppData .. "\\Programs\\Python\\Python312\\python.exe")
        table.insert(paths, localAppData .. "\\Programs\\Python\\Python311\\python.exe")
        table.insert(paths, localAppData .. "\\Programs\\Python\\Python310\\python.exe")
        table.insert(paths, "python")
    else
        -- Linux/macOS paths - check venvs first
        table.insert(paths, script_path .. ".venv/bin/python")
        table.insert(paths, home .. "/.stemperator/.venv/bin/python")
        table.insert(paths, script_path .. "../.venv/bin/python")
        -- Homebrew on macOS
        if OS == "macOS" then
            table.insert(paths, "/opt/homebrew/bin/python3")
            table.insert(paths, "/usr/local/opt/python@3.12/bin/python3")
        end
        -- User local and system paths
        table.insert(paths, home .. "/.local/bin/python3")
        table.insert(paths, "/usr/local/bin/python3")
        table.insert(paths, "/usr/bin/python3")
        table.insert(paths, "python3")
        table.insert(paths, "python")
    end

    for _, p in ipairs(paths) do
        local f = io.open(p, "r")
        if f then f:close(); return p end
    end
    return OS == "Windows" and "python" or "python3"
end

local function findSeparatorScript()
    local paths = {
        script_path .. "audio_separator_process.py",
        script_path .. ".." .. PATH_SEP .. "AI" .. PATH_SEP .. "audio_separator_process.py",
        script_path .. ".." .. PATH_SEP .. ".." .. PATH_SEP .. "Source" .. PATH_SEP .. "AI" .. PATH_SEP .. "audio_separator_process.py",
    }
    for _, p in ipairs(paths) do
        local f = io.open(p, "r")
        if f then f:close(); return p end
    end
    return script_path .. "audio_separator_process.py"
end

local PYTHON_PATH = findPython()
local SEPARATOR_SCRIPT = findSeparatorScript()

-- Stem configuration (with selection state)
-- First 4 are always shown, Guitar/Piano only for 6-stem model
local STEMS = {
    { name = "Vocals", color = {255, 100, 100}, file = "vocals.wav", selected = true, key = "1", sixStemOnly = false },
    { name = "Drums",  color = {100, 200, 255}, file = "drums.wav", selected = true, key = "2", sixStemOnly = false },
    { name = "Bass",   color = {150, 100, 255}, file = "bass.wav", selected = true, key = "3", sixStemOnly = false },
    { name = "Other",  color = {100, 255, 150}, file = "other.wav", selected = true, key = "4", sixStemOnly = false },
    { name = "Guitar", color = {255, 180, 80},  file = "guitar.wav", selected = true, key = "5", sixStemOnly = true },
    { name = "Piano",  color = {255, 120, 200}, file = "piano.wav", selected = true, key = "6", sixStemOnly = true },
}

-- Available models
local MODELS = {
    { id = "htdemucs", name = "Fast (htdemucs)", desc = "4 stems, fastest" },
    { id = "htdemucs_ft", name = "Quality (htdemucs_ft)", desc = "4 stems, best quality" },
    { id = "htdemucs_6s", name = "6-Stem (guitar/piano)", desc = "6 stems, includes guitar & piano" },
}

-- Settings (persist between runs)
local SETTINGS = {
    model = "htdemucs",
    createNewTracks = true,
    createFolder = true,
    deleteOriginal = false,
    deleteOriginalTrack = false,
}

-- GUI state
local GUI = {
    running = false,
    result = nil,
    wasMouseDown = false,
    -- Scaling
    baseW = 380,
    baseH = 340,
    minW = 380,
    minH = 340,
    maxW = 1520,  -- Up to 4x scale
    maxH = 1360,
    scale = 1.0,
}

-- Load settings from ExtState
local function loadSettings()
    local model = reaper.GetExtState(EXT_SECTION, "model")
    if model ~= "" then SETTINGS.model = model end

    local createNewTracks = reaper.GetExtState(EXT_SECTION, "createNewTracks")
    if createNewTracks ~= "" then SETTINGS.createNewTracks = (createNewTracks == "1") end

    local createFolder = reaper.GetExtState(EXT_SECTION, "createFolder")
    if createFolder ~= "" then SETTINGS.createFolder = (createFolder == "1") end

    local deleteOriginal = reaper.GetExtState(EXT_SECTION, "deleteOriginal")
    if deleteOriginal ~= "" then SETTINGS.deleteOriginal = (deleteOriginal == "1") end

    local deleteOriginalTrack = reaper.GetExtState(EXT_SECTION, "deleteOriginalTrack")
    if deleteOriginalTrack ~= "" then SETTINGS.deleteOriginalTrack = (deleteOriginalTrack == "1") end

    -- Load stem selections
    for i, stem in ipairs(STEMS) do
        local sel = reaper.GetExtState(EXT_SECTION, "stem_" .. stem.name)
        if sel ~= "" then STEMS[i].selected = (sel == "1") end
    end

    -- Load window size
    local winW = reaper.GetExtState(EXT_SECTION, "windowWidth")
    local winH = reaper.GetExtState(EXT_SECTION, "windowHeight")
    if winW ~= "" then GUI.savedW = tonumber(winW) end
    if winH ~= "" then GUI.savedH = tonumber(winH) end
end

-- Save settings to ExtState
local function saveSettings()
    reaper.SetExtState(EXT_SECTION, "model", SETTINGS.model, true)
    reaper.SetExtState(EXT_SECTION, "createNewTracks", SETTINGS.createNewTracks and "1" or "0", true)
    reaper.SetExtState(EXT_SECTION, "createFolder", SETTINGS.createFolder and "1" or "0", true)
    reaper.SetExtState(EXT_SECTION, "deleteOriginal", SETTINGS.deleteOriginal and "1" or "0", true)
    reaper.SetExtState(EXT_SECTION, "deleteOriginalTrack", SETTINGS.deleteOriginalTrack and "1" or "0", true)

    for _, stem in ipairs(STEMS) do
        reaper.SetExtState(EXT_SECTION, "stem_" .. stem.name, stem.selected and "1" or "0", true)
    end

    -- Save window size
    if gfx.w > 0 and gfx.h > 0 then
        reaper.SetExtState(EXT_SECTION, "windowWidth", tostring(gfx.w), true)
        reaper.SetExtState(EXT_SECTION, "windowHeight", tostring(gfx.h), true)
    end
end

-- Preset functions
local function applyPresetKaraoke()
    -- Instrumental only (no vocals)
    STEMS[1].selected = false  -- Vocals OFF
    STEMS[2].selected = true   -- Drums
    STEMS[3].selected = true   -- Bass
    STEMS[4].selected = true   -- Other
end

local function applyPresetInstrumental()
    -- Same as karaoke but clearer name
    applyPresetKaraoke()
end

local function applyPresetDrumsOnly()
    STEMS[1].selected = false  -- Vocals
    STEMS[2].selected = true   -- Drums ONLY
    STEMS[3].selected = false  -- Bass
    STEMS[4].selected = false  -- Other
end

local function applyPresetVocalsOnly()
    STEMS[1].selected = true   -- Vocals ONLY
    STEMS[2].selected = false  -- Drums
    STEMS[3].selected = false  -- Bass
    STEMS[4].selected = false  -- Other
end

local function applyPresetAll()
    for i = 1, #STEMS do
        STEMS[i].selected = true
    end
end

local function rgbToReaperColor(r, g, b)
    return reaper.ColorToNative(r, g, b) | 0x1000000
end

-- Scaling helper: converts base coordinates to current scale
local function S(val)
    return math.floor(val * GUI.scale + 0.5)
end

-- Calculate current scale based on window size
local function updateScale()
    local scaleW = gfx.w / GUI.baseW
    local scaleH = gfx.h / GUI.baseH
    GUI.scale = math.min(scaleW, scaleH)
    -- Clamp scale (1.0 to 4.0)
    GUI.scale = math.max(1.0, math.min(4.0, GUI.scale))
end

-- Track if we've made window resizable
local windowResizableSet = false

-- Make window resizable using JS_ReaScriptAPI (if available)
local function makeWindowResizable()
    if windowResizableSet then return true end
    if not reaper.JS_Window_Find then return false end

    -- Find the gfx window
    local hwnd = reaper.JS_Window_Find(SCRIPT_NAME, true)
    if not hwnd then return false end

    -- On Linux/X11, use different approach - set window hints
    if OS == "Linux" then
        -- For Linux, we need to modify GDK window properties
        -- js_ReaScriptAPI doesn't directly support this, but we can try
        local style = reaper.JS_Window_GetLong(hwnd, "STYLE")
        if style then
            -- Try to add resize style bits
            reaper.JS_Window_SetLong(hwnd, "STYLE", style | 0x00040000 | 0x00010000)
        end
    else
        -- Windows: add WS_THICKFRAME and WS_MAXIMIZEBOX
        local style = reaper.JS_Window_GetLong(hwnd, "STYLE")
        local WS_THICKFRAME = 0x00040000
        local WS_MAXIMIZEBOX = 0x00010000
        reaper.JS_Window_SetLong(hwnd, "STYLE", style | WS_THICKFRAME | WS_MAXIMIZEBOX)
    end

    windowResizableSet = true
    return true
end

-- Draw a checkbox and return if it was clicked (scaled)
local function drawCheckbox(x, y, checked, label, r, g, b)
    local boxSize = S(18)
    local clicked = false
    local labelWidth = gfx.measurestr(label)
    local totalWidth = boxSize + S(8) + labelWidth
    local mx, my = gfx.mouse_x, gfx.mouse_y
    local mouseDown = gfx.mouse_cap & 1 == 1

    if mouseDown and mx >= x and mx <= x + totalWidth and my >= y and my <= y + boxSize then
        if not GUI.wasMouseDown then clicked = true end
    end

    if checked then
        gfx.set(0.3, 0.5, 0.7, 1)
    else
        gfx.set(0.3, 0.3, 0.3, 1)
    end
    gfx.rect(x, y, boxSize, boxSize, 1)
    gfx.set(0.6, 0.6, 0.6, 1)
    gfx.rect(x, y, boxSize, boxSize, 0)

    if checked then
        gfx.set(1, 1, 1, 1)
        local s = GUI.scale
        gfx.line(x + S(3), y + S(9), x + S(7), y + S(13))
        gfx.line(x + S(7), y + S(13), x + S(14), y + S(4))
        gfx.line(x + S(3), y + S(10), x + S(7), y + S(14))
        gfx.line(x + S(7), y + S(14), x + S(14), y + S(5))
    end

    gfx.set(r/255, g/255, b/255, 1)
    gfx.x = x + boxSize + S(8)
    gfx.y = y + S(2)
    gfx.drawstr(label)

    return clicked
end

-- Draw a radio button and return if it was clicked (scaled)
local function drawRadio(x, y, selected, label)
    local radius = S(8)
    local clicked = false
    local mx, my = gfx.mouse_x, gfx.mouse_y
    local mouseDown = gfx.mouse_cap & 1 == 1

    if mouseDown and mx >= x and mx <= x + S(150) and my >= y and my <= y + radius * 2 then
        if not GUI.wasMouseDown then clicked = true end
    end

    gfx.set(0.6, 0.6, 0.6, 1)
    gfx.circle(x + radius, y + radius, radius, 0, 1)

    if selected then
        gfx.set(0.4, 0.7, 1, 1)
        gfx.circle(x + radius, y + radius, radius - S(3), 1, 1)
    end

    gfx.set(0.9, 0.9, 0.9, 1)
    gfx.x = x + radius * 2 + S(8)
    gfx.y = y + S(2)
    gfx.drawstr(label)

    return clicked
end

-- Draw a small button and return if it was clicked (scaled)
local function drawButton(x, y, w, h, label, isDefault, color)
    local clicked = false
    local mx, my = gfx.mouse_x, gfx.mouse_y
    local mouseDown = gfx.mouse_cap & 1 == 1
    local hover = mx >= x and mx <= x + w and my >= y and my <= y + h

    if mouseDown and hover then
        if not GUI.wasMouseDown then clicked = true end
    end

    if color then
        if hover then
            gfx.set(color[1]/255 * 1.2, color[2]/255 * 1.2, color[3]/255 * 1.2, 1)
        else
            gfx.set(color[1]/255, color[2]/255, color[3]/255, 1)
        end
    else
        if hover then
            gfx.set(isDefault and 0.3 or 0.4, isDefault and 0.5 or 0.4, isDefault and 0.8 or 0.4, 1)
        else
            gfx.set(isDefault and 0.2 or 0.3, isDefault and 0.4 or 0.3, isDefault and 0.7 or 0.3, 1)
        end
    end
    gfx.rect(x, y, w, h, 1)
    gfx.set(0.6, 0.6, 0.6, 1)
    gfx.rect(x, y, w, h, 0)

    gfx.set(1, 1, 1, 1)
    local tw = gfx.measurestr(label)
    gfx.x = x + (w - tw) / 2
    gfx.y = y + (h - S(14)) / 2
    gfx.drawstr(label)

    return clicked
end

-- Main dialog loop
local function dialogLoop()
    -- Try to make window resizable (needs to be called after window is visible)
    makeWindowResizable()

    -- Update scale based on current window size
    updateScale()

    gfx.set(0.18, 0.18, 0.2, 1)
    gfx.rect(0, 0, gfx.w, gfx.h, 1)

    -- Title
    gfx.set(1, 1, 1, 1)
    gfx.setfont(1, "Arial", S(18), string.byte('b'))
    gfx.x = S(20)
    gfx.y = S(12)
    gfx.drawstr("Stemperator - AI Stem Separation")

    gfx.setfont(1, "Arial", S(13))

    -- === LEFT COLUMN: Stems ===
    local is6Stem = (SETTINGS.model == "htdemucs_6s")
    gfx.set(0.7, 0.7, 0.7, 1)
    gfx.x = S(20)
    gfx.y = S(45)
    gfx.drawstr(is6Stem and "Stems (1-6):" or "Stems (1-4):")

    local y = S(65)
    for i, stem in ipairs(STEMS) do
        -- Only show Guitar/Piano if 6-stem model selected
        if not stem.sixStemOnly or is6Stem then
            local label = stem.key .. " " .. stem.name
            if drawCheckbox(S(25), y, stem.selected, label, stem.color[1], stem.color[2], stem.color[3]) then
                STEMS[i].selected = not STEMS[i].selected
            end
            y = y + S(24)
        end
    end

    -- Presets section
    gfx.set(0.7, 0.7, 0.7, 1)
    gfx.x = S(20)
    gfx.y = y + S(8)
    gfx.drawstr("Presets:")

    y = y + S(28)
    if drawButton(S(25), y, S(60), S(22), "All", false) then applyPresetAll() end
    if drawButton(S(90), y, S(70), S(22), "Karaoke", false, {100, 180, 100}) then applyPresetKaraoke() end
    y = y + S(26)
    if drawButton(S(25), y, S(60), S(22), "Vocals", false, {255, 100, 100}) then applyPresetVocalsOnly() end
    if drawButton(S(90), y, S(70), S(22), "Drums", false, {100, 200, 255}) then applyPresetDrumsOnly() end

    -- === RIGHT COLUMN: Model & Options ===
    gfx.set(0.7, 0.7, 0.7, 1)
    gfx.x = S(180)
    gfx.y = S(45)
    gfx.drawstr("AI Model:")

    y = S(65)
    for _, model in ipairs(MODELS) do
        if drawRadio(S(185), y, SETTINGS.model == model.id, model.name) then
            SETTINGS.model = model.id
        end
        y = y + S(24)
    end

    -- Output mode
    gfx.set(0.7, 0.7, 0.7, 1)
    gfx.x = S(180)
    gfx.y = y + S(10)
    gfx.drawstr("Output:")

    y = y + S(28)
    if drawRadio(S(185), y, SETTINGS.createNewTracks, "New tracks") then
        SETTINGS.createNewTracks = true
    end
    y = y + S(22)
    if drawRadio(S(185), y, not SETTINGS.createNewTracks, "In-place (takes)") then
        SETTINGS.createNewTracks = false
    end

    -- Options (only when creating new tracks)
    if SETTINGS.createNewTracks then
        y = y + S(28)
        if drawCheckbox(S(185), y, SETTINGS.createFolder, "Group in folder", 160, 160, 160) then
            SETTINGS.createFolder = not SETTINGS.createFolder
        end
        y = y + S(22)
        if drawCheckbox(S(185), y, SETTINGS.deleteOriginal, "Delete item", 160, 160, 160) then
            SETTINGS.deleteOriginal = not SETTINGS.deleteOriginal
        end
        y = y + S(22)
        if drawCheckbox(S(185), y, SETTINGS.deleteOriginalTrack, "Delete track", 255, 120, 120) then
            SETTINGS.deleteOriginalTrack = not SETTINGS.deleteOriginalTrack
            if SETTINGS.deleteOriginalTrack then SETTINGS.deleteOriginal = true end
        end
    end

    -- Keyboard shortcuts hint
    gfx.set(0.5, 0.5, 0.5, 1)
    gfx.setfont(1, "Arial", S(11))
    gfx.x = S(20)
    gfx.y = gfx.h - S(65)
    if is6Stem then
        gfx.drawstr("Keys: 1-6=stems, K=karaoke, A=all, +/-=resize")
    else
        gfx.drawstr("Keys: 1-4=stems, K=karaoke, A=all, +/-=resize")
    end

    -- Buttons
    gfx.setfont(1, "Arial", S(13))
    local btnY = gfx.h - S(40)
    local btnW = S(80)
    local btnH = S(28)
    if drawButton(gfx.w - S(185), btnY, btnW, btnH, "Cancel", false) then
        GUI.result = false
    end
    if drawButton(gfx.w - S(95), btnY, btnW, btnH, "Separate", true) then
        local anySelected = false
        for _, stem in ipairs(STEMS) do
            if stem.selected then anySelected = true; break end
        end
        if anySelected then
            saveSettings()
            GUI.result = true
        else
            reaper.MB("Please select at least one stem.", SCRIPT_NAME, 0)
        end
    end

    GUI.wasMouseDown = (gfx.mouse_cap & 1 == 1)

    -- Handle keyboard
    local char = gfx.getchar()
    if char == 27 then  -- ESC
        GUI.result = false
    elseif char == 13 then  -- Enter
        local anySelected = false
        for _, stem in ipairs(STEMS) do
            if stem.selected then anySelected = true; break end
        end
        if anySelected then
            saveSettings()
            GUI.result = true
        end
    elseif char == 49 then STEMS[1].selected = not STEMS[1].selected  -- 1: Vocals
    elseif char == 50 then STEMS[2].selected = not STEMS[2].selected  -- 2: Drums
    elseif char == 51 then STEMS[3].selected = not STEMS[3].selected  -- 3: Bass
    elseif char == 52 then STEMS[4].selected = not STEMS[4].selected  -- 4: Other
    elseif char == 53 and SETTINGS.model == "htdemucs_6s" then STEMS[5].selected = not STEMS[5].selected  -- 5: Guitar (6-stem only)
    elseif char == 54 and SETTINGS.model == "htdemucs_6s" then STEMS[6].selected = not STEMS[6].selected  -- 6: Piano (6-stem only)
    elseif char == 107 or char == 75 then applyPresetKaraoke()  -- K
    elseif char == 105 or char == 73 then applyPresetInstrumental()  -- I
    elseif char == 100 or char == 68 then applyPresetDrumsOnly()  -- D
    elseif char == 118 or char == 86 then applyPresetVocalsOnly()  -- V
    elseif char == 97 or char == 65 then applyPresetAll()  -- A
    elseif char == 43 or char == 61 then  -- + or = to grow window
        local newW = math.min(GUI.maxW, gfx.w + 76)
        local newH = math.min(GUI.maxH, gfx.h + 68)
        gfx.init(SCRIPT_NAME, newW, newH)
    elseif char == 45 then  -- - to shrink window
        local newW = math.max(GUI.minW, gfx.w - 76)
        local newH = math.max(GUI.minH, gfx.h - 68)
        gfx.init(SCRIPT_NAME, newW, newH)
    end

    gfx.update()

    if GUI.result == nil and char ~= -1 then
        reaper.defer(dialogLoop)
    else
        gfx.quit()
        if GUI.result then
            reaper.defer(runSeparationWorkflow)
        end
    end
end

-- Show stem selection dialog
local function showStemSelectionDialog()
    loadSettings()
    GUI.result = nil
    GUI.wasMouseDown = false

    local screenW, screenH = 1920, 1080
    if reaper.JS_Window_GetClientRect then
        local hwnd = reaper.GetMainHwnd()
        if hwnd then
            local _, left, top, right, bottom = reaper.JS_Window_GetClientRect(hwnd)
            screenW = right - left
            screenH = bottom - top
        end
    end

    -- Use saved size if available, otherwise use default
    local dialogW = GUI.savedW or GUI.baseW
    local dialogH = GUI.savedH or GUI.baseH
    -- Clamp to min/max
    dialogW = math.max(GUI.minW, math.min(GUI.maxW, dialogW))
    dialogH = math.max(GUI.minH, math.min(GUI.maxH, dialogH))

    local mouseX, mouseY = reaper.GetMousePosition()
    local posX = math.max(50, math.min(mouseX - dialogW / 2, screenW - dialogW - 50))
    local posY = math.max(50, math.min(mouseY - 20, screenH - dialogH - 50))

    gfx.init(SCRIPT_NAME, dialogW, dialogH, 0, posX, posY)

    -- Make window resizable (requires js_ReaScriptAPI extension)
    makeWindowResizable()

    gfx.setfont(1, "Arial", S(13))
    dialogLoop()
end

-- Get temp directory (cross-platform)
local function getTempDir()
    if OS == "Windows" then
        return os.getenv("TEMP") or os.getenv("TMP") or "C:\\Temp"
    else
        return os.getenv("TMPDIR") or "/tmp"
    end
end

-- Create directory (cross-platform)
local function makeDir(path)
    if OS == "Windows" then
        os.execute('mkdir "' .. path .. '" 2>nul')
    else
        os.execute('mkdir -p "' .. path .. '"')
    end
end

-- Suppress stderr (cross-platform)
local function suppressStderr()
    return OS == "Windows" and " 2>nul" or " 2>/dev/null"
end

-- Render selected item to a temporary WAV file
local function renderItemToWav(item, outputPath)
    local take = reaper.GetActiveTake(item)
    if not take then return nil, "No active take" end

    local source = reaper.GetMediaItemTake_Source(take)
    if not source then return nil, "No source" end

    local sourceFile = reaper.GetMediaSourceFileName(source, "")
    if not sourceFile or sourceFile == "" then return nil, "No source file" end

    local itemLen = reaper.GetMediaItemInfo_Value(item, "D_LENGTH")
    local takeOffset = reaper.GetMediaItemTakeInfo_Value(take, "D_STARTOFFS")
    local playrate = reaper.GetMediaItemTakeInfo_Value(take, "D_PLAYRATE")
    local duration = itemLen * playrate

    local ffmpegCmd = string.format(
        'ffmpeg -y -i "%s" -ss %.6f -t %.6f -ar 44100 -ac 2 "%s"' .. suppressStderr(),
        sourceFile, takeOffset, duration, outputPath
    )

    os.execute(ffmpegCmd)

    local f = io.open(outputPath, "r")
    if f then f:close(); return outputPath
    else return nil, "Failed to extract audio" end
end

-- Render time selection to a temporary WAV file
local function renderTimeSelectionToWav(outputPath)
    local startTime, endTime = reaper.GetSet_LoopTimeRange(false, false, 0, 0, false)
    if startTime >= endTime then return nil, "No time selection" end

    -- Use REAPER's render to bounce time selection
    -- We need to render whatever audio is in the time selection

    -- Save current render settings
    local projPath = reaper.GetProjectPath("")

    -- Create render settings for time selection
    local renderCfg = {
        ["RENDER_FILE"] = outputPath:match("(.+)[/\\]"),
        ["RENDER_PATTERN"] = outputPath:match("[/\\]([^/\\]+)$"):gsub("%.wav$", ""),
        ["RENDER_FMT"] = "WAV",
        ["RENDER_SRATE"] = 44100,
        ["RENDER_CHANNELS"] = 2,
        ["RENDER_STARTPOS"] = 0,  -- time selection
        ["RENDER_ENDPOS"] = 0,
        ["RENDER_TAILFLAG"] = 0,
        ["RENDER_TAILMS"] = 0,
        ["RENDER_ADDTOPROJ"] = 0,
        ["RENDER_DITHER"] = 0,
    }

    -- Use command line render via REAPER action
    -- First, set time selection as render bounds
    reaper.GetSet_LoopTimeRange(true, false, startTime, endTime, false)

    -- Create a simple render script using ffmpeg to mix down
    -- This is more reliable than REAPER's render API

    -- Get all tracks and their audio
    local numTracks = reaper.CountTracks(0)
    if numTracks == 0 then return nil, "No tracks in project" end

    -- Use REAPER's built-in render (action 42230 = Render project to file)
    -- But we need a simpler approach - just bounce via selected tracks

    -- Alternative: Use SWS BR_RenderProject or simpler approach
    -- For now, use glue-based approach: select items in time range, glue, export

    -- Simpler approach: Find items overlapping time selection and use first one
    local foundItem = nil
    local foundTrack = nil
    for t = 0, numTracks - 1 do
        local track = reaper.GetTrack(0, t)
        local numItems = reaper.CountTrackMediaItems(track)
        for i = 0, numItems - 1 do
            local item = reaper.GetTrackMediaItem(track, i)
            local iPos = reaper.GetMediaItemInfo_Value(item, "D_POSITION")
            local iLen = reaper.GetMediaItemInfo_Value(item, "D_LENGTH")
            local iEnd = iPos + iLen
            -- Check if item overlaps time selection
            if iPos < endTime and iEnd > startTime then
                foundItem = item
                foundTrack = track
                break
            end
        end
        if foundItem then break end
    end

    if not foundItem then return nil, "No audio items in time selection" end

    -- Get the source and extract just the time selection portion
    local take = reaper.GetActiveTake(foundItem)
    if not take then return nil, "No active take" end

    local source = reaper.GetMediaItemTake_Source(take)
    if not source then return nil, "No source" end

    local sourceFile = reaper.GetMediaSourceFileName(source, "")
    if not sourceFile or sourceFile == "" then return nil, "No source file" end

    -- Calculate offsets relative to the item
    local itemPos = reaper.GetMediaItemInfo_Value(foundItem, "D_POSITION")
    local takeOffset = reaper.GetMediaItemTakeInfo_Value(take, "D_STARTOFFS")
    local playrate = reaper.GetMediaItemTakeInfo_Value(take, "D_PLAYRATE")

    -- Calculate the portion of the source file to extract
    local selStartInItem = math.max(0, startTime - itemPos)
    local selEndInItem = math.min(endTime - itemPos, reaper.GetMediaItemInfo_Value(foundItem, "D_LENGTH"))
    local duration = (selEndInItem - selStartInItem) * playrate

    -- Source offset = take offset + selection start relative to item
    local sourceOffset = takeOffset + (selStartInItem * playrate)

    local ffmpegCmd = string.format(
        'ffmpeg -y -i "%s" -ss %.6f -t %.6f -ar 44100 -ac 2 "%s"' .. suppressStderr(),
        sourceFile, sourceOffset, duration, outputPath
    )

    os.execute(ffmpegCmd)

    local f = io.open(outputPath, "r")
    if f then f:close(); return outputPath, nil, foundItem  -- Return the found item too
    else return nil, "Failed to extract audio from time selection", nil end
end

-- Check if there's a valid time selection
local function hasTimeSelection()
    local startTime, endTime = reaper.GetSet_LoopTimeRange(false, false, 0, 0, false)
    return endTime > startTime
end

-- Run AI separation
local function runSeparation(inputFile, outputDir, model)
    local cmd = string.format(
        '"%s" -u "%s" "%s" "%s" --model %s' .. suppressStderr(),
        PYTHON_PATH, SEPARATOR_SCRIPT, inputFile, outputDir, model
    )

    local handle = io.popen(cmd)
    if not handle then return nil, "Failed to start separation" end
    handle:read("*a")
    handle:close()

    local stems = {}
    for _, stem in ipairs(STEMS) do
        if stem.selected then
            local stemPath = outputDir .. PATH_SEP .. stem.file
            local f = io.open(stemPath, "r")
            if f then f:close(); stems[stem.name:lower()] = stemPath end
        end
    end

    if next(stems) == nil then return nil, "No stems created" end
    return stems
end

-- Replace only a portion of an item with stems (for time selection mode)
-- Splits the item at selection boundaries and replaces only the selected portion
local function replaceInPlacePartial(item, stemPaths, selStart, selEnd)
    local track = reaper.GetMediaItem_Track(item)
    local origItemPos = reaper.GetMediaItemInfo_Value(item, "D_POSITION")
    local origItemEnd = origItemPos + reaper.GetMediaItemInfo_Value(item, "D_LENGTH")

    reaper.Undo_BeginBlock()

    -- We need to split the item at selection boundaries
    -- First, deselect all items and select only our target item
    reaper.SelectAllMediaItems(0, false)
    reaper.SetMediaItemSelected(item, true)

    local leftItem = nil   -- Part before selection (if any)
    local middleItem = item -- Part to replace
    local rightItem = nil  -- Part after selection (if any)

    -- Split at selection start if it's inside the item
    if selStart > origItemPos and selStart < origItemEnd then
        middleItem = reaper.SplitMediaItem(item, selStart)
        leftItem = item
        if middleItem then
            reaper.SetMediaItemSelected(leftItem, false)
            reaper.SetMediaItemSelected(middleItem, true)
        else
            -- Split failed, middle is still the original item
            middleItem = item
            leftItem = nil
        end
    end

    -- Split at selection end if it's inside what remains
    if middleItem then
        local midPos = reaper.GetMediaItemInfo_Value(middleItem, "D_POSITION")
        local midEnd = midPos + reaper.GetMediaItemInfo_Value(middleItem, "D_LENGTH")

        if selEnd > midPos and selEnd < midEnd then
            rightItem = reaper.SplitMediaItem(middleItem, selEnd)
            if rightItem then
                reaper.SetMediaItemSelected(rightItem, false)
            end
        end
    end

    -- Now delete the middle item and insert stems in its place
    local selLen = selEnd - selStart
    if middleItem then
        reaper.DeleteTrackMediaItem(track, middleItem)
    end

    -- Create stem items at the selection position
    local items = {}
    for _, stem in ipairs(STEMS) do
        if stem.selected then
            local stemPath = stemPaths[stem.name:lower()]
            if stemPath then
                local newItem = reaper.AddMediaItemToTrack(track)
                reaper.SetMediaItemInfo_Value(newItem, "D_POSITION", selStart)
                reaper.SetMediaItemInfo_Value(newItem, "D_LENGTH", selLen)

                local take = reaper.AddTakeToMediaItem(newItem)
                local source = reaper.PCM_Source_CreateFromFile(stemPath)
                reaper.SetMediaItemTake_Source(take, source)
                reaper.GetSetMediaItemTakeInfo_String(take, "P_NAME", stem.name, true)
                reaper.SetMediaItemInfo_Value(newItem, "I_CUSTOMCOLOR", rgbToReaperColor(stem.color[1], stem.color[2], stem.color[3]))

                items[#items + 1] = newItem
            end
        end
    end

    -- Merge into takes
    if #items > 1 then
        local mainItem = items[1]
        for i = 2, #items do
            local srcTake = reaper.GetActiveTake(items[i])
            if srcTake then
                local newTake = reaper.AddTakeToMediaItem(mainItem)
                reaper.SetMediaItemTake_Source(newTake, reaper.GetMediaItemTake_Source(srcTake))
                local _, name = reaper.GetSetMediaItemTakeInfo_String(srcTake, "P_NAME", "", false)
                reaper.GetSetMediaItemTakeInfo_String(newTake, "P_NAME", name, true)
            end
            reaper.DeleteTrackMediaItem(track, items[i])
        end
    end

    reaper.Undo_EndBlock("Stemperator: Replace selection in-place", -1)
    return #items
end

-- Replace item in-place with stems as takes
local function replaceInPlace(item, stemPaths, itemPos, itemLen)
    local track = reaper.GetMediaItem_Track(item)
    reaper.Undo_BeginBlock()
    reaper.DeleteTrackMediaItem(track, item)

    local items = {}
    for _, stem in ipairs(STEMS) do
        if stem.selected then
            local stemPath = stemPaths[stem.name:lower()]
            if stemPath then
                local newItem = reaper.AddMediaItemToTrack(track)
                reaper.SetMediaItemInfo_Value(newItem, "D_POSITION", itemPos)
                reaper.SetMediaItemInfo_Value(newItem, "D_LENGTH", itemLen)

                local take = reaper.AddTakeToMediaItem(newItem)
                local source = reaper.PCM_Source_CreateFromFile(stemPath)
                reaper.SetMediaItemTake_Source(take, source)
                reaper.GetSetMediaItemTakeInfo_String(take, "P_NAME", stem.name, true)
                reaper.SetMediaItemInfo_Value(newItem, "I_CUSTOMCOLOR", rgbToReaperColor(stem.color[1], stem.color[2], stem.color[3]))

                items[#items + 1] = newItem
            end
        end
    end

    -- Merge into takes
    if #items > 1 then
        local mainItem = items[1]
        for i = 2, #items do
            local srcTake = reaper.GetActiveTake(items[i])
            if srcTake then
                local newTake = reaper.AddTakeToMediaItem(mainItem)
                reaper.SetMediaItemTake_Source(newTake, reaper.GetMediaItemTake_Source(srcTake))
                local _, name = reaper.GetSetMediaItemTakeInfo_String(srcTake, "P_NAME", "", false)
                reaper.GetSetMediaItemTakeInfo_String(newTake, "P_NAME", name, true)
            end
            reaper.DeleteTrackMediaItem(track, items[i])
        end
    end

    reaper.Undo_EndBlock("Stemperator: Replace in-place", -1)
    return #items
end

-- Create new tracks for each selected stem
local function createStemTracks(item, stemPaths, itemPos, itemLen)
    local track = reaper.GetMediaItem_Track(item)
    local trackIdx = math.floor(reaper.GetMediaTrackInfo_Value(track, "IP_TRACKNUMBER"))
    local _, trackName = reaper.GetSetMediaTrackInfo_String(track, "P_NAME", "", false)
    if trackName == "" then trackName = "Item" end

    local take = reaper.GetActiveTake(item)
    local sourceName = trackName
    if take then
        local _, takeName = reaper.GetSetMediaItemTakeInfo_String(take, "P_NAME", "", false)
        if takeName and takeName ~= "" then
            sourceName = takeName:match("([^/\\]+)%.[^.]*$") or takeName
        end
    end

    reaper.Undo_BeginBlock()

    local selectedCount = 0
    for _, stem in ipairs(STEMS) do
        if stem.selected and stemPaths[stem.name:lower()] then selectedCount = selectedCount + 1 end
    end

    local folderTrack = nil
    if selectedCount > 1 and SETTINGS.createFolder then
        reaper.InsertTrackAtIndex(trackIdx, true)
        folderTrack = reaper.GetTrack(0, trackIdx)
        reaper.GetSetMediaTrackInfo_String(folderTrack, "P_NAME", sourceName .. " - Stems", true)
        reaper.SetMediaTrackInfo_Value(folderTrack, "I_FOLDERDEPTH", 1)
        reaper.SetMediaTrackInfo_Value(folderTrack, "I_CUSTOMCOLOR", rgbToReaperColor(180, 140, 200))
        trackIdx = trackIdx + 1
    end

    local importedCount = 0
    for _, stem in ipairs(STEMS) do
        if stem.selected then
            local stemPath = stemPaths[stem.name:lower()]
            if stemPath then
                reaper.InsertTrackAtIndex(trackIdx + importedCount, true)
                local newTrack = reaper.GetTrack(0, trackIdx + importedCount)

                local newTrackName = selectedCount == 1 and (stem.name .. " - " .. sourceName) or (sourceName .. " - " .. stem.name)
                reaper.GetSetMediaTrackInfo_String(newTrack, "P_NAME", newTrackName, true)

                local color = rgbToReaperColor(stem.color[1], stem.color[2], stem.color[3])
                reaper.SetMediaTrackInfo_Value(newTrack, "I_CUSTOMCOLOR", color)

                local newItem = reaper.AddMediaItemToTrack(newTrack)
                reaper.SetMediaItemInfo_Value(newItem, "D_POSITION", itemPos)
                reaper.SetMediaItemInfo_Value(newItem, "D_LENGTH", itemLen)

                local newTake = reaper.AddTakeToMediaItem(newItem)
                reaper.SetMediaItemTake_Source(newTake, reaper.PCM_Source_CreateFromFile(stemPath))
                reaper.GetSetMediaItemTakeInfo_String(newTake, "P_NAME", stem.name, true)
                reaper.SetMediaItemInfo_Value(newItem, "I_CUSTOMCOLOR", color)

                importedCount = importedCount + 1
            end
        end
    end

    if folderTrack and importedCount > 0 then
        reaper.SetMediaTrackInfo_Value(reaper.GetTrack(0, trackIdx + importedCount - 1), "I_FOLDERDEPTH", -1)
    end

    if SETTINGS.deleteOriginalTrack then
        reaper.DeleteTrack(track)
    elseif SETTINGS.deleteOriginal then
        reaper.DeleteTrackMediaItem(track, item)
    else
        reaper.SetMediaItemInfo_Value(item, "B_MUTE", 1)
    end

    reaper.Undo_EndBlock("Stemperator: Create stem tracks", -1)
    return importedCount
end

-- Store item reference for async workflow
local selectedItem = nil
local itemPos = 0
local itemLen = 0
local timeSelectionMode = false  -- true when processing time selection instead of item
local timeSelectionStart = 0
local timeSelectionEnd = 0
local timeSelectionSourceItem = nil  -- The item found in time selection (for in-place replacement)

-- Create new tracks for stems from time selection (no original item)
local function createStemTracksForSelection(stemPaths, selPos, selLen)
    reaper.Undo_BeginBlock()

    -- Get the first selected track as reference, or track 0
    local refTrack = reaper.GetSelectedTrack(0, 0) or reaper.GetTrack(0, 0)
    local trackIdx = 0
    if refTrack then
        trackIdx = math.floor(reaper.GetMediaTrackInfo_Value(refTrack, "IP_TRACKNUMBER"))
    end

    local selectedCount = 0
    for _, stem in ipairs(STEMS) do
        if stem.selected and stemPaths[stem.name:lower()] then selectedCount = selectedCount + 1 end
    end

    local folderTrack = nil
    local sourceName = "Selection"
    if selectedCount > 1 and SETTINGS.createFolder then
        reaper.InsertTrackAtIndex(trackIdx, true)
        folderTrack = reaper.GetTrack(0, trackIdx)
        reaper.GetSetMediaTrackInfo_String(folderTrack, "P_NAME", sourceName .. " - Stems", true)
        reaper.SetMediaTrackInfo_Value(folderTrack, "I_FOLDERDEPTH", 1)
        reaper.SetMediaTrackInfo_Value(folderTrack, "I_CUSTOMCOLOR", rgbToReaperColor(180, 140, 200))
        trackIdx = trackIdx + 1
    end

    local importedCount = 0
    for _, stem in ipairs(STEMS) do
        if stem.selected then
            local stemPath = stemPaths[stem.name:lower()]
            if stemPath then
                reaper.InsertTrackAtIndex(trackIdx + importedCount, true)
                local newTrack = reaper.GetTrack(0, trackIdx + importedCount)

                local newTrackName = selectedCount == 1 and (stem.name .. " - " .. sourceName) or (sourceName .. " - " .. stem.name)
                reaper.GetSetMediaTrackInfo_String(newTrack, "P_NAME", newTrackName, true)

                local color = rgbToReaperColor(stem.color[1], stem.color[2], stem.color[3])
                reaper.SetMediaTrackInfo_Value(newTrack, "I_CUSTOMCOLOR", color)

                local newItem = reaper.AddMediaItemToTrack(newTrack)
                reaper.SetMediaItemInfo_Value(newItem, "D_POSITION", selPos)
                reaper.SetMediaItemInfo_Value(newItem, "D_LENGTH", selLen)

                local newTake = reaper.AddTakeToMediaItem(newItem)
                reaper.SetMediaItemTake_Source(newTake, reaper.PCM_Source_CreateFromFile(stemPath))
                reaper.GetSetMediaItemTakeInfo_String(newTake, "P_NAME", stem.name, true)
                reaper.SetMediaItemInfo_Value(newItem, "I_CUSTOMCOLOR", color)

                importedCount = importedCount + 1
            end
        end
    end

    if folderTrack and importedCount > 0 then
        reaper.SetMediaTrackInfo_Value(reaper.GetTrack(0, trackIdx + importedCount - 1), "I_FOLDERDEPTH", -1)
    end

    reaper.Undo_EndBlock("Stemperator: Create stem tracks from selection", -1)
    return importedCount
end

-- Separation workflow
function runSeparationWorkflow()
    -- Validate we have something to process
    if not timeSelectionMode and not selectedItem then return end

    local tempDir = getTempDir() .. PATH_SEP .. "stemperator_" .. os.time()
    makeDir(tempDir)
    local tempInput = tempDir .. PATH_SEP .. "input.wav"

    local extracted, err, sourceItem
    if timeSelectionMode then
        extracted, err, sourceItem = renderTimeSelectionToWav(tempInput)
        timeSelectionSourceItem = sourceItem  -- Store for later use
    else
        extracted, err = renderItemToWav(selectedItem, tempInput)
    end

    if not extracted then
        reaper.MB("Failed to extract audio:\n\n" .. (err or "Unknown"), SCRIPT_NAME, 0)
        return
    end

    reaper.ShowMessageBox(
        "AI stem separation starting...\n\n" ..
        "Model: " .. SETTINGS.model .. "\n" ..
        "This may take 10-60 seconds.\n\n" ..
        "Click OK to proceed.",
        SCRIPT_NAME, 0)

    local stems, sepErr = runSeparation(tempInput, tempDir, SETTINGS.model)
    if not stems then
        reaper.MB("Separation failed:\n\n" .. (sepErr or "Unknown"), SCRIPT_NAME, 0)
        return
    end

    local count
    local resultMsg

    if timeSelectionMode then
        -- Time selection mode: respect user's setting
        if SETTINGS.createNewTracks then
            count = createStemTracksForSelection(stems, itemPos, itemLen)
            resultMsg = count .. " stem track(s) created from time selection."
        else
            -- In-place mode: replace only the selected portion of the item
            if timeSelectionSourceItem then
                -- Use partial replacement - splits the item and replaces only the selected part
                count = replaceInPlacePartial(timeSelectionSourceItem, stems, timeSelectionStart, timeSelectionEnd)
                resultMsg = count == 1 and "Selection replaced with stem." or "Selection replaced with stems as takes (press T to switch)."
            else
                -- Fallback: create new tracks if no source item
                count = createStemTracksForSelection(stems, itemPos, itemLen)
                resultMsg = count .. " stem track(s) created from time selection."
            end
        end
    elseif SETTINGS.createNewTracks then
        count = createStemTracks(selectedItem, stems, itemPos, itemLen)
        local action = SETTINGS.deleteOriginalTrack and "Track deleted." or
                       (SETTINGS.deleteOriginal and "Item deleted." or "Item muted.")
        resultMsg = count .. " stem track(s) created.\n" .. action
    else
        count = replaceInPlace(selectedItem, stems, itemPos, itemLen)
        resultMsg = count == 1 and "Stem replaced." or "Stems added as takes (press T to switch)."
    end

    local selectedNames = {}
    for _, stem in ipairs(STEMS) do
        if stem.selected then selectedNames[#selectedNames + 1] = stem.name end
    end

    reaper.MB("Separation complete!\n\nExtracted: " .. table.concat(selectedNames, ", ") .. "\n\n" .. resultMsg, SCRIPT_NAME, 0)
    reaper.UpdateArrange()
end

-- Check for quick preset mode (called from toolbar scripts)
local function checkQuickPreset()
    local quickRun = reaper.GetExtState(EXT_SECTION, "quick_run")
    if quickRun == "1" then
        -- Clear the flag
        reaper.DeleteExtState(EXT_SECTION, "quick_run", false)

        -- Apply preset based on quick_preset
        local preset = reaper.GetExtState(EXT_SECTION, "quick_preset")
        reaper.DeleteExtState(EXT_SECTION, "quick_preset", false)

        if preset == "karaoke" or preset == "instrumental" then
            applyPresetKaraoke()
        elseif preset == "vocals" then
            applyPresetVocalsOnly()
        elseif preset == "drums" then
            applyPresetDrumsOnly()
        elseif preset == "bass" then
            STEMS[1].selected = false
            STEMS[2].selected = false
            STEMS[3].selected = true
            STEMS[4].selected = false
        elseif preset == "all" then
            applyPresetAll()
        end

        return true  -- Quick mode, skip dialog
    end
    return false
end

-- Main
local function main()
    selectedItem = reaper.GetSelectedMediaItem(0, 0)
    timeSelectionMode = false

    if not selectedItem then
        -- No item selected - check for time selection
        if hasTimeSelection() then
            timeSelectionMode = true
            timeSelectionStart, timeSelectionEnd = reaper.GetSet_LoopTimeRange(false, false, 0, 0, false)
            itemPos = timeSelectionStart
            itemLen = timeSelectionEnd - timeSelectionStart
        else
            reaper.MB("Please select a media item or make a time selection to separate.", SCRIPT_NAME, 0)
            return
        end
    else
        itemPos = reaper.GetMediaItemInfo_Value(selectedItem, "D_POSITION")
        itemLen = reaper.GetMediaItemInfo_Value(selectedItem, "D_LENGTH")
    end

    -- Load settings first
    loadSettings()

    -- Check for quick preset mode (from toolbar scripts)
    if checkQuickPreset() then
        -- Quick mode: run immediately without dialog
        saveSettings()
        reaper.defer(runSeparationWorkflow)
    else
        -- Normal mode: show dialog
        showStemSelectionDialog()
    end
end

main()
